#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
模型预加载管理器
统一管理所有模块的模型预加载，优化系统启动和运行速率
"""

import logging
import threading
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
import time

@dataclass
class PreloadStatus:
    """预加载状态"""
    module_name: str
    status: str  # 'pending', 'loading', 'loaded', 'failed'
    load_time: float = 0.0
    error: Optional[str] = None


class ModelPreloader:
    """
    模型预加载管理器
    统一管理CV、STT、ComfyUI、Agent等模块的模型预加载
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化模型预加载管理器
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
        """
        self.logger = logging.getLogger(__name__)
        
        # 加载配置
        if config is None:
            try:
                from utils.path_utils import get_config_loader
                config_loader = get_config_loader()
                # 尝试读取预加载配置
                try:
                    import yaml
                    from pathlib import Path
                    preload_config_path = Path(__file__).parent.parent / 'config' / 'preload_config.yaml'
                    if preload_config_path.exists():
                        with open(preload_config_path, 'r', encoding='utf-8') as f:
                            config = yaml.safe_load(f) or {}
                    else:
                        config = {}
                except Exception:
                    config = {}
            except Exception:
                config = {}
        
        self.config = config or {}
        
        # 预加载状态
        self.preload_status: Dict[str, PreloadStatus] = {}
        
        # 预加载配置
        self.preload_config = self.config.get('preload', {})
        self.enable_preload = self.preload_config.get('enable', True)
        self.parallel_load = self.preload_config.get('parallel', True)
        
        # 已加载的模块实例（缓存）
        self.loaded_modules: Dict[str, Any] = {}
        
    def preload_all(self) -> Dict[str, PreloadStatus]:
        """
        预加载所有模块的模型
        
        Returns:
            Dict[str, PreloadStatus]: 预加载状态字典
        """
        if not self.enable_preload:
            self.logger.info("模型预加载已禁用")
            return {}
        
        self.logger.info("开始预加载所有模型...")
        start_time = time.time()
        
        if self.parallel_load:
            # 并行加载
            self._preload_parallel()
        else:
            # 串行加载
            self._preload_sequential()
        
        total_time = time.time() - start_time
        self.logger.info(f"模型预加载完成，总耗时: {total_time:.2f}秒")
        
        return self.preload_status
    
    def _preload_parallel(self):
        """并行预加载所有模型"""
        threads = []
        
        # CV模块
        if self.preload_config.get('cv', True):
            thread = threading.Thread(target=self._preload_cv, daemon=True)
            thread.start()
            threads.append(('cv', thread))
        
        # STT模块
        if self.preload_config.get('stt', True):
            thread = threading.Thread(target=self._preload_stt, daemon=True)
            thread.start()
            threads.append(('stt', thread))
        
        # ComfyUI模块
        if self.preload_config.get('comfyui', True):
            thread = threading.Thread(target=self._preload_comfyui, daemon=True)
            thread.start()
            threads.append(('comfyui', thread))
        
        # Agent模块
        if self.preload_config.get('agent', True):
            thread = threading.Thread(target=self._preload_agent, daemon=True)
            thread.start()
            threads.append(('agent', thread))
        
        # 等待所有线程完成
        for name, thread in threads:
            thread.join(timeout=300)  # 最多等待5分钟
            if thread.is_alive():
                self.logger.warning(f"{name}模块预加载超时")
                if name in self.preload_status:
                    self.preload_status[name].status = 'failed'
                    self.preload_status[name].error = "预加载超时"
    
    def _preload_sequential(self):
        """串行预加载所有模型"""
        if self.preload_config.get('cv', True):
            self._preload_cv()
        
        if self.preload_config.get('stt', True):
            self._preload_stt()
        
        if self.preload_config.get('comfyui', True):
            self._preload_comfyui()
        
        if self.preload_config.get('agent', True):
            self._preload_agent()
    
    def _preload_cv(self):
        """预加载CV模块模型"""
        module_name = 'cv'
        self.preload_status[module_name] = PreloadStatus(module_name, 'loading')
        start_time = time.time()
        
        try:
            from parts.cv.cv_controller import CVController
            from utils.path_utils import get_config_loader
            
            config_loader = get_config_loader()
            cv_config = config_loader.get_cv_config()
            
            cv_controller = CVController(config=cv_config)
            if cv_controller.initialize_models():
                self.loaded_modules['cv'] = cv_controller
                load_time = time.time() - start_time
                self.preload_status[module_name] = PreloadStatus(
                    module_name, 'loaded', load_time
                )
                self.logger.info(f"✅ CV模块预加载成功，耗时: {load_time:.2f}秒")
            else:
                raise RuntimeError("CV模型初始化失败")
        except Exception as e:
            load_time = time.time() - start_time
            self.preload_status[module_name] = PreloadStatus(
                module_name, 'failed', load_time, str(e)
            )
            self.logger.error(f"❌ CV模块预加载失败: {e}")
    
    def _preload_stt(self):
        """预加载STT模块模型"""
        module_name = 'stt'
        self.preload_status[module_name] = PreloadStatus(module_name, 'loading')
        start_time = time.time()
        
        try:
            from parts.stt.stt_controller import STTController
            from utils.path_utils import get_config_loader
            
            config_loader = get_config_loader()
            stt_config = config_loader.get_stt_config()
            
            # STT模块在初始化时就会加载VAD和ASR模型
            stt_controller = STTController(config=stt_config)
            self.loaded_modules['stt'] = stt_controller
            
            load_time = time.time() - start_time
            self.preload_status[module_name] = PreloadStatus(
                module_name, 'loaded', load_time
            )
            self.logger.info(f"✅ STT模块预加载成功，耗时: {load_time:.2f}秒")
        except Exception as e:
            load_time = time.time() - start_time
            self.preload_status[module_name] = PreloadStatus(
                module_name, 'failed', load_time, str(e)
            )
            self.logger.error(f"❌ STT模块预加载失败: {e}")
    
    def _preload_comfyui(self):
        """预加载ComfyUI模块"""
        module_name = 'comfyui'
        self.preload_status[module_name] = PreloadStatus(module_name, 'loading')
        start_time = time.time()
        
        try:
            from adapter.comfyui.comfyui_controller import ComfyUIController
            from utils.path_utils import get_config_loader
            
            config_loader = get_config_loader()
            comfyui_config = config_loader.get_comfyui_config()
            
            comfyui_controller = ComfyUIController(config=comfyui_config)
            
            # 预加载工作流
            workflow_config = comfyui_config.get('workflow', {})
            workflow_path = (
                workflow_config.get('default_workflow_path')
                or workflow_config.get('default_path')
                or workflow_config.get('path')
            )
            workflow_loaded = False
            if workflow_path:
                workflow_loaded = comfyui_controller.load_workflow(workflow_path)
                if workflow_loaded:
                    self.logger.debug("ComfyUI工作流已加载: %s", workflow_path)
                else:
                    self.logger.warning(
                        "ComfyUI工作流加载失败: %s，后续将跳过模型预热阶段",
                        workflow_path
                    )
            
            # 预加载模型（通过发送一个最小化的prompt来触发模型加载）
            preload_config = comfyui_config.get('performance', {}).get('preload_models', False)
            if (
                preload_config
                and workflow_loaded
                and hasattr(comfyui_controller, 'cloud_api')
                and comfyui_controller.cloud_api
                and comfyui_controller.cloud_api.get_workflow_id()
            ):
                if hasattr(comfyui_controller.cloud_api, 'preload_models'):
                    try:
                        comfyui_controller.cloud_api.preload_models()
                        self.logger.debug("ComfyUI模型预加载已触发")
                    except Exception as e:
                        self.logger.warning(f"ComfyUI模型预加载触发失败: {e}，将在首次执行时自动加载")
            
            self.loaded_modules['comfyui'] = comfyui_controller
            
            load_time = time.time() - start_time
            self.preload_status[module_name] = PreloadStatus(
                module_name, 'loaded', load_time
            )
            self.logger.info(f"✅ ComfyUI模块预加载成功，耗时: {load_time:.2f}秒")
        except Exception as e:
            load_time = time.time() - start_time
            self.preload_status[module_name] = PreloadStatus(
                module_name, 'failed', load_time, str(e)
            )
            self.logger.error(f"❌ ComfyUI模块预加载失败: {e}")
    
    def _preload_agent(self):
        """预加载Agent模块（LLM）"""
        module_name = 'agent'
        self.preload_status[module_name] = PreloadStatus(module_name, 'loading')
        start_time = time.time()
        
        try:
            from controller.agent_manager import AgentManager
            
            # AgentManager在初始化时会加载LLM
            agent_manager = AgentManager(config={})
            self.loaded_modules['agent'] = agent_manager
            
            load_time = time.time() - start_time
            self.preload_status[module_name] = PreloadStatus(
                module_name, 'loaded', load_time
            )
            self.logger.info(f"✅ Agent模块预加载成功，耗时: {load_time:.2f}秒")
        except Exception as e:
            load_time = time.time() - start_time
            self.preload_status[module_name] = PreloadStatus(
                module_name, 'failed', load_time, str(e)
            )
            self.logger.error(f"❌ Agent模块预加载失败: {e}")
    
    def get_module(self, module_name: str) -> Optional[Any]:
        """
        获取已预加载的模块实例
        
        Args:
            module_name: 模块名称（'cv', 'stt', 'comfyui', 'agent'）
            
        Returns:
            模块实例，如果未预加载则返回None
        """
        return self.loaded_modules.get(module_name)
    
    def get_status(self) -> Dict[str, PreloadStatus]:
        """获取所有模块的预加载状态"""
        return self.preload_status.copy()
    
    def is_loaded(self, module_name: str) -> bool:
        """检查模块是否已预加载"""
        status = self.preload_status.get(module_name)
        return status is not None and status.status == 'loaded'

