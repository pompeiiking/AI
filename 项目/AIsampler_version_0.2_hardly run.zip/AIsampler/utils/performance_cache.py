#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
性能缓存管理器
提供统一的缓存机制，优化系统运行速率
"""

import time
import threading
from typing import Dict, Any, Optional, Callable
from collections import OrderedDict
from dataclasses import dataclass


@dataclass
class CacheEntry:
    """缓存条目"""
    key: str
    value: Any
    timestamp: float
    ttl: float  # 过期时间（秒）


class PerformanceCache:
    """
    性能缓存管理器
    提供LRU缓存和TTL过期机制
    """
    
    def __init__(self, max_size: int = 100, default_ttl: float = 3600.0):
        """
        初始化缓存管理器
        
        Args:
            max_size: 最大缓存条目数
            default_ttl: 默认过期时间（秒）
        """
        self.max_size = max_size
        self.default_ttl = default_ttl
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._lock = threading.RLock()
    
    def get(self, key: str) -> Optional[Any]:
        """
        获取缓存值
        
        Args:
            key: 缓存键
            
        Returns:
            缓存值，如果不存在或已过期返回None
        """
        with self._lock:
            if key not in self._cache:
                return None
            
            entry = self._cache[key]
            
            # 检查是否过期
            if time.time() - entry.timestamp > entry.ttl:
                del self._cache[key]
                return None
            
            # 移动到末尾（LRU）
            self._cache.move_to_end(key)
            return entry.value
    
    def set(self, key: str, value: Any, ttl: Optional[float] = None):
        """
        设置缓存值
        
        Args:
            key: 缓存键
            value: 缓存值
            ttl: 过期时间（秒），如果为None使用默认值
        """
        with self._lock:
            # 如果已存在，先删除
            if key in self._cache:
                del self._cache[key]
            
            # 如果缓存已满，删除最旧的条目
            if len(self._cache) >= self.max_size:
                self._cache.popitem(last=False)
            
            # 添加新条目
            entry = CacheEntry(
                key=key,
                value=value,
                timestamp=time.time(),
                ttl=ttl or self.default_ttl
            )
            self._cache[key] = entry
    
    def delete(self, key: str):
        """删除缓存条目"""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
    
    def clear(self):
        """清空所有缓存"""
        with self._lock:
            self._cache.clear()
    
    def size(self) -> int:
        """获取缓存大小"""
        with self._lock:
            return len(self._cache)
    
    def cleanup_expired(self):
        """清理过期的缓存条目"""
        with self._lock:
            current_time = time.time()
            expired_keys = [
                key for key, entry in self._cache.items()
                if current_time - entry.timestamp > entry.ttl
            ]
            for key in expired_keys:
                del self._cache[key]
            return len(expired_keys)


class FunctionCache:
    """
    函数结果缓存装饰器
    自动缓存函数调用结果
    """
    
    def __init__(self, cache: PerformanceCache, ttl: Optional[float] = None):
        """
        初始化函数缓存
        
        Args:
            cache: 缓存管理器
            ttl: 缓存过期时间（秒）
        """
        self.cache = cache
        self.ttl = ttl
    
    def __call__(self, func: Callable):
        """装饰器实现"""
        def wrapper(*args, **kwargs):
            # 生成缓存键
            cache_key = f"{func.__name__}:{str(args)}:{str(sorted(kwargs.items()))}"
            
            # 尝试从缓存获取
            cached_value = self.cache.get(cache_key)
            if cached_value is not None:
                return cached_value
            
            # 执行函数
            result = func(*args, **kwargs)
            
            # 缓存结果
            self.cache.set(cache_key, result, ttl=self.ttl)
            
            return result
        
        return wrapper

