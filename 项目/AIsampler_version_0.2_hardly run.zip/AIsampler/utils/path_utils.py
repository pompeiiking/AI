#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
路径工具模块
统一管理项目路径配置
"""

import os
import sys
from pathlib import Path
from typing import Optional


def setup_project_path(module_file: str) -> Path:
    """
    设置项目路径
    
    Args:
        module_file: 当前模块文件的路径（使用__file__）
        
    Returns:
        Path: 项目根目录路径
    """
    # 计算项目根目录（AIsampler目录）
    current_file = Path(module_file).resolve()
    
    # 根据文件位置确定项目根目录
    if 'controller' in current_file.parts:
        # controller目录下的文件
        project_root = current_file.parent.parent
    elif 'parts' in current_file.parts:
        # parts目录下的文件
        project_root = current_file.parent.parent
    elif 'adapter' in current_file.parts:
        # adapter目录下的文件
        project_root = current_file.parent.parent
    elif 'config' in current_file.parts:
        # config目录下的文件
        project_root = current_file.parent
    else:
        # 其他情况，向上查找
        project_root = current_file.parent
    
    # 添加到sys.path（如果不存在）
    project_root_str = str(project_root)
    if project_root_str not in sys.path:
        sys.path.insert(0, project_root_str)
    
    return project_root


def get_config_path(project_root: Optional[Path] = None) -> Path:
    """
    获取配置目录路径
    
    Args:
        project_root: 项目根目录，如果为None则自动计算
        
    Returns:
        Path: 配置目录路径
    """
    if project_root is None:
        # 默认从当前工作目录计算
        project_root = Path.cwd()
        # 尝试找到AIsampler目录
        for parent in project_root.parents:
            if parent.name == 'AIsampler':
                project_root = parent
                break
    
    return project_root / 'config'


def get_config_loader():
    """
    获取配置加载器实例
    
    Returns:
        ConfigLoader: 配置加载器实例
    """
    from config.config_loader import config_loader
    return config_loader

