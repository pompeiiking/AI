#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试LangChain 1.0的新导入路径"""

import sys

print("=" * 80)
print("测试LangChain 1.0导入路径")
print("=" * 80)

# 测试各种可能的导入路径
test_imports = [
    ("langchain", ["__version__"]),
    ("langchain.agents", ["AgentExecutor", "create_structured_chat_agent"]),
    ("langchain_core.agents", ["AgentExecutor"]),
    ("langchain.agents.agent", ["AgentExecutor"]),
    ("langchain_core.runnables", ["RunnableSequence"]),
]

for module_name, items in test_imports:
    print(f"\n尝试从 '{module_name}' 导入...")
    try:
        module = __import__(module_name, fromlist=items)
        for item in items:
            if hasattr(module, item):
                print(f"  ✓ {item}")
            else:
                print(f"  ✗ {item} (不存在)")
    except ImportError as e:
        print(f"  ✗ 模块导入失败: {e}")

# 检查langchain包内容
print("\n" + "=" * 80)
print("检查 langchain.agents 可用内容")
print("=" * 80)

try:
    import langchain.agents as agents_module
    print("\n可用的类和函数:")
    for name in dir(agents_module):
        if not name.startswith('_'):
            print(f"  • {name}")
except Exception as e:
    print(f"✗ 无法导入: {e}")

# 检查版本
print("\n" + "=" * 80)
print("包版本信息")
print("=" * 80)

packages = ['langchain', 'langchain-core', 'langchain-openai', 'langgraph']
for package in packages:
    try:
        if package == 'langchain':
            import langchain
            print(f"  • {package}: {langchain.__version__}")
        elif package == 'langchain-core':
            import langchain_core
            print(f"  • {package}: {langchain_core.__version__}")
        elif package == 'langchain-openai':
            import langchain_openai
            print(f"  • {package}: {langchain_openai.__version__}")
        elif package == 'langgraph':
            import langgraph
            print(f"  • {package}: {langgraph.__version__ if hasattr(langgraph, '__version__') else 'N/A'}")
    except ImportError:
        print(f"  ✗ {package}: 未安装")
