#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
简化启动脚本 - CV + Text AI模式
不依赖STT语音识别模块

启动模式：
- ✅ CV模块（视觉输入）
- ✅ Text AI模块（文本输入 + DeepSeek分析）
- ❌ STT模块（语音识别 - 跳过）
"""

import sys
import signal
import logging
from pathlib import Path

# 项目路径设置
PROJECT_ROOT = Path(__file__).resolve().parent.parent  # 向上两级到AIsampler
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path
setup_project_path(__file__)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

print("=" * 80)
print("🚀 AIsampler系统启动 - CV + Text AI模式")
print("=" * 80)
print()
print("📋 启动模块:")
print("  ✅ CV模块（视觉输入 - 情感识别）")
print("  ✅ Text AI模块（文本输入 + DeepSeek AI分析）")
print("  ❌ STT模块（语音识别 - 已禁用）")
print()
print("=" * 80)

# 全局变量
main_controller = None
running = True

def signal_handler(sig, frame):
    """信号处理器"""
    global running, main_controller
    logger.info("\n\n收到中断信号，正在优雅关闭...")
    running = False
    if main_controller:
        main_controller.stop()
    sys.exit(0)

def main():
    """主函数"""
    global main_controller
    
    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        # 检查依赖
        print("\n【1/4】检查核心依赖")
        print("-" * 80)
        
        try:
            from parts.cv.cv_controller import CVController
            print("✓ CV模块可用")
        except ImportError as e:
            print(f"✗ CV模块不可用: {e}")
            return 1
        
        try:
            from parts.text.text_controller import TextController
            print("✓ Text模块可用")
        except ImportError as e:
            print(f"✗ Text模块不可用: {e}")
            return 1
        
        try:
            from parts.text.ai_dialogue_graph import AIDialogueGraph
            print("✓ AI对话图可用（LangGraph + DeepSeek）")
        except ImportError as e:
            print(f"⚠️ AI对话图不可用: {e}")
            print("  将使用关键词匹配模式")
        
        # 初始化MainController
        print("\n【2/4】初始化系统控制器")
        print("-" * 80)
        
        from controller.controller import MainController
        
        main_controller = MainController()
        
        # 初始化模块（跳过STT）
        if not main_controller.initialize(use_preload=False):
            logger.error("系统初始化失败")
            return 1
        
        print("✓ 系统控制器初始化成功")
        
        # 启动事件处理循环（重要！）
        if not main_controller.start():
            logger.error("❌ 启动事件处理循环失败")
            return 1
        
        print("✓ 事件处理循环已启动")
        
        # 检查模块状态
        print("\n【3/4】检查模块状态")
        print("-" * 80)
        
        # 简单检查核心模块
        cv_ok = main_controller.cv_controller is not None
        text_ok = main_controller.text_controller is not None
        stt_skip = main_controller.stt_controller is None
        
        print(f"{'✓' if cv_ok else '✗'} CV模块: {'就绪' if cv_ok else '失败'}")
        print(f"{'✓' if text_ok else '✗'} Text AI模块: {'就绪' if text_ok else '失败'}")
        print(f"⊘ STT模块: 已跳过（不需要语音识别）")
        
        # 检查CV和Text模块
        if not main_controller.cv_controller:
            logger.error("❌ CV模块未初始化，无法继续")
            return 1
        
        if not main_controller.text_controller:
            logger.error("❌ Text模块未初始化，无法继续")
            return 1
        
        print(f"\n✓ 核心模块已就绪")
        
        # 启动数据流
        print("\n【4/4】启动数据流")
        print("-" * 80)
        
        # CV流
        def cv_callback(data):
            emotion = data.get('emotion', 'N/A')
            conf = data.get('confidence', 0.0)
            logger.info(f"📷 CV: {emotion} ({conf:.2f})")
        
        main_controller.start_cv_stream(callback=cv_callback, show_window=False)
        print("✓ CV流已启动（情感识别）")
        
        # Text AI流
        def text_callback(data):
            text = data.get('text', '')
            emotion = data.get('emotion', 'N/A')
            conf = data.get('confidence', 0.0)
            ai_powered = data.get('ai_powered', False)
            mode = "🤖 AI" if ai_powered else "📝 关键词"
            logger.info(f"{mode} Text: \"{text[:30]}...\" → {emotion} ({conf:.2f})")
        
        main_controller.start_text_stream(callback=text_callback)
        print("✓ Text AI流已启动（DeepSeek分析）")
        
        # 系统就绪
        print("\n" + "=" * 80)
        print("✅ 系统启动成功！")
        print("=" * 80)
        print()
        print("💡 使用说明:")
        print("  • CV模块正在实时检测情感")
        print("  • Text模块等待文本输入")
        print("  • 直接输入文本，AI将自动分析情感")
        print("  • 按 Ctrl+C 退出系统")
        print()
        print("🧪 测试Text AI:")
        print("  在控制台输入文本，查看AI分析结果")
        print()
        print("=" * 80)
        
        # 保持运行
        try:
            while running:
                import time
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("\n收到中断信号...")
        finally:
            # 清理
            logger.info("正在关闭系统...")
            if main_controller:
                main_controller.stop()
            logger.info("系统已关闭")
        
        return 0
        
    except Exception as e:
        logger.error(f"启动失败: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
