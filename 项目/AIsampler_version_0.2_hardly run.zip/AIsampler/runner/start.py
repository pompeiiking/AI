#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
系统启动入口
统一启动入口，提供命令行接口和信号处理
"""

import argparse
import logging
import signal
import sys
import time
from pathlib import Path
from typing import Optional

# 设置项目根目录路径
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 导入启动模块
from runner.startup.manager import StartupManager
from runner.startup.logger import StartupLogger


class SystemStarter:
    """系统启动器"""
    
    def __init__(self, args: argparse.Namespace):
        """
        初始化系统启动器
        
        Args:
            args: 命令行参数
        """
        self.args = args
        self.startup_manager: Optional[StartupManager] = None
        self._shutdown_event = False
        
    def run(self) -> int:
        """
        启动系统
        
        Returns:
            int: 退出码，0表示成功
        """
        try:
            # 配置启动日志
            startup_logger = StartupLogger()
            startup_logger.configure(
                log_level=self.args.log_level,
                log_file=self.args.log_file
            )
            
            logger = logging.getLogger(__name__)
            logger.info("=" * 60)
            logger.info("多模态实时交互具身智能数字人系统启动")
            logger.info("=" * 60)
            logger.info(f"项目根目录: {PROJECT_ROOT}")
            
            # 安装信号处理器
            self._install_signal_handlers()
            
            # 创建启动管理器
            self.startup_manager = StartupManager(
                skip_preload=self.args.skip_preload,
                no_parallel_preload=self.args.no_parallel_preload,
                agent_verbose=self.args.agent_verbose,
                video_generation_interval=self.args.video_generation_interval,
                show_progress=self.args.show_progress
            )
            
            # 执行启动流程
            success = self.startup_manager.start()
            
            if not success:
                logger.error("系统启动失败")
                return 1
            
            logger.info("系统启动成功，开始运行...")
            logger.info("按 Ctrl+C 停止系统")
            
            # 等待运行
            self._wait_for_shutdown()
            
            return 0
            
        except KeyboardInterrupt:
            logging.info("收到中断信号，正在停止系统...")
            return 0
        except Exception as e:
            logging.exception(f"启动过程中发生未捕获的异常: {e}")
            return 1
        finally:
            self._cleanup()
    
    def _install_signal_handlers(self):
        """安装信号处理器"""
        def handle_signal(signum, frame):
            logging.info(f"收到信号 {signum}，准备停止系统...")
            self._shutdown_event = True
        
        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)
    
    def _wait_for_shutdown(self):
        """等待关闭信号"""
        if self.args.runtime > 0:
            logging.info(f"系统将运行 {self.args.runtime} 秒")
            start_time = time.time()
            while not self._shutdown_event:
                if time.time() - start_time >= self.args.runtime:
                    logging.info("达到预设运行时长，准备停止系统")
                    break
                time.sleep(0.5)
        else:
            # 持续运行直到收到停止信号
            while not self._shutdown_event:
                time.sleep(0.5)
    
    def _cleanup(self):
        """清理资源"""
        if self.startup_manager:
            try:
                logging.info("正在清理系统资源...")
                self.startup_manager.cleanup()
                logging.info("资源清理完成")
            except Exception as e:
                logging.exception(f"清理资源时发生异常: {e}")


def parse_args(argv: Optional[list] = None) -> argparse.Namespace:
    """
    解析命令行参数
    
    Args:
        argv: 可选的参数列表，默认为 sys.argv[1:]
        
    Returns:
        argparse.Namespace: 解析后的参数对象
    """
    parser = argparse.ArgumentParser(
        description="启动多模态实时交互具身智能数字人系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 基本启动
  python runner/start.py
  
  # 跳过预加载
  python runner/start.py --skip-preload
  
  # 设置运行时长
  python runner/start.py --runtime 300
  
  # 启用详细日志
  python runner/start.py --log-level DEBUG --show-progress
        """
    )
    
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="日志级别 (默认: INFO)"
    )
    
    parser.add_argument(
        "--log-file",
        type=str,
        default=None,
        help="日志文件路径（可选）"
    )
    
    parser.add_argument(
        "--skip-preload",
        action="store_true",
        help="跳过模型预加载"
    )
    
    parser.add_argument(
        "--no-parallel-preload",
        action="store_true",
        help="预加载时禁用并行加载"
    )
    
    parser.add_argument(
        "--runtime",
        type=int,
        default=0,
        help="系统运行时长（秒），0 表示持续运行直到手动停止"
    )
    
    parser.add_argument(
        "--agent-verbose",
        action="store_true",
        help="启用 AgentManager 的详细日志"
    )
    
    parser.add_argument(
        "--video-generation-interval",
        type=float,
        default=10.0,
        help="视频生成间隔（秒，默认: 10.0）"
    )
    
    parser.add_argument(
        "--show-progress",
        action="store_true",
        help="显示启动进度"
    )
    
    return parser.parse_args(argv)


def main(argv: Optional[list] = None) -> int:
    """
    程序入口
    
    Args:
        argv: 可选的参数列表
        
    Returns:
        int: 退出码
    """
    args = parse_args(argv)
    starter = SystemStarter(args)
    return starter.run()


if __name__ == "__main__":
    sys.exit(main())

