#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
启动状态监控模块
实时监控启动进度和模块状态
"""

import logging
import time
from typing import Dict, Optional
from enum import Enum
from dataclasses import dataclass, field


class StartupStage(Enum):
    """启动阶段枚举"""
    PRE_CHECK = "pre_check"
    CONFIG_VALIDATE = "config_validate"
    PRELOAD = "preload"
    INIT = "init"
    START = "start"
    RUNNING = "running"
    ERROR = "error"
    STOPPED = "stopped"


@dataclass
class StageStatus:
    """阶段状态"""
    stage: StartupStage
    status: str  # 'pending', 'running', 'completed', 'failed'
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    error: Optional[str] = None
    progress: float = 0.0  # 0.0 - 1.0


class StartupMonitor:
    """启动状态监控器"""
    
    def __init__(self, show_progress: bool = False):
        """
        初始化启动状态监控器
        
        Args:
            show_progress: 是否显示进度
        """
        self.logger = logging.getLogger(__name__)
        self.show_progress = show_progress
        self.stages: Dict[StartupStage, StageStatus] = {}
        self.current_stage: Optional[StartupStage] = None
        self.start_time = time.time()
        
        # 初始化所有阶段
        for stage in StartupStage:
            self.stages[stage] = StageStatus(
                stage=stage,
                status='pending'
            )
    
    def start_stage(self, stage: StartupStage):
        """
        开始一个阶段
        
        Args:
            stage: 启动阶段
        """
        self.current_stage = stage
        stage_status = self.stages[stage]
        stage_status.status = 'running'
        stage_status.start_time = time.time()
        stage_status.progress = 0.0
        
        if self.show_progress:
            self.logger.info(f"▶️  开始阶段: {self._get_stage_name(stage)}")
    
    def update_progress(self, stage: StartupStage, progress: float, message: str = ""):
        """
        更新阶段进度
        
        Args:
            stage: 启动阶段
            progress: 进度值 (0.0 - 1.0)
            message: 进度消息
        """
        stage_status = self.stages[stage]
        stage_status.progress = max(0.0, min(1.0, progress))
        
        if self.show_progress and message:
            percentage = int(stage_status.progress * 100)
            self.logger.info(f"  [{percentage:3d}%] {message}")
    
    def complete_stage(self, stage: StartupStage, success: bool = True, error: Optional[str] = None):
        """
        完成一个阶段
        
        Args:
            stage: 启动阶段
            success: 是否成功
            error: 错误信息（如果有）
        """
        stage_status = self.stages[stage]
        stage_status.end_time = time.time()
        stage_status.progress = 1.0
        
        if success:
            stage_status.status = 'completed'
            elapsed = stage_status.end_time - (stage_status.start_time or time.time())
            if self.show_progress:
                self.logger.info(f"✅ 完成阶段: {self._get_stage_name(stage)} (耗时: {elapsed:.2f}秒)")
        else:
            stage_status.status = 'failed'
            stage_status.error = error
            if self.show_progress:
                self.logger.error(f"❌ 阶段失败: {self._get_stage_name(stage)} - {error}")
    
    def get_overall_progress(self) -> float:
        """
        获取总体进度
        
        Returns:
            float: 总体进度 (0.0 - 1.0)
        """
        # 定义阶段权重
        stage_weights = {
            StartupStage.PRE_CHECK: 0.1,
            StartupStage.CONFIG_VALIDATE: 0.1,
            StartupStage.PRELOAD: 0.2,
            StartupStage.INIT: 0.3,
            StartupStage.START: 0.2,
            StartupStage.RUNNING: 0.1,
        }
        
        total_progress = 0.0
        total_weight = 0.0
        
        for stage, weight in stage_weights.items():
            stage_status = self.stages[stage]
            if stage_status.status == 'completed':
                total_progress += weight
            elif stage_status.status == 'running':
                total_progress += weight * stage_status.progress
            total_weight += weight
        
        return total_progress / total_weight if total_weight > 0 else 0.0
    
    def get_status_summary(self) -> Dict[str, any]:
        """
        获取状态摘要
        
        Returns:
            Dict: 状态摘要
        """
        summary = {
            'current_stage': self.current_stage.value if self.current_stage else None,
            'overall_progress': self.get_overall_progress(),
            'elapsed_time': time.time() - self.start_time,
            'stages': {}
        }
        
        for stage, stage_status in self.stages.items():
            summary['stages'][stage.value] = {
                'status': stage_status.status,
                'progress': stage_status.progress,
                'elapsed': (stage_status.end_time or time.time()) - (stage_status.start_time or time.time()) if stage_status.start_time else None,
                'error': stage_status.error
            }
        
        return summary
    
    def print_summary(self):
        """打印状态摘要"""
        summary = self.get_status_summary()
        
        self.logger.info("=" * 60)
        self.logger.info("启动状态摘要")
        self.logger.info("=" * 60)
        self.logger.info(f"当前阶段: {summary['current_stage']}")
        self.logger.info(f"总体进度: {int(summary['overall_progress'] * 100)}%")
        self.logger.info(f"已用时间: {summary['elapsed_time']:.2f}秒")
        self.logger.info("-" * 60)
        
        for stage_value, stage_info in summary['stages'].items():
            status_icon = {
                'pending': '⏳',
                'running': '▶️ ',
                'completed': '✅',
                'failed': '❌'
            }.get(stage_info['status'], '❓')
            
            stage_name = self._get_stage_name(StartupStage(stage_value))
            progress_bar = self._create_progress_bar(stage_info['progress'])
            
            self.logger.info(f"{status_icon} {stage_name:20s} {progress_bar} {int(stage_info['progress'] * 100):3d}%")
            
            if stage_info['error']:
                self.logger.info(f"   错误: {stage_info['error']}")
        
        self.logger.info("=" * 60)
    
    def _get_stage_name(self, stage: StartupStage) -> str:
        """获取阶段名称"""
        names = {
            StartupStage.PRE_CHECK: "启动前检查",
            StartupStage.CONFIG_VALIDATE: "配置验证",
            StartupStage.PRELOAD: "模型预加载",
            StartupStage.INIT: "模块初始化",
            StartupStage.START: "模块启动",
            StartupStage.RUNNING: "系统运行",
            StartupStage.ERROR: "错误状态",
            StartupStage.STOPPED: "已停止",
        }
        return names.get(stage, stage.value)
    
    def _create_progress_bar(self, progress: float, length: int = 20) -> str:
        """创建进度条"""
        filled = int(progress * length)
        bar = '█' * filled + '░' * (length - filled)
        return f"[{bar}]"

