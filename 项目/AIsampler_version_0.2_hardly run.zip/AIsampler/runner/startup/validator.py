#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置验证模块
验证配置文件的格式和内容
"""

import yaml
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional

# 设置项目根目录
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in __import__('sys').path:
    __import__('sys').path.insert(0, str(PROJECT_ROOT))


class StartupValidator:
    """配置验证器"""
    
    def __init__(self):
        """初始化配置验证器"""
        self.logger = logging.getLogger(__name__)
        self.config_dir = PROJECT_ROOT / 'config'
        self.errors: List[str] = []
        self.warnings: List[str] = []
        
    def validate_all(self) -> Tuple[bool, List[str], List[str]]:
        """
        验证所有配置文件
        
        Returns:
            Tuple[bool, List[str], List[str]]: (是否通过, 错误列表, 警告列表)
        """
        self.logger.info("开始配置验证...")
        
        # 验证各个配置文件
        configs = [
            ('cv_config.yaml', self._validate_cv_config),
            ('stt_config.yaml', self._validate_stt_config),
            ('fusion_config.yaml', self._validate_fusion_config),
            ('blender_config.yaml', self._validate_blender_config),
            ('comfyui_config.yaml', self._validate_comfyui_config),
        ]
        
        for config_file, validator_func in configs:
            config_path = self.config_dir / config_file
            if config_path.exists():
                try:
                    with open(config_path, 'r', encoding='utf-8') as f:
                        config = yaml.safe_load(f)
                    validator_func(config, config_file)
                except yaml.YAMLError as e:
                    error = f"{config_file} YAML格式错误: {e}"
                    self.errors.append(error)
                    self.logger.error(error)
                except Exception as e:
                    error = f"{config_file} 验证失败: {e}"
                    self.errors.append(error)
                    self.logger.error(error)
            else:
                warning = f"{config_file} 不存在，跳过验证"
                self.warnings.append(warning)
                self.logger.warning(warning)
        
        # 汇总结果
        passed = len(self.errors) == 0
        
        if passed:
            self.logger.info("✅ 配置验证通过")
            if self.warnings:
                self.logger.warning(f"⚠️  发现 {len(self.warnings)} 个警告")
        else:
            self.logger.error(f"❌ 配置验证失败，发现 {len(self.errors)} 个错误")
        
        return passed, self.errors, self.warnings
    
    def _validate_cv_config(self, config: Dict[str, Any], config_file: str):
        """验证CV配置"""
        self.logger.debug(f"验证 {config_file}...")
        
        required_fields = ['model']
        self._check_required_fields(config, required_fields, config_file)
        
        # 验证模型配置
        if 'model' in config:
            model_config = config['model']
            if isinstance(model_config, dict):
                model_name = model_config.get('name')
                if not model_name:
                    warning = f"{config_file}: 模型名称未指定"
                    self.warnings.append(warning)
                    self.logger.warning(warning)
    
    def _validate_stt_config(self, config: Dict[str, Any], config_file: str):
        """验证STT配置"""
        self.logger.debug(f"验证 {config_file}...")
        
        # STT配置通常有VAD和ASR配置
        if 'vad' not in config and 'asr' not in config:
            warning = f"{config_file}: 未找到VAD或ASR配置"
            self.warnings.append(warning)
            self.logger.warning(warning)
    
    def _validate_fusion_config(self, config: Dict[str, Any], config_file: str):
        """验证融合配置"""
        self.logger.debug(f"验证 {config_file}...")
        
        # 验证同步窗口
        if 'synchronizer' in config:
            sync_config = config['synchronizer']
            sync_window = sync_config.get('sync_window', 0.5)
            if sync_window <= 0 or sync_window > 10:
                warning = f"{config_file}: 同步窗口值异常: {sync_window}"
                self.warnings.append(warning)
                self.logger.warning(warning)
        
        # 验证融合方法
        if 'fusion' in config:
            fusion_config = config['fusion']
            method = fusion_config.get('method', 'weighted_average')
            valid_methods = ['weighted_average', 'majority_vote', 'attention']
            if method not in valid_methods:
                warning = f"{config_file}: 未知的融合方法: {method}"
                self.warnings.append(warning)
                self.logger.warning(warning)
    
    def _validate_blender_config(self, config: Dict[str, Any], config_file: str):
        """验证Blender配置"""
        self.logger.debug(f"验证 {config_file}...")
        
        # 验证路径配置
        if 'paths' in config:
            paths_config = config['paths']
            openpose_file = paths_config.get('openpose_bone_file')
            if openpose_file:
                # 检查文件路径
                bone_path = PROJECT_ROOT / openpose_file
                if not bone_path.exists():
                    warning = f"{config_file}: 骨骼文件不存在: {openpose_file}"
                    self.warnings.append(warning)
                    self.logger.warning(warning)
        
        # 验证Socket配置
        if 'socket' in config:
            socket_config = config['socket']
            if socket_config.get('enabled', False):
                port = socket_config.get('port', 8888)
                if port < 1024 or port > 65535:
                    error = f"{config_file}: Socket端口无效: {port}，应在 1024-65535 之间"
                    self.errors.append(error)
                    self.logger.error(error)
    
    def _validate_comfyui_config(self, config: Dict[str, Any], config_file: str):
        """验证ComfyUI配置"""
        self.logger.debug(f"验证 {config_file}...")
        
        # 验证服务器配置
        if 'server' in config:
            server_config = config['server']
            cloud_api_config = server_config.get('cloud_api', {})
            
            if not cloud_api_config.get('use_cloud_api', True):
                error = f"{config_file}: 必须启用云端API模式"
                self.errors.append(error)
                self.logger.error(error)
            
            base_url = cloud_api_config.get('base_url', '')
            if not base_url:
                warning = f"{config_file}: 云端API基础URL未指定"
                self.warnings.append(warning)
                self.logger.warning(warning)
        
        # 验证工作流配置
        if 'workflow' in config:
            workflow_config = config['workflow']
            workflow_path = workflow_config.get('default_workflow_path')
            if workflow_path:
                workflow_file = PROJECT_ROOT / workflow_path
                if not workflow_file.exists():
                    warning = f"{config_file}: 工作流文件不存在: {workflow_path}"
                    self.warnings.append(warning)
                    self.logger.warning(warning)
    
    def _check_required_fields(self, config: Dict[str, Any], 
                              required_fields: List[str], 
                              config_file: str):
        """
        检查必需字段
        
        Args:
            config: 配置字典
            required_fields: 必需字段列表
            config_file: 配置文件名
        """
        for field in required_fields:
            if field not in config:
                warning = f"{config_file}: 缺少字段 '{field}'"
                self.warnings.append(warning)
                self.logger.warning(warning)
    
    def _validate_path(self, path: str, config_file: str, field_name: str) -> bool:
        """
        验证路径
        
        Args:
            path: 路径字符串
            config_file: 配置文件名
            field_name: 字段名
            
        Returns:
            bool: 路径是否有效
        """
        if not path:
            return True  # 空路径跳过验证
        
        path_obj = Path(path)
        if path_obj.is_absolute():
            if not path_obj.exists():
                warning = f"{config_file}: {field_name} 路径不存在: {path}"
                self.warnings.append(warning)
                self.logger.warning(warning)
                return False
        else:
            # 相对路径，相对于项目根目录
            full_path = PROJECT_ROOT / path
            if not full_path.exists():
                warning = f"{config_file}: {field_name} 路径不存在: {path}"
                self.warnings.append(warning)
                self.logger.warning(warning)
                return False
        
        return True
    
    def _validate_port(self, port: Any, config_file: str, field_name: str) -> bool:
        """
        验证端口号
        
        Args:
            port: 端口号
            config_file: 配置文件名
            field_name: 字段名
            
        Returns:
            bool: 端口是否有效
        """
        if not isinstance(port, int):
            error = f"{config_file}: {field_name} 必须是整数"
            self.errors.append(error)
            self.logger.error(error)
            return False
        
        if port < 1024 or port > 65535:
            error = f"{config_file}: {field_name} 端口无效: {port}，应在 1024-65535 之间"
            self.errors.append(error)
            self.logger.error(error)
            return False
        
        return True

