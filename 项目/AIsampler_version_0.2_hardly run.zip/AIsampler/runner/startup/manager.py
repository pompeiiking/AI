#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
启动管理器（核心模块）
管理整个启动流程，包括检查、验证、预加载、初始化、启动等阶段
"""

import logging
import sys
import time
from pathlib import Path
from typing import Optional, Dict, Any

# 设置项目根目录
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from runner.startup.checker import StartupChecker
from runner.startup.validator import StartupValidator
from runner.startup.monitor import StartupMonitor, StartupStage

# 延迟导入pipeline，先检查torchaudio
def _check_torchaudio():
    """检查torchaudio是否可用"""
    try:
        import torchaudio
        return True, None
    except OSError as e:
        error_msg = str(e)
        if "Could not load this library" in error_msg or "找不到指定的程序" in error_msg:
            return False, "torchaudio库加载失败，可能是缺少Visual C++ Redistributable或版本不匹配"
        return False, f"torchaudio加载失败: {error_msg}"
    except Exception as e:
        return False, f"torchaudio导入失败: {e}"

# 在导入pipeline之前检查torchaudio
_torchaudio_ok, _torchaudio_error = _check_torchaudio()
if not _torchaudio_ok:
    # 延迟导入，避免立即失败
    _pipeline_import_error = _torchaudio_error
else:
    try:
        from controller.pipeline import EndToEndPipeline
        _pipeline_import_error = None
    except Exception as e:
        _pipeline_import_error = str(e)


class StartupManager:
    """启动管理器"""
    
    def __init__(self, 
                 skip_preload: bool = False,
                 no_parallel_preload: bool = False,
                 agent_verbose: bool = False,
                 video_generation_interval: float = 10.0,
                 show_progress: bool = False):
        """
        初始化启动管理器
        
        Args:
            skip_preload: 是否跳过模型预加载
            no_parallel_preload: 是否禁用并行预加载
            agent_verbose: 是否启用Agent详细日志
            video_generation_interval: 视频生成间隔（秒）
            show_progress: 是否显示启动进度
        """
        self.logger = logging.getLogger(__name__)
        self.skip_preload = skip_preload
        self.no_parallel_preload = no_parallel_preload
        self.agent_verbose = agent_verbose
        self.video_generation_interval = video_generation_interval
        self.show_progress = show_progress
        
        # 初始化组件
        self.checker = StartupChecker()
        self.validator = StartupValidator()
        self.monitor = StartupMonitor(show_progress=show_progress)
        
        # Pipeline实例
        self.pipeline: Optional[EndToEndPipeline] = None
        
        # 启动状态
        self._started = False
        self._cleanup_called = False
    
    def start(self) -> bool:
        """
        启动系统
        
        Returns:
            bool: 是否启动成功
        """
        if self._started:
            self.logger.warning("系统已经启动")
            return True
        
        try:
            # 阶段1: 启动前检查
            if not self._stage_pre_check():
                return False
            
            # 阶段2: 配置验证
            if not self._stage_config_validate():
                return False
            
            # 阶段3: 模型预加载（可选）
            if not self.skip_preload:
                if not self._stage_preload():
                    # 预加载失败不是致命错误，记录警告继续
                    self.logger.warning("模型预加载失败，将使用常规初始化")
            
            # 阶段4: 模块初始化
            if not self._stage_init():
                return False
            
            # 阶段5: 模块启动
            if not self._stage_start():
                return False
            
            # 阶段6: 系统运行
            self.monitor.start_stage(StartupStage.RUNNING)
            self.monitor.complete_stage(StartupStage.RUNNING, success=True)
            
            self._started = True
            
            if self.show_progress:
                self.monitor.print_summary()
            
            return True
            
        except Exception as e:
            self.logger.exception(f"启动过程中发生异常: {e}")
            self.monitor.complete_stage(
                self.monitor.current_stage or StartupStage.ERROR,
                success=False,
                error=str(e)
            )
            return False
    
    def _stage_pre_check(self) -> bool:
        """阶段1: 启动前检查"""
        self.monitor.start_stage(StartupStage.PRE_CHECK)
        
        try:
            passed, errors, warnings = self.checker.check_all()
            
            if not passed:
                self.monitor.complete_stage(
                    StartupStage.PRE_CHECK,
                    success=False,
                    error=f"发现 {len(errors)} 个错误"
                )
                self.logger.error("启动前检查失败，请修复以下错误：")
                for error in errors:
                    self.logger.error(f"  - {error}")
                return False
            
            self.monitor.complete_stage(StartupStage.PRE_CHECK, success=True)
            return True
            
        except Exception as e:
            self.monitor.complete_stage(
                StartupStage.PRE_CHECK,
                success=False,
                error=str(e)
            )
            return False
    
    def _stage_config_validate(self) -> bool:
        """阶段2: 配置验证"""
        self.monitor.start_stage(StartupStage.CONFIG_VALIDATE)
        
        try:
            passed, errors, warnings = self.validator.validate_all()
            
            if not passed:
                self.monitor.complete_stage(
                    StartupStage.CONFIG_VALIDATE,
                    success=False,
                    error=f"发现 {len(errors)} 个错误"
                )
                self.logger.error("配置验证失败，请修复以下错误：")
                for error in errors:
                    self.logger.error(f"  - {error}")
                return False
            
            self.monitor.complete_stage(StartupStage.CONFIG_VALIDATE, success=True)
            return True
            
        except Exception as e:
            self.monitor.complete_stage(
                StartupStage.CONFIG_VALIDATE,
                success=False,
                error=str(e)
            )
            return False
    
    def _stage_preload(self) -> bool:
        """阶段3: 模型预加载"""
        self.monitor.start_stage(StartupStage.PRELOAD)
        
        try:
            from utils.model_preloader import ModelPreloader
            
            preload_config = {
                'preload': {
                    'enable': True,
                    'parallel': not self.no_parallel_preload,
                    'cv': True,
                    'stt': True,
                    'comfyui': True,
                    'agent': True,
                }
            }
            
            preloader = ModelPreloader(config=preload_config)
            preload_status = preloader.preload_all()
            
            # 检查预加载结果
            failed_modules = [
                name for name, status in preload_status.items()
                if status.status == 'failed'
            ]
            
            if failed_modules:
                self.monitor.complete_stage(
                    StartupStage.PRELOAD,
                    success=False,
                    error=f"以下模块预加载失败: {', '.join(failed_modules)}"
                )
                return False
            
            self.monitor.complete_stage(StartupStage.PRELOAD, success=True)
            return True
            
        except Exception as e:
            self.monitor.complete_stage(
                StartupStage.PRELOAD,
                success=False,
                error=str(e)
            )
            return False
    
    def _stage_init(self) -> bool:
        """阶段4: 模块初始化"""
        self.monitor.start_stage(StartupStage.INIT)
        
        # 检查pipeline导入错误
        if _pipeline_import_error:
            error_msg = _pipeline_import_error
            if "torchaudio" in error_msg.lower():
                detailed_msg = (
                    f"{error_msg}\n\n"
                    "解决方案:\n"
                    "  1. 运行诊断工具: python runner/check_torchaudio.py\n"
                    "  2. 安装 Visual C++ Redistributable:\n"
                    "     https://aka.ms/vs/17/release/vc_redist.x64.exe\n"
                    "  3. 重新安装 torchaudio:\n"
                    "     pip uninstall torchaudio\n"
                    "     pip install torchaudio\n"
                )
            else:
                detailed_msg = error_msg
            
            self.monitor.complete_stage(
                StartupStage.INIT,
                success=False,
                error=detailed_msg
            )
            self.logger.error(f"Pipeline导入失败: {error_msg}")
            return False
        
        try:
            # 构建Pipeline配置
            pipeline_config = {
                'preload': {
                    'enable': not self.skip_preload,
                    'parallel': not self.no_parallel_preload,
                },
                'agent': {
                    'verbose': self.agent_verbose,
                },
                'video_generation_interval': self.video_generation_interval,
            }
            
            # 更新进度
            self.monitor.update_progress(StartupStage.INIT, 0.2, "创建Pipeline实例...")
            
            # 创建Pipeline实例（这会初始化所有模块）
            self.pipeline = EndToEndPipeline(config=pipeline_config)
            
            self.monitor.update_progress(StartupStage.INIT, 1.0, "Pipeline初始化完成")
            self.monitor.complete_stage(StartupStage.INIT, success=True)
            return True
            
        except Exception as e:
            self.monitor.complete_stage(
                StartupStage.INIT,
                success=False,
                error=str(e)
            )
            self.logger.exception("模块初始化失败")
            return False
    
    def _stage_start(self) -> bool:
        """阶段5: 模块启动"""
        self.monitor.start_stage(StartupStage.START)
        
        if not self.pipeline:
            self.monitor.complete_stage(
                StartupStage.START,
                success=False,
                error="Pipeline未初始化"
            )
            return False
        
        try:
            self.monitor.update_progress(StartupStage.START, 0.2, "启动Pipeline...")
            
            # 启动Pipeline
            success = self.pipeline.start()
            
            if not success:
                self.monitor.complete_stage(
                    StartupStage.START,
                    success=False,
                    error="Pipeline启动失败"
                )
                return False
            
            self.monitor.update_progress(StartupStage.START, 1.0, "Pipeline启动完成")
            self.monitor.complete_stage(StartupStage.START, success=True)
            return True
            
        except Exception as e:
            self.monitor.complete_stage(
                StartupStage.START,
                success=False,
                error=str(e)
            )
            self.logger.exception("模块启动失败")
            return False
    
    def cleanup(self):
        """清理资源"""
        if self._cleanup_called:
            return
        
        self._cleanup_called = True
        
        try:
            if self.pipeline:
                self.logger.info("正在停止Pipeline...")
                self.pipeline.stop()
                self.pipeline.cleanup()
                self.pipeline = None
            
            self.monitor.complete_stage(StartupStage.STOPPED, success=True)
            self.logger.info("资源清理完成")
            
        except Exception as e:
            self.logger.exception(f"清理资源时发生异常: {e}")
    
    def get_pipeline(self) -> Optional[EndToEndPipeline]:
        """
        获取Pipeline实例
        
        Returns:
            Optional[EndToEndPipeline]: Pipeline实例
        """
        return self.pipeline
    
    def is_running(self) -> bool:
        """
        检查系统是否在运行
        
        Returns:
            bool: 是否在运行
        """
        return self._started and self.pipeline is not None

