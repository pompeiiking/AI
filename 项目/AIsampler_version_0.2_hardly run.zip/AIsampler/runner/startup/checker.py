#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
启动前检查模块
检查环境、依赖、配置文件、API密钥等
"""

import sys
import importlib
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import socket
import time

# 设置项目根目录
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


class StartupChecker:
    """启动前检查器"""
    
    def __init__(self):
        """初始化启动前检查器"""
        self.logger = logging.getLogger(__name__)
        self.config_dir = PROJECT_ROOT / 'config'
        self.errors: List[str] = []
        self.warnings: List[str] = []
        
    def check_all(self) -> Tuple[bool, List[str], List[str]]:
        """
        执行所有检查
        
        Returns:
            Tuple[bool, List[str], List[str]]: (是否通过, 错误列表, 警告列表)
        """
        self.logger.info("开始启动前检查...")
        
        # 1. Python版本检查
        self._check_python_version()
        
        # 2. 依赖包检查
        self._check_dependencies()
        
        # 3. 配置文件检查
        self._check_config_files()
        
        # 4. API密钥文件检查
        self._check_api_keys()
        
        # 5. 系统资源检查
        self._check_system_resources()
        
        # 6. Blender连接检查（可选）
        self._check_blender_connection()
        
        # 汇总结果
        passed = len(self.errors) == 0
        
        if passed:
            self.logger.info("✅ 启动前检查通过")
            if self.warnings:
                self.logger.warning(f"⚠️  发现 {len(self.warnings)} 个警告")
        else:
            self.logger.error(f"❌ 启动前检查失败，发现 {len(self.errors)} 个错误")
        
        return passed, self.errors, self.warnings
    
    def _check_python_version(self):
        """检查Python版本"""
        self.logger.debug("检查Python版本...")
        
        version = sys.version_info
        if version.major < 3 or (version.major == 3 and version.minor < 7):
            error = f"Python版本过低: {version.major}.{version.minor}，需要 >= 3.7"
            self.errors.append(error)
            self.logger.error(error)
        else:
            self.logger.debug(f"✅ Python版本: {version.major}.{version.minor}.{version.micro}")
    
    def _check_dependencies(self):
        """检查依赖包"""
        self.logger.debug("检查依赖包...")
        
        # 读取requirements.txt
        requirements_file = PROJECT_ROOT / 'requirements.txt'
        if not requirements_file.exists():
            warning = "requirements.txt 文件不存在，跳过依赖检查"
            self.warnings.append(warning)
            self.logger.warning(warning)
            return
        
        # 可选依赖包（缺失时只警告，不报错）
        optional_packages = {'psutil'}  # psutil 是可选的，用于性能监控
        
        # 包名到导入名的映射
        package_to_import = {
            'opencv-python': 'cv2',
            'pillow': 'PIL',
            'pyyaml': 'yaml',
            'langchain-openai': 'langchain_openai',  # 包名是 langchain-openai，导入名是 langchain_openai
        }
        
        # 解析requirements.txt
        required_packages = []
        try:
            with open(requirements_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        # 提取包名（去除版本号）
                        package_name = line.split('>=')[0].split('==')[0].split(';')[0].strip()
                        if package_name:
                            required_packages.append(package_name)
        except Exception as e:
            warning = f"读取requirements.txt失败: {e}"
            self.warnings.append(warning)
            self.logger.warning(warning)
            return
        
        # 检查每个包
        missing_packages = []
        missing_optional = []
        
        for package in required_packages:
            # 处理特殊包名映射
            import_name = package_to_import.get(package, package)
            
            try:
                importlib.import_module(import_name)
            except ImportError:
                if package in optional_packages:
                    missing_optional.append(package)
                else:
                    missing_packages.append(package)
        
        # 处理缺失的必需包
        if missing_packages:
            error = f"缺少依赖包: {', '.join(missing_packages)}"
            self.errors.append(error)
            self.logger.error(error)
            self.logger.error("请运行以下命令安装缺失的依赖包：")
            self.logger.error(f"  pip install {' '.join(missing_packages)}")
        
        # 处理缺失的可选包
        if missing_optional:
            warning = f"缺少可选依赖包: {', '.join(missing_optional)}（某些功能可能不可用）"
            self.warnings.append(warning)
            self.logger.warning(warning)
        
        if not missing_packages:
            self.logger.debug(f"✅ 所有必需依赖包已安装 ({len(required_packages) - len(missing_optional)} 个)")
    
    def _check_config_files(self):
        """检查配置文件"""
        self.logger.debug("检查配置文件...")
        
        required_configs = [
            'cv_config.yaml',
            'stt_config.yaml',
            'fusion_config.yaml',
            'blender_config.yaml',
            'comfyui_config.yaml',
        ]
        
        missing_configs = []
        for config_file in required_configs:
            config_path = self.config_dir / config_file
            if not config_path.exists():
                missing_configs.append(config_file)
        
        if missing_configs:
            error = f"缺少配置文件: {', '.join(missing_configs)}"
            self.errors.append(error)
            self.logger.error(error)
        else:
            self.logger.debug(f"✅ 所有配置文件存在 ({len(required_configs)} 个)")
    
    def _check_api_keys(self):
        """检查API密钥文件"""
        self.logger.debug("检查API密钥文件...")
        
        # DeepSeek API密钥
        deepseek_key_file = self.config_dir / 'deepseek_key'
        if not deepseek_key_file.exists():
            error = "DeepSeek API密钥文件不存在: config/deepseek_key"
            self.errors.append(error)
            self.logger.error(error)
        else:
            # 检查文件是否为空
            try:
                with open(deepseek_key_file, 'rb') as f:
                    content = f.read()
                # 尝试多种编码
                key = None
                for encoding in ['utf-8', 'utf-8-sig', 'gbk']:
                    try:
                        key = content.decode(encoding).strip()
                        if key.startswith('\ufeff'):
                            key = key[1:].strip()
                        if key:
                            break
                    except (UnicodeDecodeError, UnicodeError):
                        continue
                
                if not key or len(key) < 10:
                    error = "DeepSeek API密钥文件为空或格式不正确"
                    self.errors.append(error)
                    self.logger.error(error)
                else:
                    self.logger.debug("✅ DeepSeek API密钥文件存在且有效")
            except Exception as e:
                error = f"读取DeepSeek API密钥文件失败: {e}"
                self.errors.append(error)
                self.logger.error(error)
        
        # ComfyUI API密钥和实例ID
        comfyui_cloud_dir = self.config_dir / 'comfyui_cloud'
        api_key_file = comfyui_cloud_dir / 'api_key'
        instance_id_file = comfyui_cloud_dir / 'instance_id'
        
        if not api_key_file.exists():
            error = "ComfyUI API密钥文件不存在: config/comfyui_cloud/api_key"
            self.errors.append(error)
            self.logger.error(error)
        else:
            try:
                with open(api_key_file, 'r', encoding='utf-8') as f:
                    api_key = f.read().strip()
                if not api_key:
                    error = "ComfyUI API密钥文件为空"
                    self.errors.append(error)
                    self.logger.error(error)
                else:
                    self.logger.debug("✅ ComfyUI API密钥文件存在且有效")
            except Exception as e:
                error = f"读取ComfyUI API密钥文件失败: {e}"
                self.errors.append(error)
                self.logger.error(error)
        
        if not instance_id_file.exists():
            error = "ComfyUI 实例ID文件不存在: config/comfyui_cloud/instance_id"
            self.errors.append(error)
            self.logger.error(error)
        else:
            try:
                with open(instance_id_file, 'r', encoding='utf-8') as f:
                    instance_id = f.read().strip()
                if not instance_id:
                    error = "ComfyUI 实例ID文件为空"
                    self.errors.append(error)
                    self.logger.error(error)
                else:
                    self.logger.debug("✅ ComfyUI 实例ID文件存在且有效")
            except Exception as e:
                error = f"读取ComfyUI 实例ID文件失败: {e}"
                self.errors.append(error)
                self.logger.error(error)
    
    def _check_system_resources(self):
        """检查系统资源"""
        self.logger.debug("检查系统资源...")
        
        try:
            import psutil
            
            # 检查内存
            memory = psutil.virtual_memory()
            memory_gb = memory.total / (1024 ** 3)
            memory_available_gb = memory.available / (1024 ** 3)
            
            if memory_available_gb < 2.0:
                warning = f"可用内存不足: {memory_available_gb:.2f} GB，建议至少 2 GB"
                self.warnings.append(warning)
                self.logger.warning(warning)
            else:
                self.logger.debug(f"✅ 可用内存: {memory_available_gb:.2f} GB")
            
            # 检查磁盘空间
            disk = psutil.disk_usage(PROJECT_ROOT)
            disk_free_gb = disk.free / (1024 ** 3)
            
            if disk_free_gb < 5.0:
                warning = f"可用磁盘空间不足: {disk_free_gb:.2f} GB，建议至少 5 GB"
                self.warnings.append(warning)
                self.logger.warning(warning)
            else:
                self.logger.debug(f"✅ 可用磁盘空间: {disk_free_gb:.2f} GB")
                
        except ImportError:
            warning = "psutil 未安装，跳过系统资源检查"
            self.warnings.append(warning)
            self.logger.warning(warning)
        except Exception as e:
            warning = f"系统资源检查失败: {e}"
            self.warnings.append(warning)
            self.logger.warning(warning)
    
    def _check_blender_connection(self):
        """检查Blender连接（Socket模式）"""
        self.logger.debug("检查Blender连接...")
        
        try:
            # 读取Blender配置
            from utils.path_utils import get_config_loader
            config_loader = get_config_loader()
            blender_config = config_loader.get_blender_config()
            
            socket_config = blender_config.get('socket', {})
            use_socket = socket_config.get('enabled', False)
            
            if not use_socket:
                self.logger.debug("Blender Socket模式未启用，跳过连接检查")
                return
            
            host = socket_config.get('host', 'localhost')
            port = socket_config.get('port', 8888)
            
            # 尝试连接
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2.0)
                result = sock.connect_ex((host, port))
                sock.close()
                
                if result == 0:
                    self.logger.debug(f"✅ Blender Socket连接成功 ({host}:{port})")
                else:
                    warning = f"无法连接到Blender Socket服务器 ({host}:{port})，请确保Blender插件已启动"
                    self.warnings.append(warning)
                    self.logger.warning(warning)
            except Exception as e:
                warning = f"Blender Socket连接检查失败: {e}"
                self.warnings.append(warning)
                self.logger.warning(warning)
        except Exception as e:
            warning = f"Blender连接检查失败: {e}"
            self.warnings.append(warning)
            self.logger.warning(warning)

