#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
启动日志模块
专门用于启动过程的日志记录
"""

import logging
import sys
from pathlib import Path
from typing import Optional
from datetime import datetime


class StartupLogger:
    """启动日志管理器"""
    
    def __init__(self):
        """初始化启动日志管理器"""
        self.logger = None
        self.log_file_handler = None
        
    def configure(self, log_level: str = "INFO", log_file: Optional[str] = None):
        """
        配置日志
        
        Args:
            log_level: 日志级别
            log_file: 日志文件路径（可选）
        """
        # 获取根日志记录器
        self.logger = logging.getLogger()
        
        # 清除现有的处理器
        self.logger.handlers.clear()
        
        # 设置日志级别
        level = getattr(logging, log_level.upper(), logging.INFO)
        self.logger.setLevel(level)
        
        # 创建格式化器
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # 控制台处理器
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)
        
        # 文件处理器（如果指定）
        if log_file:
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            
            self.log_file_handler = logging.FileHandler(
                log_file,
                encoding='utf-8',
                mode='a'
            )
            self.log_file_handler.setLevel(level)
            self.log_file_handler.setFormatter(formatter)
            self.logger.addHandler(self.log_file_handler)
        else:
            # 默认日志文件：logs/startup_YYYYMMDD_HHMMSS.log
            logs_dir = Path(__file__).parent.parent.parent / 'logs'
            logs_dir.mkdir(exist_ok=True)
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            default_log_file = logs_dir / f'startup_{timestamp}.log'
            
            self.log_file_handler = logging.FileHandler(
                default_log_file,
                encoding='utf-8',
                mode='a'
            )
            self.log_file_handler.setLevel(level)
            self.log_file_handler.setFormatter(formatter)
            self.logger.addHandler(self.log_file_handler)
            
            logging.info(f"启动日志已保存到: {default_log_file}")
    
    def get_logger(self, name: str = None) -> logging.Logger:
        """
        获取日志记录器
        
        Args:
            name: 日志记录器名称
            
        Returns:
            logging.Logger: 日志记录器
        """
        if name:
            return logging.getLogger(name)
        return self.logger or logging.getLogger()
    
    def cleanup(self):
        """清理日志资源"""
        if self.log_file_handler:
            self.log_file_handler.close()

