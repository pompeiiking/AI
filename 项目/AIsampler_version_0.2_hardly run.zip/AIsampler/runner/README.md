# 系统启动模块

本目录包含系统启动相关的所有文件，提供统一的启动入口和完善的启动流程管理。

## 📁 文件结构

```
runner/
├── start.py                    # 主启动入口（命令行接口）
├── startup/                    # 启动模块包
│   ├── __init__.py            # 包初始化
│   ├── checker.py             # 启动前检查模块
│   ├── validator.py           # 配置验证模块
│   ├── manager.py             # 启动管理器（核心）
│   ├── monitor.py             # 启动状态监控
│   └── logger.py              # 启动日志模块
└── README.md                  # 本文件
```

## 🚀 快速开始

### 基本启动

```bash
# 从项目根目录执行
python runner/start.py
```

### 常用启动选项

```bash
# 跳过模型预加载（加快启动速度，但首次响应会慢）
python runner/start.py --skip-preload

# 禁用并行预加载（如果遇到资源竞争问题）
python runner/start.py --no-parallel-preload

# 设置运行时长（秒）
python runner/start.py --runtime 300

# 启用详细日志和进度显示
python runner/start.py --log-level DEBUG --show-progress

# 指定日志文件
python runner/start.py --log-file logs/my_startup.log
```

## 📋 启动流程

系统启动分为以下阶段：

1. **启动前检查** (PRE_CHECK)
   - Python版本检查
   - 依赖包检查
   - 配置文件存在性检查
   - API密钥文件检查
   - 系统资源检查
   - Blender连接检查（Socket模式）

2. **配置验证** (CONFIG_VALIDATE)
   - YAML配置文件格式验证
   - 必需字段存在性验证
   - 配置值有效性验证

3. **模型预加载** (PRELOAD) - 可选
   - CV模型预加载
   - STT模型预加载
   - ComfyUI工作流预加载
   - Agent模型预加载

4. **模块初始化** (INIT)
   - ConfigLoader初始化
   - MainController初始化
   - FusionController初始化
   - EmotionToBoneMapper初始化
   - BlenderController初始化
   - ComfyUIController初始化
   - AgentManager初始化

5. **模块启动** (START)
   - MainController启动
   - Agent系统初始化
   - Blender骨骼文件加载
   - 回调函数注册
   - CV/STT流启动

6. **系统运行** (RUNNING)
   - 数据流处理循环
   - 实时处理CV和STT数据

## 🔧 命令行参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--log-level` | 日志级别 (DEBUG/INFO/WARNING/ERROR/CRITICAL) | INFO |
| `--log-file` | 日志文件路径 | 自动生成 |
| `--skip-preload` | 跳过模型预加载 | False |
| `--no-parallel-preload` | 禁用并行预加载 | False |
| `--runtime` | 系统运行时长（秒），0表示持续运行 | 0 |
| `--agent-verbose` | 启用Agent详细日志 | False |
| `--video-generation-interval` | 视频生成间隔（秒） | 10.0 |
| `--show-progress` | 显示启动进度 | False |

## 📊 启动状态监控

启用 `--show-progress` 选项后，会显示详细的启动进度：

```
▶️  开始阶段: 启动前检查
✅ 完成阶段: 启动前检查 (耗时: 0.45秒)
▶️  开始阶段: 配置验证
✅ 完成阶段: 配置验证 (耗时: 0.12秒)
...
============================================================
启动状态摘要
============================================================
当前阶段: running
总体进度: 100%
已用时间: 15.23秒
------------------------------------------------------------
✅ 启动前检查        [████████████████████] 100%
✅ 配置验证          [████████████████████] 100%
✅ 模型预加载        [████████████████████] 100%
✅ 模块初始化        [████████████████████] 100%
✅ 模块启动          [████████████████████] 100%
✅ 系统运行          [████████████████████] 100%
============================================================
```

## ⚠️ 错误处理

系统采用分级错误处理策略：

- **致命错误 (FATAL)**: 停止启动
  - Agent系统初始化失败
  - 必需配置文件缺失
  - Python版本不兼容

- **严重错误 (CRITICAL)**: 记录错误，继续但禁用功能
  - ComfyUI连接失败 → 禁用视频生成
  - Blender连接失败 → 禁用骨骼更新

- **一般错误 (WARNING)**: 记录警告，继续运行
  - 预加载失败 → 使用常规初始化
  - 可选配置缺失 → 使用默认值

## 📝 日志文件

启动日志会自动保存到 `logs/startup_YYYYMMDD_HHMMSS.log`，也可以通过 `--log-file` 参数指定自定义路径。

## 🔍 故障排查

### 启动失败

1. **检查启动前检查结果**
   ```bash
   python runner/start.py --log-level DEBUG
   ```
   查看详细的检查信息

2. **检查配置文件**
   确保所有必需的配置文件存在且格式正确：
   - `config/cv_config.yaml`
   - `config/stt_config.yaml`
   - `config/fusion_config.yaml`
   - `config/blender_config.yaml`
   - `config/comfyui_config.yaml`

3. **检查API密钥**
   确保以下文件存在且包含有效密钥：
   - `config/deepseek_key`
   - `config/comfyui_cloud/api_key`
   - `config/comfyui_cloud/instance_id`

4. **检查依赖包**
   ```bash
   pip install -r requirements.txt
   ```

### 模块初始化失败

查看日志文件中的详细错误信息，常见问题：
- 模型文件缺失
- API密钥无效
- 网络连接问题
- 资源不足

## 🔄 与原有启动脚本的关系

原有的 `scripts/run_pipeline.py` 仍然保留，用于向后兼容。新的启动系统 (`runner/start.py`) 提供了更完善的启动流程管理和错误处理。

## 📚 相关文档

- [系统架构图](../docs/系统架构图.md)
- [系统架构图-Mermaid](../docs/系统架构图-Mermaid.md)
- [快速实施指南](../docs/快速实施指南.md)

