# 系统全面分析报告

生成时间: 2025-11-19 18:38:10

## 测试结果

### imports

- **MainController**: True
- **CVController**: True
- **TextController**: True
- **AIDialogueGraph**: True
- **FusionController**: True
- **BlenderController**: True
- **ComfyUIController**: True
- **AgentManager**: True

### configs

- **cv_config**: True
- **text_config**: True
- **fusion_config**: True
- **blender_config**: True
- **comfyui_config**: True
- **mcp_config**: True
- **text_ai_config**: True

### cv

- **inference**: True
- **result**: {'emotion': 'neutral', 'confidence': 0.0, 'face_detected': False, 'face_positions': None}

### event_queue

- **thread_alive**: True
- **consumer_working**: True

### data_flow

- **cv**: True
- **text**: waiting

