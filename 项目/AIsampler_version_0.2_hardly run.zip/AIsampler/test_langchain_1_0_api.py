#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""探索LangChain 1.0的新API"""

import sys

print("=" * 80)
print("LangChain 1.0 新API探索")
print("=" * 80)

# 1. 检查新的Agent API
print("\n【1. 新的Agent API】")
try:
    from langchain.agents import create_agent, AgentState
    print("✓ create_agent, AgentState 可用")
    print(f"  create_agent 文档: {create_agent.__doc__[:200] if create_agent.__doc__ else 'N/A'}...")
except ImportError as e:
    print(f"✗ {e}")

# 2. 检查Tools
print("\n【2. Tools API】")
try:
    from langchain_core.tools import tool
    print("✓ langchain_core.tools.tool 可用")
except ImportError as e:
    print(f"✗ {e}")

# 3. 检查LLM
print("\n【3. LLM API】")
try:
    from langchain_openai import ChatOpenAI
    print("✓ ChatOpenAI 可用")
except ImportError as e:
    print(f"✗ {e}")

# 4. 检查Runnables
print("\n【4. Runnables API】")
try:
    from langchain_core.runnables import RunnableSequence, RunnableLambda
    print("✓ RunnableSequence, RunnableLambda 可用")
except ImportError as e:
    print(f"✗ {e}")

# 5. 检查Messages
print("\n【5. Messages API】")
try:
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
    print("✓ HumanMessage, AIMessage, SystemMessage 可用")
except ImportError as e:
    print(f"✗ {e}")

# 6. 尝试创建简单的Agent
print("\n【6. 测试创建简单Agent】")
try:
    from langchain.agents import create_agent, AgentState
    from langchain_openai import ChatOpenAI
    from langchain_core.tools import tool
    
    # 定义一个简单的工具
    @tool
    def get_weather(location: str) -> str:
        """获取天气信息"""
        return f"{location}的天气：晴天"
    
    # 创建LLM（不需要真实API key，只是测试结构）
    llm = ChatOpenAI(model="gpt-3.5-turbo", api_key="test-key", base_url="http://localhost:8000")
    
    # 创建Agent
    tools = [get_weather]
    agent = create_agent(llm, tools)
    
    print("✓ Agent创建成功")
    print(f"  Agent类型: {type(agent)}")
    print(f"  Agent属性: {dir(agent)[:10]}...")
    
except Exception as e:
    print(f"✗ 创建Agent失败: {e}")
    import traceback
    traceback.print_exc()

# 7. 检查langchain.agents模块的完整内容
print("\n【7. langchain.agents 模块内容】")
try:
    import langchain.agents as agents
    print("可用的类和函数:")
    for name in sorted(dir(agents)):
        if not name.startswith('_'):
            obj = getattr(agents, name)
            obj_type = type(obj).__name__
            print(f"  • {name:30s} ({obj_type})")
except Exception as e:
    print(f"✗ {e}")
