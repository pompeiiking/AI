#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI对话流测试
测试基于LangGraph + DeepSeek的真正AI情感分析
"""

import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)

try:
    from parts.text.ai_dialogue_graph import AIDialogueGraph
    AI_DIALOGUE_AVAILABLE = True
except ImportError as e:
    print(f"❌ 无法导入AIDialogueGraph: {e}")
    print("\n请安装依赖:")
    print("   pip install langgraph langchain langchain-openai")
    sys.exit(1)

print("=" * 80)
print("🤖 AI对话流测试 (LangGraph + DeepSeek)")
print("=" * 80)

# 检查依赖
print("\n【依赖检查】")
print("-" * 80)
print(f"✓ AIDialogueGraph导入成功")
print(f"✓ LangGraph和LangChain可用")

# 初始化AI对话图
print("\n【初始化AI对话图】")
print("-" * 80)

config_loader = get_config_loader()
ai_config = config_loader.load_config('text_ai_config')

print(f"DeepSeek API配置:")
print(f"  • API Base: {ai_config['deepseek']['api_base']}")
print(f"  • Model: {ai_config['deepseek']['model']}")
print(f"  • Temperature: {ai_config['deepseek']['temperature']}")
print(f"  • Max Tokens: {ai_config['deepseek']['max_tokens']}")

try:
    ai_dialogue = AIDialogueGraph(config=ai_config)
    print("\n✓ AI对话图初始化成功")
except Exception as e:
    print(f"\n❌ AI对话图初始化失败: {e}")
    sys.exit(1)

# 测试连接
print("\n【测试DeepSeek连接】")
print("-" * 80)

if ai_dialogue.test_connection():
    print("✓ DeepSeek API连接成功")
else:
    print("❌ DeepSeek API连接失败，请检查API密钥")
    sys.exit(1)

# 测试情感分析
print("\n【AI情感分析测试】")
print("=" * 80)

test_texts = [
    "我今天真的太开心了！一切都很顺利，心情特别好！",
    "我很难过，事情进展得不太顺利，感觉有点低落。",
    "这让我非常生气！简直不能接受这样的结果！",
    "天哪，这真是太让我惊讶了，完全没想到会是这样！",
    "我有点担心和害怕，不知道该怎么办才好。",
    "好的，知道了，明白你的意思。"
]

print(f"\n将测试 {len(test_texts)} 个文本示例...")
print("\n" + "-" * 80)

for i, text in enumerate(test_texts, 1):
    print(f"\n【测试 {i}/{len(test_texts)}】")
    print(f"文本: \"{text}\"")
    print()
    
    try:
        # 调用AI分析
        print("🤖 调用DeepSeek AI分析...")
        start_time = time.time()
        
        result = ai_dialogue.analyze_emotion(text)
        
        elapsed = time.time() - start_time
        
        # 显示结果
        if result.get('error'):
            print(f"❌ 分析失败: {result['error']}")
        else:
            print(f"✓ AI分析完成 (耗时: {elapsed:.2f}秒)")
            print()
            print(f"  情感类型: {result['emotion']}")
            print(f"  置信度: {result['confidence']:.2f}")
            print(f"  分析理由: {result.get('reasoning', 'N/A')}")
            
            keywords = result.get('keywords', [])
            if keywords:
                print(f"  关键词: {', '.join(keywords)}")
            
            print(f"  AI驱动: {'是' if result.get('ai_powered') else '否'}")
        
    except Exception as e:
        print(f"❌ 分析异常: {e}")
    
    # 延迟避免频繁请求
    if i < len(test_texts):
        time.sleep(1)
    
    print("-" * 80)

# 对话历史
print("\n【对话历史】")
print("=" * 80)

history = ai_dialogue.get_conversation_history()
print(f"历史记录数: {len(history)}")

if history:
    print("\n最近的对话:")
    for i, item in enumerate(history[-5:], 1):
        print(f"{i}. {item['emotion']} ({item['confidence']:.2f}) - \"{item['text'][:30]}...\"")

# 总结
print("\n" + "=" * 80)
print("📊 测试总结")
print("=" * 80)

print(f"✓ 完成 {len(test_texts)} 个AI情感分析测试")
print(f"✓ LangGraph状态图正常运行")
print(f"✓ DeepSeek API调用成功")
print(f"✓ 对话历史管理正常")

print("\n💡 使用说明:")
print("  • AI对话图已成功集成到TextController")
print("  • 文本输入会自动使用DeepSeek AI进行情感分析")
print("  • 支持对话历史管理（最多10条）")
print("  • 失败时自动回退到关键词匹配")

print("\n🎯 下一步:")
print("  • 运行 test_text_stream.py 测试流式AI分析")
print("  • 运行 test_multimodal_text_fusion.py 测试多模态融合")
print("  • 集成到完整Pipeline中使用")

print("=" * 80)
