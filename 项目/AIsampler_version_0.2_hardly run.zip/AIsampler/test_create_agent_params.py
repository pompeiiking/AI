#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试create_agent的正确参数"""

from langchain.agents import create_agent
import inspect

print("=" * 80)
print("create_agent 函数签名")
print("=" * 80)

# 获取函数签名
sig = inspect.signature(create_agent)
print(f"\n函数签名: {sig}")

print("\n参数列表:")
for param_name, param in sig.parameters.items():
    print(f"  • {param_name}: {param.annotation if param.annotation != inspect.Parameter.empty else 'Any'}")
    if param.default != inspect.Parameter.empty:
        print(f"    默认值: {param.default}")

# 获取文档
print("\n" + "=" * 80)
print("函数文档")
print("=" * 80)
if create_agent.__doc__:
    print(create_agent.__doc__)
