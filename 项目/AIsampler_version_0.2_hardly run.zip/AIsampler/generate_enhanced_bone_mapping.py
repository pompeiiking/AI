#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增强版骨骼映射生成器
修复动作幅度过小的问题，增加大幅度肢体动作
"""

import json
import socket
import yaml
from pathlib import Path
from typing import Dict, List

PROJECT_ROOT = Path(__file__).resolve().parent


class EnhancedBoneMappingGenerator:
    """增强版骨骼映射生成器"""
    
    def __init__(self):
        # 骨骼分类规则
        self.bone_categories = {
            'head': ['head', 'neck', 'c_head'],
            'spine': ['spine', 'c_spine', 'torso', 'chest'],
            'shoulder': ['shoulder', 'c_shoulder', 'clavicle'],
            'arm_upper': ['arm', 'c_arm', 'upperarm'],
            'arm_lower': ['forearm', 'c_forearm'],
            'hand': ['hand', 'c_hand', 'wrist'],
            'finger_thumb': ['thumb'],
            'finger_index': ['index'],
            'finger_middle': ['middle'],
            'finger_ring': ['ring'],
            'finger_pinky': ['pinky', 'little'],
            'leg_upper': ['thigh', 'upleg'],
            'leg_lower': ['shin', 'calf', 'leg.', 'leg_'],
            'foot': ['foot', 'ankle'],
            'toe': ['toe'],
            'pelvis': ['pelvis', 'hip'],
        }
        
        # 增强的情感旋转模板（单位：弧度）
        # [X轴(前后), Y轴(上下), Z轴(旋转)]
        self.emotion_templates = {
            'happy': {
                'head': [0.4, 0.0, 0.6],           # 头部上扬并微笑
                'spine': [0.25, 0.0, 0.0],         # 挺胸
                'shoulder': [-0.3, 0.0, -0.8],     # 肩膀放松下沉
                'arm_upper': [0.8, -0.9, 0.5],     # 手臂大幅张开（向前向外）⭐
                'arm_lower': [0.0, -0.6, -0.4],    # 前臂外展
                'hand': [0.3, 0.0, 0.2],           # 手掌打开
                'finger_thumb': [0.0, 0.0, 0.4],   # 拇指伸展
                'finger_index': [0.0, 0.0, 0.2],
                'finger_middle': [0.0, 0.0, 0.2],
                'finger_ring': [0.0, 0.0, 0.2],
                'finger_pinky': [0.0, 0.0, 0.2],
                'leg_upper': [-0.2, 0.0, 0.3],     # 腿部放松
                'leg_lower': [0.0, 0.0, 0.0],
                'foot': [0.1, 0.0, 0.0],
            },
            'sad': {
                'head': [-0.6, 0.0, 0.0],          # 头部明显低垂
                'spine': [-0.5, 0.0, 0.0],         # 弯腰
                'shoulder': [0.5, 0.0, 0.6],       # 耸肩
                'arm_upper': [-0.4, 0.8, -0.7],    # 手臂下垂内收⭐
                'arm_lower': [0.0, 0.5, 0.6],      # 前臂弯曲
                'hand': [-0.3, 0.0, -0.4],         # 手掌内收
                'finger_thumb': [0.0, 0.0, -0.3],
                'finger_index': [0.0, 0.0, -0.2],
                'finger_middle': [0.0, 0.0, -0.2],
                'finger_ring': [0.0, 0.0, -0.2],
                'finger_pinky': [0.0, 0.0, -0.2],
                'leg_upper': [0.3, 0.0, -0.2],
                'leg_lower': [0.0, 0.0, 0.0],
                'foot': [-0.1, 0.0, 0.0],
            },
            'angry': {
                'head': [0.3, 0.0, 0.0],           # 头部前倾
                'spine': [0.3, 0.0, 0.0],          # 身体前压
                'shoulder': [0.7, 0.0, 1.2],       # 肩膀紧张上提
                'arm_upper': [0.6, -1.2, 1.0],     # 手臂大幅度张开（威胁姿态）⭐
                'arm_lower': [0.0, -0.8, -0.8],    # 前臂弯曲握拳
                'hand': [0.0, 0.0, 0.6],           # 握拳
                'finger_thumb': [0.0, 0.0, 0.8],   # 拇指紧握
                'finger_index': [0.0, 0.0, 1.0],   # 手指蜷缩
                'finger_middle': [0.0, 0.0, 1.0],
                'finger_ring': [0.0, 0.0, 1.0],
                'finger_pinky': [0.0, 0.0, 1.0],
                'leg_upper': [-0.3, 0.0, 0.5],     # 腿部微张站稳
                'leg_lower': [0.0, 0.0, 0.0],
                'foot': [0.0, 0.0, 0.0],
            },
            'surprise': {
                'head': [0.4, 0.0, 0.0],           # 头部后仰
                'spine': [-0.1, 0.0, 0.0],         # 身体微后
                'shoulder': [-0.2, 0.0, -0.3],
                'arm_upper': [0.5, -1.0, 0.7],     # 手臂突然张开⭐
                'arm_lower': [0.0, -0.7, -0.5],
                'hand': [0.2, 0.0, 0.4],           # 手掌张开
                'finger_thumb': [0.0, 0.0, 0.6],
                'finger_index': [0.0, 0.0, 0.4],
                'finger_middle': [0.0, 0.0, 0.4],
                'finger_ring': [0.0, 0.0, 0.4],
                'finger_pinky': [0.0, 0.0, 0.4],
                'leg_upper': [0.0, 0.0, 0.2],
                'leg_lower': [0.0, 0.0, 0.0],
                'foot': [0.0, 0.0, 0.0],
            },
            'neutral': {
                # 所有骨骼回到中性位置
                'head': [0.0, 0.0, 0.0],
                'spine': [0.0, 0.0, 0.0],
                'shoulder': [0.0, 0.0, 0.0],
                'arm_upper': [0.0, 0.0, 0.0],
                'arm_lower': [0.0, 0.0, 0.0],
                'hand': [0.0, 0.0, 0.0],
                'finger_thumb': [0.0, 0.0, 0.0],
                'finger_index': [0.0, 0.0, 0.0],
                'finger_middle': [0.0, 0.0, 0.0],
                'finger_ring': [0.0, 0.0, 0.0],
                'finger_pinky': [0.0, 0.0, 0.0],
                'leg_upper': [0.0, 0.0, 0.0],
                'leg_lower': [0.0, 0.0, 0.0],
                'foot': [0.0, 0.0, 0.0],
            },
            'fear': {
                'head': [-0.2, 0.0, 0.0],          # 头部微缩
                'spine': [-0.3, 0.0, 0.0],         # 身体收缩
                'shoulder': [0.4, 0.0, 0.4],       # 耸肩防御
                'arm_upper': [0.8, 0.9, -1.0],     # 手臂抬起护胸⭐
                'arm_lower': [0.0, 0.8, 1.0],      # 前臂弯曲护头
                'hand': [-0.4, 0.0, -0.6],         # 手掌内收
                'finger_thumb': [0.0, 0.0, -0.4],
                'finger_index': [0.0, 0.0, -0.4],
                'finger_middle': [0.0, 0.0, -0.4],
                'finger_ring': [0.0, 0.0, -0.4],
                'finger_pinky': [0.0, 0.0, -0.4],
                'leg_upper': [0.5, 0.0, -0.4],     # 腿部收紧
                'leg_lower': [0.0, 0.0, 0.0],
                'foot': [0.0, 0.0, 0.0],
            },
            'disgust': {
                'head': [0.0, 0.2, -0.3],          # 头部偏转避开
                'spine': [0.0, 0.0, -0.1],
                'shoulder': [0.2, 0.0, 0.2],
                'arm_upper': [0.4, 0.6, -0.5],     # 手臂推开姿态⭐
                'arm_lower': [0.0, 0.4, 0.4],
                'hand': [-0.2, 0.0, -0.3],
                'finger_thumb': [0.0, 0.0, -0.2],
                'finger_index': [0.0, 0.0, -0.2],
                'finger_middle': [0.0, 0.0, -0.2],
                'finger_ring': [0.0, 0.0, -0.2],
                'finger_pinky': [0.0, 0.0, -0.2],
                'leg_upper': [0.0, 0.0, -0.3],     # 腿部后退
                'leg_lower': [0.0, 0.0, 0.0],
                'foot': [-0.1, 0.0, 0.0],
            },
        }
    
    def get_all_bones_from_blender(self) -> List[str]:
        """从Blender获取所有骨骼名称"""
        try:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.settimeout(5.0)
            client.connect(('localhost', 8888))
            
            get_cmd = json.dumps({'type': 'get_bone_position'})
            client.send(get_cmd.encode('utf-8'))
            
            response_data = b""
            while True:
                try:
                    chunk = client.recv(16384)
                    if not chunk:
                        break
                    response_data += chunk
                    if len(chunk) < 16384:
                        break
                except socket.timeout:
                    break
            
            response = response_data.decode('utf-8')
            result = json.loads(response)
            
            if result.get('success'):
                bones = list(result.get('data', {}).keys())
                print(f"✓ 从Blender获取到 {len(bones)} 个骨骼")
                return bones
            else:
                print(f"✗ 获取骨骼失败: {result.get('error')}")
                return []
        
        except Exception as e:
            print(f"✗ 连接Blender失败: {e}")
            return []
        finally:
            client.close()
    
    def classify_bone(self, bone_name: str) -> str:
        """将骨骼分类"""
        bone_lower = bone_name.lower()
        
        for category, keywords in self.bone_categories.items():
            if any(kw in bone_lower for kw in keywords):
                return category
        
        return 'other'
    
    def generate_rotation_for_bone(self, bone_name: str, emotion: str) -> List[float]:
        """为特定骨骼和情感生成旋转值"""
        category = self.classify_bone(bone_name)
        template = self.emotion_templates.get(emotion, {})
        rotation = template.get(category, [0.0, 0.0, 0.0]).copy()
        
        # 左右侧对称处理
        is_right = '.r' in bone_name.lower() or '_r' in bone_name.lower() or 'right' in bone_name.lower()
        
        if is_right:
            # 右侧骨骼
            # Y轴（上下）和Z轴（旋转）反向
            rotation[1] = -rotation[1]
            rotation[2] = -rotation[2]
        
        return rotation
    
    def generate_full_mapping(self, bones: List[str]) -> Dict:
        """生成完整的骨骼映射"""
        print("\n开始生成增强版骨骼映射...")
        print("⭐ 特点：")
        print("  • 手臂动作幅度增加3-5倍")
        print("  • X轴（前后）动作明显增强")
        print("  • Y轴（上下）动作增强")
        print("  • 情感差异更加明显")
        
        mapping = {}
        
        for emotion in self.emotion_templates.keys():
            print(f"\n生成 '{emotion}' 的映射...")
            bone_list = []
            
            # 统计
            category_counts = {}
            max_rotation = [0.0, 0.0, 0.0]
            
            for bone_name in bones:
                rotation = self.generate_rotation_for_bone(bone_name, emotion)
                bone_list.append({
                    'name': bone_name,
                    'rotation': rotation
                })
                
                category = self.classify_bone(bone_name)
                category_counts[category] = category_counts.get(category, 0) + 1
                
                # 更新最大旋转值
                for i in range(3):
                    max_rotation[i] = max(max_rotation[i], abs(rotation[i]))
            
            mapping[emotion] = {
                'bones': bone_list,
                'intensity_scale': 1.0
            }
            
            print(f"  ✓ 生成了 {len(bone_list)} 个骨骼映射")
            print(f"  • 最大旋转: X={max_rotation[0]:.2f}, Y={max_rotation[1]:.2f}, Z={max_rotation[2]:.2f}")
        
        return mapping
    
    def save_to_yaml(self, mapping: Dict, output_file: Path):
        """保存映射到YAML文件"""
        with open(output_file, 'w', encoding='utf-8') as f:
            yaml.dump(mapping, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
        print(f"\n✓ 映射已保存到: {output_file}")
    
    def generate_comparison_report(self, mapping: Dict):
        """生成对比报告"""
        print("\n" + "=" * 80)
        print("📊 增强版映射 vs 原版映射对比")
        print("=" * 80)
        
        print("\n【手臂动作幅度对比】")
        print(f"{'情感':<12} {'原版X轴':<12} {'增强X轴':<12} {'原版Y轴':<12} {'增强Y轴':<12}")
        print("-" * 60)
        
        comparisons = {
            'happy': {
                'old': [0.0, -0.3, 0.2],
                'new': [0.8, -0.9, 0.5]
            },
            'angry': {
                'old': [0.0, -0.5, 0.5],
                'new': [0.6, -1.2, 1.0]
            },
            'fear': {
                'old': [0.0, 0.3, -0.4],
                'new': [0.8, 0.9, -1.0]
            }
        }
        
        for emotion, values in comparisons.items():
            old = values['old']
            new = values['new']
            print(f"{emotion:<12} {old[0]:<12.2f} {new[0]:<12.2f} {old[1]:<12.2f} {new[1]:<12.2f}")
            increase_x = (new[0] / old[0] - 1) * 100 if old[0] != 0 else float('inf')
            increase_y = (abs(new[1]) / abs(old[1]) - 1) * 100 if old[1] != 0 else 0
            print(f"{'':12} {'→':12} {f'+{increase_x:.0f}%':12} {'→':12} {f'+{increase_y:.0f}%':12}")
        
        print("\n【主要改进】")
        print("  ✅ X轴（前后）：从0增加到0.4-0.8弧度（23-46度）")
        print("  ✅ Y轴（上下）：幅度增加200-300%")
        print("  ✅ Z轴（旋转）：幅度增加100-200%")
        print("  ✅ 情感差异：更加明显和自然")


def main():
    """主函数"""
    print("=" * 80)
    print("🎬 增强版完整骨骼映射生成器")
    print("=" * 80)
    
    generator = EnhancedBoneMappingGenerator()
    
    # 1. 从Blender获取所有骨骼
    print("\n[步骤1] 从Blender获取所有骨骼...")
    bones = generator.get_all_bones_from_blender()
    
    if not bones:
        print("\n❌ 无法获取骨骼列表")
        return 1
    
    # 2. 生成增强映射
    print("\n[步骤2] 生成增强版骨骼映射...")
    mapping = generator.generate_full_mapping(bones)
    
    # 3. 保存映射
    print("\n[步骤3] 保存映射文件...")
    yaml_file = PROJECT_ROOT / "config" / "enhanced_bone_mapping.yaml"
    yaml_file.parent.mkdir(exist_ok=True)
    generator.save_to_yaml(mapping, yaml_file)
    
    # 4. 生成对比报告
    generator.generate_comparison_report(mapping)
    
    print("\n" + "=" * 80)
    print("✅ 增强版骨骼映射生成完成！")
    print("=" * 80)
    print(f"\n使用方法:")
    print(f"  mapper = EmotionToBoneMapper(mapping_file='{yaml_file}')")
    
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
