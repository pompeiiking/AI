#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置加载器
用于加载和管理各种模块的配置文件
"""

import yaml
import os
from typing import Dict, Any, Optional
from pathlib import Path

class ConfigLoader:
    """配置加载器"""
    
    def __init__(self, config_dir: str = None):
        """
        初始化配置加载器
        
        Args:
            config_dir: 配置文件目录，默认为当前目录下的config文件夹
        """
        if config_dir is None:
            # 获取当前文件所在目录的上级目录
            current_dir = Path(__file__).parent
            self.config_dir = current_dir
        else:
            self.config_dir = Path(config_dir)
        
        self._configs = {}
    
    def load_config(self, config_name: str) -> Dict[str, Any]:
        """
        加载指定配置文件
        
        Args:
            config_name: 配置文件名（不包含扩展名）
            
        Returns:
            Dict[str, Any]: 配置字典
        """
        if config_name in self._configs:
            return self._configs[config_name]
        
        config_file = self.config_dir / f"{config_name}.yaml"
        
        if not config_file.exists():
            raise FileNotFoundError(f"配置文件不存在: {config_file}")
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            self._configs[config_name] = config
            return config
            
        except Exception as e:
            raise Exception(f"加载配置文件失败 {config_file}: {e}")
    
    def get_cv_config(self) -> Dict[str, Any]:
        """获取视觉模块配置"""
        return self.load_config("cv_config")
    
    def get_stt_config(self) -> Dict[str, Any]:
        """获取语音识别模块配置"""
        return self.load_config("stt_config")
    
    def get_fusion_config(self) -> Dict[str, Any]:
        """获取融合模块配置"""
        return self.load_config("fusion_config")
    
    def get_blender_config(self) -> Dict[str, Any]:
        """获取Blender适配器配置"""
        return self.load_config("blender_config")
    
    def get_comfyui_config(self) -> Dict[str, Any]:
        """获取ComfyUI适配器配置"""
        return self.load_config("comfyui_config")
    
    def get_mcp_config(self) -> Dict[str, Any]:
        """获取MCP服务器配置"""
        return self.load_config("mcp_config")
    
    def get_text_config(self) -> Dict[str, Any]:
        """获取文本输入模块配置"""
        return self.load_config("text_config")
    
    def reload_config(self, config_name: str) -> Dict[str, Any]:
        """
        重新加载配置文件
        
        Args:
            config_name: 配置文件名
            
        Returns:
            Dict[str, Any]: 重新加载的配置
        """
        if config_name in self._configs:
            del self._configs[config_name]
        
        return self.load_config(config_name)
    
    def save_config(self, config_name: str, config: Dict[str, Any]) -> bool:
        """
        保存配置到文件
        
        Args:
            config_name: 配置文件名
            config: 配置字典
            
        Returns:
            bool: 保存是否成功
        """
        try:
            config_file = self.config_dir / f"{config_name}.yaml"
            
            with open(config_file, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
            
            # 更新缓存
            self._configs[config_name] = config
            return True
            
        except Exception as e:
            print(f"保存配置文件失败: {e}")
            return False

# 创建全局配置加载器实例
config_loader = ConfigLoader()
