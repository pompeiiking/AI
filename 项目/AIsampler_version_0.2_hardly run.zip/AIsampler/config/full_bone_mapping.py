#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动生成的完整骨骼映射配置
包含 7 种情感的完整骨骼映射
"""

FULL_BONE_MAPPINGS = {
    "happy": {
        "bones": [
            {
                "name": "c_pos",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_traj",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_stretch.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "forearm_stretch.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "forearm_twist.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "forearm.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "hand.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "hand_rot_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "arm_stretch.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "forearm_stretch.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "forearm_twist.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "forearm.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "hand.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "hand_rot_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "c_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root_bend.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "root.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_spine_01.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "spine_01.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_spine_01.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_shoulder.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.6
                ]
            },
            {
                "name": "arm_ik.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "forearm_ik.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "arm.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "c_stretch_arm.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "shoulder.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.6
                ]
            },
            {
                "name": "shoulder_track_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.6
                ]
            },
            {
                "name": "shoulder_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.6
                ]
            },
            {
                "name": "arm_twist_twk.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "arm_ik_nostr.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "forearm_ik_nostr.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "arm_twist.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "c_arm_twist_offset.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "c_arm_ik.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "c_arm_fk.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "arm_fk.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "c_forearm_fk.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "forearm_fk.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "c_hand_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "arm_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "arm_fk_pole.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "c_shoulder.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.6
                ]
            },
            {
                "name": "arm_ik.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "forearm_ik.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "shoulder.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.6
                ]
            },
            {
                "name": "shoulder_track_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.6
                ]
            },
            {
                "name": "shoulder_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.6
                ]
            },
            {
                "name": "arm_twist_twk.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "arm.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "c_stretch_arm.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "arm_ik_nostr.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "forearm_ik_nostr.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "arm_twist.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "c_arm_twist_offset.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "c_arm_ik.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "c_arm_fk.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "c_forearm_fk.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "forearm_fk.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "c_hand_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "arm_fk.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "arm_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "arm_fk_pole.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "c_thigh_b.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_b.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_neck.x",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "c_p_neck.x",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "neck.x",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "neck_twist.x",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "head_scale_fix.x",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "c_head.x",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "head.x",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "leg_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_arm_pin.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "c_stretch_arm_pin.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "c_stretch_leg_pin.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg_pin.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arms_pole.l",
                "rotation": [
                    0.0,
                    -0.3,
                    0.2
                ]
            },
            {
                "name": "c_hand_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "c_arms_pole.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "c_hand_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "root_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "spine_01_ref.x",
                "rotation": [
                    0.15,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.6
                ]
            },
            {
                "name": "arm_ref.l",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "forearm_ref.l",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "hand_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "shoulder_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.6
                ]
            },
            {
                "name": "arm_ref.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "forearm_ref.r",
                "rotation": [
                    0.0,
                    -0.3,
                    -0.2
                ]
            },
            {
                "name": "hand_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "neck_ref.x",
                "rotation": [
                    0.3,
                    0.0,
                    -0.45
                ]
            },
            {
                "name": "head_ref.x",
                "rotation": [
                    0.3,
                    0.0,
                    -0.45
                ]
            },
            {
                "name": "thigh_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_neck_01.x",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "c_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_track.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_snap_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_heel.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_01_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik_target.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_roll.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_track.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_snap_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_heel.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik_target.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_01_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            }
        ],
        "intensity_scale": 1.0
    },
    "sad": {
        "bones": [
            {
                "name": "c_pos",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_traj",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_stretch.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "forearm_stretch.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "forearm_twist.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "forearm.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "hand.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "hand_rot_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "arm_stretch.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "forearm_stretch.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "forearm_twist.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "forearm.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "hand.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "hand_rot_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "c_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root_bend.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "root.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_spine_01.x",
                "rotation": [
                    -0.3,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "spine_01.x",
                "rotation": [
                    -0.3,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_spine_01.x",
                "rotation": [
                    -0.3,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_shoulder.l",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "arm_ik.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "forearm_ik.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "arm.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "c_stretch_arm.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "shoulder.l",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "shoulder_track_pole.l",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "shoulder_pole.l",
                "rotation": [
                    0.3,
                    0.0,
                    0.45
                ]
            },
            {
                "name": "arm_twist_twk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "arm_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "forearm_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "arm_twist.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "c_arm_twist_offset.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "c_arm_ik.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "c_arm_fk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "arm_fk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "c_forearm_fk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "forearm_fk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "c_hand_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "arm_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "arm_fk_pole.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "c_shoulder.r",
                "rotation": [
                    0.3,
                    0.0,
                    -0.45
                ]
            },
            {
                "name": "arm_ik.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "forearm_ik.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "shoulder.r",
                "rotation": [
                    0.3,
                    0.0,
                    -0.45
                ]
            },
            {
                "name": "shoulder_track_pole.r",
                "rotation": [
                    0.3,
                    0.0,
                    -0.45
                ]
            },
            {
                "name": "shoulder_pole.r",
                "rotation": [
                    0.3,
                    0.0,
                    -0.45
                ]
            },
            {
                "name": "arm_twist_twk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "arm.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "c_stretch_arm.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "arm_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "forearm_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "arm_twist.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "c_arm_twist_offset.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "c_arm_ik.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "c_arm_fk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "c_forearm_fk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "forearm_fk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "c_hand_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "arm_fk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "arm_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "arm_fk_pole.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "c_thigh_b.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_b.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_neck.x",
                "rotation": [
                    -0.45,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_neck.x",
                "rotation": [
                    -0.45,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck.x",
                "rotation": [
                    -0.45,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck_twist.x",
                "rotation": [
                    -0.45,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head_scale_fix.x",
                "rotation": [
                    -0.45,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_head.x",
                "rotation": [
                    -0.45,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head.x",
                "rotation": [
                    -0.45,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_arm_pin.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "c_stretch_arm_pin.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "c_stretch_leg_pin.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg_pin.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arms_pole.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.3
                ]
            },
            {
                "name": "c_hand_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "c_arms_pole.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "c_hand_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "root_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "spine_01_ref.x",
                "rotation": [
                    -0.3,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder_ref.l",
                "rotation": [
                    0.3,
                    0.0,
                    -0.45
                ]
            },
            {
                "name": "arm_ref.l",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "forearm_ref.l",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "hand_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "shoulder_ref.r",
                "rotation": [
                    0.3,
                    0.0,
                    -0.45
                ]
            },
            {
                "name": "arm_ref.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "forearm_ref.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.3
                ]
            },
            {
                "name": "hand_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "neck_ref.x",
                "rotation": [
                    -0.45,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "head_ref.x",
                "rotation": [
                    -0.45,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_neck_01.x",
                "rotation": [
                    -0.45,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_track.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_snap_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_heel.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_01_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik_target.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_roll.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_track.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_snap_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_heel.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik_target.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_01_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            }
        ],
        "intensity_scale": 1.0
    },
    "angry": {
        "bones": [
            {
                "name": "c_pos",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_traj",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_stretch.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "forearm_stretch.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "forearm_twist.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "forearm.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "hand.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "hand_rot_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "arm_stretch.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "forearm_stretch.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "forearm_twist.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "forearm.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "hand.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "hand_rot_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "c_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root_bend.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "root.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_spine_01.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "spine_01.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_spine_01.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_shoulder.l",
                "rotation": [
                    0.45,
                    0.0,
                    0.9
                ]
            },
            {
                "name": "arm_ik.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "forearm_ik.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "arm.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "c_stretch_arm.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "shoulder.l",
                "rotation": [
                    0.45,
                    0.0,
                    0.9
                ]
            },
            {
                "name": "shoulder_track_pole.l",
                "rotation": [
                    0.45,
                    0.0,
                    0.9
                ]
            },
            {
                "name": "shoulder_pole.l",
                "rotation": [
                    0.45,
                    0.0,
                    0.9
                ]
            },
            {
                "name": "arm_twist_twk.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "arm_ik_nostr.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "forearm_ik_nostr.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "arm_twist.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "c_arm_twist_offset.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "c_arm_ik.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "c_arm_fk.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "arm_fk.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "c_forearm_fk.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "forearm_fk.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "c_hand_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "arm_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "arm_fk_pole.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "c_shoulder.r",
                "rotation": [
                    0.45,
                    0.0,
                    -0.9
                ]
            },
            {
                "name": "arm_ik.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "forearm_ik.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "shoulder.r",
                "rotation": [
                    0.45,
                    0.0,
                    -0.9
                ]
            },
            {
                "name": "shoulder_track_pole.r",
                "rotation": [
                    0.45,
                    0.0,
                    -0.9
                ]
            },
            {
                "name": "shoulder_pole.r",
                "rotation": [
                    0.45,
                    0.0,
                    -0.9
                ]
            },
            {
                "name": "arm_twist_twk.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "arm.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "c_stretch_arm.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "arm_ik_nostr.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "forearm_ik_nostr.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "arm_twist.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "c_arm_twist_offset.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "c_arm_ik.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "c_arm_fk.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "c_forearm_fk.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "forearm_fk.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "c_hand_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "arm_fk.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "arm_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "arm_fk_pole.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "c_thigh_b.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_b.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_neck.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_neck.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck_twist.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head_scale_fix.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_head.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_arm_pin.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "c_stretch_arm_pin.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "c_stretch_leg_pin.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg_pin.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arms_pole.l",
                "rotation": [
                    0.0,
                    -0.5,
                    0.5
                ]
            },
            {
                "name": "c_hand_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "c_arms_pole.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "c_hand_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "root_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "spine_01_ref.x",
                "rotation": [
                    0.15,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder_ref.l",
                "rotation": [
                    0.45,
                    0.0,
                    -0.9
                ]
            },
            {
                "name": "arm_ref.l",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "forearm_ref.l",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "hand_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "shoulder_ref.r",
                "rotation": [
                    0.45,
                    0.0,
                    -0.9
                ]
            },
            {
                "name": "arm_ref.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "forearm_ref.r",
                "rotation": [
                    0.0,
                    -0.5,
                    -0.5
                ]
            },
            {
                "name": "hand_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "neck_ref.x",
                "rotation": [
                    0.15,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "head_ref.x",
                "rotation": [
                    0.15,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_neck_01.x",
                "rotation": [
                    0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_track.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_snap_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_heel.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_01_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik_target.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_roll.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_track.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_snap_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_heel.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik_target.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_01_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            }
        ],
        "intensity_scale": 1.0
    },
    "surprise": {
        "bones": [
            {
                "name": "c_pos",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_traj",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_stretch.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "forearm_stretch.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "forearm_twist.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "forearm.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "hand.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "hand_rot_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "arm_stretch.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "forearm_stretch.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "forearm_twist.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "forearm.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "hand.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "hand_rot_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "c_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root_bend.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "root.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_spine_01.x",
                "rotation": [
                    -0.05,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "spine_01.x",
                "rotation": [
                    -0.05,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_spine_01.x",
                "rotation": [
                    -0.05,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_shoulder.l",
                "rotation": [
                    -0.1,
                    0.0,
                    -0.15
                ]
            },
            {
                "name": "arm_ik.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "forearm_ik.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "arm.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "c_stretch_arm.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "shoulder.l",
                "rotation": [
                    -0.1,
                    0.0,
                    -0.15
                ]
            },
            {
                "name": "shoulder_track_pole.l",
                "rotation": [
                    -0.1,
                    0.0,
                    -0.15
                ]
            },
            {
                "name": "shoulder_pole.l",
                "rotation": [
                    -0.1,
                    0.0,
                    -0.15
                ]
            },
            {
                "name": "arm_twist_twk.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "arm_ik_nostr.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "forearm_ik_nostr.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "arm_twist.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "c_arm_twist_offset.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "c_arm_ik.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "c_arm_fk.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "arm_fk.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "c_forearm_fk.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "forearm_fk.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "c_hand_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "arm_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "arm_fk_pole.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "c_shoulder.r",
                "rotation": [
                    -0.1,
                    0.0,
                    0.15
                ]
            },
            {
                "name": "arm_ik.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "forearm_ik.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "shoulder.r",
                "rotation": [
                    -0.1,
                    0.0,
                    0.15
                ]
            },
            {
                "name": "shoulder_track_pole.r",
                "rotation": [
                    -0.1,
                    0.0,
                    0.15
                ]
            },
            {
                "name": "shoulder_pole.r",
                "rotation": [
                    -0.1,
                    0.0,
                    0.15
                ]
            },
            {
                "name": "arm_twist_twk.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "arm.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "c_stretch_arm.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "arm_ik_nostr.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "forearm_ik_nostr.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "arm_twist.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "c_arm_twist_offset.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "c_arm_ik.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "c_arm_fk.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "c_forearm_fk.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "forearm_fk.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "c_hand_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "arm_fk.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "arm_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "arm_fk_pole.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "c_thigh_b.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_b.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_neck.x",
                "rotation": [
                    0.2,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_neck.x",
                "rotation": [
                    0.2,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck.x",
                "rotation": [
                    0.2,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck_twist.x",
                "rotation": [
                    0.2,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head_scale_fix.x",
                "rotation": [
                    0.2,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_head.x",
                "rotation": [
                    0.2,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head.x",
                "rotation": [
                    0.2,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_arm_pin.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "c_stretch_arm_pin.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "c_stretch_leg_pin.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg_pin.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arms_pole.l",
                "rotation": [
                    0.0,
                    -0.4,
                    0.3
                ]
            },
            {
                "name": "c_hand_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "c_arms_pole.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "c_hand_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "root_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "spine_01_ref.x",
                "rotation": [
                    -0.05,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder_ref.l",
                "rotation": [
                    -0.1,
                    0.0,
                    0.15
                ]
            },
            {
                "name": "arm_ref.l",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "forearm_ref.l",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "hand_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "shoulder_ref.r",
                "rotation": [
                    -0.1,
                    0.0,
                    0.15
                ]
            },
            {
                "name": "arm_ref.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "forearm_ref.r",
                "rotation": [
                    0.0,
                    -0.4,
                    -0.3
                ]
            },
            {
                "name": "hand_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "neck_ref.x",
                "rotation": [
                    0.2,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "head_ref.x",
                "rotation": [
                    0.2,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_neck_01.x",
                "rotation": [
                    0.2,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_track.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_snap_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_heel.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_01_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik_target.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_roll.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_track.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_snap_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_heel.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik_target.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_01_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            }
        ],
        "intensity_scale": 1.0
    },
    "neutral": {
        "bones": [
            {
                "name": "c_pos",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_traj",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "forearm_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "forearm_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "forearm.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "hand.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "hand_rot_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "forearm_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "forearm_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "forearm.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "hand.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "hand_rot_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root_bend.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "root.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_spine_01.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "spine_01.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_spine_01.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_shoulder.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "forearm_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_arm.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "shoulder.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "shoulder_track_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "shoulder_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_twist_twk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "forearm_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_arm_twist_offset.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_arm_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_arm_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_forearm_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "forearm_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_hand_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_fk_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_shoulder.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "forearm_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder_track_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_twist_twk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_arm.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "forearm_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arm_twist_offset.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arm_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arm_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_forearm_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "forearm_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_hand_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_fk_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_b.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_b.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_neck.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_neck.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck_twist.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head_scale_fix.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_head.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_arm_pin.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_arm_pin.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_leg_pin.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg_pin.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arms_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_hand_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_arms_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_hand_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "root_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "spine_01_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "forearm_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "hand_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "arm_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "forearm_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "hand_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "neck_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "head_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_neck_01.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_track.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_snap_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_heel.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_01_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik_target.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_roll.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_track.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_snap_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_heel.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik_target.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_01_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            }
        ],
        "intensity_scale": 1.0
    },
    "fear": {
        "bones": [
            {
                "name": "c_pos",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_traj",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_stretch.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "forearm_stretch.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "forearm_twist.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "forearm.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "hand.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "hand_rot_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "arm_stretch.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "forearm_stretch.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "forearm_twist.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "forearm.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "hand.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "hand_rot_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "c_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root_bend.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "root.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_spine_01.x",
                "rotation": [
                    -0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "spine_01.x",
                "rotation": [
                    -0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_spine_01.x",
                "rotation": [
                    -0.15,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_shoulder.l",
                "rotation": [
                    0.2,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "arm_ik.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "forearm_ik.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "arm.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "c_stretch_arm.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "shoulder.l",
                "rotation": [
                    0.2,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "shoulder_track_pole.l",
                "rotation": [
                    0.2,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "shoulder_pole.l",
                "rotation": [
                    0.2,
                    0.0,
                    0.2
                ]
            },
            {
                "name": "arm_twist_twk.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "arm_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "forearm_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "arm_twist.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "c_arm_twist_offset.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "c_arm_ik.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "c_arm_fk.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "arm_fk.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "c_forearm_fk.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "forearm_fk.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "c_hand_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "arm_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "arm_fk_pole.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "c_shoulder.r",
                "rotation": [
                    0.2,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "arm_ik.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "forearm_ik.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "shoulder.r",
                "rotation": [
                    0.2,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "shoulder_track_pole.r",
                "rotation": [
                    0.2,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "shoulder_pole.r",
                "rotation": [
                    0.2,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "arm_twist_twk.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "arm.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "c_stretch_arm.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "arm_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "forearm_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "arm_twist.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "c_arm_twist_offset.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "c_arm_ik.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "c_arm_fk.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "c_forearm_fk.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "forearm_fk.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "c_hand_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "arm_fk.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "arm_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "arm_fk_pole.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "c_thigh_b.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_b.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_neck.x",
                "rotation": [
                    -0.1,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_neck.x",
                "rotation": [
                    -0.1,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck.x",
                "rotation": [
                    -0.1,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "neck_twist.x",
                "rotation": [
                    -0.1,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head_scale_fix.x",
                "rotation": [
                    -0.1,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_head.x",
                "rotation": [
                    -0.1,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "head.x",
                "rotation": [
                    -0.1,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_arm_pin.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "c_stretch_arm_pin.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "c_stretch_leg_pin.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg_pin.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arms_pole.l",
                "rotation": [
                    0.0,
                    0.3,
                    -0.4
                ]
            },
            {
                "name": "c_hand_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.3
                ]
            },
            {
                "name": "c_arms_pole.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "c_hand_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "root_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "spine_01_ref.x",
                "rotation": [
                    -0.15,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "shoulder_ref.l",
                "rotation": [
                    0.2,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "arm_ref.l",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "forearm_ref.l",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "hand_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "shoulder_ref.r",
                "rotation": [
                    0.2,
                    0.0,
                    -0.2
                ]
            },
            {
                "name": "arm_ref.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "forearm_ref.r",
                "rotation": [
                    0.0,
                    0.3,
                    0.4
                ]
            },
            {
                "name": "hand_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.3
                ]
            },
            {
                "name": "neck_ref.x",
                "rotation": [
                    -0.1,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "head_ref.x",
                "rotation": [
                    -0.1,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_neck_01.x",
                "rotation": [
                    -0.1,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_track.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_snap_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_heel.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_01_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik_target.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_roll.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_track.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_snap_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_heel.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik_target.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_01_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            }
        ],
        "intensity_scale": 1.0
    },
    "disgust": {
        "bones": [
            {
                "name": "c_pos",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_traj",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "arm_stretch.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "forearm_stretch.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "forearm_twist.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "forearm.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "hand.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "hand_rot_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "arm_stretch.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "forearm_stretch.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "forearm_twist.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "forearm.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "hand.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "hand_rot_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "c_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_root.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_root_bend.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "root.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_root_master.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_spine_01.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.05
                ]
            },
            {
                "name": "spine_01.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.05
                ]
            },
            {
                "name": "c_p_spine_01.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.05
                ]
            },
            {
                "name": "c_shoulder.l",
                "rotation": [
                    0.1,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "arm_ik.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "forearm_ik.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "arm.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "c_stretch_arm.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "shoulder.l",
                "rotation": [
                    0.1,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "shoulder_track_pole.l",
                "rotation": [
                    0.1,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "shoulder_pole.l",
                "rotation": [
                    0.1,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "arm_twist_twk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "arm_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "forearm_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "arm_twist.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "c_arm_twist_offset.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "c_arm_ik.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "c_arm_fk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "arm_fk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "c_forearm_fk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "forearm_fk.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "c_hand_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "arm_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "arm_fk_pole.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "c_shoulder.r",
                "rotation": [
                    0.1,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "arm_ik.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "forearm_ik.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "shoulder.r",
                "rotation": [
                    0.1,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "shoulder_track_pole.r",
                "rotation": [
                    0.1,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "shoulder_pole.r",
                "rotation": [
                    0.1,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "arm_twist_twk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "arm.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "c_stretch_arm.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "arm_ik_nostr_scale_fix.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "arm_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "forearm_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "arm_twist.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "c_arm_twist_offset.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "c_arm_ik.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "c_arm_fk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "c_forearm_fk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "forearm_fk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "c_hand_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "c_hand_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "arm_fk.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "arm_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "arm_fk_pole.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "c_thigh_b.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_fk_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_ik_nostr.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_thigh_b.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ik_nostr.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk_scale_fix.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pre_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_fk_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_thigh_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_neck.x",
                "rotation": [
                    0.0,
                    0.1,
                    -0.15
                ]
            },
            {
                "name": "c_p_neck.x",
                "rotation": [
                    0.0,
                    0.1,
                    -0.15
                ]
            },
            {
                "name": "neck.x",
                "rotation": [
                    0.0,
                    0.1,
                    -0.15
                ]
            },
            {
                "name": "neck_twist.x",
                "rotation": [
                    0.0,
                    0.1,
                    -0.15
                ]
            },
            {
                "name": "head_scale_fix.x",
                "rotation": [
                    0.0,
                    0.1,
                    -0.15
                ]
            },
            {
                "name": "c_head.x",
                "rotation": [
                    0.0,
                    0.1,
                    -0.15
                ]
            },
            {
                "name": "head.x",
                "rotation": [
                    0.0,
                    0.1,
                    -0.15
                ]
            },
            {
                "name": "leg_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_twist.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "thigh_stretch.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "leg_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_twist.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_stretch.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_stretch_arm_pin.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "c_stretch_arm_pin.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "c_stretch_leg_pin.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_stretch_leg_pin.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_arms_pole.l",
                "rotation": [
                    0.0,
                    0.2,
                    -0.2
                ]
            },
            {
                "name": "c_hand_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "c_arms_pole.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "c_hand_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "root_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "spine_01_ref.x",
                "rotation": [
                    0.0,
                    0.0,
                    0.05
                ]
            },
            {
                "name": "shoulder_ref.l",
                "rotation": [
                    0.1,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "arm_ref.l",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "forearm_ref.l",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "hand_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "shoulder_ref.r",
                "rotation": [
                    0.1,
                    0.0,
                    -0.1
                ]
            },
            {
                "name": "arm_ref.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "forearm_ref.r",
                "rotation": [
                    0.0,
                    0.2,
                    0.2
                ]
            },
            {
                "name": "hand_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    0.1
                ]
            },
            {
                "name": "neck_ref.x",
                "rotation": [
                    0.0,
                    0.1,
                    0.15
                ]
            },
            {
                "name": "head_ref.x",
                "rotation": [
                    0.0,
                    0.1,
                    0.15
                ]
            },
            {
                "name": "thigh_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "thigh_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "leg_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_01_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_bank_02_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_heel_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_ref.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_neck_01.x",
                "rotation": [
                    0.0,
                    0.1,
                    -0.15
                ]
            },
            {
                "name": "c_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_p_foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_track.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_01_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "toes_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_snap_fk.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_bank_02.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_heel.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_ik.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_01_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "foot_ik_target.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_toes_end_01.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_roll.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.l",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.l",
                "rotation": [
                    0.0,
                    0.0,
                    0.0
                ]
            },
            {
                "name": "c_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_p_foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_track.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_01_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "toes_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_snap_fk.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_bank_02.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_heel.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_ik.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_ik_target.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "foot_01_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_toes_end_01.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_foot_roll_cursor.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            },
            {
                "name": "c_leg_pole.r",
                "rotation": [
                    0.0,
                    0.0,
                    -0.0
                ]
            }
        ],
        "intensity_scale": 1.0
    }
}
