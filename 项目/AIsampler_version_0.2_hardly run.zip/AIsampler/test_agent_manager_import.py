#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试AgentManager导入问题"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path
setup_project_path(__file__)

print("=" * 80)
print("测试AgentManager导入")
print("=" * 80)

try:
    print("\n1. 测试LangChain导入...")
    from langchain.agents import AgentExecutor, create_structured_chat_agent
    print("✓ AgentExecutor, create_structured_chat_agent")
    
    from langchain.tools import Tool
    print("✓ Tool")
    
    from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
    print("✓ ChatPromptTemplate, MessagesPlaceholder")
    
    from langchain_openai import ChatOpenAI
    print("✓ ChatOpenAI")
    
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
    print("✓ Messages")
    
    print("\n2. 测试AgentManager导入...")
    from controller.agent_manager import AgentManager
    print("✓ AgentManager导入成功!")
    
    print("\n✅ 所有导入成功")
    
except ImportError as e:
    print(f"\n✗ 导入失败: {e}")
    print("\n详细错误信息:")
    import traceback
    traceback.print_exc()
    
    print("\n建议:")
    print("  可能是LangChain版本兼容问题")
    print("  当前LangChain版本导致某些导入路径不匹配")
    
except Exception as e:
    print(f"\n✗ 其他错误: {e}")
    import traceback
    traceback.print_exc()
