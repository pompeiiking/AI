#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多模态融合控制器
实现CV、STT、文本等多模态数据的融合处理
"""

import time
import threading
import logging
import numpy as np
from typing import Dict, Any, Optional, List, Tuple, Callable
from collections import deque
from dataclasses import dataclass, field
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 添加项目路径
from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)
config_loader = get_config_loader()


@dataclass
class FusionResult:
    """融合结果数据类"""
    timestamp: float
    emotion: str
    confidence: float
    sources: Dict[str, Dict[str, Any]]
    fusion_method: str
    sequence_id: int = 0


class TemporalSynchronizer:
    """
    时间同步器
    实现滑动窗口管理、时间戳对齐、数据插值
    """
    
    def __init__(self, sync_window: float = 0.5, max_delay: float = 1.0, 
                 interpolation: bool = True):
        """
        初始化时间同步器
        
        Args:
            sync_window: 同步时间窗口（秒）
            max_delay: 最大延迟容忍度（秒）
            interpolation: 是否启用插值
        """
        self.sync_window = sync_window
        self.max_delay = max_delay
        self.interpolation = interpolation
        
        # 滑动窗口：存储不同来源的数据
        self._windows: Dict[str, deque] = {
            'cv': deque(),
            'stt': deque(),
            'text': deque()
        }
        
        self._lock = threading.RLock()
        self.logger = logging.getLogger(__name__)
    
    def add_data(self, source: str, timestamp: float, data: Dict[str, Any]):
        """
        添加数据到同步窗口
        
        Args:
            source: 数据来源（cv/stt/text）
            timestamp: 时间戳
            data: 数据字典
        """
        if source not in self._windows:
            self.logger.warning(f"未知数据来源: {source}")
            return
        
        with self._lock:
            # 添加数据
            self._windows[source].append({
                'timestamp': timestamp,
                'data': data
            })
            
            # 清理过期数据
            current_time = time.time()
            while (self._windows[source] and 
                   current_time - self._windows[source][0]['timestamp'] > self.max_delay):
                self._windows[source].popleft()
    
    def synchronize(self, target_timestamp: Optional[float] = None) -> Dict[str, Optional[Dict[str, Any]]]:
        """
        同步数据
        
        Args:
            target_timestamp: 目标时间戳，如果为None则使用当前时间
            
        Returns:
            Dict[str, Optional[Dict[str, Any]]]: 同步后的数据，键为来源，值为数据或None
        """
        if target_timestamp is None:
            target_timestamp = time.time()
        
        with self._lock:
            result = {}
            
            for source, window in self._windows.items():
                if not window:
                    result[source] = None
                    continue
                
                # 查找最接近目标时间戳的数据
                best_data = None
                min_diff = float('inf')
                
                for item in window:
                    diff = abs(item['timestamp'] - target_timestamp)
                    if diff < min_diff and diff <= self.sync_window:
                        min_diff = diff
                        best_data = item['data']
                
                # 如果启用插值且没有找到精确匹配
                if best_data is None and self.interpolation and len(window) >= 2:
                    # 尝试插值
                    best_data = self._interpolate(source, target_timestamp, window)
                
                result[source] = best_data
            
            return result
    
    def _interpolate(self, source: str, target_timestamp: float, 
                    window: deque) -> Optional[Dict[str, Any]]:
        """
        插值数据
        
        Args:
            source: 数据来源
            target_timestamp: 目标时间戳
            window: 数据窗口
            
        Returns:
            Optional[Dict[str, Any]]: 插值后的数据
        """
        # 找到目标时间戳前后的两个数据点
        before = None
        after = None
        
        for item in window:
            if item['timestamp'] <= target_timestamp:
                if before is None or item['timestamp'] > before['timestamp']:
                    before = item
            else:
                if after is None or item['timestamp'] < after['timestamp']:
                    after = item
        
        # 如果只有一个数据点，直接返回
        if before is None:
            return after['data'] if after else None
        if after is None:
            return before['data']
        
        # 线性插值
        total_diff = after['timestamp'] - before['timestamp']
        if total_diff == 0:
            return before['data']
        
        weight = (target_timestamp - before['timestamp']) / total_diff
        
        # 对于数值型数据，进行插值
        interpolated = {}
        for key, value in before['data'].items():
            if isinstance(value, (int, float)) and key in after['data']:
                interpolated[key] = before['data'][key] * (1 - weight) + after['data'][key] * weight
            else:
                # 对于非数值型数据，使用最近的数据
                interpolated[key] = before['data'][key] if weight < 0.5 else after['data'][key]
        
        return interpolated
    
    def clear(self):
        """清空所有窗口"""
        with self._lock:
            for window in self._windows.values():
                window.clear()


class FeatureFusion:
    """
    特征融合器
    实现特征归一化、加权平均、注意力融合、多数投票
    """
    
    def __init__(self, fusion_mode: str = "weighted_average", 
                 normalization_method: str = "min_max"):
        """
        初始化特征融合器
        
        Args:
            fusion_mode: 融合模式（weighted_average/majority_vote/attention）
            normalization_method: 归一化方法（min_max/z_score）
        """
        self.fusion_mode = fusion_mode
        self.normalization_method = normalization_method
        self.logger = logging.getLogger(__name__)
    
    def normalize(self, features: Dict[str, float], 
                  method: Optional[str] = None) -> Dict[str, float]:
        """
        归一化特征
        
        Args:
            features: 特征字典
            method: 归一化方法，如果为None则使用self.normalization_method
            
        Returns:
            Dict[str, float]: 归一化后的特征
        """
        if method is None:
            method = self.normalization_method
        
        if not features:
            return {}
        
        values = list(features.values())
        
        if method == "min_max":
            min_val = min(values)
            max_val = max(values)
            if max_val == min_val:
                return {k: 0.5 for k in features.keys()}
            return {k: (v - min_val) / (max_val - min_val) for k, v in features.items()}
        
        elif method == "z_score":
            mean_val = np.mean(values)
            std_val = np.std(values)
            if std_val == 0:
                return {k: 0.0 for k in features.keys()}
            return {k: (v - mean_val) / std_val for k, v in features.items()}
        
        else:
            self.logger.warning(f"未知归一化方法: {method}")
            return features
    
    def weighted_average(self, sources: Dict[str, Dict[str, Any]], 
                        weights: Dict[str, float]) -> Tuple[str, float]:
        """
        加权平均融合
        
        Args:
            sources: 数据来源字典，键为来源名称，值为数据字典
            weights: 权重字典，键为来源名称，值为权重
            
        Returns:
            Tuple[str, float]: (融合后的情绪, 置信度)
        """
        # 情绪映射到数值
        emotion_map = {
            'angry': 0, 'disgust': 1, 'fear': 2, 'happy': 3,
            'sad': 4, 'surprise': 5, 'neutral': 6
        }
        
        emotion_scores = {}
        total_weight = 0.0
        
        for source, data in sources.items():
            if data is None:
                continue
            
            weight = weights.get(source, 0.0)
            if weight <= 0:
                continue
            
            # 从数据中提取情绪和置信度
            emotion = data.get('emotion', 'neutral')
            confidence = data.get('confidence', 0.0)
            
            if emotion in emotion_map:
                emotion_value = emotion_map[emotion]
                weighted_value = emotion_value * weight * confidence
                emotion_scores[emotion] = emotion_scores.get(emotion, 0.0) + weighted_value
                total_weight += weight * confidence
        
        if not emotion_scores or total_weight == 0:
            return ('neutral', 0.0)
        
        # 找到得分最高的情绪
        best_emotion = max(emotion_scores, key=emotion_scores.get)
        best_score = emotion_scores[best_emotion]
        confidence = best_score / total_weight if total_weight > 0 else 0.0
        
        return (best_emotion, min(confidence, 1.0))
    
    def majority_vote(self, sources: Dict[str, Dict[str, Any]]) -> Tuple[str, float]:
        """
        多数投票融合
        
        Args:
            sources: 数据来源字典
            
        Returns:
            Tuple[str, float]: (融合后的情绪, 置信度)
        """
        emotion_votes = {}
        total_confidence = 0.0
        
        for source, data in sources.items():
            if data is None:
                continue
            
            emotion = data.get('emotion', 'neutral')
            confidence = data.get('confidence', 0.0)
            
            if emotion not in emotion_votes:
                emotion_votes[emotion] = 0.0
            
            emotion_votes[emotion] += confidence
            total_confidence += confidence
        
        if not emotion_votes:
            return ('neutral', 0.0)
        
        # 找到得票最多的情绪
        best_emotion = max(emotion_votes, key=emotion_votes.get)
        best_votes = emotion_votes[best_emotion]
        confidence = best_votes / total_confidence if total_confidence > 0 else 0.0
        
        return (best_emotion, min(confidence, 1.0))
    
    def attention_fusion(self, sources: Dict[str, Dict[str, Any]], 
                        weights: Dict[str, float]) -> Tuple[str, float]:
        """
        注意力融合
        
        Args:
            sources: 数据来源字典
            weights: 权重字典
            
        Returns:
            Tuple[str, float]: (融合后的情绪, 置信度)
        """
        # 计算注意力权重（基于置信度）
        attention_weights = {}
        total_attention = 0.0
        
        for source, data in sources.items():
            if data is None:
                continue
            
            base_weight = weights.get(source, 0.0)
            confidence = data.get('confidence', 0.0)
            
            attention = base_weight * confidence
            attention_weights[source] = attention
            total_attention += attention
        
        if total_attention == 0:
            return self.majority_vote(sources)
        
        # 归一化注意力权重
        normalized_weights = {k: v / total_attention for k, v in attention_weights.items()}
        
        # 使用归一化后的权重进行加权平均
        return self.weighted_average(sources, normalized_weights)
    
    def fuse(self, sources: Dict[str, Dict[str, Any]], 
            weights: Optional[Dict[str, float]] = None) -> Tuple[str, float]:
        """
        融合数据
        
        Args:
            sources: 数据来源字典
            weights: 权重字典，如果为None则使用均等权重
            
        Returns:
            Tuple[str, float]: (融合后的情绪, 置信度)
        """
        if weights is None:
            # 均等权重
            active_sources = [k for k, v in sources.items() if v is not None]
            if not active_sources:
                return ('neutral', 0.0)
            weights = {k: 1.0 / len(active_sources) for k in active_sources}
        
        if self.fusion_mode == "weighted_average":
            return self.weighted_average(sources, weights)
        elif self.fusion_mode == "majority_vote":
            return self.majority_vote(sources)
        elif self.fusion_mode == "attention":
            return self.attention_fusion(sources, weights)
        else:
            self.logger.warning(f"未知融合模式: {self.fusion_mode}，使用多数投票")
            return self.majority_vote(sources)


class FusionController:
    """
    多模态融合控制器
    接收CV、STT、文本等多模态输入，进行时间同步和特征融合
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化融合控制器
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
        """
        # 加载配置
        if config is None:
            config = config_loader.get_fusion_config()
        
        self.config = config
        
        # 初始化日志（避免重复配置）
        self.logger = logging.getLogger(__name__)
        
        # 从配置中读取参数
        fusion_strategy = config.get('fusion_strategy', {})
        temporal_config = config.get('temporal', {})
        feature_fusion_config = config.get('feature_fusion', {})
        
        # 初始化时间同步器
        self.synchronizer = TemporalSynchronizer(
            sync_window=temporal_config.get('sync_window', 0.5),
            max_delay=temporal_config.get('max_delay', 1.0),
            interpolation=temporal_config.get('interpolation', True)
        )
        
        # 初始化特征融合器
        self.feature_fusion = FeatureFusion(
            fusion_mode=fusion_strategy.get('mode', 'weighted_average'),
            normalization_method=feature_fusion_config.get('normalization_method', 'min_max')
        )
        
        # 融合权重
        self.weights = fusion_strategy.get('weights', {
            'cv': 0.4,
            'stt': 0.4,
            'text': 0.2
        })
        
        # 融合阈值
        self.confidence_threshold = fusion_strategy.get('threshold', 0.5)
        
        # 回调函数
        self._callbacks: List[Callable[[FusionResult], None]] = []
        self._lock = threading.RLock()
        
        # 序列号计数器
        self._sequence_counter = 0
        self._sequence_lock = threading.Lock()
        
        self.logger.info("融合控制器初始化完成")
    
    def add_cv_data(self, timestamp: float, data: Dict[str, Any]):
        """
        添加CV数据
        
        Args:
            timestamp: 时间戳
            data: CV数据字典
        """
        self.synchronizer.add_data('cv', timestamp, data)
        self._try_fusion()
    
    def add_stt_data(self, timestamp: float, data: Dict[str, Any]):
        """
        添加STT数据
        
        Args:
            timestamp: 时间戳
            data: STT数据字典
        """
        self.synchronizer.add_data('stt', timestamp, data)
        self._try_fusion()
    
    def add_text_data(self, timestamp: float, data: Dict[str, Any]):
        """
        添加文本数据
        
        Args:
            timestamp: 时间戳
            data: 文本数据字典
        """
        self.synchronizer.add_data('text', timestamp, data)
        self._try_fusion()
    
    def _try_fusion(self):
        """尝试进行融合"""
        try:
            # 同步数据
            synchronized = self.synchronizer.synchronize()
            
            # 检查是否有足够的数据
            active_sources = [k for k, v in synchronized.items() if v is not None]
            if not active_sources:
                return
            
            # 进行融合
            emotion, confidence = self.feature_fusion.fuse(synchronized, self.weights)
            
            # 检查置信度阈值
            if confidence < self.confidence_threshold:
                emotion = 'neutral'
            
            # 创建融合结果
            with self._sequence_lock:
                self._sequence_counter += 1
                sequence_id = self._sequence_counter
            
            result = FusionResult(
                timestamp=time.time(),
                emotion=emotion,
                confidence=confidence,
                sources=synchronized,
                fusion_method=self.feature_fusion.fusion_mode,
                sequence_id=sequence_id
            )
            
            # 调用回调函数
            with self._lock:
                callbacks = self._callbacks.copy()
            
            for callback in callbacks:
                try:
                    self.logger.info(f"🔔 触发融合回调: emotion={result.emotion}, confidence={result.confidence:.2f}")
                    callback(result)
                except Exception as e:
                    self.logger.error(f"融合回调执行失败: {e}")
        
        except Exception as e:
            self.logger.error(f"融合处理失败: {e}")
    
    def register_callback(self, callback: Callable[[FusionResult], None]):
        """
        注册融合结果回调
        
        Args:
            callback: 回调函数
        """
        with self._lock:
            if callback not in self._callbacks:
                self._callbacks.append(callback)
    
    def unregister_callback(self, callback: Callable[[FusionResult], None]):
        """
        取消注册融合结果回调
        
        Args:
            callback: 回调函数
        """
        with self._lock:
            if callback in self._callbacks:
                self._callbacks.remove(callback)
    
    def clear(self):
        """清空所有数据"""
        self.synchronizer.clear()
        with self._lock:
            self._callbacks.clear()

