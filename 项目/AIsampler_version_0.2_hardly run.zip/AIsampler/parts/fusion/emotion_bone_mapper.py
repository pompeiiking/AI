#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
情绪到骨骼映射器
将融合后的情绪/意图映射到Blender骨骼动作
"""

import logging
import yaml
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 添加项目路径
from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)
config_loader = get_config_loader()


@dataclass
class BonePose:
    """骨骼姿势数据类"""
    bone_name: str
    position: List[float]
    rotation: List[float]
    scale: Optional[List[float]] = None


@dataclass
class EmotionMapping:
    """情绪映射配置"""
    emotion: str
    bone_poses: List[BonePose]
    intensity_scale: float = 1.0  # 强度缩放因子


class EmotionToBoneMapper:
    """
    情绪到骨骼映射器
    将情绪/意图转换为Blender骨骼参数，实现平滑过渡
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, 
                 mapping_file: Optional[str] = None):
        """
        初始化情绪到骨骼映射器
        
        Args:
            config: 配置字典
            mapping_file: 映射配置文件路径（YAML格式）
        """
        # 初始化日志（避免重复配置）
        self.logger = logging.getLogger(__name__)
        
        # 加载配置
        if config is None:
            config = {}
        
        self.config = config
        
        # 情绪-动作映射表
        self.emotion_mappings: Dict[str, EmotionMapping] = {}
        
        # 当前骨骼状态（用于平滑过渡）
        self.current_bone_states: Dict[str, BonePose] = {}
        
        # 平滑过渡参数
        self.smoothing_factor = config.get('smoothing_factor', 0.3)  # 0-1，越大越平滑
        self.transition_duration = config.get('transition_duration', 0.5)  # 过渡时长（秒）
        
        # 加载映射文件
        if mapping_file:
            self.load_mapping_file(mapping_file)
        else:
            # 使用默认映射
            self._load_default_mappings()
    
    def load_mapping_file(self, file_path: str) -> bool:
        """
        从YAML文件加载映射配置
        
        Args:
            file_path: 配置文件路径
            
        Returns:
            bool: 是否加载成功
        """
        try:
            if not os.path.exists(file_path):
                self.logger.warning(f"映射文件不存在: {file_path}，使用默认映射")
                self._load_default_mappings()
                return False
            
            with open(file_path, 'r', encoding='utf-8') as f:
                mapping_data = yaml.safe_load(f)
            
            # 解析映射数据
            for emotion_name, emotion_config in mapping_data.items():
                bone_poses = []
                
                for bone_config in emotion_config.get('bones', []):
                    bone_pose = BonePose(
                        bone_name=bone_config['name'],
                        position=bone_config.get('position', [0.0, 0.0, 0.0]),
                        rotation=bone_config.get('rotation', [0.0, 0.0, 0.0]),
                        scale=bone_config.get('scale')
                    )
                    bone_poses.append(bone_pose)
                
                mapping = EmotionMapping(
                    emotion=emotion_name,
                    bone_poses=bone_poses,
                    intensity_scale=emotion_config.get('intensity_scale', 1.0)
                )
                
                self.emotion_mappings[emotion_name] = mapping
            
            self.logger.info(f"成功加载映射文件: {file_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"加载映射文件失败: {e}")
            self._load_default_mappings()
            return False
    
    def _load_default_mappings(self):
        """加载默认映射配置 - 支持多种骨架"""
        # 默认情绪-骨骼映射（兼容rig和Armature_Old骨架）
        # rig骨架关键骨骼: c_head.x, c_spine_01.x, c_shoulder.l, c_shoulder.r
        # Armature_Old骨架: Head, Spine, Shoulder_L, Shoulder_R
        default_mappings = {
            'happy': {
                'bones': [
                    # 尝试rig骨架的骨骼名称（增大幅度3倍）
                    {'name': 'c_head.x', 'rotation': [0.3, 0.0, 0.45]},  # 头部明显上扬
                    {'name': 'c_spine_01.x', 'rotation': [0.15, 0.0, 0.0]},  # 脊柱挺直
                    {'name': 'c_shoulder.l', 'rotation': [0.0, 0.0, -0.6]},  # 左肩放松
                    {'name': 'c_shoulder.r', 'rotation': [0.0, 0.0, 0.6]},   # 右肩放松
                    # 备用：Armature_Old骨架的骨骼名称
                    {'name': 'Head', 'rotation': [0.3, 0.0, 0.45]},
                    {'name': 'Spine', 'rotation': [0.15, 0.0, 0.0]},
                    {'name': 'Shoulder_L', 'rotation': [0.0, 0.0, -0.6]},
                    {'name': 'Shoulder_R', 'rotation': [0.0, 0.0, 0.6]},
                ],
                'intensity_scale': 3.0  # 增大整体强度
            },
            'sad': {
                'bones': [
                    {'name': 'c_head.x', 'rotation': [-0.45, 0.0, 0.0]},  # 头部明显低垂
                    {'name': 'c_spine_01.x', 'rotation': [-0.3, 0.0, 0.0]},  # 脊柱弯曲
                    {'name': 'c_shoulder.l', 'rotation': [0.3, 0.0, 0.45]},  # 双肩耸起
                    {'name': 'c_shoulder.r', 'rotation': [0.3, 0.0, -0.45]},
                    {'name': 'Head', 'rotation': [-0.45, 0.0, 0.0]},
                    {'name': 'Spine', 'rotation': [-0.3, 0.0, 0.0]},
                    {'name': 'Shoulder_L', 'rotation': [0.3, 0.0, 0.45]},
                    {'name': 'Shoulder_R', 'rotation': [0.3, 0.0, -0.45]},
                ],
                'intensity_scale': 2.4  # 增大强度
            },
            'angry': {
                'bones': [
                    {'name': 'c_head.x', 'rotation': [0.15, 0.0, 0.0]},  # 头部前倾
                    {'name': 'c_spine_01.x', 'rotation': [0.15, 0.0, 0.0]},  # 身体前倾
                    {'name': 'c_shoulder.l', 'rotation': [0.45, 0.0, 0.9]},  # 左肩紧张
                    {'name': 'c_shoulder.r', 'rotation': [0.45, 0.0, -0.9]},  # 右肩紧张
                    {'name': 'Head', 'rotation': [0.15, 0.0, 0.0]},
                    {'name': 'Spine', 'rotation': [0.15, 0.0, 0.0]},
                    {'name': 'Shoulder_L', 'rotation': [0.45, 0.0, 0.9]},
                    {'name': 'Shoulder_R', 'rotation': [0.45, 0.0, -0.9]},
                ],
                'intensity_scale': 3.6  # 增大强度
            },
            'surprise': {
                'bones': [
                    {'name': 'Head', 'rotation': [0.2, 0.0, 0.0]},   # 头部后仰
                    {'name': 'Spine', 'rotation': [-0.05, 0.0, 0.0]}, # 身体略后倾
                    {'name': 'Shoulder_L', 'rotation': [-0.1, 0.0, -0.15]},
                    {'name': 'Shoulder_R', 'rotation': [-0.1, 0.0, 0.15]},
                ],
                'intensity_scale': 1.1
            },
            'neutral': {
                'bones': [
                    {'name': 'c_head.x', 'rotation': [0.0, 0.0, 0.0]},
                    {'name': 'c_spine_01.x', 'rotation': [0.0, 0.0, 0.0]},
                    {'name': 'c_shoulder.l', 'rotation': [0.0, 0.0, 0.0]},
                    {'name': 'c_shoulder.r', 'rotation': [0.0, 0.0, 0.0]},
                    {'name': 'Head', 'rotation': [0.0, 0.0, 0.0]},
                    {'name': 'Spine', 'rotation': [0.0, 0.0, 0.0]},
                    {'name': 'Shoulder_L', 'rotation': [0.0, 0.0, 0.0]},
                    {'name': 'Shoulder_R', 'rotation': [0.0, 0.0, 0.0]},
                ],
                'intensity_scale': 1.0
            },
            'fear': {
                'bones': [
                    {'name': 'Head', 'rotation': [-0.1, 0.0, 0.0]},
                    {'name': 'Spine', 'rotation': [-0.15, 0.0, 0.0]},  # 身体收缩
                    {'name': 'Shoulder_L', 'rotation': [0.2, 0.0, 0.2]},
                    {'name': 'Shoulder_R', 'rotation': [0.2, 0.0, -0.2]},
                ],
                'intensity_scale': 0.9
            },
            'disgust': {
                'bones': [
                    {'name': 'Head', 'rotation': [0.0, 0.1, -0.15]},  # 头部偏转
                    {'name': 'Spine', 'rotation': [0.0, 0.0, -0.05]},
                    {'name': 'Shoulder_L', 'rotation': [0.1, 0.0, 0.1]},
                    {'name': 'Shoulder_R', 'rotation': [0.1, 0.0, -0.1]},
                ],
                'intensity_scale': 0.9
            }
        }
        
        for emotion_name, emotion_config in default_mappings.items():
            bone_poses = []
            
            for bone_config in emotion_config['bones']:
                bone_pose = BonePose(
                    bone_name=bone_config['name'],
                    position=bone_config.get('position', [0.0, 0.0, 0.0]),
                    rotation=bone_config.get('rotation', [0.0, 0.0, 0.0]),
                    scale=bone_config.get('scale')
                )
                bone_poses.append(bone_pose)
            
            mapping = EmotionMapping(
                emotion=emotion_name,
                bone_poses=bone_poses,
                intensity_scale=emotion_config['intensity_scale']
            )
            
            self.emotion_mappings[emotion_name] = mapping
        
        self.logger.info("已加载默认情绪-骨骼映射")
    
    def map_emotion_to_bones(self, emotion: str, confidence: float = 1.0) -> List[BonePose]:
        """
        将情绪映射到骨骼姿势
        
        Args:
            emotion: 情绪类型
            confidence: 置信度（0.0-1.0），用于调整动作幅度
            
        Returns:
            List[BonePose]: 骨骼姿势列表
        """
        # 获取情绪映射
        if emotion not in self.emotion_mappings:
            self.logger.warning(f"未知情绪: {emotion}，使用neutral")
            emotion = 'neutral'
        
        mapping = self.emotion_mappings[emotion]
        
        # 计算强度缩放（基于置信度和映射的强度缩放因子）
        intensity = confidence * mapping.intensity_scale
        
        # 生成骨骼姿势
        bone_poses = []
        
        for bone_pose_template in mapping.bone_poses:
            # 应用强度缩放
            position = [p * intensity for p in bone_pose_template.position]
            rotation = [r * intensity for r in bone_pose_template.rotation]
            scale = bone_pose_template.scale
            
            # 平滑过渡
            if bone_pose_template.bone_name in self.current_bone_states:
                current_pose = self.current_bone_states[bone_pose_template.bone_name]
                position = self._smooth_transition(current_pose.position, position)
                rotation = self._smooth_transition(current_pose.rotation, rotation)
            
            bone_pose = BonePose(
                bone_name=bone_pose_template.bone_name,
                position=position,
                rotation=rotation,
                scale=scale
            )
            
            bone_poses.append(bone_pose)
            
            # 更新当前状态
            self.current_bone_states[bone_pose_template.bone_name] = bone_pose
        
        return bone_poses
    
    def _smooth_transition(self, current: List[float], target: List[float]) -> List[float]:
        """
        平滑过渡
        
        Args:
            current: 当前值
            target: 目标值
            
        Returns:
            List[float]: 过渡后的值
        """
        if len(current) != len(target):
            return target
        
        # 线性插值
        result = []
        for c, t in zip(current, target):
            # 使用平滑因子进行插值
            new_value = c * (1 - self.smoothing_factor) + t * self.smoothing_factor
            result.append(new_value)
        
        return result
    
    def reset(self):
        """重置当前骨骼状态"""
        self.current_bone_states.clear()
        self.logger.info("已重置骨骼状态")
    
    def get_bone_pose_dict(self, emotion: str, confidence: float = 1.0) -> Dict[str, Dict[str, Any]]:
        """
        获取骨骼姿势字典（用于Blender更新）
        
        Args:
            emotion: 情绪类型
            confidence: 置信度
            
        Returns:
            Dict[str, Dict[str, Any]]: 骨骼姿势字典，键为骨骼名称，值为姿势信息
        """
        bone_poses = self.map_emotion_to_bones(emotion, confidence)
        
        result = {}
        for bone_pose in bone_poses:
            result[bone_pose.bone_name] = {
                'position': bone_pose.position,
                'rotation': bone_pose.rotation,
                'scale': bone_pose.scale
            }
        
        return result

