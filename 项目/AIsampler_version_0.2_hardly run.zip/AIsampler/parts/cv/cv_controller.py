#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CV控制器
计算机视觉模块，负责表情识别和人脸检测
"""

import cv2
import numpy as np
from modelscope import snapshot_download
from typing import Dict, Any, List, Tuple, Optional, Callable
import torch
from PIL import Image
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 添加项目路径
from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)
config_loader = get_config_loader()

class CVController:
    def __init__(self, config: Dict[str, Any] = None):
        """
        初始化CV控制器
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
        """
        # 初始化日志
        import logging
        self.logger = logging.getLogger(__name__)
        
        # 加载配置
        if config is None:
            config = config_loader.get_cv_config()
        self.config = config
        
        #模型初始化
        self.model_dir = None
        self.model = None
        self.model_type = None  # 'pytorch' 或 'onnx'
        self.device = None

        #摄像头初始化
        self.cap = None
        self.is_running = False
        self.frame_counter = 0
        self.debug_mode = False  # 调试模式
        # 从配置中读取参数
        self.confidence_threshold = self.config.get('emotion_recognition', {}).get('confidence_threshold', 0.5)
        self.face_cascade = None
        
        # 人脸检测配置
        face_detection_config = self.config.get('face_detection', {})
        self.scale_factor = face_detection_config.get('scale_factor', 1.1)
        self.min_neighbors = face_detection_config.get('min_neighbors', 5)
        self.min_size = tuple(face_detection_config.get('min_size', [30, 30]))
        
        # 流式处理配置
        processing_config = self.config.get('processing', {})
        self.frame_skip = processing_config.get('frame_skip', 2)  # 每几帧处理一次
        self.frame_counter = 0  # 帧计数器

    def initialize_models(self):
        #表情识别模型和人脸检测器初始化
        try:
            # 从配置中读取模型设置
            emotion_config = self.config.get('emotion_recognition', {})
            model_name = emotion_config.get('model_name', "yikshing/emotion_ferplus")
            device_config = emotion_config.get('device', "cpu")
            
            # 性能配置
            performance_config = self.config.get('performance', {})
            enable_gpu = performance_config.get('enable_gpu', False)
            
            # 下载模型
            self.model_dir = snapshot_download(model_name)
            self.logger.info(f"表情识别模型下载完成，路径: {self.model_dir}")

            # 查找模型文件（支持.pth和.onnx格式）
            model_path = None
            model_files = ['model.pth', 'model.pt', 'model.onnx', 'emotion-ferplus-8.onnx']
            
            for model_file in model_files:
                candidate_path = os.path.join(self.model_dir, model_file)
                if os.path.exists(candidate_path):
                    model_path = candidate_path
                    self.logger.info(f"找到模型文件: {model_file}")
                    break
            
            if not model_path:
                # 列出目录内容以便调试
                available_files = os.listdir(self.model_dir)
                self.logger.error(f"未找到模型文件，目录内容: {available_files}")
                raise FileNotFoundError(f"在 {self.model_dir} 中未找到模型文件（尝试: {model_files}）")
            
            # 根据文件格式加载模型
            if model_path.endswith('.onnx'):
                # ONNX格式模型（需要onnxruntime）
                try:
                    import onnxruntime as ort
                    providers = ['CUDAExecutionProvider', 'CPUExecutionProvider'] if enable_gpu and torch.cuda.is_available() else ['CPUExecutionProvider']
                    self.model = ort.InferenceSession(model_path, providers=providers)
                    self.model_type = 'onnx'
                    self.logger.info("使用ONNX Runtime加载模型")
                except ImportError:
                    self.logger.error("ONNX模型需要onnxruntime包，请安装: pip install onnxruntime")
                    raise
            else:
                # PyTorch格式模型
                if enable_gpu and torch.cuda.is_available():
                    map_location = 'cuda'
                else:
                    map_location = 'cpu'
                
                self.model = torch.load(model_path, map_location=map_location)
                if hasattr(self.model, 'eval'):
                    self.model.eval()
                self.model_type = 'pytorch'
                self.logger.info("使用PyTorch加载模型")

            # 初始化人脸检测器
            self.face_cascade = cv2.CascadeClassifier(
                cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
            )

            # 确定设备
            if device_config == "cuda" and torch.cuda.is_available() and enable_gpu:
                self.device = torch.device("cuda")
            else:
                self.device = torch.device("cpu")
            
            self.logger.info(f"使用设备：{self.device}")

        except Exception as e:
            self.logger.error(f"模型初始化失败: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return False
        return True

    def start_camera(self, camera_id: int = None):
        #摄像头启动
        # 从配置中读取摄像头设置
        camera_config = self.config.get('camera', {})
        if camera_id is None:
            camera_id = camera_config.get('device_id', 0)
        
        width = camera_config.get('width', 640)
        height = camera_config.get('height', 480)
        fps = camera_config.get('fps', 30)
        
        self.cap = cv2.VideoCapture(camera_id)
        if not self.cap.isOpened():
            raise RuntimeError(f"无法打开摄像头 {camera_id}")

        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS, fps)

        self.is_running = True
        self.logger.info(f"摄像头启动成功，设备ID: {camera_id}, 分辨率: {width}x{height}, 帧率: {fps}")

    def stop_camera(self):
        """停止摄像头"""
        if self.cap:
            self.cap.release()
            cv2.destroyAllWindows()
            self.is_running = False
            self.logger.info("摄像头已停止")

    def process_frame(self,frame: np.ndarray) -> dict[str, Any]:
        #单帧处理的总流程：
        result = {
            'emotion' : 'neutral',
            'confidence' : 0.0,
            'face_detected' : False,
            'face_positions' : None
        }

        face_info = self.detect_face(frame)

        if face_info:
            x,y,w,h = face_info
            result["face_detected"] = True
            result["face_positions"] = (x,y,w,h)

            face_roi = frame[y:y+h, x:x+w]

            emotion, confidence = self.recognize_emotion(face_roi)
            result["emotion"] = emotion
            result["confidence"] = confidence

            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
            cv2.putText(frame, f"Emotion: {emotion} ({confidence:.2f})", (x, y-10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
        
        return result

    def detect_face(self, frame: np.ndarray) -> Optional[tuple]:
        #人脸检测
        gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(
            gray,
            scaleFactor=self.scale_factor,
            minNeighbors=self.min_neighbors,
            minSize=self.min_size
        )

        if len(faces) > 0:
            x,y,w,h = max(faces,key = lambda face: face[2] * face[3])
            return (x,y,w,h)
        return None

    def recognize_emotion(self, frame: np.ndarray) -> Tuple[str, float]:
        try:
            # 图像预处理
            target_size = self.config.get('emotion_recognition', {}).get('input_size', 64)
            face_resized = cv2.resize(frame, (target_size, target_size))
            face_gray = cv2.cvtColor(face_resized, cv2.COLOR_BGR2GRAY)

            # 归一化
            face_normalized = face_gray.astype(np.float32) / 255.0

            # 模型推理
            if hasattr(self, 'model_type') and self.model_type == 'onnx':
                # ONNX模型推理
                # 准备输入（ONNX通常需要特定的输入格式）
                face_input = face_normalized.reshape(1, 1, target_size, target_size).astype(np.float32)
                
                # 获取输入名称
                input_name = self.model.get_inputs()[0].name
                outputs = self.model.run(None, {input_name: face_input})
                predictions = outputs[0]
                
                # 计算softmax
                exp_predictions = np.exp(predictions - np.max(predictions))
                emotion_prons = exp_predictions / np.sum(exp_predictions)
                
                # 获取最高置信度情感
                emotion_idx = int(np.argmax(emotion_prons))
                confidence = float(emotion_prons[0][emotion_idx])
            else:
                # PyTorch模型推理
                face_tensor = torch.tensor(face_normalized).unsqueeze(0).unsqueeze(0)
                face_tensor = face_tensor.to(self.device)

                with torch.no_grad():
                    predictions = self.model(face_tensor)
                    emotion_prons = torch.softmax(predictions, dim=1)

                # 获取最高置信度情感
                emotion_idx = torch.argmax(emotion_prons, dim=1).item()
                confidence = emotion_prons[0][emotion_idx].item()

            # 表情标签映射（FER+标准顺序）
            # 注意：不同模型可能有不同的顺序
            emotion_labels = ['neutral', 'happiness', 'surprise', 'sadness', 'anger', 'disgust', 'fear', 'contempt']
            
            # 调试信息：输出所有概率
            if hasattr(self, 'debug_mode') and self.debug_mode:
                # 转换概率为numpy array以便处理
                if hasattr(emotion_prons, 'cpu'):  # PyTorch tensor
                    prob_array = emotion_prons[0].cpu().numpy()
                else:  # numpy array
                    prob_array = emotion_prons[0] if len(emotion_prons.shape) > 1 else emotion_prons
                
                prob_dict = {emotion_labels[i]: float(prob_array[i]) for i in range(min(len(emotion_labels), len(prob_array)))}
                self.logger.info(f"🔍 情感概率: {prob_dict}")
                self.logger.info(f"✅ 选择: 索引={emotion_idx}, 情感={emotion_labels[emotion_idx]}, 置信度={confidence:.2%}")
            
            emotion = emotion_labels[emotion_idx] if emotion_idx < len(emotion_labels) else 'neutral'

            # 如果置信度低于阈值，返回neutral
            if confidence < self.confidence_threshold:
                return ('neutral', confidence)
            
            return (emotion, confidence)

        except Exception as e:
            self.logger.error(f"表情识别失败：{e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return ('neutral', 0.0)

    def cv(self, callback: Optional[Callable[[Dict[str, Any]], None]] = None, show_window: bool = False):
        """
        流式处理视频流
        
        Args:
            callback: 可选的回调函数，接收处理结果作为参数
            show_window: 是否显示视频窗口
        
        Returns:
            处理结果字典
        """
        # 确保摄像头已启动
        if not self.is_running or self.cap is None:
            self.logger.warning("摄像头未启动，正在启动摄像头...")
            self.start_camera()
        
        # 确保模型已初始化（使用缓存避免重复初始化）
        if self.model is None or self.face_cascade is None:
            self.logger.warning("模型未初始化，正在初始化模型...")
            if not self.initialize_models():
                raise RuntimeError("模型初始化失败，无法进行流式处理")
        
        self.logger.info("视觉识别已开启，正在处理视频流...")
        self.frame_counter = 0
        
        try:
            while self.is_running:
                ret, frame = self.cap.read()
                if not ret:
                    self.logger.warning("无法读取摄像头帧")
                    break
                
                # 帧跳过逻辑：每frame_skip帧处理一次
                self.frame_counter += 1
                should_process = (self.frame_counter % self.frame_skip == 0)
                
                # 处理当前帧（根据frame_skip配置）
                if should_process:
                    result = self.process_frame(frame)
                    
                    # 打印结果
                    if result['face_detected']:
                        self.logger.debug(f"检测到人脸: {result['emotion']} (置信度: {result['confidence']:.2f})")
                else:
                    # 不处理时使用默认结果，但保持显示流畅
                    result = {
                        'emotion': 'neutral',
                        'confidence': 0.0,
                        'face_detected': False,
                        'face_positions': None
                    }
                
                # 调用回调函数（如果提供）- 每帧都调用，确保数据流连续
                if callback:
                    callback(result)
                
                # 显示当前帧（处理后的帧已包含标注）
                if show_window:
                    try:
                        cv2.imshow('CV Stream', frame)
                        # 按 'q' 键退出
                        if cv2.waitKey(1) & 0xFF == ord('q'):
                            self.logger.info("用户按下 'q' 键，退出流式处理")
                            break
                    except cv2.error as e:
                        # 无GUI环境，禁用窗口显示
                        self.logger.warning(f"无法显示窗口: {e}，禁用窗口显示")
                        show_window = False
                    except Exception as e:
                        self.logger.warning(f"窗口显示错误: {e}，禁用窗口显示")
                        show_window = False
        except KeyboardInterrupt:
            self.logger.info("收到中断信号，停止流式处理")
        finally:
            # 清理窗口
            if show_window:
                try:
                    cv2.destroyAllWindows()
                except:
                    pass  # 忽略窗口清理错误
        
        return result if 'result' in locals() else {
            'emotion': 'neutral',
            'confidence': 0.0,
            'face_detected': False,
            'face_positions': None
        }