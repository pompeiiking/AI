import numpy as np
import os
import sys

# 禁用FunASR的进度条输出
os.environ['FUNASR_DISABLE_PBAR'] = '1'
os.environ['FUNASR_DISABLE_LOG'] = '1'

from funasr import AutoModel
from typing import Dict, Any, Optional

class ASR:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化ASR模块
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
        """
        # 加载配置
        if config is None:
            from utils.path_utils import setup_project_path, get_config_loader
            setup_project_path(__file__)
            config_loader = get_config_loader()
            stt_config = config_loader.get_stt_config()
            config = stt_config.get('asr', {})
        
        self.config = config
        self.asr_cache = {}
        
        # 从配置中读取参数
        model_name = config.get('model', "paraformer-zh-streaming")
        device = config.get('device', "cuda")
        disable_update = config.get('disable_update', True)
        trust_remote_code = config.get('trust_remote_code', False)
        
        self.model = AutoModel(
            model=model_name,
            device=device,
            disable_update=disable_update,
            trust_remote_code=trust_remote_code
        )
        
        # 保存流式识别参数
        self.chunk_size = config.get('chunk_size', [5, 10, 5])  # 流式chunk配置
        self.chunk_interval = config.get('chunk_interval', 10)
    
    def audio_trans(self, audio_data, is_final):
        """音频转换（支持流式识别）"""
        # 合并音频数据
        concat_audio = np.concatenate(audio_data)
        
        # 转换为 float32 [-1, 1]
        if concat_audio.dtype == np.int16:
            audio_float = concat_audio.astype(np.float32) / 32768.0
        else:
            audio_float = concat_audio.astype(np.float32)
        
        # 调用模型
        result = self.model.generate(
            input=audio_float,
            is_final=is_final,
            chunk_size=[5, 10, 5],  # 流式识别的chunk配置
            chunk_interval=self.chunk_interval,
            cache=self.asr_cache
        )
        
        # 解析结果（只返回新增的文本）
        if isinstance(result, list) and len(result) > 0:
            if isinstance(result[0], dict) and 'text' in result[0]:
                text = result[0]['text']
                # 最终结果时清理cache
                if is_final:
                    self.asr_cache = {}
                return text
        return ""

    def reset_cache(self):
        """重置cache"""
        self.asr_cache = {}
