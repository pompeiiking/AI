#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FunASR VAD 适配器
提供与 TenVad 兼容的接口
"""

import numpy as np
import os

# 禁用进度条
os.environ['FUNASR_DISABLE_PBAR'] = '1'
os.environ['FUNASR_DISABLE_LOG'] = '1'

from funasr import AutoModel
from typing import Optional


class FunasrVAD:
    """FunASR VAD 适配器，提供与 TenVad 兼容的接口"""
    
    def __init__(self, threshold=0.5, sample_rate=16000, hop_size=512):
        """
        初始化 FunASR VAD 模型
        
        Args:
            threshold: VAD 检测阈值 (0-1)
            sample_rate: 音频采样率
            hop_size: 跳跃大小（为兼容性保留）
        """
        self.threshold = threshold
        self.sample_rate = sample_rate
        self.vad_model = AutoModel(
            model="fsmn-vad",
            device="cuda",
            disable_update=True,
            trust_remote_code=False
        )
        self.audio_buffer = []
        self.buffer_duration = 0.2  # 缓冲 200ms 音频
        self.buffer_size = int(self.sample_rate * self.buffer_duration)
        self.last_speech_state = 0
        self.silence_cnt = 0
        
    def process(self, audio_chunk):
        """
        处理音频块并返回 VAD 结果
        
        Args:
            audio_chunk: int16 音频数据 (1D numpy array)
            
        Returns:
            bool: 是否为语音 (True=语音, False=静音)
        """
        # 将音频块添加到缓冲区
        self.audio_buffer.append(audio_chunk)
        
        # 计算当前缓冲区大小
        current_buffer_size = sum(len(chunk) for chunk in self.audio_buffer)
        
        # 如果缓冲区未满，返回上一次的状态
        if current_buffer_size < self.buffer_size:
            return self.last_speech_state == 1
        
        # 合并缓冲区音频
        combined_audio = np.concatenate(self.audio_buffer)
        
        # 转换为 float32 [-1, 1]
        if combined_audio.dtype == np.int16:
            audio_float = combined_audio.astype(np.float32) / 32768.0
        else:
            audio_float = combined_audio.astype(np.float32)
        
        try:
            # 调用 VAD 模型
            vad_result = self.vad_model.generate(
                input=audio_float,
                cache={},
                is_final=True
            )
            
            # 解析 VAD 结果
            speech_flag = 0
            
            if vad_result:
                if isinstance(vad_result, list) and len(vad_result) > 0:
                    first_result = vad_result[0]
                    if isinstance(first_result, dict):
                        # 检查是否有语音段
                        if 'value' in first_result and first_result['value']:
                            speech_flag = 1
                        elif 'text' in first_result and first_result['text']:
                            speech_flag = 1
                        elif any(key in first_result for key in ['start', 'end', 'duration']):
                            speech_flag = 1
                    elif isinstance(vad_result[0], (list, tuple)) and len(vad_result[0]) > 0:
                        speech_flag = 1
                        
            # 更新状态
            self.last_speech_state = speech_flag
            
            # 清空缓冲区，只保留最新的部分（用于滑动窗口）
            overlap_size = self.buffer_size // 2
            self.audio_buffer = [combined_audio[-overlap_size:]]
            
            return speech_flag == 1
            
        except Exception as e:
            # VAD 检测失败，返回默认值
            return self.last_speech_state == 1
    
    def update_silence_cnt(self, is_speech):
        """更新静音计数"""
        if is_speech:
            self.silence_cnt = 0
        else:
            self.silence_cnt += 1
    
    def is_speech_end(self, max_silence_cnt=8):
        """判断语音是否结束"""
        return self.silence_cnt >= max_silence_cnt
