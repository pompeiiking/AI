#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STT控制器
语音识别控制器，整合VAD和ASR模块
"""

import os
import sys
import sounddevice as sd
import numpy as np
import time
import logging
from typing import Dict, Any, Optional
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 添加项目路径
from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)

# 使用相对导入
from .funasr_vad import FunasrVAD
from .asr import ASR

class STTController:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化STT控制器
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
        """
        self.logger = logging.getLogger(__name__)
        
        # 加载配置
        if config is None:
            config_loader = get_config_loader()
            config = config_loader.get_stt_config()
        
        self.config = config
        
        # 使用 FunASR VAD（按照stream_stt.py设置）
        vad_config = config.get('vad', {})
        self.vad = FunasrVAD(
            threshold=vad_config.get('threshold', 0.5),  # stream_stt.py默认0.5
            sample_rate=16000,
            hop_size=vad_config.get('hop_size', 512)
        )
        self.max_silence_cnt = vad_config.get('max_silence_cnt', 10)  # stream_stt.py默认10
        
        self.asr = ASR(config.get('asr', {}))
        self.audio_result = []
        
        # 从配置中读取录音参数
        recording_config = config.get('recording', {})
        self.frames = recording_config.get('frames', 512)
        self.samplerate = recording_config.get('samplerate', 16000)
        self.channels = recording_config.get('channels', 1)
        self.dtype = recording_config.get('dtype', 'int16')
        self.device = recording_config.get('device', None)
        
        # 流管理（关键改进：使用持续流）
        self.stream = None
        self.is_initialized = False
        
        # 预热参数（完全按照stream_stt.py）
        self.warmup_iters = 120  # ~4秒预热（stream_stt.py的设置）
        self.warmup_counter = 0
        
        # 错误处理
        self.consecutive_read_errors = 0
        self.max_consecutive_errors = 50

    def _select_best_device(self):
        """智能选择最佳音频设备（借鉴stream_stt.py）"""
        try:
            devices = sd.query_devices()
            input_indices = [idx for idx, d in enumerate(devices) if d.get('max_input_channels', 0) > 0]
            
            if not input_indices:
                self.logger.error("未发现可用麦克风输入设备")
                return None
            
            # 检查兼容性
            compatible_indices = []
            for idx in input_indices:
                try:
                    sd.check_input_settings(device=idx, samplerate=16000, channels=1, dtype='int16')
                    compatible_indices.append(idx)
                except:
                    pass
            
            if not compatible_indices:
                return None
            
            # 优先硬件设备
            def is_hardware(name):
                n = name.lower()
                return not any(k in n for k in ['mapper', 'speaker', 'loopback', 'default'])
            
            hardware = [i for i in compatible_indices if is_hardware(str(devices[i]['name']))]
            selected = hardware[0] if hardware else compatible_indices[0]
            
            self.logger.info(f"✓ 选择设备: [{selected}] {devices[selected]['name']}")
            return selected
        except:
            return None
    
    def _init_stream(self):
        """初始化音频流（使用InputStream - 关键改进）"""
        if self.is_initialized and self.stream is not None:
            return True
        
        if self.device is None:
            self.device = self._select_best_device()
            if self.device is None:
                self.logger.error("无法选择可用设备")
                return False
        
        try:
            # 使用InputStream替代sd.rec()（关键改进）
            self.stream = sd.InputStream(
                samplerate=self.samplerate,
                channels=self.channels,
                dtype=self.dtype,
                device=self.device,
                blocksize=self.frames
            )
            self.stream.start()
            time.sleep(0.1)
            self.is_initialized = True
            self.warmup_counter = 0
            self.logger.info("✅ 音频流已启动")
            return True
        except Exception as e:
            self.logger.error(f"初始化失败: {e}")
            return False
    
    def _close_stream(self):
        """关闭音频流"""
        if self.stream:
            try:
                self.stream.stop()
                self.stream.close()
            except:
                pass
            self.stream = None
        self.is_initialized = False
    
    def stt(self):
        """语音识别（使用持续流模式）"""
        if not self._init_stream():
            return None
        
        self.logger.info("语音识别已开启，正在监听...")
        
        try:
            while True:
                # 从流中读取（而非sd.rec）
                try:
                    frames, overflowed = self.stream.read(self.frames)
                    self.consecutive_read_errors = 0
                    audio_data = frames.reshape(-1)
                    
                    # 计算音量
                    audio_float = audio_data.astype(np.float32) / 32768.0
                    rms = float(np.sqrt(np.mean(np.square(audio_float))))
                    
                except Exception as e:
                    self.consecutive_read_errors += 1
                    if self.consecutive_read_errors >= self.max_consecutive_errors:
                        self.logger.error("读取失败次数过多，重新初始化")
                        self._close_stream()
                        if not self._init_stream():
                            return None
                    time.sleep(0.1)
                    continue
                
                # 预热期间跳过
                if self.warmup_counter < self.warmup_iters:
                    self.warmup_counter += 1
                    if self.warmup_counter == 1:
                        self.logger.info("设备预热中...")
                    if self.warmup_counter == self.warmup_iters:
                        self.logger.info("✅ 预热完成")
                    continue
                
                # VAD检测
                is_speech = self.vad.process(audio_data)
                self.vad.update_silence_cnt(is_speech)
                
                if is_speech:
                    self.audio_result.append(audio_data)
                    # 实时识别（减少频率）
                    audio_duration = len(self.audio_result) * self.frames / self.samplerate
                    if len(self.audio_result) % 10 == 0 and audio_duration >= 1.5:
                        try:
                            result = self.asr.audio_trans(self.audio_result, False)
                            if result:
                                self.logger.debug(f"识别中: {result}")
                        except:
                            pass
                else:
                    if self.vad.is_speech_end(self.max_silence_cnt):
                        if len(self.audio_result) > 0:
                            self.logger.info("录音结束，识别中...")
                            try:
                                final_result = self.asr.audio_trans(self.audio_result, True)
                                self.logger.info(f"✅ 识别结果：{final_result}")
                                self.audio_result = []
                                self.asr.reset_cache()
                                return final_result
                            except Exception as e:
                                self.logger.error(f"识别失败: {e}")
                                self.audio_result = []
                                self.asr.reset_cache()
                        else:
                            self.logger.debug("未检测到语音，继续监听...")
                            self.vad.silence_cnt = 0
        except KeyboardInterrupt:
            self.logger.info("用户中断")
        except Exception as e:
            self.logger.error(f"STT异常: {e}")
        finally:
            self._close_stream()
        
        return None
    
    def __del__(self):
        """析构函数"""
        self._close_stream()


