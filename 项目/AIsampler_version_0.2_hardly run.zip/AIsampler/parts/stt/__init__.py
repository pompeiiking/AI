#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STT模块
语音识别模块，包含VAD（语音活动检测）和ASR（自动语音识别）
"""

from .stt_controller import STTController
from .vad import VAD
from .asr import ASR

__all__ = ['STTController', 'VAD', 'ASR']
