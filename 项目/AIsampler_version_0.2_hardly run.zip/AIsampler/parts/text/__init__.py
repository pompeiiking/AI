#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文本输入模块
"""

from .text_controller import TextController

__all__ = ['TextController']
