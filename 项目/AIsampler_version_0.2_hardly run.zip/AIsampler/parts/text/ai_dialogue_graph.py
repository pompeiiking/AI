#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI对话流图系统
基于LangGraph + DeepSeek构建真正的AI情感分析对话流
"""

import logging
import json
from typing import Dict, Any, Optional, List, TypedDict, Annotated
from pathlib import Path
import sys
import operator

PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)

# LangGraph导入
try:
    from langgraph.graph import StateGraph, END
    from langgraph.checkpoint.memory import MemorySaver
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False
    StateGraph = None
    END = None
    MemorySaver = None

# LangChain导入
try:
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
    from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
    LANGCHAIN_AVAILABLE = True
except ImportError:
    try:
        from langchain.chat_models import ChatOpenAI
        from langchain.schema import HumanMessage, AIMessage, SystemMessage
        LANGCHAIN_AVAILABLE = True
    except ImportError:
        LANGCHAIN_AVAILABLE = False
        ChatOpenAI = None


# 定义状态类型
class DialogueState(TypedDict):
    """对话状态"""
    text: str                          # 输入文本
    history: List[Dict[str, str]]      # 对话历史
    emotion: Optional[str]             # 检测的情感
    confidence: Optional[float]        # 置信度
    reasoning: Optional[str]           # 分析理由
    keywords: Optional[List[str]]      # 关键词
    ai_response: Optional[str]         # AI响应
    error: Optional[str]               # 错误信息
    processed: bool                    # 是否已处理


class AIDialogueGraph:
    """
    AI对话流图系统
    使用LangGraph构建状态机，DeepSeek进行真正的AI推理
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化AI对话流图
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
        """
        self.logger = logging.getLogger(__name__)
        
        # 检查依赖
        if not LANGGRAPH_AVAILABLE:
            raise ImportError(
                "LangGraph未安装。请运行: pip install langgraph"
            )
        if not LANGCHAIN_AVAILABLE:
            raise ImportError(
                "LangChain未安装。请运行: pip install langchain langchain-openai"
            )
        
        # 加载配置
        if config is None:
            config_loader = get_config_loader()
            config = config_loader.load_config('text_ai_config')
        self.config = config
        
        # DeepSeek配置
        deepseek_config = self.config.get('deepseek', {})
        self.api_key = deepseek_config.get('api_key', '')
        self.api_base = deepseek_config.get('api_base', 'https://api.deepseek.com/v1')
        self.model_name = deepseek_config.get('model', 'deepseek-chat')
        self.temperature = deepseek_config.get('temperature', 0.7)
        self.max_tokens = deepseek_config.get('max_tokens', 2000)
        
        # 提示词配置
        prompts_config = self.config.get('prompts', {})
        self.system_prompt = prompts_config.get('system_prompt', '')
        self.emotion_analysis_prompt = prompts_config.get('emotion_analysis_prompt', '')
        
        # 对话配置
        conversation_config = self.config.get('langgraph', {}).get('conversation', {})
        self.keep_history = conversation_config.get('keep_history', True)
        self.max_history = conversation_config.get('max_history', 10)
        
        # 初始化LLM
        try:
            self.llm = ChatOpenAI(
                model=self.model_name,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                openai_api_key=self.api_key,
                openai_api_base=self.api_base,
                timeout=deepseek_config.get('timeout', 30)
            )
            self.logger.info(f"DeepSeek LLM初始化成功: {self.model_name}")
        except Exception as e:
            self.logger.error(f"DeepSeek LLM初始化失败: {e}")
            self.llm = None
        
        # 初始化对话历史
        self.conversation_history: List[Dict[str, str]] = []
        
        # 构建LangGraph
        self.graph = self._build_graph()
        self.app = None
        if self.graph:
            # 使用内存检查点
            checkpointer = MemorySaver()
            self.app = self.graph.compile(checkpointer=checkpointer)
            self.logger.info("LangGraph对话流图构建成功")
    
    def _build_graph(self) -> Optional[StateGraph]:
        """构建LangGraph状态图"""
        try:
            # 创建状态图
            workflow = StateGraph(DialogueState)
            
            # 添加节点
            workflow.add_node("input_processing", self._input_processing_node)
            workflow.add_node("emotion_analysis", self._emotion_analysis_node)
            workflow.add_node("output_formatting", self._output_formatting_node)
            
            # 定义边（数据流）
            workflow.set_entry_point("input_processing")
            workflow.add_edge("input_processing", "emotion_analysis")
            workflow.add_edge("emotion_analysis", "output_formatting")
            workflow.add_edge("output_formatting", END)
            
            return workflow
            
        except Exception as e:
            self.logger.error(f"构建LangGraph失败: {e}")
            return None
    
    def _input_processing_node(self, state: DialogueState) -> DialogueState:
        """输入处理节点"""
        self.logger.debug(f"输入处理: {state['text'][:50]}...")
        
        # 清理文本
        text = state['text'].strip()
        
        # 更新状态
        state['text'] = text
        state['processed'] = False
        
        return state
    
    def _emotion_analysis_node(self, state: DialogueState) -> DialogueState:
        """情感分析节点 - 使用DeepSeek AI进行真正的情感分析"""
        text = state['text']
        
        if not self.llm:
            self.logger.error("LLM未初始化，无法进行AI分析")
            state['error'] = "AI模型未初始化"
            state['emotion'] = 'neutral'
            state['confidence'] = 0.3
            return state
        
        try:
            # 构建提示词
            analysis_prompt = f"""请分析以下文本的情感，并以JSON格式返回结果。

文本：{text}

请返回JSON格式，包含以下字段：
- emotion: 情感类型（happy/sad/angry/surprise/fear/neutral）
- confidence: 置信度（0.0-1.0）
- reasoning: 分析理由（简短，20字以内）
- keywords: 关键词列表（最多5个）

只返回JSON，不要其他内容。"""

            # 调用DeepSeek AI
            messages = [
                SystemMessage(content=self.system_prompt),
                HumanMessage(content=analysis_prompt)
            ]
            
            self.logger.info("🤖 调用DeepSeek AI进行情感分析...")
            response = self.llm.invoke(messages)
            ai_response = response.content.strip()
            
            self.logger.debug(f"AI响应: {ai_response}")
            
            # 解析JSON响应
            try:
                # 提取JSON部分（处理可能的markdown包装）
                if '```json' in ai_response:
                    json_str = ai_response.split('```json')[1].split('```')[0].strip()
                elif '```' in ai_response:
                    json_str = ai_response.split('```')[1].strip()
                else:
                    json_str = ai_response
                
                result = json.loads(json_str)
                
                # 更新状态
                state['emotion'] = result.get('emotion', 'neutral')
                state['confidence'] = float(result.get('confidence', 0.5))
                state['reasoning'] = result.get('reasoning', '')
                state['keywords'] = result.get('keywords', [])
                state['ai_response'] = ai_response
                
                self.logger.info(f"✓ AI分析完成: {state['emotion']} ({state['confidence']:.2f})")
                
            except json.JSONDecodeError as e:
                self.logger.warning(f"JSON解析失败: {e}，使用文本分析")
                # 回退：从文本中提取情感
                emotion = self._extract_emotion_from_text(ai_response)
                state['emotion'] = emotion
                state['confidence'] = 0.6
                state['reasoning'] = "基于AI文本分析"
                state['ai_response'] = ai_response
            
            # 添加到历史
            if self.keep_history:
                self._add_to_history(text, state['emotion'], state['confidence'])
            
        except Exception as e:
            self.logger.error(f"AI情感分析失败: {e}")
            state['error'] = str(e)
            state['emotion'] = 'neutral'
            state['confidence'] = 0.3
        
        return state
    
    def _output_formatting_node(self, state: DialogueState) -> DialogueState:
        """输出格式化节点"""
        state['processed'] = True
        
        self.logger.debug(f"输出格式化完成: {state['emotion']} ({state.get('confidence', 0):.2f})")
        
        return state
    
    def _extract_emotion_from_text(self, text: str) -> str:
        """从文本中提取情感（回退方法）"""
        text_lower = text.lower()
        
        emotion_keywords = {
            'happy': ['happy', 'joy', '开心', '快乐', '高兴'],
            'sad': ['sad', 'sorrow', '难过', '悲伤', '低落'],
            'angry': ['angry', 'rage', '生气', '愤怒', '恼火'],
            'surprise': ['surprise', 'shock', '惊讶', '震惊', '意外'],
            'fear': ['fear', 'afraid', '害怕', '恐惧', '担心'],
        }
        
        for emotion, keywords in emotion_keywords.items():
            if any(kw in text_lower for kw in keywords):
                return emotion
        
        return 'neutral'
    
    def _add_to_history(self, text: str, emotion: str, confidence: float):
        """添加到对话历史"""
        self.conversation_history.append({
            'text': text,
            'emotion': emotion,
            'confidence': confidence
        })
        
        # 限制历史长度
        if len(self.conversation_history) > self.max_history:
            self.conversation_history = self.conversation_history[-self.max_history:]
    
    def analyze_emotion(self, text: str) -> Dict[str, Any]:
        """
        分析文本情感（主要接口）
        
        Args:
            text: 输入文本
            
        Returns:
            分析结果字典
        """
        if not self.app:
            self.logger.error("LangGraph应用未初始化")
            return {
                'emotion': 'neutral',
                'confidence': 0.0,
                'error': 'LangGraph未初始化',
                'ai_powered': False
            }
        
        try:
            # 初始化状态
            initial_state: DialogueState = {
                'text': text,
                'history': self.conversation_history.copy(),
                'emotion': None,
                'confidence': None,
                'reasoning': None,
                'keywords': None,
                'ai_response': None,
                'error': None,
                'processed': False
            }
            
            # 运行图
            config = {"configurable": {"thread_id": "default"}}
            result = self.app.invoke(initial_state, config)
            
            # 返回结果
            return {
                'emotion': result.get('emotion', 'neutral'),
                'confidence': result.get('confidence', 0.5),
                'reasoning': result.get('reasoning', ''),
                'keywords': result.get('keywords', []),
                'ai_response': result.get('ai_response', ''),
                'error': result.get('error'),
                'ai_powered': True,  # 标记为AI驱动
                'processed': result.get('processed', False)
            }
            
        except Exception as e:
            self.logger.error(f"情感分析失败: {e}")
            return {
                'emotion': 'neutral',
                'confidence': 0.0,
                'error': str(e),
                'ai_powered': False
            }
    
    def get_conversation_history(self) -> List[Dict[str, str]]:
        """获取对话历史"""
        return self.conversation_history.copy()
    
    def clear_history(self):
        """清空对话历史"""
        self.conversation_history.clear()
        self.logger.info("对话历史已清空")
    
    def test_connection(self) -> bool:
        """测试DeepSeek连接"""
        if not self.llm:
            return False
        
        try:
            test_message = HumanMessage(content="Hello")
            response = self.llm.invoke([test_message])
            self.logger.info(f"DeepSeek连接测试成功: {response.content[:50]}...")
            return True
        except Exception as e:
            self.logger.error(f"DeepSeek连接测试失败: {e}")
            return False
