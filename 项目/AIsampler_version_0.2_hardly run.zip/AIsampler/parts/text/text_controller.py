#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文本输入控制器
实现文本输入的多模态数据采集，支持控制台输入、文件输入、API输入等多种方式
"""

import logging
import threading
import queue
import time
from typing import Dict, Any, Optional, Callable, List
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)

# 尝试导入AI对话图
try:
    from .ai_dialogue_graph import AIDialogueGraph
    AI_DIALOGUE_AVAILABLE = True
except ImportError as e:
    AI_DIALOGUE_AVAILABLE = False
    AIDialogueGraph = None
    import warnings
    warnings.warn(f"AI对话图不可用，将使用关键词匹配: {e}")


class TextController:
    """
    文本输入控制器
    
    功能:
    - 控制台文本输入
    - 文件批量输入
    - API接口输入
    - 情感关键词检测
    - 流式处理回调
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化文本控制器
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
        """
        self.logger = logging.getLogger(__name__)
        
        # 加载配置
        if config is None:
            config_loader = get_config_loader()
            config = config_loader.get_text_config()
        self.config = config
        
        # 输入模式配置
        input_config = self.config.get('input', {})
        self.input_mode = input_config.get('mode', 'console')  # console/file/api/stream
        self.enable_emotion_detection = input_config.get('enable_emotion_detection', True)
        self.min_text_length = input_config.get('min_text_length', 1)
        self.max_text_length = input_config.get('max_text_length', 500)
        
        # 情感关键词配置
        emotion_config = self.config.get('emotion_keywords', {})
        self.emotion_keywords = emotion_config if emotion_config else {
            'happy': ['开心', '高兴', '快乐', '愉快', '太好了', '顺利', '幸福', '喜悦', '兴奋'],
            'sad': ['难过', '低落', '不顺', '伤心', '失望', '沮丧', '郁闷', '痛苦'],
            'angry': ['生气', '愤怒', '不能接受', '气死了', '讨厌', '烦躁', '恼火'],
            'surprise': ['意外', '没想到', '惊讶', '震惊', '不可思议', '天哪'],
            'fear': ['害怕', '恐惧', '担心', '紧张', '焦虑', '不安'],
            'neutral': ['嗯', '好的', '知道了', '明白', '是的', '可以']
        }
        
        # 流式处理
        self.is_running = False
        self._input_queue = queue.Queue(maxsize=100)
        self._thread = None
        
        # 统计信息
        self.total_inputs = 0
        self.last_input_time = None
        
        # 初始化AI对话图（真正的AI模型）
        self.ai_dialogue = None
        self.use_ai_model = self.config.get('use_ai_model', True)
        
        if self.use_ai_model and AI_DIALOGUE_AVAILABLE:
            try:
                self.ai_dialogue = AIDialogueGraph()
                if self.ai_dialogue.test_connection():
                    self.logger.info("✓ AI对话图初始化成功，使用DeepSeek AI进行情感分析")
                else:
                    self.logger.warning("AI连接测试失败，将使用关键词匹配")
                    self.ai_dialogue = None
            except Exception as e:
                self.logger.warning(f"AI对话图初始化失败: {e}，将使用关键词匹配")
                self.ai_dialogue = None
        
        mode_desc = "AI模式" if self.ai_dialogue else "关键词模式"
        self.logger.info(f"TextController初始化完成，输入模式: {self.input_mode}，检测模式: {mode_desc}")
    
    def detect_emotion_from_text(self, text: str) -> tuple[str, float]:
        """
        从文本中检测情感
        
        Args:
            text: 输入文本
            
        Returns:
            tuple: (emotion, confidence)
        """
        if not self.enable_emotion_detection or not text:
            return ('neutral', 0.3)
        
        # 优先使用AI模型
        if self.ai_dialogue:
            try:
                result = self.ai_dialogue.analyze_emotion(text)
                if result.get('ai_powered', False) and not result.get('error'):
                    emotion = result.get('emotion', 'neutral')
                    confidence = result.get('confidence', 0.5)
                    reasoning = result.get('reasoning', '')
                    
                    self.logger.info(f"🤖 AI分析: {emotion} ({confidence:.2f}) - {reasoning}")
                    return (emotion, confidence)
                else:
                    self.logger.warning(f"AI分析失败: {result.get('error')}，使用关键词匹配")
            except Exception as e:
                self.logger.warning(f"AI分析异常: {e}，使用关键词匹配")
        
        # 回退到关键词匹配
        return self._detect_emotion_by_keywords(text)
    
    def _detect_emotion_by_keywords(self, text: str) -> tuple[str, float]:
        """
        基于关键词的情感检测（回退方法）
        
        Args:
            text: 输入文本
            
        Returns:
            tuple: (emotion, confidence)
        """
        # 统计每种情感的匹配得分
        emotion_scores = {}
        text_lower = text.lower()
        
        for emotion, keywords in self.emotion_keywords.items():
            score = 0.0
            matched_keywords = []
            
            for keyword in keywords:
                if keyword in text:
                    score += 1.0
                    matched_keywords.append(keyword)
            
            if score > 0:
                emotion_scores[emotion] = score
                if matched_keywords:
                    self.logger.debug(f"情感 '{emotion}' 匹配关键词: {matched_keywords}")
        
        # 如果没有匹配任何关键词
        if not emotion_scores:
            return ('neutral', 0.3)
        
        # 选择得分最高的情感
        detected_emotion = max(emotion_scores, key=emotion_scores.get)
        max_score = emotion_scores[detected_emotion]
        
        # 计算置信度 (基于匹配数量和文本长度)
        confidence = min(0.5 + (max_score * 0.2), 0.95)
        
        return (detected_emotion, confidence)
    
    def process_text(self, text: str) -> Dict[str, Any]:
        """
        处理单条文本输入
        
        Args:
            text: 输入文本
            
        Returns:
            处理结果字典
        """
        # 文本清理
        text = text.strip()
        
        # 验证文本长度
        if len(text) < self.min_text_length:
            self.logger.warning(f"文本过短（{len(text)}字符），跳过处理")
            return {
                'text': text,
                'emotion': 'neutral',
                'confidence': 0.0,
                'valid': False,
                'reason': 'text_too_short'
            }
        
        if len(text) > self.max_text_length:
            self.logger.warning(f"文本过长（{len(text)}字符），截断到{self.max_text_length}字符")
            text = text[:self.max_text_length]
        
        # 情感检测
        emotion, confidence = self.detect_emotion_from_text(text)
        
        # 更新统计
        self.total_inputs += 1
        self.last_input_time = time.time()
        
        result = {
            'text': text,
            'emotion': emotion,
            'confidence': confidence,
            'timestamp': time.time(),
            'sequence_id': self.total_inputs,
            'valid': True,
            'source': 'text_input',
            'input_mode': self.input_mode
        }
        
        self.logger.info(f"文本处理完成: \"{text[:50]}...\" → {emotion}({confidence:.2f})")
        
        return result
    
    def console_input(self, callback: Optional[Callable[[Dict[str, Any]], None]] = None) -> Dict[str, Any]:
        """
        控制台交互式输入（单次）
        
        Args:
            callback: 可选的回调函数，接收处理结果
            
        Returns:
            处理结果字典
        """
        try:
            print("\n" + "=" * 60)
            print("📝 文本输入模式")
            print("=" * 60)
            print("请输入文本（输入'quit'或'exit'退出）：")
            
            user_input = input("> ").strip()
            
            if user_input.lower() in ['quit', 'exit', 'q']:
                self.logger.info("用户退出文本输入")
                return {
                    'text': '',
                    'emotion': 'neutral',
                    'confidence': 0.0,
                    'valid': False,
                    'reason': 'user_quit'
                }
            
            result = self.process_text(user_input)
            
            # 调用回调
            if callback and result.get('valid', False):
                callback(result)
            
            return result
            
        except KeyboardInterrupt:
            self.logger.info("收到中断信号")
            return {
                'text': '',
                'emotion': 'neutral',
                'confidence': 0.0,
                'valid': False,
                'reason': 'interrupted'
            }
        except Exception as e:
            self.logger.error(f"控制台输入失败: {e}")
            return {
                'text': '',
                'emotion': 'neutral',
                'confidence': 0.0,
                'valid': False,
                'reason': f'error: {e}'
            }
    
    def stream_input(self, callback: Optional[Callable[[Dict[str, Any]], None]] = None):
        """
        流式文本输入（持续运行）
        
        Args:
            callback: 回调函数，接收每次处理结果
        """
        self.is_running = True
        self.logger.info("文本流式输入已启动，等待用户输入...")
        
        print("\n" + "=" * 60)
        print("📝 文本流式输入模式")
        print("=" * 60)
        print("提示:")
        print("  • 输入文本后按回车发送")
        print("  • 输入 'quit' 或 'exit' 退出")
        print("  • 按 Ctrl+C 强制退出")
        print("=" * 60)
        
        try:
            while self.is_running:
                try:
                    user_input = input("\n> ").strip()
                    
                    if user_input.lower() in ['quit', 'exit', 'q']:
                        self.logger.info("用户退出文本输入")
                        break
                    
                    if not user_input:
                        continue
                    
                    result = self.process_text(user_input)
                    
                    # 调用回调
                    if callback and result.get('valid', False):
                        callback(result)
                    
                except EOFError:
                    self.logger.info("输入流结束")
                    break
                    
        except KeyboardInterrupt:
            self.logger.info("收到中断信号，停止文本输入")
        finally:
            self.is_running = False
            self.logger.info("文本流式输入已停止")
    
    def batch_input_from_file(self, file_path: str, 
                              callback: Optional[Callable[[Dict[str, Any]], None]] = None,
                              delay: float = 1.0) -> List[Dict[str, Any]]:
        """
        从文件批量输入文本
        
        Args:
            file_path: 文本文件路径（每行一条文本）
            callback: 可选的回调函数
            delay: 每条文本之间的延迟（秒）
            
        Returns:
            处理结果列表
        """
        results = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            self.logger.info(f"从文件 {file_path} 读取到 {len(lines)} 行文本")
            
            for i, line in enumerate(lines, 1):
                text = line.strip()
                
                if not text or text.startswith('#'):  # 跳过空行和注释
                    continue
                
                self.logger.info(f"处理第 {i}/{len(lines)} 行...")
                result = self.process_text(text)
                results.append(result)
                
                # 调用回调
                if callback and result.get('valid', False):
                    callback(result)
                
                # 延迟
                if delay > 0 and i < len(lines):
                    time.sleep(delay)
            
            self.logger.info(f"批量处理完成，共处理 {len(results)} 条文本")
            return results
            
        except FileNotFoundError:
            self.logger.error(f"文件不存在: {file_path}")
            return []
        except Exception as e:
            self.logger.error(f"批量输入失败: {e}")
            return []
    
    def add_text_async(self, text: str):
        """
        异步添加文本到处理队列
        
        Args:
            text: 输入文本
        """
        try:
            self._input_queue.put_nowait(text)
        except queue.Full:
            self.logger.warning("文本队列已满，丢弃输入")
    
    def start_async_processing(self, callback: Callable[[Dict[str, Any]], None]):
        """
        启动异步文本处理线程
        
        Args:
            callback: 处理结果回调函数
        """
        if self._thread and self._thread.is_alive():
            self.logger.warning("异步处理线程已在运行")
            return
        
        self.is_running = True
        self._thread = threading.Thread(
            target=self._async_worker,
            args=(callback,),
            daemon=True,
            name="TextController-AsyncWorker"
        )
        self._thread.start()
        self.logger.info("异步文本处理线程已启动")
    
    def _async_worker(self, callback: Callable[[Dict[str, Any]], None]):
        """异步处理工作线程"""
        self.logger.info("异步工作线程开始运行")
        
        while self.is_running:
            try:
                # 从队列获取文本（超时1秒）
                text = self._input_queue.get(timeout=1.0)
                
                # 处理文本
                result = self.process_text(text)
                
                # 调用回调
                if result.get('valid', False):
                    callback(result)
                
                self._input_queue.task_done()
                
            except queue.Empty:
                continue
            except Exception as e:
                self.logger.error(f"异步处理失败: {e}")
        
        self.logger.info("异步工作线程已停止")
    
    def stop_async_processing(self):
        """停止异步处理"""
        self.is_running = False
        if self._thread:
            self._thread.join(timeout=2.0)
            self._thread = None
        self.logger.info("异步文本处理已停止")
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        stats = {
            'total_inputs': self.total_inputs,
            'last_input_time': self.last_input_time,
            'queue_size': self._input_queue.qsize() if self._input_queue else 0,
            'is_running': self.is_running,
            'input_mode': self.input_mode,
            'ai_enabled': self.ai_dialogue is not None,
            'detection_mode': 'AI' if self.ai_dialogue else 'Keywords'
        }
        
        # 添加AI对话历史信息
        if self.ai_dialogue:
            stats['conversation_history_length'] = len(self.ai_dialogue.get_conversation_history())
        
        return stats
    
    def __del__(self):
        """析构函数"""
        self.stop_async_processing()
