# 事件队列消费者问题修复

## 问题描述

用户报告事件队列已满：
```
2025-11-19 15:36:53,810 - root - WARNING - 事件队列已满，丢弃事件: cv_result
```

## 根本原因

**事件消费者线程未启动！**

### 原因分析

1. **事件队列架构**：
   ```
   CV/STT/Text → 生产事件 → EventQueue → 消费者线程处理
   ```

2. **消费者启动位置**：
   ```python
   # controller/controller.py 第549-550行
   def start(self):
       # 启动事件处理线程
       self._event_thread = threading.Thread(target=self._event_loop, daemon=True)
       self._event_thread.start()
   ```

3. **问题**：
   - `start_cv_text_ai.py` 只调用了 `main_controller.initialize()`
   - **从未调用 `main_controller.start()`**
   - 导致事件消费者线程 `_event_loop` 永远不会启动
   - 事件不断被生产但无人消费 → 队列满溢

## 修复方案

### 文件：`runner/start_cv_text_ai.py`

#### 1. 启动事件处理循环

```python
# 初始化模块（跳过STT）
if not main_controller.initialize(use_preload=False):
    logger.error("系统初始化失败")
    return 1

print("✓ 系统控制器初始化成功")

# ✅ 新增：启动事件处理循环（重要！）
if not main_controller.start():
    logger.error("❌ 启动事件处理循环失败")
    return 1

print("✓ 事件处理循环已启动")
```

#### 2. 修复全局变量和信号处理

```python
# 全局变量
main_controller = None
running = True

def signal_handler(sig, frame):
    """信号处理器"""
    global running, main_controller
    logger.info("\n\n收到中断信号，正在优雅关闭...")
    running = False
    if main_controller:
        main_controller.stop()  # ✅ 正确停止
    sys.exit(0)

def main():
    """主函数"""
    global main_controller  # ✅ 声明使用全局变量
```

#### 3. 添加清理逻辑

```python
# 保持运行
try:
    while running:
        import time
        time.sleep(1)
except KeyboardInterrupt:
    logger.info("\n收到中断信号...")
finally:
    # ✅ 确保清理
    logger.info("正在关闭系统...")
    if main_controller:
        main_controller.stop()
    logger.info("系统已关闭")
```

## 验证步骤

### 1. 检查事件消费者是否启动

运行后应该看到：
```
✓ 系统控制器初始化成功
✓ 事件处理循环已启动  ← 新增日志
```

### 2. 检查事件队列状态

不应再看到队列满警告：
```
❌ 之前：WARNING - 事件队列已满，丢弃事件: cv_result
✅ 现在：正常处理，无警告
```

### 3. 检查日志

应该看到事件正常处理的日志（如果有回调注册）。

## 技术细节

### MainController 生命周期

```
创建实例 → initialize() → start() → 运行 → stop()
         ↓              ↓         ↓        ↓
         加载配置       启动线程   处理事件  清理资源
                       ├─ 事件消费者
                       ├─ 健康检查
                       └─ CV/STT流
```

### 事件流程

```
1. CV模块检测情感
   ↓
2. 生产事件 → event_queue.put()
   ↓
3. 消费者线程 _event_loop()
   ├─ event_queue.get()
   ├─ _process_event()
   └─ 调用注册的回调
```

## 影响范围

- ✅ `runner/start_cv_text_ai.py` - 已修复
- ⚠️ 其他启动脚本需要检查是否也缺少 `start()` 调用

## 总结

**关键教训**：
- `initialize()` ≠ `start()`
- `initialize()` 只准备资源
- `start()` 才启动工作线程
- 必须调用两者才能正常运行

**修复后流程**：
```python
controller = MainController()
controller.initialize()  # 准备模块
controller.start()       # 启动线程（包括事件消费者）
# ... 系统运行 ...
controller.stop()        # 清理
```

---

**修复时间**: 2025-11-19  
**问题严重性**: 🔴 严重（导致系统无法正常工作）  
**修复难度**: 🟢 简单（添加一行调用）
