#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
完整Pipeline测试 - 包含真实ComfyUI视频生成
测试从CV/Text输入到视频生成的完整流程
"""

import sys
import time
import logging
from pathlib import Path
from typing import Dict, Any
import json

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - [%(levelname)s] - %(name)s - %(message)s'
)

logger = logging.getLogger(__name__)

class FullPipelineTester:
    """完整Pipeline测试器"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.test_results = {}
        self.timeline = []
        
    def print_header(self, title: str):
        print("\n" + "=" * 80)
        print(f"🎬 {title}")
        print("=" * 80)
    
    def print_section(self, title: str):
        print(f"\n【{title}】")
        print("-" * 80)
    
    def log_timeline(self, event: str):
        """记录时间线"""
        timestamp = time.strftime('%H:%M:%S')
        self.timeline.append(f"[{timestamp}] {event}")
        print(f"  ⏱️ [{timestamp}] {event}")
    
    def test_complete_flow(self) -> bool:
        """测试完整流程"""
        self.print_header("完整Pipeline端到端测试")
        
        try:
            # ========== 阶段1：初始化所有模块 ==========
            self.print_section("阶段1：初始化所有模块")
            
            from controller.controller import MainController
            from parts.fusion.fusion_controller import FusionController
            from parts.fusion.emotion_bone_mapper import EmotionToBoneMapper
            from adapter.blender.blender_controller import BlenderController
            from adapter.comfyui.comfyui_controller import ComfyUIController
            from controller.agent_manager import AgentManager
            
            config_loader = get_config_loader()
            
            # 1.1 MainController
            print("\n[1.1] 初始化MainController...")
            main_controller = MainController()
            if not main_controller.initialize(use_preload=False):
                print("✗ MainController初始化失败")
                return False
            if not main_controller.start():
                print("✗ MainController启动失败")
                return False
            print("✓ MainController初始化成功")
            self.log_timeline("MainController已启动")
            
            # 1.2 FusionController
            print("\n[1.2] 初始化FusionController...")
            fusion_config = config_loader.get_fusion_config()
            fusion_controller = FusionController(config=fusion_config)
            print("✓ FusionController初始化成功")
            self.log_timeline("FusionController已就绪")
            
            # 1.3 EmotionToBoneMapper
            print("\n[1.3] 初始化EmotionToBoneMapper...")
            # 使用增强版203骨骼映射
            enhanced_mapping_file = PROJECT_ROOT / "config" / "enhanced_bone_mapping.yaml"
            if enhanced_mapping_file.exists():
                bone_mapper = EmotionToBoneMapper(mapping_file=str(enhanced_mapping_file))
                print(f"✓ EmotionToBoneMapper初始化成功（增强版203骨骼）")
            else:
                bone_mapper = EmotionToBoneMapper()
                print("⚠️ 使用默认映射（8骨骼）- 建议运行 generate_enhanced_bone_mapping.py")
            self.log_timeline("BoneMapper已就绪")
            
            # 1.4 BlenderController
            print("\n[1.4] 初始化BlenderController...")
            blender_config = config_loader.get_blender_config()
            blender_controller = BlenderController(config=blender_config)
            if blender_controller.socket_client:
                print("✓ Blender Socket已连接")
                self.log_timeline("Blender已连接")
            else:
                print("⚠️ Blender未连接（需要Blender运行）")
            
            # 1.5 ComfyUIController
            print("\n[1.5] 初始化ComfyUIController...")
            comfyui_config = config_loader.get_comfyui_config()
            comfyui_controller = ComfyUIController(config=comfyui_config)
            
            # 加载工作流
            workflow_loaded = comfyui_controller.load_workflow()
            if workflow_loaded:
                print("✓ ComfyUI工作流加载成功")
                self.log_timeline("ComfyUI工作流已加载")
            else:
                print("✗ ComfyUI工作流加载失败")
                return False
            
            # 1.6 AgentManager
            print("\n[1.6] 初始化AgentManager...")
            agent_manager = AgentManager(verbose=False)
            agent_init = agent_manager.initialize_agents()
            if agent_init:
                print("✓ AgentManager初始化成功")
                self.log_timeline("AgentManager已就绪")
            else:
                print("⚠️ AgentManager初始化失败（将使用回退决策）")
            
            # ========== 阶段2：模拟多模态输入 ==========
            self.print_section("阶段2：模拟多模态输入")
            
            # 2.1 CV输入
            print("\n[2.1] CV模块输出（模拟）...")
            cv_data = {
                'emotion': 'happy',
                'confidence': 0.87,
                'face_detected': True,
                'timestamp': time.time()
            }
            print(f"  • 情感: {cv_data['emotion']}")
            print(f"  • 置信度: {cv_data['confidence']}")
            self.log_timeline(f"CV输入: {cv_data['emotion']} ({cv_data['confidence']:.2f})")
            
            # 2.2 Text AI输入
            print("\n[2.2] Text AI输出（模拟）...")
            text_data = {
                'text': '我今天非常开心！',
                'emotion': 'happy',
                'confidence': 0.95,
                'ai_powered': True,
                'timestamp': time.time()
            }
            print(f"  • 文本: {text_data['text']}")
            print(f"  • 情感: {text_data['emotion']}")
            print(f"  • AI分析: {text_data['ai_powered']}")
            self.log_timeline(f"Text AI输入: {text_data['emotion']} ({text_data['confidence']:.2f})")
            
            # ========== 阶段3：融合决策 ==========
            self.print_section("阶段3：多模态融合与AI决策")
            
            # 3.1 Fusion融合
            print("\n[3.1] Fusion融合...")
            fusion_input = {
                'cv': cv_data,
                'text': text_data
            }
            
            # 使用AgentManager进行融合决策
            if agent_manager.initialized:
                print("  • 使用AI Agent进行融合决策...")
                fusion_result = agent_manager.make_fusion_decision(fusion_input)
            else:
                print("  • 使用规则融合...")
                # 简单的加权平均
                fusion_result = {
                    'emotion': 'happy',
                    'confidence': (cv_data['confidence'] * 0.4 + text_data['confidence'] * 0.6),
                    'action': 'generate_video',
                    'ai_powered': False
                }
            
            print(f"  ✓ 融合结果:")
            print(f"    • 情感: {fusion_result['emotion']}")
            print(f"    • 置信度: {fusion_result['confidence']:.2f}")
            print(f"    • 动作: {fusion_result.get('action', 'observe')}")
            print(f"    • AI驱动: {fusion_result.get('ai_powered', False)}")
            self.log_timeline(f"Fusion完成: {fusion_result['emotion']} ({fusion_result['confidence']:.2f})")
            
            # ========== 阶段4：骨骼映射 ==========
            self.print_section("阶段4：情感到骨骼映射")
            
            print("\n[4.1] BoneMapper映射...")
            bone_pose = bone_mapper.get_bone_pose_dict(
                emotion=fusion_result['emotion'],
                confidence=fusion_result['confidence']
            )
            
            print(f"  ✓ 生成骨骼姿势:")
            print(f"    • 骨骼数量: {len(bone_pose)}")
            # 显示前3个骨骼
            for i, (bone_name, transforms) in enumerate(list(bone_pose.items())[:3]):
                rotation = transforms.get('rotation', [0, 0, 0])
                print(f"    • {bone_name}: rotation={rotation}")
            self.log_timeline(f"BoneMapper: {len(bone_pose)}个骨骼")
            
            # ========== 阶段5：Blender骨骼更新 ==========
            self.print_section("阶段5：Blender骨骼更新")
            
            if blender_controller.socket_client:
                print("\n[5.1] 更新Blender骨骼...")
                
                # 批量更新骨骼
                success_count = 0
                for bone_name, transforms in bone_pose.items():
                    rotation = transforms.get('rotation')
                    position = transforms.get('position')
                    
                    result = blender_controller.update_bone_pose(
                        bone_name=bone_name,
                        position=position,
                        rotation=rotation
                    )
                    
                    if result:
                        success_count += 1
                
                print(f"  ✓ 成功更新: {success_count}/{len(bone_pose)} 个骨骼")
                self.log_timeline(f"Blender更新: {success_count}个骨骼")
                
                # 创建姿势快照
                print("\n[5.2] 创建姿势快照...")
                try:
                    snapshot = blender_controller.create_pose_shot()
                    if snapshot:
                        print(f"  ✓ 快照创建成功")
                        self.log_timeline("姿势快照已创建")
                except Exception as e:
                    print(f"  ⚠️ 快照创建失败: {e}")
            else:
                print("⚠️ Blender未连接，跳过骨骼更新")
                self.log_timeline("Blender未连接（跳过）")
            
            # ========== 阶段6：ComfyUI视频生成 ==========
            self.print_section("阶段6：ComfyUI视频生成")
            
            print("\n[6.1] 准备视频生成参数...")
            
            # 构建提示词
            emotion_prompts = {
                'happy': 'joyful, cheerful, bright smile, positive energy',
                'sad': 'melancholic, downcast, gentle sadness',
                'angry': 'fierce, intense, strong expression',
                'neutral': 'calm, composed, neutral expression'
            }
            
            base_prompt = emotion_prompts.get(fusion_result['emotion'], 'neutral expression')
            full_prompt = f"A realistic digital human avatar, {base_prompt}, high quality, detailed"
            
            print(f"  • 情感: {fusion_result['emotion']}")
            print(f"  • 提示词: {full_prompt[:80]}...")
            
            # 设置模型参数
            model_params = {
                'steps': 20,
                'cfg_scale': 7.0,
                'width': 512,
                'height': 512
            }
            
            print(f"\n[6.2] 提交ComfyUI任务...")
            self.log_timeline("提交ComfyUI任务...")
            
            try:
                # 设置提示词
                comfyui_controller.set_prompt(full_prompt)
                
                # 设置模型参数
                comfyui_controller.set_model_parameters(model_params)
                
                # 提交任务
                task_id = comfyui_controller.execute_workflow()
                
                if task_id:
                    print(f"  ✓ 任务已提交: {task_id}")
                    self.log_timeline(f"任务ID: {task_id}")
                    
                    # 等待任务完成
                    print(f"\n[6.3] 等待视频生成...")
                    max_wait = 120  # 最多等待2分钟
                    check_interval = 5
                    elapsed = 0
                    
                    # 检查任务状态（尝试一次）
                    time.sleep(2)  # 给API一点时间
                    status = comfyui_controller.get_task_status(task_id)
                    
                    if status:
                        task_status = status.get('status', 'unknown')
                        
                        if task_status in ['success', 'completed', 'done']:
                            print(f"\n  ✓ 视频生成完成！")
                            self.log_timeline("视频生成完成")
                            self.test_results['comfyui'] = {
                                'success': True,
                                'task_id': task_id,
                                'emotion': fusion_result['emotion']
                            }
                        elif task_status == 'submitted':
                            print(f"\n  ✓ 任务已提交到ComfyUI云端")
                            print(f"  ℹ️ ComfyOne云端API采用异步处理模式")
                            print(f"  ℹ️ 任务将在后台处理，结果通过其他方式获取")
                            self.log_timeline("任务已提交（异步处理）")
                            self.test_results['comfyui'] = {
                                'success': True,
                                'task_id': task_id,
                                'status': 'submitted_async',
                                'emotion': fusion_result['emotion'],
                                'note': 'ComfyOne云端异步处理，不支持实时状态查询'
                            }
                        elif task_status == 'failed':
                            print(f"\n  ✗ 视频生成失败: {status.get('message')}")
                            self.log_timeline("视频生成失败")
                            self.test_results['comfyui'] = {
                                'success': False,
                                'error': status.get('message')
                            }
                        else:
                            print(f"\n  ℹ️ 任务状态: {task_status}")
                            print(f"  ℹ️ 任务正在处理中...")
                            self.log_timeline(f"任务状态: {task_status}")
                            self.test_results['comfyui'] = {
                                'success': True,
                                'task_id': task_id,
                                'status': task_status
                            }
                    else:
                        print(f"\n  ⚠️ 无法获取任务状态")
                        self.test_results['comfyui'] = {
                            'success': True,
                            'task_id': task_id,
                            'status': 'status_unavailable',
                            'note': '任务已提交，状态查询不可用'
                        }
                else:
                    print("  ✗ 任务提交失败")
                    self.test_results['comfyui'] = {
                        'success': False,
                        'error': 'submission_failed'
                    }
                    
            except Exception as e:
                print(f"  ✗ ComfyUI调用失败: {e}")
                import traceback
                traceback.print_exc()
                self.test_results['comfyui'] = {
                    'success': False,
                    'error': str(e)
                }
            
            # ========== 完成 ==========
            self.print_header("测试完成")
            
            # 停止MainController
            main_controller.stop()
            
            return True
            
        except Exception as e:
            print(f"\n✗ 测试失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def generate_report(self):
        """生成测试报告"""
        self.print_header("完整Pipeline测试报告")
        
        print("\n【时间线】")
        for event in self.timeline:
            print(f"  {event}")
        
        print("\n【测试结果】")
        for key, value in self.test_results.items():
            print(f"  • {key}: {value}")
        
        # 保存报告
        report_path = PROJECT_ROOT / "FULL_PIPELINE_TEST_REPORT.md"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# 完整Pipeline测试报告\n\n")
            f.write(f"生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write("## 时间线\n\n")
            for event in self.timeline:
                f.write(f"- {event}\n")
            
            f.write("\n## 测试结果\n\n")
            f.write(f"```json\n{json.dumps(self.test_results, indent=2, ensure_ascii=False)}\n```\n")
        
        print(f"\n✓ 详细报告已保存: {report_path}")

def main():
    """主函数"""
    tester = FullPipelineTester()
    
    tester.print_header("AIsampler完整Pipeline测试")
    print("\n测试流程:")
    print("  1. 初始化所有模块")
    print("  2. 模拟多模态输入 (CV + Text AI)")
    print("  3. 融合决策 (AgentManager)")
    print("  4. 骨骼映射 (BoneMapper)")
    print("  5. Blender骨骼更新")
    print("  6. ComfyUI视频生成 ⭐")
    
    print("\n⚠️ 注意:")
    print("  • 需要Blender运行Socket服务器 (localhost:8888)")
    print("  • 需要ComfyUI云端服务运行")
    
    print("\n⏱️ 自动开始测试...\n")
    
    try:
        success = tester.test_complete_flow()
        
        if success:
            tester.generate_report()
            print("\n✅ 完整Pipeline测试成功！")
        else:
            print("\n❌ 测试失败")
            return 1
        
    except KeyboardInterrupt:
        print("\n\n⚠️ 测试被中断")
        return 1
    except Exception as e:
        print(f"\n❌ 测试异常: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
