#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
完整端到端Pipeline测试
验证从CV/Text输入到Blender/ComfyUI输出的完整数据流
"""

import sys
import time
import logging
from pathlib import Path
from typing import Dict, Any
import json

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - [%(levelname)s] - %(name)s - %(message)s'
)

logger = logging.getLogger(__name__)

class EndToEndTester:
    """端到端完整测试器"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.test_results = {}
        self.data_flow_trace = []
        
    def print_header(self, title: str):
        print("\n" + "=" * 80)
        print(f"📊 {title}")
        print("=" * 80)
    
    def print_section(self, title: str):
        print(f"\n【{title}】")
        print("-" * 80)
    
    def test_fusion_controller(self) -> bool:
        """测试1：Fusion模块（多模态融合）"""
        self.print_section("测试1：Fusion控制器（多模态融合）")
        
        try:
            from parts.fusion.fusion_controller import FusionController
            config_loader = get_config_loader()
            fusion_config = config_loader.get_fusion_config()
            
            print("初始化Fusion控制器...")
            fusion = FusionController(config=fusion_config)
            
            # 模拟多模态输入
            timestamp = time.time()
            
            # CV数据
            cv_data = {
                'emotion': 'happy',
                'confidence': 0.85,
                'timestamp': timestamp
            }
            fusion.add_cv_data(timestamp, cv_data)
            print(f"✓ 添加CV数据: {cv_data}")
            
            # Text数据
            text_data = {
                'text': '我很开心',
                'emotion': 'happy',
                'confidence': 0.92,
                'timestamp': timestamp
            }
            fusion.add_text_data(timestamp, text_data)
            print(f"✓ 添加Text数据: {text_data}")
            
            # 触发融合
            time.sleep(0.5)  # 等待时间窗口
            
            # 检查是否有融合结果
            if hasattr(fusion, 'get_latest_result'):
                result = fusion.get_latest_result()
                if result:
                    print(f"\n✓ 融合成功:")
                    print(f"  • 情感: {result.emotion}")
                    print(f"  • 置信度: {result.confidence:.2f}")
                    print(f"  • 权重: CV={result.weights.get('cv', 0):.2f}, Text={result.weights.get('text', 0):.2f}")
                    
                    self.test_results['fusion'] = {
                        'success': True,
                        'result': {
                            'emotion': result.emotion,
                            'confidence': result.confidence
                        }
                    }
                    self.data_flow_trace.append(f"Fusion → {result.emotion} ({result.confidence:.2f})")
                    return True
            
            print("⚠️ 无法获取融合结果（可能需要回调机制）")
            self.test_results['fusion'] = {'success': False, 'reason': 'no_result'}
            return False
            
        except Exception as e:
            print(f"✗ Fusion测试失败: {e}")
            import traceback
            traceback.print_exc()
            self.test_results['fusion'] = {'success': False, 'error': str(e)}
            return False
    
    def test_emotion_bone_mapper(self) -> bool:
        """测试2：情感到骨骼映射"""
        self.print_section("测试2：EmotionToBoneMapper（情感→骨骼映射）")
        
        try:
            from parts.fusion.emotion_bone_mapper import EmotionToBoneMapper
            
            print("初始化EmotionToBoneMapper...")
            # 使用增强版203骨骼映射
            enhanced_mapping_file = Path(__file__).resolve().parent / "config" / "enhanced_bone_mapping.yaml"
            if enhanced_mapping_file.exists():
                mapper = EmotionToBoneMapper(mapping_file=str(enhanced_mapping_file))
                print(f"✓ 使用增强版203骨骼映射")
            else:
                mapper = EmotionToBoneMapper()
                print("⚠️ 使用默认8骨骼映射")
            
            # 测试不同情感的骨骼映射
            test_emotions = ['happy', 'sad', 'angry', 'neutral']
            
            for emotion in test_emotions:
                bone_pose = mapper.get_bone_pose_dict(emotion, confidence=0.8)
                
                if bone_pose:
                    print(f"\n✓ {emotion} 的骨骼映射:")
                    print(f"  • 骨骼数量: {len(bone_pose)}")
                    # 显示前3个骨骼
                    for i, (bone_name, transforms) in enumerate(list(bone_pose.items())[:3]):
                        print(f"  • {bone_name}: rotation={transforms.get('rotation', [])} ")
                    
                    self.data_flow_trace.append(f"BoneMapper → {emotion}: {len(bone_pose)} bones")
                else:
                    print(f"✗ {emotion} 映射失败")
                    return False
            
            self.test_results['bone_mapper'] = {
                'success': True,
                'emotions_tested': len(test_emotions)
            }
            return True
            
        except Exception as e:
            print(f"✗ EmotionToBoneMapper测试失败: {e}")
            import traceback
            traceback.print_exc()
            self.test_results['bone_mapper'] = {'success': False, 'error': str(e)}
            return False
    
    def test_blender_interface(self) -> bool:
        """测试3：Blender接口连接"""
        self.print_section("测试3：Blender接口连接")
        
        try:
            from adapter.blender.blender_controller import BlenderController
            config_loader = get_config_loader()
            blender_config = config_loader.get_blender_config()
            
            print("初始化Blender控制器...")
            blender = BlenderController(config=blender_config)
            
            # 检查模式
            mode = blender_config.get('mode', 'socket')
            print(f"  • 模式: {mode}")
            
            if mode == 'socket':
                # Socket模式 - 检查连接
                host = blender_config.get('socket', {}).get('host', 'localhost')
                port = blender_config.get('socket', {}).get('port', 9999)
                print(f"  • Socket地址: {host}:{port}")
                
                # 检查连接状态（初始化时已自动连接）
                try:
                    # BlenderController在__init__中已自动连接
                    # 检查是否有socket_client属性表示已连接
                    if hasattr(blender, 'socket_client') and blender.socket_client:
                        print("✓ Blender Socket已连接")
                        
                        # 测试发送命令
                        result = blender.update_bone_pose('Head', rotation=[0.0, 0.0, 0.1])
                        print(f"✓ 骨骼更新测试: {'成功' if result else '失败'}")
                        
                        self.test_results['blender'] = {
                            'success': True,
                            'mode': 'socket',
                            'connected': True
                        }
                        self.data_flow_trace.append("Blender Socket → Connected")
                        return True
                    else:
                        print("✗ Blender Socket未连接")
                        print("  提示: 请确保Blender已启动并运行Socket服务器")
                        self.test_results['blender'] = {
                            'success': False,
                            'mode': 'socket',
                            'connected': False,
                            'reason': 'connection_failed'
                        }
                        return False
                        
                except Exception as e:
                    print(f"✗ Blender连接异常: {e}")
                    self.test_results['blender'] = {
                        'success': False,
                        'error': str(e)
                    }
                    return False
            
            elif mode == 'internal':
                print("⚠️ Internal模式（需要在Blender内部运行）")
                print("  当前环境无法测试Internal模式")
                self.test_results['blender'] = {
                    'success': None,
                    'mode': 'internal',
                    'skipped': True
                }
                return False
            
        except Exception as e:
            print(f"✗ Blender接口测试失败: {e}")
            import traceback
            traceback.print_exc()
            self.test_results['blender'] = {'success': False, 'error': str(e)}
            return False
    
    def test_comfyui_interface(self) -> bool:
        """测试4：ComfyUI接口连接"""
        self.print_section("测试4：ComfyUI接口连接")
        
        try:
            from adapter.comfyui.comfyui_controller import ComfyUIController
            config_loader = get_config_loader()
            comfyui_config = config_loader.get_comfyui_config()
            
            print("初始化ComfyUI控制器...")
            comfyui = ComfyUIController(config=comfyui_config)
            
            # 检查API配置
            api_config = comfyui_config.get('api', {})
            base_url = api_config.get('base_url', 'N/A')
            print(f"  • API地址: {base_url}")
            
            # 测试连接
            try:
                # 尝试加载工作流
                workflow_loaded = comfyui.load_workflow()
                if workflow_loaded:
                    print("✓ ComfyUI工作流加载成功")
                else:
                    print("⚠️ ComfyUI工作流加载失败（可能是配置问题）")
                
                # 测试API连接（如果有测试方法）
                if hasattr(comfyui, 'test_connection'):
                    connected = comfyui.test_connection()
                    if connected:
                        print("✓ ComfyUI API连接成功")
                        
                        # 测试提交任务（不实际生成）
                        print("\n测试任务提交（模拟）...")
                        # task_id = comfyui.submit_task(
                        #     prompt="test", 
                        #     model_params={'steps': 1}
                        # )
                        # print(f"✓ 任务ID: {task_id}")
                        
                        self.test_results['comfyui'] = {
                            'success': True,
                            'connected': True
                        }
                        self.data_flow_trace.append("ComfyUI API → Connected")
                        return True
                    else:
                        print("✗ ComfyUI API连接失败")
                        print(f"  API地址: {base_url}")
                        print("  提示: 请确保ComfyUI服务正在运行")
                        
                        self.test_results['comfyui'] = {
                            'success': False,
                            'connected': False,
                            'reason': 'api_unreachable'
                        }
                        return False
                else:
                    print("⚠️ ComfyUI控制器没有test_connection方法")
                    print("  假设API可用（需要实际调用验证）")
                    
                    self.test_results['comfyui'] = {
                        'success': None,
                        'reason': 'no_test_method'
                    }
                    return False
                    
            except Exception as e:
                print(f"✗ ComfyUI连接测试失败: {e}")
                self.test_results['comfyui'] = {
                    'success': False,
                    'error': str(e)
                }
                return False
                
        except Exception as e:
            print(f"✗ ComfyUI接口测试失败: {e}")
            import traceback
            traceback.print_exc()
            self.test_results['comfyui'] = {'success': False, 'error': str(e)}
            return False
    
    def test_mcp_module(self) -> bool:
        """测试5：MCP模块"""
        self.print_section("测试5：MCP模块调用")
        
        try:
            # 检查MCP配置
            config_loader = get_config_loader()
            mcp_config = config_loader.get_mcp_config()
            
            print("MCP配置:")
            print(f"  • 服务器数量: {len(mcp_config.get('servers', {}))}")
            
            # 尝试导入MCP相关模块
            try:
                # 检查是否有MCP客户端实现
                import importlib.util
                mcp_spec = importlib.util.find_spec('mcp')
                
                if mcp_spec:
                    print("✓ MCP包已安装")
                    
                    # 这里可以添加实际的MCP调用测试
                    # 但由于MCP可能需要特定的服务器运行，暂时跳过
                    
                    self.test_results['mcp'] = {
                        'success': True,
                        'package_installed': True,
                        'servers_configured': len(mcp_config.get('servers', {}))
                    }
                    return True
                else:
                    print("⚠️ MCP包未安装")
                    print("  MCP功能可能不可用")
                    
                    self.test_results['mcp'] = {
                        'success': False,
                        'package_installed': False
                    }
                    return False
                    
            except ImportError as e:
                print(f"⚠️ MCP导入失败: {e}")
                self.test_results['mcp'] = {
                    'success': False,
                    'error': str(e)
                }
                return False
                
        except Exception as e:
            print(f"✗ MCP测试失败: {e}")
            import traceback
            traceback.print_exc()
            self.test_results['mcp'] = {'success': False, 'error': str(e)}
            return False
    
    def test_complete_data_flow(self) -> bool:
        """测试6：完整数据流追踪"""
        self.print_section("测试6：完整数据流（模拟端到端）")
        
        try:
            print("模拟完整数据流...")
            print("\n数据流路径:")
            print("  CV输入 → Fusion → BoneMapper → Blender → ComfyUI")
            print("  Text AI ↗")
            
            # 步骤1: CV输入
            print("\n[1] CV模块输出:")
            cv_output = {
                'emotion': 'happy',
                'confidence': 0.85,
                'face_detected': True
            }
            print(f"  {cv_output}")
            self.data_flow_trace.append(f"CV → happy (0.85)")
            
            # 步骤2: Text AI输出
            print("\n[2] Text AI输出:")
            text_output = {
                'emotion': 'happy',
                'confidence': 0.92,
                'text': '我很开心',
                'ai_powered': True
            }
            print(f"  {text_output}")
            self.data_flow_trace.append(f"Text AI → happy (0.92)")
            
            # 步骤3: Fusion融合
            print("\n[3] Fusion融合:")
            fusion_result = {
                'emotion': 'happy',
                'confidence': 0.89,  # 加权平均
                'sources': ['cv', 'text']
            }
            print(f"  {fusion_result}")
            self.data_flow_trace.append(f"Fusion → happy (0.89)")
            
            # 步骤4: BoneMapper映射
            print("\n[4] BoneMapper映射:")
            from parts.fusion.emotion_bone_mapper import EmotionToBoneMapper
            enhanced_mapping_file = Path(__file__).resolve().parent / "config" / "enhanced_bone_mapping.yaml"
            if enhanced_mapping_file.exists():
                mapper = EmotionToBoneMapper(mapping_file=str(enhanced_mapping_file))
            else:
                mapper = EmotionToBoneMapper()
            bone_pose = mapper.get_bone_pose_dict('happy', confidence=0.89)
            print(f"  • 生成{len(bone_pose)}个骨骼姿势")
            self.data_flow_trace.append(f"BoneMapper → {len(bone_pose)} bones")
            
            # 步骤5: Blender控制（模拟）
            print("\n[5] Blender骨骼更新:")
            print(f"  • 目标: 更新{len(bone_pose)}个骨骼")
            print(f"  • 状态: {'已连接' if self.test_results.get('blender', {}).get('connected') else '未连接'}")
            if self.test_results.get('blender', {}).get('connected'):
                self.data_flow_trace.append(f"Blender → Updated {len(bone_pose)} bones")
            
            # 步骤6: ComfyUI生成（模拟）
            print("\n[6] ComfyUI视频生成:")
            print(f"  • 提示词: 生成happy情感的数字人视频")
            print(f"  • 状态: {'API可用' if self.test_results.get('comfyui', {}).get('connected') else 'API不可用'}")
            if self.test_results.get('comfyui', {}).get('connected'):
                self.data_flow_trace.append("ComfyUI → Video generation started")
            
            self.test_results['data_flow'] = {
                'success': True,
                'steps_completed': 6
            }
            
            return True
            
        except Exception as e:
            print(f"✗ 数据流测试失败: {e}")
            import traceback
            traceback.print_exc()
            self.test_results['data_flow'] = {'success': False, 'error': str(e)}
            return False
    
    def generate_report(self):
        """生成完整测试报告"""
        self.print_header("完整端到端测试报告")
        
        print("\n【测试结果概览】")
        for test_name, result in self.test_results.items():
            success = result.get('success')
            if success is True:
                symbol = "✓"
            elif success is False:
                symbol = "✗"
            else:
                symbol = "⚠️"
            
            print(f"  {symbol} {test_name}: {success}")
            
            if not success and 'reason' in result:
                print(f"      原因: {result['reason']}")
            if 'error' in result:
                print(f"      错误: {result['error']}")
        
        print("\n【数据流追踪】")
        for i, step in enumerate(self.data_flow_trace, 1):
            print(f"  {i}. {step}")
        
        # 保存到文件
        report_path = PROJECT_ROOT / "E2E_TEST_REPORT.md"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# 端到端完整测试报告\n\n")
            f.write(f"生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write("## 测试结果\n\n")
            for test_name, result in self.test_results.items():
                f.write(f"### {test_name}\n\n")
                f.write(f"```json\n{json.dumps(result, indent=2, ensure_ascii=False)}\n```\n\n")
            
            f.write("## 数据流追踪\n\n")
            for step in self.data_flow_trace:
                f.write(f"- {step}\n")
        
        print(f"\n✓ 详细报告已保存到: {report_path}")

def main():
    """主函数"""
    tester = EndToEndTester()
    
    tester.print_header("AIsampler完整端到端测试")
    
    print("\n本测试将验证:")
    print("  1. Fusion模块（多模态融合）")
    print("  2. EmotionToBoneMapper（情感→骨骼映射）")
    print("  3. Blender接口连接")
    print("  4. ComfyUI接口连接")
    print("  5. MCP模块")
    print("  6. 完整数据流追踪")
    
    print("\n⏱️ 开始测试...\n")
    
    try:
        # 执行所有测试
        tester.test_fusion_controller()
        tester.test_emotion_bone_mapper()
        tester.test_blender_interface()
        tester.test_comfyui_interface()
        tester.test_mcp_module()
        tester.test_complete_data_flow()
        
        # 生成报告
        tester.generate_report()
        
        tester.print_header("测试完成")
        print("\n✓ 所有测试已完成，请查看详细报告")
        
    except Exception as e:
        print(f"\n✗ 测试过程中发生异常: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
