# 检测脚本说明

## 📋 概述

本目录包含所有系统检测脚本，用于检查系统各个组件的状态和配置。

## 📁 脚本列表

### 1. `check_all.py` - 主检测脚本（推荐使用）

**功能**：统一调用所有检测脚本，生成完整检测报告

**使用方法**：
```bash
python scripts/check_all.py
```

**输出**：
- 完整的检测报告
- 各项检测的通过/失败状态
- 总结信息

---

### 2. `check_dependencies.py` - 依赖检查

**功能**：检查Python包、文件、外部服务等依赖

**检查项**：
- Python包安装情况（opencv, torch, modelscope, funasr, langchain等）
- 必需文件是否存在（配置文件、模型文件等）
- 外部服务状态（ComfyUI、Blender）

**使用方法**：
```bash
python scripts/check_dependencies.py
```

---

### 3. `check_config.py` - 配置检查

**功能**：检查所有配置文件是否存在、格式是否正确

**检查项**：
- YAML配置文件格式（cv_config, stt_config, fusion_config等）
- 文本配置文件内容（deepseek_key, comfyui_cloud等）
- 配置加载器功能

**使用方法**：
```bash
python scripts/check_config.py
```

---

### 4. `check_modules.py` - 模块检查（已优化）

**功能**：检查各个模块是否可以正常初始化和运行，对每个模块进行详细的对应检测

**检查模块**：
1. **CV模块（计算机视觉）**
   - 控制器初始化、基本属性、模型状态、配置、方法检查
   - ONNX模型支持检查、模型类型检测

2. **STT模块（语音识别）**
   - 控制器初始化、VAD/ASR检查、配置、方法、录音参数检查

3. **Fusion模块（多模态融合）**
   - 控制器初始化、时间同步器、特征融合器、配置、方法、数据添加测试

4. **EmotionMapper模块（情绪映射）**
   - 映射器初始化、映射功能测试（5种情绪）、置信度测试、方法检查

5. **Blender适配器（3D骨骼动画）**
   - 控制器初始化、运行模式、Socket连接、配置、方法、文件路径检查

6. **ComfyUI适配器（AI视频生成）**
   - 控制器初始化、云端API、配置、API密钥、方法、节点发现器检查

7. **Agent管理器（AI决策系统）**
   - API密钥、管理器初始化、LLM、工具封装器、Agent实例、方法、初始化测试

8. **MainController（主控制器）**
   - 控制器初始化、事件队列、健康检查器、模块控制器、方法、状态管理检查

9. **Pipeline（端到端流程）**
   - Pipeline初始化、所有控制器、方法、状态管理检查

**使用方法**：
```bash
python scripts/check_modules.py
```

**输出示例**：
```
[CV模块检测]
  ✅ 控制器初始化成功
  ✅ 基本属性检查通过
  ✅ 配置检查通过
  ✅ 方法检查通过
✅ CV模块 - 所有检测通过
```

---

### 5. `check_connections.py` - 连接检查（已优化）

**功能**：检查ComfyUI云端API连接、网络连接等

**检查项**：
- 云端配置（API密钥、实例ID）
- 网络连通性（DNS解析）
- ComfyUI云端API连接

**使用方法**：
```bash
python scripts/check_connections.py
```

---

### 7. `check_dataflow.py` - 数据流检查

**功能**：检查数据流各节点的数据格式和处理流程

**检查项**：
- CV数据格式
- STT数据格式
- 融合结果格式
- 情绪到骨骼映射
- 时间同步器
- 事件队列

**使用方法**：
```bash
python scripts/check_dataflow.py
```

---

## 🚀 快速开始

### 运行所有检测

```bash
python scripts/check_all.py
```

### 运行特定检测

```bash
# 只检查依赖
python scripts/check_dependencies.py

# 只检查配置
python scripts/check_config.py

# 只检查模块
python scripts/check_modules.py

# 只检查连接
python scripts/check_connections.py

# 只检查数据流
python scripts/check_dataflow.py
```

---

## 📊 检测结果说明

### 状态标识

- ✅ **通过**：检查项正常
- ⚠️ **警告**：检查项存在问题但不影响基本功能
- ❌ **失败**：检查项存在严重问题，需要修复

### 退出码

- `0`：所有检测通过
- `1`：存在检测失败

---

## 🔧 故障排查

### 依赖检查失败

**问题**：Python包未安装

**解决**：
```bash
pip install -r requirements.txt
```

### 配置检查失败

**问题**：配置文件格式错误或缺失

**解决**：
1. 检查配置文件是否存在
2. 验证YAML格式是否正确
3. 检查必需配置项是否填写

### 模块检查失败

**问题**：模块初始化失败

**解决**：
1. 检查依赖是否安装完整
2. 检查配置文件是否正确
3. 查看错误信息定位问题

### 连接检查失败

**问题**：无法连接到外部服务

**解决**：
1. 检查网络连接
2. 检查SSH隧道是否建立
3. 检查ComfyUI服务器状态

### 数据流检查失败

**问题**：数据格式或处理流程异常

**解决**：
1. 检查数据格式是否符合要求
2. 验证各模块的数据处理逻辑
3. 查看日志定位问题

---

## 📝 添加新检测

要添加新的检测脚本：

1. 在 `scripts/` 目录创建新脚本
2. 实现 `main()` 函数，返回 `True`（成功）或 `False`（失败）
3. 在 `check_all.py` 中导入并添加到检测列表

示例：
```python
# scripts/check_new_feature.py
def main():
    print("检查新功能...")
    # 检测逻辑
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
```

---

## 📚 相关文档

- [依赖与配置检查清单](../docs/依赖与配置检查清单.md)
- [ComfyUI云端连接说明](../docs/ComfyUI云端连接说明.md)
- [数据流验证检查清单](../docs/数据流验证检查清单.md)

