#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主检测脚本
统一调用所有检测脚本，生成完整检测报告
"""

import sys
import os
import time
from pathlib import Path
from typing import Dict, List, Tuple

# 添加项目路径
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))


# 导入所有检测脚本
from scripts.check_dependencies import main as check_dependencies
from scripts.check_config import main as check_config
from scripts.check_modules import main as check_modules
from scripts.check_connections import main as check_connections
from scripts.check_dataflow import main as check_dataflow

# 模型预加载检查
try:
    from scripts.check_preload import main as check_preload
    PRELOAD_CHECK_AVAILABLE = True
except ImportError:
    PRELOAD_CHECK_AVAILABLE = False

# 可选：性能检查（需要psutil）
try:
    from scripts.check_performance import main as check_performance
    PERFORMANCE_CHECK_AVAILABLE = True
except ImportError:
    PERFORMANCE_CHECK_AVAILABLE = False


def print_header(title: str):
    """打印标题"""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def print_summary(results: List[Tuple[str, bool]]):
    """打印总结"""
    print_header("检测总结")
    
    total = len(results)
    passed = sum(1 for _, success in results if success)
    failed = total - passed
    
    print(f"\n总计: {total} 项检测")
    print(f"通过: {passed} 项")
    print(f"失败: {failed} 项")
    
    print("\n详细结果:")
    for name, success in results:
        status = "[OK] 通过" if success else "[FAIL] 失败"
        print(f"  {status} - {name}")
    
    print("\n" + "=" * 70)
    
    if failed == 0:
        print("[OK] 所有检测通过！系统已就绪。")
        return True
    else:
        print(f"[WARN] 有 {failed} 项检测失败，请根据上述提示进行修复。")
        print("\n问题定位建议:")
        print("  1. 查看各检测项的详细错误信息")
        print("  2. 检查相关配置文件和依赖")
        print("  3. 运行单独的检测脚本获取更详细信息")
        print("  4. 查看 docs/ 目录下的相关文档")
        return False


def main():
    """主函数"""
    print("=" * 70)
    print("  多模态实时交互具身智能数字人系统 - 完整检测")
    print("=" * 70)
    print(f"检测时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"项目路径: {current_dir}")
    
    results = []
    
    # 执行各项检测
    checks = [
        ("依赖检查", check_dependencies),
        ("配置检查", check_config),
        ("模块检查", check_modules),
        ("连接检查", check_connections),
        ("数据流检查", check_dataflow),
    ]
    
    # 添加模型预加载检查（如果可用）
    if PRELOAD_CHECK_AVAILABLE:
        checks.append(("模型预加载检查", check_preload))
    
    # 添加性能检查（如果可用）
    if PERFORMANCE_CHECK_AVAILABLE:
        checks.append(("性能检查", check_performance))
    
    for check_name, check_func in checks:
        print_header(f"{check_name}")
        try:
            success = check_func()
            results.append((check_name, success))
        except Exception as e:
            print(f"❌ {check_name}执行失败: {e}")
            results.append((check_name, False))
    
    # 打印总结
    overall_success = print_summary(results)
    
    return overall_success


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

