#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
完整系统自检测脚本
按照自检测文档进行深度自查与整体测试
"""

import sys
import os
import ast
import importlib
import importlib.util
import inspect
from pathlib import Path
from typing import Dict, List, Tuple, Any
import traceback

# 添加项目路径
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))


class SystemChecker:
    """系统完整性检查器"""
    
    def __init__(self):
        self.base_dir = current_dir
        self.errors = []
        self.warnings = []
        self.passed = []
        self.total_checks = 0
        
    def log_error(self, category: str, message: str):
        """记录错误"""
        self.errors.append(f"[{category}] {message}")
        self.total_checks += 1
        try:
            print(f"❌ [{category}] {message}")
        except UnicodeEncodeError:
            print(f"[ERROR] [{category}] {message}")
    
    def log_warning(self, category: str, message: str):
        """记录警告"""
        self.warnings.append(f"[{category}] {message}")
        self.total_checks += 1
        try:
            print(f"⚠️  [{category}] {message}")
        except UnicodeEncodeError:
            print(f"[WARNING] [{category}] {message}")
    
    def log_pass(self, category: str, message: str):
        """记录通过"""
        self.passed.append(f"[{category}] {message}")
        self.total_checks += 1
        try:
            print(f"✅ [{category}] {message}")
        except UnicodeEncodeError:
            print(f"[PASS] [{category}] {message}")
    
    def check_python_syntax(self):
        """检查Python语法"""
        print("\n" + "=" * 70)
        print("一、Python语法检查")
        print("=" * 70)
        
        python_files = list(self.base_dir.rglob("*.py"))
        python_files = [f for f in python_files if "ten-vad" not in str(f) and "__pycache__" not in str(f)]
        
        for py_file in python_files:
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    code = f.read()
                
                # 尝试解析AST
                ast.parse(code)
                self.log_pass("语法检查", f"{py_file.relative_to(self.base_dir)} - 语法正确")
            except SyntaxError as e:
                self.log_error("语法检查", f"{py_file.relative_to(self.base_dir)} - 语法错误: {e}")
            except Exception as e:
                self.log_warning("语法检查", f"{py_file.relative_to(self.base_dir)} - 检查失败: {e}")
    
    def check_empty_functions(self):
        """检查空函数"""
        print("\n" + "=" * 70)
        print("二、空函数检查")
        print("=" * 70)
        
        python_files = list(self.base_dir.rglob("*.py"))
        python_files = [f for f in python_files if "ten-vad" not in str(f) and "__pycache__" not in str(f)]
        
        for py_file in python_files:
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    code = f.read()
                
                tree = ast.parse(code)
                
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        # 检查函数体
                        if len(node.body) == 0:
                            self.log_error("空函数", f"{py_file.relative_to(self.base_dir)}:{node.lineno} - {node.name}() 函数体为空")
                        elif len(node.body) == 1:
                            # 检查是否只有pass或return None
                            stmt = node.body[0]
                            if isinstance(stmt, ast.Pass):
                                self.log_warning("空函数", f"{py_file.relative_to(self.base_dir)}:{node.lineno} - {node.name}() 只有pass")
                            elif isinstance(stmt, ast.Return):
                                if stmt.value is None or (isinstance(stmt.value, ast.Constant) and stmt.value.value is None):
                                    # 检查是否有注释说明
                                    has_docstring = ast.get_docstring(node) is not None
                                    if not has_docstring:
                                        self.log_warning("空函数", f"{py_file.relative_to(self.base_dir)}:{node.lineno} - {node.name}() 只返回None，无文档说明")
            except Exception as e:
                self.log_warning("空函数检查", f"{py_file.relative_to(self.base_dir)} - 检查失败: {e}")
    
    def check_imports(self):
        """检查导入语句"""
        print("\n" + "=" * 70)
        print("三、导入语句检查")
        print("=" * 70)
        
        key_files = [
            "controller/pipeline.py",
            "controller/agent_manager.py",
            "controller/controller.py",
            "parts/fusion/fusion_controller.py",
            "parts/cv/cv_controller.py",
            "parts/stt/stt_controller.py",
            "adapter/comfyui/comfyui_controller.py",
            "adapter/blender/blender_controller.py",
        ]
        
        for rel_path in key_files:
            file_path = self.base_dir / rel_path
            if not file_path.exists():
                self.log_error("导入检查", f"{rel_path} - 文件不存在")
                continue
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    code = f.read()
                
                tree = ast.parse(code)
                imports = []
                
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            imports.append(alias.name)
                    elif isinstance(node, ast.ImportFrom):
                        module = node.module or ""
                        for alias in node.names:
                            imports.append(f"{module}.{alias.name}" if module else alias.name)
                
                # 尝试导入模块
                try:
                    # 动态导入检查
                    spec = importlib.util.spec_from_file_location("test_module", file_path)
                    if spec and spec.loader:
                        # 只检查语法，不实际执行
                        self.log_pass("导入检查", f"{rel_path} - 导入语句语法正确")
                except Exception as e:
                    self.log_warning("导入检查", f"{rel_path} - 导入可能有问题: {e}")
                    
            except Exception as e:
                self.log_error("导入检查", f"{rel_path} - 检查失败: {e}")
    
    def check_module_initialization(self):
        """检查模块初始化"""
        print("\n" + "=" * 70)
        print("四、模块初始化检查")
        print("=" * 70)
        
        modules_to_check = [
            ("ConfigLoader", "config.config_loader", "ConfigLoader"),
            ("CVController", "parts.cv.cv_controller", "CVController"),
            ("STTController", "parts.stt.stt_controller", "STTController"),
            ("FusionController", "parts.fusion.fusion_controller", "FusionController"),
            ("EmotionToBoneMapper", "parts.fusion.emotion_bone_mapper", "EmotionToBoneMapper"),
            ("BlenderController", "adapter.blender.blender_controller", "BlenderController"),
            ("ComfyUIController", "adapter.comfyui.comfyui_controller", "ComfyUIController"),
            ("CloudComfyUIAPI", "adapter.comfyui.cloud_api", "CloudComfyUIAPI"),
            ("AgentManager", "controller.agent_manager", "AgentManager"),
            ("MainController", "controller.controller", "MainController"),
            ("EndToEndPipeline", "controller.pipeline", "EndToEndPipeline"),
        ]
        
        for name, module_path, class_name in modules_to_check:
            try:
                module = importlib.import_module(module_path)
                cls = getattr(module, class_name)
                
                # 检查类是否有__init__方法
                if hasattr(cls, '__init__'):
                    init_sig = inspect.signature(cls.__init__)
                    self.log_pass("模块初始化", f"{name} - 类定义正确，__init__签名: {init_sig}")
                else:
                    self.log_error("模块初始化", f"{name} - 缺少__init__方法")
                    
            except ImportError as e:
                self.log_error("模块初始化", f"{name} - 导入失败: {e}")
            except AttributeError as e:
                self.log_error("模块初始化", f"{name} - 类不存在: {e}")
            except Exception as e:
                self.log_warning("模块初始化", f"{name} - 检查异常: {e}")
    
    def check_function_calls(self):
        """检查函数调用"""
        print("\n" + "=" * 70)
        print("五、函数调用检查")
        print("=" * 70)
        
        # 检查关键函数调用
        key_calls = [
            ("pipeline.py", "MainController", "initialize", "start"),
            ("pipeline.py", "FusionController", "add_cv_data", "add_stt_data"),
            ("pipeline.py", "AgentManager", "initialize_agents", "make_decision"),
            ("pipeline.py", "ComfyUIController", "load_workflow", "execute_workflow"),
            ("agent_manager.py", "ComfyUIController", "load_workflow", "set_prompt", "execute_workflow"),
            ("comfyui_controller.py", "CloudComfyUIAPI", "register_backend", "create_workflow", "prompt_workflow"),
        ]
        
        for file_name, obj_name, *methods in key_calls:
            file_path = self.base_dir / file_name if "/" not in file_name else self.base_dir / file_name.replace("/", "\\")
            
            if not file_path.exists():
                # 尝试查找
                found = list(self.base_dir.rglob(file_name))
                if found:
                    file_path = found[0]
                else:
                    self.log_warning("函数调用", f"{file_name} - 文件未找到")
                    continue
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    code = f.read()
                
                # 检查方法是否被调用
                for method in methods:
                    if f".{method}(" in code or f"{method}(" in code:
                        self.log_pass("函数调用", f"{file_name} - {obj_name}.{method}() 被调用")
                    else:
                        self.log_warning("函数调用", f"{file_name} - {obj_name}.{method}() 可能未被调用")
                        
            except Exception as e:
                self.log_warning("函数调用", f"{file_name} - 检查失败: {e}")
    
    def check_data_flow(self):
        """检查数据流"""
        print("\n" + "=" * 70)
        print("六、数据流检查")
        print("=" * 70)
        
        # 检查关键数据流节点
        flow_checks = [
            ("CV数据流", ["cv_controller.py", "controller.py"], "cv", "start_cv_stream"),
            ("STT数据流", ["stt_controller.py", "controller.py"], "stt", "start_stt_stream"),
            ("融合数据流", "fusion_controller.py", "add_cv_data", "add_stt_data", "synchronizer"),
            ("Agent决策流", "agent_manager.py", "orchestrate", "initialize_agents"),
            ("骨骼控制流", "emotion_bone_mapper.py", "map_emotion_to_bones"),
            ("视频生成流", "comfyui_controller.py", "load_workflow", "execute_workflow"),
        ]
        
        for flow_item in flow_checks:
            flow_name = flow_item[0]
            file_names = flow_item[1] if isinstance(flow_item[1], list) else [flow_item[1]]
            key_methods = flow_item[2:]
            
            # 查找文件
            found_files = []
            for file_name in file_names:
                found = list(self.base_dir.rglob(file_name))
                found_files.extend(found)
            
            if not found_files:
                self.log_error("数据流", f"{flow_name} - 文件未找到: {file_names}")
                continue
            
            # 检查所有方法是否在任一文件中存在
            all_found = True
            for method in key_methods:
                method_found = False
                for file_path in found_files:
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            code = f.read()
                        if method in code:
                            method_found = True
                            break
                    except:
                        pass
                
                if not method_found:
                    all_found = False
                    self.log_error("数据流", f"{flow_name} - 缺少关键方法: {method}")
            
            if all_found:
                self.log_pass("数据流", f"{flow_name} - 关键方法存在")
    
    def check_config_files(self):
        """检查配置文件"""
        print("\n" + "=" * 70)
        print("七、配置文件检查")
        print("=" * 70)
        
        config_files = [
            "config/cv_config.yaml",
            "config/stt_config.yaml",
            "config/fusion_config.yaml",
            "config/blender_config.yaml",
            "config/comfyui_config.yaml",
            "config/mcp_config.yaml",
            "config/deepseek_key",
            "config/comfyui_cloud/api_key",
            "config/comfyui_cloud/instance_id",
        ]
        
        for config_file in config_files:
            file_path = self.base_dir / config_file
            if file_path.exists():
                if file_path.stat().st_size > 0:
                    self.log_pass("配置文件", f"{config_file} - 存在且非空")
                else:
                    self.log_warning("配置文件", f"{config_file} - 存在但为空")
            else:
                self.log_error("配置文件", f"{config_file} - 不存在")
    
    def check_critical_functions(self):
        """检查关键函数实现"""
        print("\n" + "=" * 70)
        print("八、关键函数实现检查")
        print("=" * 70)
        
        critical_functions = [
            ("ComfyUIController", "load_workflow", "工作流加载"),
            ("ComfyUIController", "execute_workflow", "工作流执行"),
            ("ComfyUIController", "set_prompt", "提示词设置"),
            ("CloudComfyUIAPI", "create_workflow", "创建工作流"),
            ("CloudComfyUIAPI", "prompt_workflow", "发送prompt"),
            ("FusionController", "add_cv_data", "添加CV数据"),
            ("FusionController", "add_stt_data", "添加STT数据"),
            ("TemporalSynchronizer", "synchronize", "时间同步"),
            ("AgentManager", "initialize_agents", "初始化Agent"),
            ("AgentManager", "orchestrate", "Agent编排"),
            ("EndToEndPipeline", "start", "启动流程"),
        ]
        
        for class_name, method_name, desc in critical_functions:
            # 查找类定义
            found = False
            for py_file in self.base_dir.rglob("*.py"):
                if "ten-vad" in str(py_file) or "__pycache__" in str(py_file):
                    continue
                try:
                    with open(py_file, 'r', encoding='utf-8') as f:
                        code = f.read()
                    
                    if f"class {class_name}" in code:
                        # 检查方法是否存在
                        if f"def {method_name}" in code:
                            # 检查方法是否有实现（不只是pass）
                            tree = ast.parse(code)
                            for node in ast.walk(tree):
                                if isinstance(node, ast.ClassDef) and node.name == class_name:
                                    for item in node.body:
                                        if isinstance(item, ast.FunctionDef) and item.name == method_name:
                                            if len(item.body) > 0 and not (len(item.body) == 1 and isinstance(item.body[0], ast.Pass)):
                                                self.log_pass("关键函数", f"{class_name}.{method_name}() - {desc} - 已实现")
                                                found = True
                                                break
                                    break
                        if not found:
                            self.log_error("关键函数", f"{class_name}.{method_name}() - {desc} - 未找到或未实现")
                except:
                    pass
            
            if not found:
                self.log_warning("关键函数", f"{class_name}.{method_name}() - {desc} - 未找到类定义")
    
    def check_integration(self):
        """检查集成"""
        print("\n" + "=" * 70)
        print("九、集成检查")
        print("=" * 70)
        
        # 检查Pipeline是否能正确初始化所有模块
        try:
            from controller.pipeline import EndToEndPipeline
            
            # 尝试初始化（不实际运行）
            try:
                # 检查__init__方法
                init_sig = inspect.signature(EndToEndPipeline.__init__)
                self.log_pass("集成检查", "EndToEndPipeline.__init__ - 签名正确")
                
                # 检查关键方法
                required_methods = ['start', 'stop', '_handle_fusion_result', '_make_agent_decision']
                for method in required_methods:
                    if hasattr(EndToEndPipeline, method):
                        self.log_pass("集成检查", f"EndToEndPipeline.{method} - 存在")
                    else:
                        self.log_error("集成检查", f"EndToEndPipeline.{method} - 不存在")
                        
            except Exception as e:
                self.log_warning("集成检查", f"EndToEndPipeline - 检查异常: {e}")
                
        except ImportError as e:
            self.log_error("集成检查", f"EndToEndPipeline - 导入失败: {e}")
    
    def generate_report(self):
        """生成检测报告"""
        print("\n" + "=" * 70)
        print("检测报告")
        print("=" * 70)
        
        total = self.total_checks
        passed_count = len(self.passed)
        warning_count = len(self.warnings)
        error_count = len(self.errors)
        
        print(f"\n总计: {total} 项检测")
        print(f"通过: {passed_count} 项 ({passed_count/total*100:.1f}%)")
        print(f"警告: {warning_count} 项 ({warning_count/total*100:.1f}%)")
        print(f"错误: {error_count} 项 ({error_count/total*100:.1f}%)")
        
        if error_count > 0:
            print("\n错误列表:")
            for error in self.errors:
                print(f"  {error}")
        
        if warning_count > 0:
            print("\n警告列表:")
            for warning in self.warnings[:10]:  # 只显示前10个
                print(f"  {warning}")
            if warning_count > 10:
                print(f"  ... 还有 {warning_count - 10} 个警告")
        
        print("\n" + "=" * 70)
        if error_count == 0:
            try:
                print("✅ 系统检测通过！")
            except UnicodeEncodeError:
                print("[PASS] 系统检测通过！")
            return True
        else:
            try:
                print(f"❌ 系统检测失败，发现 {error_count} 个错误")
            except UnicodeEncodeError:
                print(f"[ERROR] 系统检测失败，发现 {error_count} 个错误")
            return False
    
    def run_all_checks(self):
        """运行所有检测"""
        print("=" * 70)
        print("完整系统自检测")
        print("=" * 70)
        print(f"检测时间: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"项目路径: {self.base_dir}")
        
        # 执行各项检测
        self.check_python_syntax()
        self.check_empty_functions()
        self.check_imports()
        self.check_module_initialization()
        self.check_function_calls()
        self.check_data_flow()
        self.check_config_files()
        self.check_critical_functions()
        self.check_integration()
        
        # 生成报告
        return self.generate_report()


def main():
    """主函数"""
    checker = SystemChecker()
    success = checker.run_all_checks()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()

