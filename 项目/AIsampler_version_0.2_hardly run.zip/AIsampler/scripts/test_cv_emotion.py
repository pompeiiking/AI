#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CV情感识别测试工具
实时识别人物表情并输出情感判断
"""

import os
import sys
import time
import logging
from pathlib import Path
from collections import deque

# 配置日志以查看调试信息
logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s: %(message)s'
)

# 设置项目根目录
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)

from parts.cv.cv_controller import CVController


class EmotionDisplay:
    """情感识别显示管理器"""
    
    # 情感映射（中文）- 更新为FER+标准
    EMOTION_MAP = {
        'neutral': '😐 平静',
        'happiness': '😊 开心',
        'happy': '😊 开心',
        'surprise': '😲 惊讶',
        'surprised': '😲 惊讶',
        'sadness': '😢 悲伤',
        'sad': '😢 悲伤',
        'anger': '😠 生气',
        'angry': '😠 生气',
        'disgust': '🤢 厌恶',
        'disgusted': '🤢 厌恶',
        'fear': '😨 恐惧',
        'fearful': '😨 恐惧',
        'contempt': '😒 蔑视'
    }
    
    def __init__(self):
        self.start_time = time.time()
        self.frame_count = 0
        self.detection_count = 0
        self.emotion_history = deque(maxlen=30)  # 最近30帧的情感历史
        self.current_emotion = 'neutral'
        self.current_confidence = 0.0
        
    def update(self, result):
        """更新显示"""
        self.frame_count += 1
        elapsed = time.time() - self.start_time
        
        # 只在检测到人脸或每10帧清一次屏，避免闪烁
        if result['face_detected'] or self.frame_count % 10 == 0:
            os.system('cls' if os.name == 'nt' else 'clear')
        
        print("=" * 80)
        print(f"🎥 CV情感识别测试")
        print("=" * 80)
        print(f"运行时间: {elapsed:.1f}s | 总帧数: {self.frame_count} | 检测次数: {self.detection_count}")
        print("-" * 80)
        
        if result['face_detected']:
            self.detection_count += 1
            emotion = result['emotion']
            confidence = result['confidence']
            
            # 只有置信度足够高才记录
            if confidence >= 0.4:
                self.current_emotion = emotion
                self.current_confidence = confidence
                self.emotion_history.append(emotion)
            else:
                # 低置信度，显示但不记录
                self.current_emotion = emotion
                self.current_confidence = confidence
            
            # 显示当前情感
            emotion_display = self.EMOTION_MAP.get(emotion, f"🤔 {emotion}")
            print(f"\n✅ 检测到人脸!")
            print(f"📊 当前情感: {emotion_display}")
            print(f"🎯 置信度: {confidence:.2%}")
            
            # 显示情感变化提示
            if len(self.emotion_history) >= 2 and self.emotion_history[-1] != self.emotion_history[-2]:
                prev_emotion = self.EMOTION_MAP.get(self.emotion_history[-2], self.emotion_history[-2])
                print(f"💫 情感变化: {prev_emotion} → {emotion_display}")
            
            # 置信度条
            bar_length = 40
            filled = int(confidence * bar_length)
            bar = '█' * filled + '░' * (bar_length - filled)
            
            if confidence >= 0.8:
                color = '🟢'  # 高置信度
            elif confidence >= 0.6:
                color = '🟡'  # 中等置信度
            else:
                color = '🔴'  # 低置信度
            
            print(f"置信度条: {color} [{bar}] {confidence:.2%}")
            
            # 人脸位置
            if result['face_positions'] is not None:
                positions = result['face_positions']
                print(f"\n📍 人脸位置:")
                try:
                    # 处理单个元组格式 (x, y, w, h)
                    if isinstance(positions, (tuple, list)) and len(positions) == 4:
                        # 检查是否都是数值
                        if all(isinstance(p, (int, float)) or hasattr(p, 'item') for p in positions):
                            x = int(positions[0]) if hasattr(positions[0], 'item') else positions[0]
                            y = int(positions[1]) if hasattr(positions[1], 'item') else positions[1]
                            w = int(positions[2]) if hasattr(positions[2], 'item') else positions[2]
                            h = int(positions[3]) if hasattr(positions[3], 'item') else positions[3]
                            print(f"   X={x}, Y={y}, 宽={w}, 高={h}")
                        else:
                            # 可能是多个人脸
                            for i, pos in enumerate(positions, 1):
                                if isinstance(pos, (list, tuple)) and len(pos) >= 4:
                                    print(f"   人脸{i}: X={pos[0]}, Y={pos[1]}, 宽={pos[2]}, 高={pos[3]}")
                    else:
                        print(f"   位置: {positions}")
                except Exception as e:
                    print(f"   (解析错误: {type(positions).__name__})")
            
            # 情感历史统计
            if len(self.emotion_history) >= 10:
                print(f"\n📈 最近情感趋势 (最近{len(self.emotion_history)}帧):")
                emotion_counts = {}
                for e in self.emotion_history:
                    emotion_counts[e] = emotion_counts.get(e, 0) + 1
                
                # 按频率排序
                sorted_emotions = sorted(emotion_counts.items(), key=lambda x: x[1], reverse=True)
                for emotion, count in sorted_emotions[:3]:
                    percentage = count / len(self.emotion_history) * 100
                    emotion_display = self.EMOTION_MAP.get(emotion, emotion)
                    print(f"   {emotion_display}: {percentage:.1f}% ({count}次)")
            
            # 情感分析
            print(f"\n💭 情感分析:")
            self._analyze_emotion(emotion, confidence)
            
        else:
            print(f"\n⚠️  未检测到人脸")
            print("提示:")
            print("  - 确保摄像头对准人脸")
            print("  - 保持良好的光线")
            print("  - 面对摄像头")
        
        print("\n" + "=" * 80)
        print("按 Ctrl+C 停止测试 | 按 'q' 键退出")
        print("=" * 80)
    
    def _analyze_emotion(self, emotion, confidence):
        """情感分析"""
        emotion_lower = emotion.lower()
        
        if emotion_lower == 'neutral':
            print("   状态平稳，情绪稳定")
        elif emotion_lower in ['happiness', 'happy']:
            print("   心情愉悦，状态良好")
        elif emotion_lower in ['surprise', 'surprised']:
            print("   表现出惊讶，可能遇到意外")
        elif emotion_lower in ['sadness', 'sad']:
            print("   情绪低落，需要关注")
        elif emotion_lower in ['anger', 'angry']:
            print("   情绪激动，需要冷静")
        elif emotion_lower in ['disgust', 'disgusted']:
            print("   表现出厌恶，可能不满")
        elif emotion_lower in ['fear', 'fearful']:
            print("   感到恐惧，需要安慰")
        elif emotion_lower == 'contempt':
            print("   表现出轻蔑，态度消极")
        else:
            print(f"   检测到情感: {emotion}")
        
        if confidence < 0.5:
            print("   ⚠️  置信度较低，结果可能不准确")
        elif confidence >= 0.8:
            print("   ✅ 置信度高，结果可靠")
    
    def print_statistics(self):
        """打印统计信息"""
        elapsed = time.time() - self.start_time
        
        print("\n" + "=" * 80)
        print("📊 测试统计")
        print("=" * 80)
        print(f"总运行时间: {elapsed:.1f}秒")
        print(f"总处理帧数: {self.frame_count}")
        print(f"检测到人脸: {self.detection_count}次")
        print(f"检测率: {self.detection_count/self.frame_count*100:.1f}%")
        print(f"平均FPS: {self.frame_count/elapsed:.1f}")
        
        if self.emotion_history:
            print(f"\n情感分布:")
            emotion_counts = {}
            for e in self.emotion_history:
                emotion_counts[e] = emotion_counts.get(e, 0) + 1
            
            for emotion, count in sorted(emotion_counts.items(), key=lambda x: x[1], reverse=True):
                percentage = count / len(self.emotion_history) * 100
                emotion_display = self.EMOTION_MAP.get(emotion, emotion)
                print(f"  {emotion_display}: {percentage:.1f}% ({count}次)")
        
        print("=" * 80)


def test_cv_emotion():
    """测试CV情感识别"""
    display = EmotionDisplay()
    
    print("=" * 80)
    print("🎥 CV情感识别测试")
    print("=" * 80)
    print("\n初始化中...")
    
    try:
        # 加载配置
        config_loader = get_config_loader()
        cv_config = config_loader.get_cv_config()
        
        # 初始化CV控制器
        cv_controller = CVController(cv_config)
        cv_controller.debug_mode = True  # 启用调试模式
        
        print("✅ CV控制器初始化完成")
        print("✅ 调试模式已启用")
        print("✅ 正在启动摄像头...")
        
        # 启动摄像头
        cv_controller.start_camera()
        
        print("✅ 摄像头已启动")
        print("\n开始识别...\n")
        
        # 回调函数
        def on_result(result):
            display.update(result)
        
        # 开始流式处理（不显示窗口，只输出结果）
        cv_controller.cv(callback=on_result, show_window=False)
        
    except KeyboardInterrupt:
        print("\n\n收到中断信号 (Ctrl+C)")
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("\n正在清理资源...")
        try:
            cv_controller.stop_camera()
            print("✅ 摄像头已关闭")
        except:
            pass
        
        # 打印统计
        display.print_statistics()


def main():
    print("\n" + "=" * 80)
    print("🎥 CV情感识别测试工具")
    print("=" * 80)
    print("\n功能:")
    print("  - 实时检测人脸")
    print("  - 识别情感表情")
    print("  - 显示置信度")
    print("  - 情感趋势分析")
    print("\n支持的情感:")
    print("  😐 平静 | 😊 开心 | 😲 惊讶 | 😢 悲伤")
    print("  😠 生气 | 🤢 厌恶 | 😨 恐惧 | 😒 蔑视")
    print("\n提示:")
    print("  - 确保摄像头正常工作")
    print("  - 保持良好的光线条件")
    print("  - 面对摄像头，表情清晰")
    print("\n按 Ctrl+C 停止测试\n")
    
    input("按回车开始测试...")
    
    test_cv_emotion()
    
    print("\n" + "=" * 80)
    print("测试完成")
    print("=" * 80)


if __name__ == "__main__":
    main()
