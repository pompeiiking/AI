#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检测总结脚本
生成所有检测的总结报告，包括问题定位和建议
"""

import sys
import os
import json
from pathlib import Path
from typing import Dict, List, Tuple
from datetime import datetime

# 添加项目路径
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))


class CheckSummary:
    """检测总结生成器"""
    
    def __init__(self):
        self.issues = []
        self.warnings = []
        self.passed = []
        self.total_checks = 0
        
    def add_issue(self, category: str, module: str, issue: str, location: str = "", suggestion: str = ""):
        """添加问题"""
        self.issues.append({
            'category': category,
            'module': module,
            'issue': issue,
            'location': location,
            'suggestion': suggestion,
            'severity': 'error'
        })
        self.total_checks += 1
    
    def add_warning(self, category: str, module: str, warning: str, location: str = "", suggestion: str = ""):
        """添加警告"""
        self.warnings.append({
            'category': category,
            'module': module,
            'warning': warning,
            'location': location,
            'suggestion': suggestion,
            'severity': 'warning'
        })
        self.total_checks += 1
    
    def add_passed(self, category: str, module: str, message: str):
        """添加通过项"""
        self.passed.append({
            'category': category,
            'module': module,
            'message': message
        })
        self.total_checks += 1
    
    def generate_report(self) -> str:
        """生成报告"""
        report = []
        report.append("=" * 70)
        report.append("  检测总结报告")
        report.append("=" * 70)
        report.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append(f"项目路径: {current_dir}")
        report.append("")
        
        # 统计信息
        report.append("统计信息:")
        report.append(f"  总检测项: {self.total_checks}")
        report.append(f"  通过: {len(self.passed)}")
        report.append(f"  警告: {len(self.warnings)}")
        report.append(f"  错误: {len(self.issues)}")
        report.append("")
        
        # 错误列表
        if self.issues:
            report.append("=" * 70)
            report.append("  错误列表（需要修复）")
            report.append("=" * 70)
            for i, issue in enumerate(self.issues, 1):
                report.append(f"\n{i}. [{issue['category']}] {issue['module']}")
                report.append(f"   问题: {issue['issue']}")
                if issue['location']:
                    report.append(f"   位置: {issue['location']}")
                if issue['suggestion']:
                    report.append(f"   建议: {issue['suggestion']}")
        
        # 警告列表
        if self.warnings:
            report.append("\n" + "=" * 70)
            report.append("  警告列表（建议修复）")
            report.append("=" * 70)
            for i, warning in enumerate(self.warnings, 1):
                report.append(f"\n{i}. [{warning['category']}] {warning['module']}")
                report.append(f"   警告: {warning['warning']}")
                if warning['location']:
                    report.append(f"   位置: {warning['location']}")
                if warning['suggestion']:
                    report.append(f"   建议: {warning['suggestion']}")
        
        # 通过列表（简要）
        if self.passed:
            report.append("\n" + "=" * 70)
            report.append("  通过项（简要）")
            report.append("=" * 70)
            categories = {}
            for item in self.passed:
                cat = item['category']
                if cat not in categories:
                    categories[cat] = []
                categories[cat].append(item['module'])
            
            for cat, modules in categories.items():
                report.append(f"\n{cat}: {', '.join(modules)}")
        
        report.append("\n" + "=" * 70)
        if not self.issues:
            report.append("[OK] 所有关键检测通过！")
        else:
            report.append(f"[FAIL] 发现 {len(self.issues)} 个错误，请根据上述提示修复。")
        report.append("=" * 70)
        
        return "\n".join(report)
    
    def save_report(self, file_path: Path = None):
        """保存报告到文件"""
        if file_path is None:
            file_path = current_dir / "scripts" / "check_report.txt"
        
        report = self.generate_report()
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n报告已保存到: {file_path}")


def main():
    """主函数"""
    print("=" * 70)
    print("  检测总结生成器")
    print("=" * 70)
    
    summary = CheckSummary()
    
    # 这里可以添加从各个检测脚本收集结果的逻辑
    # 目前作为示例，展示报告格式
    
    print("\n生成检测总结报告...")
    report = summary.generate_report()
    print(report)
    
    # 保存报告
    summary.save_report()
    
    return len(summary.issues) == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

