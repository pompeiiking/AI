#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据流检查脚本
检查数据流各节点的数据格式和处理流程
"""

import sys
import os
import time
from pathlib import Path
from typing import Dict, Any

# 添加项目路径
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))


def check_cv_data_format():
    """检查CV数据格式"""
    print("\n检查CV数据格式:")
    
    try:
        # 模拟CV数据
        cv_data = {
            'timestamp': time.time(),
            'sequence_id': 1,
            'emotion': 'happy',
            'confidence': 0.85,
            'face_detected': True,
            'face_positions': (100, 100, 200, 200)
        }
        
        # 检查必需字段
        required_fields = ['timestamp', 'emotion', 'confidence', 'face_detected']
        missing_fields = [f for f in required_fields if f not in cv_data]
        
        if missing_fields:
            print(f"❌ CV数据缺少字段: {', '.join(missing_fields)}")
            return False
        
        # 检查数据类型
        assert isinstance(cv_data['timestamp'], (int, float))
        assert isinstance(cv_data['emotion'], str)
        assert isinstance(cv_data['confidence'], (int, float))
        assert 0.0 <= cv_data['confidence'] <= 1.0
        
        print("✅ CV数据格式正确")
        return True
    except Exception as e:
        print(f"❌ CV数据格式检查失败: {e}")
        return False


def check_stt_data_format():
    """检查STT数据格式"""
    print("\n检查STT数据格式:")
    
    try:
        # 模拟STT数据
        stt_data = {
            'timestamp': time.time(),
            'sequence_id': 1,
            'text': '你好',
            'confidence': 1.0,
            'is_final': True
        }
        
        # 检查必需字段
        required_fields = ['timestamp', 'text']
        missing_fields = [f for f in required_fields if f not in stt_data]
        
        if missing_fields:
            print(f"❌ STT数据缺少字段: {', '.join(missing_fields)}")
            return False
        
        # 检查数据类型
        assert isinstance(stt_data['timestamp'], (int, float))
        assert isinstance(stt_data['text'], str)
        
        print("✅ STT数据格式正确")
        return True
    except Exception as e:
        print(f"❌ STT数据格式检查失败: {e}")
        return False


def check_fusion_result_format():
    """检查融合结果格式"""
    print("\n检查融合结果格式:")
    
    try:
        from parts.fusion.fusion_controller import FusionResult
        
        # 创建融合结果
        result = FusionResult(
            timestamp=time.time(),
            emotion='happy',
            confidence=0.8,
            sources={'cv': {}, 'stt': {}},
            fusion_method='weighted_average',
            sequence_id=1
        )
        
        # 检查必需字段
        assert hasattr(result, 'timestamp')
        assert hasattr(result, 'emotion')
        assert hasattr(result, 'confidence')
        assert hasattr(result, 'sources')
        assert hasattr(result, 'fusion_method')
        
        # 检查数据类型和范围
        assert isinstance(result.confidence, (int, float))
        assert 0.0 <= result.confidence <= 1.0
        
        print("✅ 融合结果格式正确")
        return True
    except Exception as e:
        print(f"❌ 融合结果格式检查失败: {e}")
        return False


def check_emotion_bone_mapping():
    """检查情绪到骨骼映射"""
    print("\n检查情绪到骨骼映射:")
    
    try:
        from parts.fusion.emotion_bone_mapper import EmotionToBoneMapper
        from pathlib import Path
        
        # 使用增强版映射
        enhanced_mapping_file = Path(__file__).resolve().parent.parent / "config" / "enhanced_bone_mapping.yaml"
        if enhanced_mapping_file.exists():
            mapper = EmotionToBoneMapper(mapping_file=str(enhanced_mapping_file))
        else:
            mapper = EmotionToBoneMapper()
        
        # 测试各种情绪
        emotions = ['happy', 'sad', 'angry', 'neutral', 'surprised']
        
        for emotion in emotions:
            bone_poses = mapper.map_emotion_to_bones(emotion, 0.8)
            assert isinstance(bone_poses, list)
            if len(bone_poses) > 0:
                # 检查骨骼姿势格式（可能是字典或对象）
                for pose in bone_poses:
                    # 检查是否为字典或对象
                    if isinstance(pose, dict):
                        assert 'bone_name' in pose or 'name' in pose
                    else:
                        assert hasattr(pose, 'bone_name') or hasattr(pose, 'name') or 'bone_name' in pose.__dict__
        
        print("✅ 情绪到骨骼映射正常")
        return True
    except Exception as e:
        print(f"❌ 情绪到骨骼映射检查失败: {e}")
        return False


def check_temporal_sync():
    """检查时间同步器"""
    print("\n检查时间同步器:")
    
    try:
        from parts.fusion.fusion_controller import FusionController
        from config.config_loader import config_loader
        
        config = config_loader.get_fusion_config()
        controller = FusionController(config=config)
        
        # 获取时间同步器
        sync = controller.synchronizer
        
        # 添加测试数据
        current_time = time.time()
        sync.add_data('cv', current_time, {'emotion': 'happy'})
        sync.add_data('stt', current_time, {'text': 'hello'})
        
        # 测试同步
        synced_data = sync.synchronize(current_time)
        
        assert 'cv' in synced_data
        assert 'stt' in synced_data
        
        print("✅ 时间同步器正常")
        return True
    except Exception as e:
        print(f"❌ 时间同步器检查失败: {e}")
        return False


def check_event_queue():
    """检查事件队列"""
    print("\n检查事件队列:")
    
    try:
        from controller.controller import EventQueue, Event
        
        queue = EventQueue(max_size=100)
        
        # 创建测试事件
        event = Event(
            event_type='test',
            timestamp=time.time(),
            sequence_id=1,
            data={'test': 'data'},
            source='test'
        )
        
        # 测试添加事件
        success = queue.put(event)
        assert success
        
        # 测试获取事件
        retrieved_event = queue.get(timeout=1.0)
        assert retrieved_event is not None
        assert retrieved_event.event_type == 'test'
        
        print("✅ 事件队列正常")
        return True
    except Exception as e:
        print(f"❌ 事件队列检查失败: {e}")
        return False


def main():
    print("=" * 50)
    print("数据流检查")
    print("=" * 50)
    
    all_ok = True
    
    # 检查各个数据流节点
    checks = [
        ("CV数据格式", check_cv_data_format),
        ("STT数据格式", check_stt_data_format),
        ("融合结果格式", check_fusion_result_format),
        ("情绪到骨骼映射", check_emotion_bone_mapping),
        ("时间同步器", check_temporal_sync),
        ("事件队列", check_event_queue),
    ]
    
    for check_name, check_func in checks:
        if not check_func():
            all_ok = False
    
    print("\n" + "=" * 50)
    if all_ok:
        print("✅ 所有数据流检查通过！")
    else:
        print("❌ 部分数据流存在问题，请检查上述提示")
    print("=" * 50)
    
    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

