#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
项目启动脚本
用于启动多模态实时交互具身智能数字人系统的完整流程。
"""

import argparse
import logging
import signal
import sys
import threading
import time
from pathlib import Path
from typing import Optional

# 先将项目根目录加入 sys.path，确保可以导入内部模块
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 设置项目路径，确保可以导入内部模块
from utils.path_utils import setup_project_path  # type: ignore

PROJECT_ROOT = setup_project_path(__file__)

# 现在可以安全导入项目内部模块
from controller.pipeline import EndToEndPipeline  # noqa: E402  # type: ignore


class PipelineRunner:
    """
    封装端到端流程的启动、运行和停止逻辑。
    """

    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.pipeline: Optional[EndToEndPipeline] = None
        self._shutdown_event = threading.Event()

    def run(self) -> int:
        """
        启动完整流程并阻塞直到退出。

        Returns:
            int: 进程退出码，0 表示成功退出。
        """
        try:
            self._configure_logging()
            logging.info("项目根目录: %s", PROJECT_ROOT)

            pipeline_config = self._build_pipeline_config()
            self.pipeline = EndToEndPipeline(config=pipeline_config)

            if not self.pipeline.start():
                logging.error("端到端流程启动失败")
                return 1

            logging.info("端到端流程已启动，按 Ctrl+C 结束。")

            self._install_signal_handlers()
            self._wait_for_shutdown()

        except KeyboardInterrupt:
            logging.info("收到中断信号，即将退出...")
        except Exception:
            logging.exception("运行过程中发生未捕获的异常")
            return 1
        finally:
            self._cleanup_pipeline()

        logging.info("系统已安全退出。")
        return 0

    def _configure_logging(self) -> None:
        """
        配置日志级别和格式。
        """
        log_level = getattr(logging, self.args.log_level.upper(), logging.INFO)
        logging.basicConfig(
            level=log_level,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        )

    def _build_pipeline_config(self) -> dict:
        """
        根据命令行参数构建传递给 Pipeline 的配置。
        """
        preload_config = {
            "enable": not self.args.skip_preload,
            "parallel": not self.args.no_parallel_preload,
        }

        agent_config = {
            "verbose": self.args.agent_verbose,
        }

        pipeline_config = {
            "preload": preload_config,
            "agent": agent_config,
        }

        return pipeline_config

    def _install_signal_handlers(self) -> None:
        """
        安装信号处理器，响应 Ctrl+C 和终止信号。
        """
        def handle_signal(signum, frame):
            logging.info("收到信号 %s，准备停止系统...", signum)
            self._shutdown_event.set()

        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)

    def _wait_for_shutdown(self) -> None:
        """
        根据命令行参数的运行时长等待退出。
        """
        if self.args.runtime > 0:
            logging.info("系统将运行 %s 秒，如需提前退出请按 Ctrl+C。", self.args.runtime)
            self._shutdown_event.wait(timeout=self.args.runtime)
            if not self._shutdown_event.is_set():
                logging.info("达到预设运行时长，准备停止系统。")
        else:
            while not self._shutdown_event.is_set():
                time.sleep(1.0)

    def _cleanup_pipeline(self) -> None:
        """
        停止并清理管道资源。
        """
        if not self.pipeline:
            return

        try:
            logging.info("正在停止端到端流程...")
            self.pipeline.stop()
        except Exception:
            logging.exception("停止流程时出现异常")

        try:
            self.pipeline.cleanup()
        except Exception:
            logging.exception("清理流程资源时出现异常")


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    """
    解析命令行参数。

    Args:
        argv: 可选的参数列表，默认为 sys.argv[1:].

    Returns:
        argparse.Namespace: 解析后的参数对象。
    """
    parser = argparse.ArgumentParser(
        description="启动多模态实时交互具身智能数字人系统"
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        help="日志级别 (默认: INFO)",
    )
    parser.add_argument(
        "--skip-preload",
        action="store_true",
        help="跳过模型预加载",
    )
    parser.add_argument(
        "--no-parallel-preload",
        action="store_true",
        help="预加载时禁用并行加载",
    )
    parser.add_argument(
        "--runtime",
        type=int,
        default=0,
        help="系统运行时长（秒），0 表示持续运行直到手动停止",
    )
    parser.add_argument(
        "--agent-verbose",
        action="store_true",
        help="启用 AgentManager 的详细日志",
    )

    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    """
    程序入口。
    """
    args = parse_args(argv)
    runner = PipelineRunner(args)
    return runner.run()


if __name__ == "__main__":
    sys.exit(main())

