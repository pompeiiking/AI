#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置检查脚本
检查所有配置文件是否存在、格式是否正确
"""

import sys
import os
import yaml
from pathlib import Path

# 添加项目路径
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))

from config.config_loader import config_loader


def check_yaml_file(file_path, required_keys=None):
    """检查YAML文件"""
    if not file_path.exists():
        print(f"[FAIL] {file_path} - 不存在")
        print(f"  位置: {file_path.absolute()}")
        print(f"  建议: 创建配置文件或检查路径")
        return False
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        if config is None:
            print(f"[WARN] {file_path} - 文件为空")
            print(f"  位置: {file_path.absolute()}")
            print(f"  建议: 添加配置内容")
            return False
        
        # 检查必需键
        if required_keys:
            missing_keys = []
            for key in required_keys:
                if key not in config:
                    missing_keys.append(key)
            if missing_keys:
                print(f"[FAIL] {file_path} - 缺少必需键: {', '.join(missing_keys)}")
                print(f"  位置: {file_path.absolute()}")
                print(f"  建议: 在配置文件中添加以下键: {', '.join(missing_keys)}")
                return False
        
        print(f"[OK] {file_path} - 格式正确")
        return True
    except yaml.YAMLError as e:
        print(f"[FAIL] {file_path} - YAML格式错误: {e}")
        print(f"  位置: {file_path.absolute()}")
        print(f"  建议: 检查YAML语法，可以使用在线YAML验证器")
        return False
    except Exception as e:
        print(f"[FAIL] {file_path} - 读取失败: {e}")
        print(f"  位置: {file_path.absolute()}")
        return False


def check_text_file(file_path, min_size=1):
    """检查文本文件"""
    if not file_path.exists():
        print(f"[FAIL] {file_path} - 不存在")
        print(f"  位置: {file_path.absolute()}")
        print(f"  建议: 创建该文件并填写内容")
        return False
    
    try:
        # 尝试多种编码
        content = None
        for encoding in ['utf-8', 'utf-8-sig', 'gbk', 'latin-1']:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read().strip()
                break
            except UnicodeDecodeError:
                continue
        
        if content is None:
            print(f"[FAIL] {file_path} - 无法读取（编码问题）")
            print(f"  位置: {file_path.absolute()}")
            return False
        
        if len(content) < min_size:
            print(f"[FAIL] {file_path} - 内容为空或过短 (需要至少{min_size}个字符)")
            print(f"  位置: {file_path.absolute()}")
            print(f"  建议: 填写有效内容")
            return False
        
        print(f"[OK] {file_path} - 内容有效 (长度: {len(content)} 字符)")
        return True
    except Exception as e:
        print(f"[FAIL] {file_path} - 读取失败: {e}")
        print(f"  位置: {file_path.absolute()}")
        return False


def main():
    print("=" * 50)
    print("配置文件检查")
    print("=" * 50)
    
    base_dir = Path(__file__).parent.parent
    config_dir = base_dir / "config"
    
    all_ok = True
    
    # 检查YAML配置文件
    yaml_configs = [
        (config_dir / "cv_config.yaml", ["camera", "emotion_recognition"]),
        (config_dir / "stt_config.yaml", ["recording", "vad", "asr"]),
        (config_dir / "fusion_config.yaml", ["fusion_strategy", "temporal"]),
        (config_dir / "blender_config.yaml", ["paths", "bone"]),
        (config_dir / "comfyui_config.yaml", ["server", "workflow"]),
        (config_dir / "mcp_config.yaml", ["server"]),
        (config_dir / "preload_config.yaml", ["preload"]),  # 模型预加载配置
    ]
    
    print("\nYAML配置文件:")
    for config_file, required_keys in yaml_configs:
        if not check_yaml_file(config_file, required_keys):
            all_ok = False
    
    # 检查文本配置文件
    print("\n文本配置文件:")
    text_configs = [
        (config_dir / "deepseek_key", 10),  # API密钥至少10个字符
        (config_dir / "comfyui_cloud" / "api_key", 1),  # API密钥文件
        (config_dir / "comfyui_cloud" / "instance_id", 1),  # 实例ID文件
    ]
    
    for config_file, min_size in text_configs:
        if not check_text_file(config_file, min_size):
            all_ok = False
    
    # 检查配置加载器
    print("\n配置加载器测试:")
    try:
        cv_config = config_loader.get_cv_config()
        print("✅ CV配置加载成功")
        
        stt_config = config_loader.get_stt_config()
        print("✅ STT配置加载成功")
        
        fusion_config = config_loader.get_fusion_config()
        print("✅ Fusion配置加载成功")
        
        blender_config = config_loader.get_blender_config()
        print("✅ Blender配置加载成功")
        
        comfyui_config = config_loader.get_comfyui_config()
        print("✅ ComfyUI配置加载成功")
        
        mcp_config = config_loader.get_mcp_config()
        print("✅ MCP配置加载成功")
    except Exception as e:
        print(f"[FAIL] 配置加载失败: {e}")
        print(f"  位置: config/config_loader.py")
        print(f"  建议: 检查配置加载器的实现和配置文件格式")
        all_ok = False
    
    print("\n" + "=" * 50)
    if all_ok:
        print("[OK] 所有配置文件检查通过！")
    else:
        print("[FAIL] 部分配置文件存在问题，请检查上述提示")
        print("\n问题定位建议:")
        print("  1. 检查文件路径是否正确")
        print("  2. 验证YAML格式（可以使用在线验证器）")
        print("  3. 检查必需配置项是否填写")
    print("=" * 50)
    
    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

