#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
连接检查脚本
检查ComfyUI云端API连接、网络连接等
"""

import sys
import os
import socket
import requests
from pathlib import Path
from typing import Optional

# 添加项目路径
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))


def check_port(host, port, timeout=2):
    """检查端口是否可访问"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except:
        return False


def check_comfyui_api():
    """检查ComfyUI云端API连接"""
    print("\n检查ComfyUI云端API:")
    
    try:
        from adapter.comfyui.comfyui_controller import ComfyUIController
        from utils.path_utils import setup_project_path, get_config_loader
        
        setup_project_path(__file__)
        config_loader = get_config_loader()
        config = config_loader.get_comfyui_config()
        
        controller = ComfyUIController(config=config)
        
        # 检查工作流是否已加载
        if hasattr(controller, 'cloud_api') and controller.cloud_api:
            workflow_id = controller.cloud_api.get_workflow_id()
            if workflow_id:
                print("[OK] ComfyUI云端API - 连接正常")
                print(f"   工作流ID: {workflow_id}")
                return True
            else:
                print("[WARN] ComfyUI云端API - 连接正常但工作流未创建")
                print(f"  位置: adapter/comfyui/cloud_api.py")
                print(f"  建议: 检查工作流加载逻辑")
                return True
        else:
            print("[FAIL] ComfyUI云端API - 未初始化")
            print(f"  位置: adapter/comfyui/comfyui_controller.py")
            print(f"  建议: 检查API密钥和实例ID配置")
            return False
    except ValueError as e:
        print(f"[FAIL] ComfyUI云端API - 配置错误: {e}")
        print(f"  位置: adapter/comfyui/comfyui_controller.py")
        print(f"  建议: 检查 config/comfyui_cloud/api_key 和 instance_id 文件")
        return False
    except Exception as e:
        print(f"[FAIL] ComfyUI云端API检查失败: {e}")
        print(f"  位置: adapter/comfyui/comfyui_controller.py")
        print(f"  建议: 检查网络连接和API配置")
        import traceback
        print(f"  详细错误: {traceback.format_exc()}")
        return False


def check_cloud_config():
    """检查云端配置"""
    print("\n检查云端配置:")
    
    base_dir = Path(__file__).parent.parent
    api_key_file = base_dir / "config" / "comfyui_cloud" / "api_key"
    instance_id_file = base_dir / "config" / "comfyui_cloud" / "instance_id"
    
    all_ok = True
    
    if api_key_file.exists():
        try:
            with open(api_key_file, 'r', encoding='utf-8') as f:
                api_key = f.read().strip()
            if api_key:
                print(f"[OK] API密钥配置存在 (长度: {len(api_key)} 字符)")
            else:
                print("[FAIL] API密钥文件为空")
                print(f"  位置: {api_key_file.absolute()}")
                print(f"  建议: 填写有效的API密钥")
                all_ok = False
        except Exception as e:
            print(f"[FAIL] 读取API密钥失败: {e}")
            print(f"  位置: {api_key_file.absolute()}")
            all_ok = False
    else:
        print("[FAIL] API密钥文件不存在")
        print(f"  位置: {api_key_file.absolute()}")
        print(f"  建议: 创建该文件并填写API密钥")
        all_ok = False
    
    if instance_id_file.exists():
        try:
            with open(instance_id_file, 'r', encoding='utf-8') as f:
                instance_id = f.read().strip()
            if instance_id:
                print(f"[OK] 实例ID配置存在 (长度: {len(instance_id)} 字符)")
            else:
                print("[FAIL] 实例ID文件为空")
                print(f"  位置: {instance_id_file.absolute()}")
                print(f"  建议: 填写有效的实例ID")
                all_ok = False
        except Exception as e:
            print(f"[FAIL] 读取实例ID失败: {e}")
            print(f"  位置: {instance_id_file.absolute()}")
            all_ok = False
    else:
        print("[FAIL] 实例ID文件不存在")
        print(f"  位置: {instance_id_file.absolute()}")
        print(f"  建议: 创建该文件并填写实例ID")
        all_ok = False
    
    return all_ok


def check_network_connectivity():
    """检查网络连通性"""
    print("\n检查网络连通性:")
    
    # 检查DNS解析
    try:
        import socket
        hostname = 'pandora-server-cf.onethingai.com'
        ip = socket.gethostbyname(hostname)
        print(f"[OK] DNS解析正常 ({hostname} -> {ip})")
        return True
    except socket.gaierror as e:
        print(f"[FAIL] DNS解析失败: {e}")
        print(f"  位置: 网络连接")
        print(f"  建议: 检查网络连接和DNS设置")
        return False
    except Exception as e:
        print(f"[FAIL] DNS解析失败: {e}")
        print(f"  位置: 网络连接")
        return False


def main():
    print("=" * 50)
    print("连接检查")
    print("=" * 50)
    
    all_ok = True
    
    # 检查各项连接
    checks = [
        ("云端配置", check_cloud_config),
        ("网络连通性", check_network_connectivity),
        ("ComfyUI云端API", check_comfyui_api),
    ]
    
    for check_name, check_func in checks:
        if not check_func():
            all_ok = False
    
    print("\n" + "=" * 50)
    if all_ok:
        print("[OK] 所有连接检查通过！")
    else:
        print("[FAIL] 部分连接存在问题，请检查上述提示")
        print("\n问题定位建议:")
        print("  1. 检查网络连接")
        print("  2. 验证API密钥和实例ID配置")
        print("  3. 检查防火墙设置")
    print("=" * 50)
    
    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

