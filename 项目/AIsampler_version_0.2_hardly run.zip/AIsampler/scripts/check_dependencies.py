#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
依赖检查脚本
检查Python包、文件、外部服务等依赖
"""

import sys
import importlib
import os
from pathlib import Path

# 添加项目路径
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))


def check_package(package_name, import_name=None):
    """检查包是否安装"""
    if import_name is None:
        import_name = package_name
    try:
        module = importlib.import_module(import_name)
        version = getattr(module, '__version__', '未知版本')
        print(f"[OK] {package_name} - 已安装 (版本: {version})")
        return True
    except ImportError:
        print(f"[FAIL] {package_name} - 未安装")
        print(f"  建议: pip install {package_name}")
        return False


def check_file(file_path):
    """检查文件是否存在"""
    file_path_obj = Path(file_path)
    if file_path_obj.exists():
        size = file_path_obj.stat().st_size
        print(f"[OK] {file_path} - 存在 (大小: {size} 字节)")
        return True
    else:
        print(f"[FAIL] {file_path} - 不存在")
        print(f"  位置: {file_path_obj.absolute()}")
        print(f"  建议: 创建该文件或检查路径配置")
        return False


def main():
    print("=" * 50)
    print("依赖检查")
    print("=" * 50)
    
    base_dir = Path(__file__).parent.parent
    
    # 检查Python包
    packages = [
        ("opencv-python", "cv2"),
        ("torch", "torch"),
        ("modelscope", "modelscope"),
        ("onnxruntime", "onnxruntime"),  # ONNX模型推理支持
        ("funasr", "funasr"),
        ("langchain", "langchain"),
        ("langchain-openai", "langchain_openai"),  # LangChain 0.3.x支持
        ("openai", "openai"),
        ("numpy", "numpy"),
        ("sounddevice", "sounddevice"),
        ("requests", "requests"),
        ("yaml", "yaml"),
        ("psutil", "psutil"),  # 性能监控（可选）
    ]
    
    all_ok = True
    for pkg_name, import_name in packages:
        if not check_package(pkg_name, import_name):
            all_ok = False
    
    print("\n" + "=" * 50)
    print("文件检查")
    print("=" * 50)
    
    # 检查文件
    files = [
        base_dir / "config" / "deepseek_key",
        base_dir / "adapter" / "blender" / "openpose" / "openpose_bone.blend",
        base_dir / "adapter" / "comfyui" / "workflow" / "代播视频生成.json",
        base_dir / "config" / "comfyui_cloud" / "api_key",
        base_dir / "config" / "comfyui_cloud" / "instance_id",
    ]
    
    for file_path in files:
        if not check_file(str(file_path)):
            all_ok = False
    
    print("\n" + "=" * 50)
    print("外部服务检查")
    print("=" * 50)
    
    # 检查ComfyUI云端API
    try:
        # 检查云端配置文件
        api_key_path = base_dir / "config" / "comfyui_cloud" / "api_key"
        instance_id_path = base_dir / "config" / "comfyui_cloud" / "instance_id"
        if api_key_path.exists() and instance_id_path.exists():
            print("[OK] ComfyUI云端API配置 - 已配置")
            # 尝试初始化控制器验证连接
            try:
                from adapter.comfyui.comfyui_controller import ComfyUIController
                from utils.path_utils import setup_project_path, get_config_loader
                setup_project_path(__file__)
                config_loader = get_config_loader()
                config = config_loader.get_comfyui_config()
                controller = ComfyUIController(config=config)
                print("[OK] ComfyUI云端API - 连接正常")
            except ValueError as e:
                print(f"[FAIL] ComfyUI云端API - 配置错误: {e}")
                print(f"  位置: config/comfyui_cloud/api_key 或 config/comfyui_cloud/instance_id")
                print("  建议: 检查API密钥和实例ID文件内容")
                all_ok = False
            except Exception as e:
                print(f"[WARN] ComfyUI云端API - 连接失败: {e}")
                print(f"  位置: adapter/comfyui/comfyui_controller.py")
                print("  建议: 检查API密钥、实例ID配置和网络连接")
                all_ok = False
        else:
            print("[FAIL] ComfyUI云端API配置 - 未配置")
            print("  请创建以下文件：")
            if not api_key_path.exists():
                print(f"   - {api_key_path.absolute()}")
            if not instance_id_path.exists():
                print(f"   - {instance_id_path.absolute()}")
            all_ok = False
    except Exception as e:
        print(f"⚠️ ComfyUI检查失败: {e}")
        all_ok = False
    
    # 检查Blender
    try:
        import bpy
        print("[OK] Blender - 已安装")
    except ImportError:
        print("[WARN] Blender - 未检测到（可能需要在Blender环境中运行）")
        print("  位置: adapter/blender/blender_controller.py")
        print("  建议: 在Blender内部运行或使用Socket模式")
    
    print("\n" + "=" * 50)
    if all_ok:
        print("[OK] 所有依赖检查通过！")
    else:
        print("[FAIL] 部分依赖缺失，请按照上述提示安装")
        print("\n快速修复:")
        print("  pip install -r requirements.txt")
    print("=" * 50)
    
    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

