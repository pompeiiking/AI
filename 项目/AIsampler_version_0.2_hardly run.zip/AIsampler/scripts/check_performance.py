#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
性能检查脚本
检查系统性能指标：延迟、吞吐量、资源使用等
"""

import sys
import os
import time
import psutil
from pathlib import Path
from typing import Dict, Any

# 添加项目路径
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))


def check_memory_usage():
    """检查内存使用"""
    print("\n检查内存使用:")
    
    try:
        process = psutil.Process()
        memory_info = process.memory_info()
        memory_mb = memory_info.rss / 1024 / 1024
        
        print(f"   当前内存使用: {memory_mb:.2f} MB")
        
        if memory_mb > 2048:
            print("⚠️ 内存使用较高（> 2GB）")
            return False
        else:
            print("✅ 内存使用正常")
            return True
    except ImportError:
        print("⚠️ psutil未安装，跳过内存检查")
        print("   安装: pip install psutil")
        return True  # 不视为错误
    except Exception as e:
        print(f"❌ 内存检查失败: {e}")
        return False


def check_cpu_usage():
    """检查CPU使用"""
    print("\n检查CPU使用:")
    
    try:
        cpu_percent = psutil.cpu_percent(interval=1)
        print(f"   当前CPU使用: {cpu_percent:.1f}%")
        
        if cpu_percent > 90:
            print("⚠️ CPU使用率较高（> 90%）")
            return False
        else:
            print("✅ CPU使用正常")
            return True
    except ImportError:
        print("⚠️ psutil未安装，跳过CPU检查")
        return True
    except Exception as e:
        print(f"❌ CPU检查失败: {e}")
        return False


def check_import_speed():
    """检查模块导入速度"""
    print("\n检查模块导入速度:")
    
    modules = [
        ("CV模块", "parts.cv.cv_controller"),
        ("STT模块", "parts.stt.stt_controller"),
        ("Fusion模块", "parts.fusion.fusion_controller"),
        ("ComfyUI适配器", "adapter.comfyui.comfyui_controller"),
    ]
    
    all_ok = True
    for module_name, module_path in modules:
        try:
            start_time = time.time()
            __import__(module_path)
            elapsed = (time.time() - start_time) * 1000  # 转换为毫秒
            
            if elapsed > 1000:
                print(f"⚠️ {module_name} - 导入较慢 ({elapsed:.0f}ms)")
                all_ok = False
            else:
                print(f"✅ {module_name} - 导入正常 ({elapsed:.0f}ms)")
        except Exception as e:
            print(f"❌ {module_name} - 导入失败: {e}")
            all_ok = False
    
    return all_ok


def check_event_queue_performance():
    """检查事件队列性能"""
    print("\n检查事件队列性能:")
    
    try:
        from controller.controller import EventQueue, Event
        
        queue = EventQueue(max_size=1000)
        
        # 测试添加性能
        start_time = time.time()
        for i in range(100):
            event = Event(
                event_type='test',
                timestamp=time.time(),
                sequence_id=i,
                data={'test': 'data'},
                source='test'
            )
            queue.put(event)
        add_time = (time.time() - start_time) * 1000 / 100  # 平均每事件毫秒数
        
        # 测试获取性能
        start_time = time.time()
        for _ in range(100):
            queue.get(timeout=0.1)
        get_time = (time.time() - start_time) * 1000 / 100
        
        print(f"   添加事件平均延迟: {add_time:.2f}ms")
        print(f"   获取事件平均延迟: {get_time:.2f}ms")
        
        if add_time > 10 or get_time > 10:
            print("⚠️ 事件队列性能较差")
            return False
        else:
            print("✅ 事件队列性能正常")
            return True
    except Exception as e:
        print(f"❌ 事件队列性能检查失败: {e}")
        return False


def main():
    print("=" * 50)
    print("性能检查")
    print("=" * 50)
    
    all_ok = True
    
    # 检查各项性能指标
    checks = [
        ("内存使用", check_memory_usage),
        ("CPU使用", check_cpu_usage),
        ("模块导入速度", check_import_speed),
        ("事件队列性能", check_event_queue_performance),
    ]
    
    for check_name, check_func in checks:
        if not check_func():
            all_ok = False
    
    print("\n" + "=" * 50)
    if all_ok:
        print("✅ 所有性能检查通过！")
    else:
        print("⚠️ 部分性能指标异常，请检查上述提示")
    print("=" * 50)
    
    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

