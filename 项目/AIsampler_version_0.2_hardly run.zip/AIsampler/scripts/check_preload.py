#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
模型预加载检查脚本
检查模型预加载功能是否正常工作
"""

import sys
import os
import time
from pathlib import Path
from typing import Dict, List, Tuple

# 添加项目路径
current_dir = Path(__file__).parent.parent
sys.path.insert(0, str(current_dir))


def check_preload_config():
    """检查预加载配置文件"""
    print("\n[预加载配置检查]")
    try:
        from utils.path_utils import setup_project_path, get_config_loader
        import yaml
        
        setup_project_path(__file__)
        config_dir = current_dir / "config"
        preload_config_path = config_dir / "preload_config.yaml"
        
        if not preload_config_path.exists():
            print(f"  [FAIL] 预加载配置文件不存在: {preload_config_path}")
            return False
        
        with open(preload_config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        if not config:
            print("  [FAIL] 预加载配置文件为空")
            return False
        
        # 检查必需配置项
        preload_config = config.get('preload', {})
        if not preload_config:
            print("  [FAIL] 缺少preload配置项")
            return False
        
        print(f"  [OK] 预加载配置存在")
        print(f"     - 启用预加载: {preload_config.get('enable', False)}")
        print(f"     - 并行加载: {preload_config.get('parallel', False)}")
        print(f"     - CV模块: {preload_config.get('cv', False)}")
        print(f"     - STT模块: {preload_config.get('stt', False)}")
        print(f"     - ComfyUI模块: {preload_config.get('comfyui', False)}")
        print(f"     - Agent模块: {preload_config.get('agent', False)}")
        
        return True
    except Exception as e:
        print(f"  [FAIL] 预加载配置检查失败: {e}")
        import traceback
        print(f"  详细错误: {traceback.format_exc()}")
        return False


def check_preloader_class():
    """检查预加载器类"""
    print("\n[预加载器类检查]")
    try:
        from utils.model_preloader import ModelPreloader, PreloadStatus
        
        # 检查类是否存在
        assert ModelPreloader is not None, "ModelPreloader类不存在"
        assert PreloadStatus is not None, "PreloadStatus类不存在"
        print("  [OK] 预加载器类存在")
        
        # 检查预加载器方法
        preloader = ModelPreloader()
        assert hasattr(preloader, 'preload_all'), "缺少preload_all方法"
        assert hasattr(preloader, 'get_module'), "缺少get_module方法"
        assert hasattr(preloader, 'get_status'), "缺少get_status方法"
        assert hasattr(preloader, 'is_loaded'), "缺少is_loaded方法"
        print("  [OK] 预加载器方法检查通过")
        
        # 检查配置
        assert hasattr(preloader, 'enable_preload'), "缺少enable_preload属性"
        assert hasattr(preloader, 'parallel_load'), "缺少parallel_load属性"
        print("  [OK] 预加载器属性检查通过")
        
        return True
    except AssertionError as e:
        print(f"  [FAIL] 检测失败: {e}")
        return False
    except Exception as e:
        print(f"  [FAIL] 预加载器类检查失败: {e}")
        import traceback
        print(f"  详细错误: {traceback.format_exc()}")
        return False


def check_preload_functionality():
    """检查预加载功能"""
    print("\n[预加载功能检查]")
    try:
        from utils.model_preloader import ModelPreloader
        from utils.path_utils import setup_project_path
        
        setup_project_path(__file__)
        
        # 创建预加载器
        preloader = ModelPreloader()
        print("  [OK] 预加载器创建成功")
        
        # 检查预加载状态（不实际执行预加载，只检查接口）
        status = preloader.get_status()
        assert isinstance(status, dict), "get_status应返回字典"
        print("  [OK] 预加载状态接口正常")
        
        # 检查模块获取接口
        for module_name in ['cv', 'stt', 'comfyui', 'agent']:
            module = preloader.get_module(module_name)
            # 模块可能为None（未预加载），这是正常的
            is_loaded = preloader.is_loaded(module_name)
            print(f"  [INFO] {module_name}模块: {'已预加载' if is_loaded else '未预加载'}")
        
        print("  [OK] 预加载功能接口检查通过")
        return True
    except Exception as e:
        print(f"  [FAIL] 预加载功能检查失败: {e}")
        import traceback
        print(f"  详细错误: {traceback.format_exc()}")
        return False


def check_preload_integration():
    """检查预加载集成"""
    print("\n[预加载集成检查]")
    try:
        from utils.path_utils import setup_project_path
        
        setup_project_path(__file__)
        
        # 检查Pipeline是否集成预加载
        try:
            from controller.pipeline import EndToEndPipeline
            import inspect
            
            # 检查__init__方法是否使用预加载
            init_source = inspect.getsource(EndToEndPipeline.__init__)
            if 'ModelPreloader' in init_source or 'preloader' in init_source:
                print("  [OK] Pipeline已集成预加载")
            else:
                print("  [WARN] Pipeline可能未集成预加载")
        except Exception as e:
            print(f"  [WARN] 检查Pipeline集成失败: {e}")
        
        # 检查MainController是否集成预加载
        try:
            from controller.controller import MainController
            import inspect
            
            # 检查initialize方法是否使用预加载
            init_source = inspect.getsource(MainController.initialize)
            if 'preload' in init_source.lower():
                print("  [OK] MainController已集成预加载")
            else:
                print("  [WARN] MainController可能未集成预加载")
        except Exception as e:
            print(f"  [WARN] 检查MainController集成失败: {e}")
        
        return True
    except Exception as e:
        print(f"  [FAIL] 预加载集成检查失败: {e}")
        import traceback
        print(f"  详细错误: {traceback.format_exc()}")
        return False


def main():
    """主函数：执行所有预加载检测"""
    print("=" * 70)
    print("  模型预加载检查 - 多模态实时交互具身智能数字人系统")
    print("=" * 70)
    
    all_ok = True
    
    # 检查各项
    checks = [
        ("预加载配置", check_preload_config),
        ("预加载器类", check_preloader_class),
        ("预加载功能", check_preload_functionality),
        ("预加载集成", check_preload_integration),
    ]
    
    results = []
    for check_name, check_func in checks:
        try:
            success = check_func()
            results.append((check_name, success))
            if not success:
                all_ok = False
        except Exception as e:
            print(f"\n[FAIL] {check_name} - 检测异常: {e}")
            results.append((check_name, False))
            all_ok = False
    
    # 打印总结
    print("\n" + "=" * 70)
    print("  检测总结")
    print("=" * 70)
    
    total = len(results)
    passed = sum(1 for _, success in results if success)
    failed = total - passed
    
    print(f"\n总计: {total} 项检测")
    print(f"通过: {passed} 项")
    print(f"失败: {failed} 项")
    
    print("\n详细结果:")
    for check_name, success in results:
        status = "[OK] 通过" if success else "[FAIL] 失败"
        print(f"  {status} - {check_name}")
    
    print("\n" + "=" * 70)
    if all_ok:
        print("[OK] 所有预加载检查通过！")
    else:
        print("[FAIL] 部分预加载检查失败，请根据上述提示进行修复。")
    print("=" * 70)
    
    return all_ok


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

