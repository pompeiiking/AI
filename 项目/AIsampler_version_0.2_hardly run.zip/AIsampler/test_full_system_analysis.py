#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全面系统流程测试与分析
验证每个模块的真实性、数据流和工作状态
"""

import sys
import time
import logging
from pathlib import Path
from typing import Dict, Any, List
import threading
from collections import defaultdict

# 项目路径设置
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path
setup_project_path(__file__)

# 配置详细日志
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - [%(levelname)s] - %(name)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('system_analysis.log', mode='w')
    ]
)

logger = logging.getLogger(__name__)

class SystemAnalyzer:
    """系统分析器 - 验证所有模块的真实性和工作状态"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.test_results = defaultdict(dict)
        self.data_flow_log = []
        self.module_calls = defaultdict(int)
        
    def print_header(self, title: str):
        """打印标题"""
        print("\n" + "=" * 80)
        print(f"📊 {title}")
        print("=" * 80)
    
    def print_section(self, title: str):
        """打印章节"""
        print(f"\n【{title}】")
        print("-" * 80)
    
    def test_imports(self) -> bool:
        """测试1：验证所有关键模块可导入"""
        self.print_section("测试1：验证模块导入")
        
        modules = {
            'MainController': 'controller.controller',
            'CVController': 'parts.cv.cv_controller',
            'TextController': 'parts.text.text_controller',
            'AIDialogueGraph': 'parts.text.ai_dialogue_graph',
            'FusionController': 'parts.fusion.fusion_controller',
            'BlenderController': 'adapter.blender.blender_controller',
            'ComfyUIController': 'adapter.comfyui.comfyui_controller',
            'AgentManager': 'controller.agent_manager',
        }
        
        all_ok = True
        for name, module_path in modules.items():
            try:
                __import__(module_path, fromlist=[name])
                print(f"✓ {name:25s} - 导入成功")
                self.test_results['imports'][name] = True
            except Exception as e:
                print(f"✗ {name:25s} - 导入失败: {e}")
                self.test_results['imports'][name] = False
                all_ok = False
        
        return all_ok
    
    def test_configs(self) -> bool:
        """测试2：验证配置文件"""
        self.print_section("测试2：验证配置文件")
        
        from utils.path_utils import get_config_loader
        config_loader = get_config_loader()
        
        configs = {
            'cv_config': 'get_cv_config',
            'text_config': 'get_text_config',
            'fusion_config': 'get_fusion_config',
            'blender_config': 'get_blender_config',
            'comfyui_config': 'get_comfyui_config',
            'mcp_config': 'get_mcp_config',
        }
        
        all_ok = True
        for name, method in configs.items():
            try:
                config = getattr(config_loader, method)()
                print(f"✓ {name:20s} - 加载成功 ({len(config)} 项)")
                self.test_results['configs'][name] = True
            except Exception as e:
                print(f"✗ {name:20s} - 加载失败: {e}")
                self.test_results['configs'][name] = False
                all_ok = False
        
        # 检查AI配置
        try:
            ai_config = config_loader.load_config('text_ai_config')
            api_key = ai_config.get('deepseek', {}).get('api_key', '')
            print(f"✓ text_ai_config   - DeepSeek密钥: {api_key[:15]}...")
            self.test_results['configs']['text_ai_config'] = True
        except Exception as e:
            print(f"✗ text_ai_config   - 加载失败: {e}")
            self.test_results['configs']['text_ai_config'] = False
            all_ok = False
        
        return all_ok
    
    def test_cv_module(self) -> bool:
        """测试3：CV模块真实性验证"""
        self.print_section("测试3：CV模块真实性验证")
        
        try:
            from parts.cv.cv_controller import CVController
            from utils.path_utils import get_config_loader
            
            config_loader = get_config_loader()
            cv_config = config_loader.get_cv_config()
            
            print("初始化CV控制器...")
            cv = CVController(config=cv_config)
            
            # 检查模型初始化
            if not cv.initialize_models():
                print("✗ CV模型初始化失败")
                return False
            
            print(f"✓ CV模型初始化成功")
            print(f"  • 模型类型: {cv.model_type}")
            print(f"  • 设备: {cv.device}")
            print(f"  • 是否使用真实模型: {'✓' if cv.model else '✗ (占位符)'}")
            
            # 检查是否有真实的模型文件
            if hasattr(cv, 'model_path'):
                print(f"  • 模型路径: {cv.model_path}")
                self.test_results['cv']['model_path'] = str(cv.model_path)
            
            # 测试推理
            import numpy as np
            test_img = np.zeros((224, 224, 3), dtype=np.uint8)
            
            print("\n测试推理（使用空图像）...")
            result = cv.process_frame(test_img)
            
            if result:
                print(f"✓ 推理成功")
                print(f"  • 检测到人脸: {result.get('face_detected', False)}")
                print(f"  • 情感: {result.get('emotion', 'N/A')}")
                print(f"  • 置信度: {result.get('confidence', 0.0):.2f}")
                
                self.test_results['cv']['inference'] = True
                self.test_results['cv']['result'] = result
            else:
                print("✗ 推理失败")
                self.test_results['cv']['inference'] = False
            
            cv.stop_camera()
            return True
            
        except Exception as e:
            print(f"✗ CV模块测试失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def test_text_ai_module(self) -> bool:
        """测试4：Text AI模块真实性验证"""
        self.print_section("测试4：Text AI模块（DeepSeek）真实性验证")
        
        try:
            from parts.text.ai_dialogue_graph import AIDialogueGraph
            from utils.path_utils import get_config_loader
            
            config_loader = get_config_loader()
            ai_config = config_loader.load_config('text_ai_config')
            
            print("初始化AI对话图...")
            ai_graph = AIDialogueGraph(ai_config)
            
            # 检查LLM初始化
            if ai_graph.llm:
                print(f"✓ DeepSeek LLM初始化成功")
                print(f"  • 模型: {ai_graph.llm.model_name if hasattr(ai_graph.llm, 'model_name') else 'N/A'}")
                print(f"  • 是否为真实API: {'✓' if hasattr(ai_graph.llm, 'openai_api_key') else '✗'}")
            else:
                print("✗ LLM未初始化（占位符）")
                return False
            
            # 测试连接
            print("\n测试DeepSeek API连接...")
            test_result = ai_graph.test_connection()
            
            if test_result.get('success'):
                print(f"✓ API连接成功")
                print(f"  • 响应: {test_result.get('response', '')[:100]}...")
                self.test_results['text_ai']['connection'] = True
            else:
                print(f"✗ API连接失败: {test_result.get('error')}")
                self.test_results['text_ai']['connection'] = False
                return False
            
            # 测试情感分析
            print("\n测试情感分析（真实AI推理）...")
            test_texts = [
                "我今天非常开心！",
                "这让我很生气",
                "我有点害怕"
            ]
            
            for text in test_texts:
                result = ai_graph.analyze_emotion(text)
                emotion = result.get('emotion', 'N/A')
                conf = result.get('confidence', 0.0)
                ai_powered = result.get('ai_powered', False)
                
                print(f"  • 文本: \"{text}\"")
                print(f"    → 情感: {emotion} ({conf:.2f}) [{'AI' if ai_powered else '关键词'}]")
                
                if not ai_powered:
                    print("    ⚠️ 警告：使用关键词回退，非真实AI")
            
            self.test_results['text_ai']['analysis'] = True
            return True
            
        except Exception as e:
            print(f"✗ Text AI模块测试失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def test_event_queue(self) -> bool:
        """测试5：事件队列和消费者"""
        self.print_section("测试5：事件队列和消费者验证")
        
        try:
            from controller.controller import MainController
            
            print("创建MainController...")
            main_controller = MainController()
            
            if not main_controller.initialize(use_preload=False):
                print("✗ MainController初始化失败")
                return False
            
            print("✓ MainController初始化成功")
            
            # 启动事件处理循环
            print("\n启动事件处理循环...")
            if not main_controller.start():
                print("✗ 事件处理循环启动失败")
                return False
            
            print("✓ 事件处理循环已启动")
            
            # 检查事件线程
            if hasattr(main_controller, '_event_thread'):
                thread = main_controller._event_thread
                print(f"  • 事件线程: {'运行中' if thread.is_alive() else '未运行'}")
                self.test_results['event_queue']['thread_alive'] = thread.is_alive()
            
            # 生产测试事件
            print("\n生产测试事件...")
            events_received = []
            
            def test_callback(event):
                events_received.append(event)
                print(f"  ✓ 收到事件: {event.event_type}")
            
            main_controller.register_callback('test_event', test_callback)
            
            # 发送测试事件
            from controller.controller import Event
            test_event = Event(
                event_type='test_event',
                timestamp=time.time(),
                sequence_id=1,
                data={'test': 'data'},
                source='test'
            )
            
            main_controller.event_queue.put(test_event)
            
            # 等待处理
            time.sleep(0.5)
            
            if events_received:
                print(f"✓ 事件消费者正常工作 (收到 {len(events_received)} 个事件)")
                self.test_results['event_queue']['consumer_working'] = True
            else:
                print("✗ 事件消费者未工作（事件未被处理）")
                self.test_results['event_queue']['consumer_working'] = False
            
            main_controller.stop()
            return True
            
        except Exception as e:
            print(f"✗ 事件队列测试失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def test_data_flow(self) -> bool:
        """测试6：完整数据流追踪"""
        self.print_section("测试6：完整数据流追踪")
        
        try:
            from controller.controller import MainController
            
            print("创建MainController并启动完整数据流...")
            main_controller = MainController()
            
            if not main_controller.initialize(use_preload=False):
                print("✗ 初始化失败")
                return False
            
            if not main_controller.start():
                print("✗ 启动失败")
                return False
            
            # 数据收集器
            cv_data_received = []
            text_data_received = []
            
            def cv_callback(data):
                cv_data_received.append(data)
                print(f"  📷 CV数据: emotion={data.get('emotion')}, conf={data.get('confidence', 0):.2f}")
            
            def text_callback(data):
                text_data_received.append(data)
                ai_flag = "🤖" if data.get('ai_powered') else "📝"
                print(f"  {ai_flag} Text数据: emotion={data.get('emotion')}, conf={data.get('confidence', 0):.2f}")
            
            # 启动数据流
            print("\n启动CV流...")
            main_controller.start_cv_stream(callback=cv_callback, show_window=False)
            
            print("启动Text流...")
            main_controller.start_text_stream(callback=text_callback)
            
            print("\n等待数据流... (5秒)")
            time.sleep(5)
            
            print(f"\n数据流统计:")
            print(f"  • CV数据: {len(cv_data_received)} 帧")
            print(f"  • Text数据: {len(text_data_received)} 条")
            
            if cv_data_received:
                print(f"  ✓ CV数据流正常")
                self.test_results['data_flow']['cv'] = True
            else:
                print(f"  ✗ CV数据流异常（无数据）")
                self.test_results['data_flow']['cv'] = False
            
            if text_data_received:
                print(f"  ✓ Text数据流正常")
                self.test_results['data_flow']['text'] = True
            else:
                print(f"  ⚠️ Text数据流无数据（正常，等待输入）")
                self.test_results['data_flow']['text'] = 'waiting'
            
            main_controller.stop()
            return True
            
        except Exception as e:
            print(f"✗ 数据流测试失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def check_placeholder_modules(self):
        """测试7：检查占位符模块"""
        self.print_section("测试7：占位符模块检测")
        
        print("检查可能的占位符标记...")
        
        placeholder_patterns = [
            'TODO', 'FIXME', 'PLACEHOLDER', 'STUB',
            'pass  # 占位', 'raise NotImplementedError',
            'return None  # 临时', '# 假实现'
        ]
        
        suspicious_files = []
        
        # 扫描关键文件
        key_files = [
            'parts/cv/cv_controller.py',
            'parts/text/text_controller.py',
            'parts/text/ai_dialogue_graph.py',
            'controller/controller.py',
            'controller/agent_manager.py',
        ]
        
        for file_path in key_files:
            full_path = PROJECT_ROOT / file_path
            if full_path.exists():
                with open(full_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    for pattern in placeholder_patterns:
                        if pattern in content:
                            suspicious_files.append(f"{file_path}: 包含 '{pattern}'")
        
        if suspicious_files:
            print("⚠️ 发现疑似占位符:")
            for item in suspicious_files:
                print(f"  • {item}")
        else:
            print("✓ 未发现明显的占位符标记")
    
    def generate_report(self):
        """生成测试报告"""
        self.print_header("测试报告总结")
        
        print("\n【模块导入】")
        for name, status in self.test_results['imports'].items():
            symbol = "✓" if status else "✗"
            print(f"  {symbol} {name}")
        
        print("\n【配置文件】")
        for name, status in self.test_results['configs'].items():
            symbol = "✓" if status else "✗"
            print(f"  {symbol} {name}")
        
        print("\n【CV模块】")
        cv_tests = self.test_results.get('cv', {})
        for key, value in cv_tests.items():
            print(f"  • {key}: {value}")
        
        print("\n【Text AI模块】")
        text_ai_tests = self.test_results.get('text_ai', {})
        for key, value in text_ai_tests.items():
            print(f"  • {key}: {value}")
        
        print("\n【事件队列】")
        eq_tests = self.test_results.get('event_queue', {})
        for key, value in eq_tests.items():
            print(f"  • {key}: {value}")
        
        print("\n【数据流】")
        df_tests = self.test_results.get('data_flow', {})
        for key, value in df_tests.items():
            print(f"  • {key}: {value}")
        
        # 保存到文件
        report_path = PROJECT_ROOT / "SYSTEM_ANALYSIS_REPORT.md"
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# 系统全面分析报告\n\n")
            f.write(f"生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write("## 测试结果\n\n")
            for category, tests in self.test_results.items():
                f.write(f"### {category}\n\n")
                for key, value in tests.items():
                    f.write(f"- **{key}**: {value}\n")
                f.write("\n")
        
        print(f"\n✓ 详细报告已保存到: {report_path}")

def main():
    """主函数"""
    analyzer = SystemAnalyzer()
    
    analyzer.print_header("AIsampler系统全面分析测试")
    
    print("\n本测试将验证:")
    print("  1. 所有模块可正常导入")
    print("  2. 配置文件完整性")
    print("  3. CV模块真实性（非占位符）")
    print("  4. Text AI模块真实性（DeepSeek连接）")
    print("  5. 事件队列消费者工作状态")
    print("  6. 完整数据流追踪")
    print("  7. 占位符模块检测")
    
    print("\n⏱️ 自动开始测试...")
    
    try:
        # 执行测试
        analyzer.test_imports()
        analyzer.test_configs()
        analyzer.test_cv_module()
        analyzer.test_text_ai_module()
        analyzer.test_event_queue()
        analyzer.test_data_flow()
        analyzer.check_placeholder_modules()
        
        # 生成报告
        analyzer.generate_report()
        
        analyzer.print_header("测试完成")
        print("\n✓ 所有测试已完成，请查看详细日志和报告")
        
    except Exception as e:
        print(f"\n✗ 测试过程中发生异常: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
