#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI对话流系统部署脚本
自动检查依赖、配置和系统状态
"""

import sys
import os
from pathlib import Path
import subprocess

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

print("=" * 80)
print("🚀 AI对话流系统部署脚本")
print("=" * 80)

# 检查Python版本
print("\n【1/6】检查Python版本")
print("-" * 80)
py_version = sys.version_info
print(f"Python版本: {py_version.major}.{py_version.minor}.{py_version.micro}")

if py_version.major < 3 or (py_version.major == 3 and py_version.minor < 8):
    print("❌ 需要Python 3.8或更高版本")
    sys.exit(1)
else:
    print("✓ Python版本符合要求")

# 检查依赖
print("\n【2/6】检查依赖包")
print("-" * 80)

required_packages = {
    'langgraph': 'LangGraph（AI对话流图）',
    'langchain': 'LangChain（基础框架）',
    'langchain_openai': 'LangChain OpenAI（LLM集成）',
    'langchain_core': 'LangChain Core（核心组件）',
    'openai': 'OpenAI（API客户端）',
    'yaml': 'PyYAML（配置文件）',
}

missing_packages = []

for package, description in required_packages.items():
    try:
        if package == 'yaml':
            __import__('yaml')
        else:
            __import__(package)
        print(f"✓ {description}")
    except ImportError:
        print(f"✗ {description} - 缺失")
        missing_packages.append(package)

if missing_packages:
    print(f"\n⚠️ 缺少依赖包: {', '.join(missing_packages)}")
    print("\n安装命令:")
    print("  pip install -r requirements.txt")
    print("\n或者单独安装AI相关依赖:")
    print("  pip install langgraph langchain langchain-openai langchain-core openai")
    
    response = input("\n是否现在安装？(y/n): ").lower()
    if response == 'y':
        print("\n开始安装依赖...")
        try:
            # 使用绝对路径
            requirements_path = PROJECT_ROOT / "requirements.txt"
            if requirements_path.exists():
                subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", str(requirements_path)])
                print("✓ 依赖安装完成")
            else:
                # 如果requirements.txt不存在，直接安装关键依赖
                print(f"⚠️ requirements.txt不存在，直接安装AI相关依赖...")
                subprocess.check_call([sys.executable, "-m", "pip", "install", 
                                     "langgraph", "langchain", "langchain-openai", "langchain-core", "openai"])
                print("✓ AI依赖安装完成")
        except subprocess.CalledProcessError as e:
            print(f"❌ 依赖安装失败: {e}")
            print("\n请手动运行以下命令安装:")
            print(f"  pip install langgraph langchain langchain-openai langchain-core openai")
            sys.exit(1)
    else:
        print("❌ 请先安装依赖")
        sys.exit(1)

# 检查配置文件
print("\n【3/6】检查配置文件")
print("-" * 80)

config_files = {
    'config/text_ai_config.yaml': 'AI对话流配置',
    'config/text_config.yaml': '文本控制器配置',
    'config/deepseek_key': 'Agent API密钥',
}

all_config_exist = True
for file_path, description in config_files.items():
    full_path = PROJECT_ROOT / file_path
    if full_path.exists():
        print(f"✓ {description}: {file_path}")
    else:
        print(f"✗ {description}: {file_path} - 不存在")
        all_config_exist = False

if not all_config_exist:
    print("\n❌ 配置文件不完整，请检查")
    sys.exit(1)

# 验证AI配置
print("\n【4/6】验证AI配置")
print("-" * 80)

try:
    from utils.path_utils import setup_project_path, get_config_loader
    setup_project_path(__file__)
    
    config_loader = get_config_loader()
    
    # 检查text_ai_config
    try:
        ai_config = config_loader.load_config('text_ai_config')
        api_key = ai_config.get('deepseek', {}).get('api_key', '')
        
        if api_key and api_key.startswith('sk-'):
            print(f"✓ DeepSeek API密钥已配置: {api_key[:10]}...")
        else:
            print("⚠️ DeepSeek API密钥可能无效")
        
        model = ai_config.get('deepseek', {}).get('model', '')
        print(f"✓ 模型: {model}")
        
        enabled = ai_config.get('langgraph', {}).get('enabled', False)
        print(f"✓ LangGraph启用: {enabled}")
        
    except Exception as e:
        print(f"❌ 加载AI配置失败: {e}")
        sys.exit(1)
    
    # 检查text_config
    try:
        text_config = config_loader.get_text_config()
        use_ai = text_config.get('use_ai_model', False)
        print(f"✓ 使用AI模型: {use_ai}")
        
        if not use_ai:
            print("\n⚠️ 警告: use_ai_model设置为false，系统将使用关键词模式")
            print("   建议在 config/text_config.yaml 中设置 use_ai_model: true")
    except Exception as e:
        print(f"❌ 加载文本配置失败: {e}")
        sys.exit(1)

except Exception as e:
    print(f"❌ 配置验证失败: {e}")
    sys.exit(1)

# 测试AI系统
print("\n【5/6】测试AI系统")
print("-" * 80)

try:
    from parts.text.ai_dialogue_graph import AIDialogueGraph
    
    print("正在初始化AI对话图...")
    ai_dialogue = AIDialogueGraph()
    print("✓ AI对话图初始化成功")
    
    print("\n正在测试DeepSeek连接...")
    if ai_dialogue.test_connection():
        print("✓ DeepSeek API连接成功")
    else:
        print("❌ DeepSeek API连接失败")
        print("   请检查:")
        print("   1. API密钥是否正确")
        print("   2. 网络连接是否正常")
        print("   3. DeepSeek服务是否可用")
        sys.exit(1)
    
    print("\n正在测试情感分析...")
    test_text = "我今天很开心！"
    result = ai_dialogue.analyze_emotion(test_text)
    
    if result.get('ai_powered') and not result.get('error'):
        print(f"✓ AI分析成功")
        print(f"  测试文本: \"{test_text}\"")
        print(f"  情感: {result['emotion']}")
        print(f"  置信度: {result['confidence']:.2f}")
        print(f"  理由: {result.get('reasoning', 'N/A')}")
    else:
        print(f"❌ AI分析失败: {result.get('error')}")
        sys.exit(1)

except Exception as e:
    print(f"❌ AI系统测试失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 测试TextController集成
print("\n【6/6】测试TextController集成")
print("-" * 80)

try:
    from parts.text.text_controller import TextController
    
    print("正在初始化TextController...")
    text_controller = TextController()
    
    stats = text_controller.get_statistics()
    print("✓ TextController初始化成功")
    print(f"  检测模式: {stats['detection_mode']}")
    print(f"  AI启用: {stats['ai_enabled']}")
    
    if stats['ai_enabled']:
        print("\n正在测试AI情感检测...")
        emotion, confidence = text_controller.detect_emotion_from_text("我很担心明天的考试")
        print(f"✓ AI情感检测正常")
        print(f"  情感: {emotion}")
        print(f"  置信度: {confidence:.2f}")
    else:
        print("\n⚠️ 警告: TextController未启用AI模式")

except Exception as e:
    print(f"❌ TextController测试失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 部署总结
print("\n" + "=" * 80)
print("📊 部署总结")
print("=" * 80)

print("\n✅ 所有检查通过！AI对话流系统已成功部署！")

print("\n📋 系统配置:")
print(f"  • Python版本: {py_version.major}.{py_version.minor}.{py_version.micro}")
print(f"  • AI模型: DeepSeek ({ai_config.get('deepseek', {}).get('model', 'N/A')})")
print(f"  • 对话框架: LangGraph")
print(f"  • 检测模式: AI + 关键词回退")

print("\n🧪 运行测试:")
print("  python test_ai_dialogue.py          # AI对话流测试")
print("  python test_text_input.py           # 基础功能测试")
print("  python test_text_stream.py          # 流式输入测试")

print("\n🚀 启动系统:")
print("  python runner/start.py              # 启动完整系统")

print("\n📖 查看文档:")
print("  AI_DIALOGUE_DEPLOYMENT.md           # 部署指南")
print("  TEXT_INPUT_GUIDE.md                 # 使用指南")

print("\n" + "=" * 80)
print("🎉 部署完成！系统已准备就绪！")
print("=" * 80)
