#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Agent管理器 v2.0 - 适配LangChain 1.0
基于LangGraph的智能决策和任务编排
"""

import logging
import json
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass
import os
import sys
from pathlib import Path

try:
    import numpy as np
except ImportError:
    np = None

PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)
config_loader = get_config_loader()

# LangChain 1.0导入
try:
    from langchain.agents import create_agent, AgentState
    from langchain_openai import ChatOpenAI
    from langchain_core.tools import tool
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
    from langchain_core.runnables import RunnableConfig
    LANGCHAIN_AVAILABLE = True
except ImportError as e:
    LANGCHAIN_AVAILABLE = False
    logging.warning(f"LangChain 1.0不可用: {e}")


@dataclass
class AgentTask:
    """Agent任务数据类"""
    task_id: str
    task_type: str
    description: str
    input_data: Dict[str, Any]
    status: str = "pending"
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class AgentManager:
    """
    Agent管理器 v2.0
    使用LangChain 1.0和LangGraph进行智能决策
    """
    
    def __init__(self, verbose: bool = False):
        """
        初始化Agent管理器
        
        Args:
            verbose: 是否显示详细日志
        """
        self.logger = logging.getLogger(__name__)
        self.verbose = verbose
        self.initialized = False
        
        if not LANGCHAIN_AVAILABLE:
            self.logger.error("❌ LangChain 1.0不可用，Agent功能将被禁用")
            return
        
        # LLM配置
        self.llm = None
        self.agents = {}  # 存储不同类型的agent
        
        # 控制器
        self.blender_controller = None
        self.comfyui_controller = None
        
        self.logger.info("Agent管理器 v2.0 初始化")
    
    def initialize_agents(self) -> bool:
        """
        初始化所有Agents
        
        Returns:
            bool: 是否初始化成功
        """
        if not LANGCHAIN_AVAILABLE:
            self.logger.warning("⚠️ LangChain不可用，Agent功能禁用")
            return False
        
        try:
            # 1. 初始化LLM
            self._initialize_llm()
            
            # 2. 初始化控制器
            self._initialize_controllers()
            
            # 3. 创建Agents
            self._create_fusion_agent()
            
            self.initialized = True
            self.logger.info("✓ Agent系统初始化成功")
            return True
            
        except Exception as e:
            self.logger.error(f"❌ Agent系统初始化失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _initialize_llm(self):
        """初始化LLM"""
        try:
            # 读取DeepSeek配置
            deepseek_key_path = PROJECT_ROOT / "config" / "deepseek_key"
            
            if deepseek_key_path.exists():
                with open(deepseek_key_path, 'r') as f:
                    api_key = f.read().strip()
            else:
                raise FileNotFoundError("DeepSeek API密钥文件不存在")
            
            # 创建LLM
            self.llm = ChatOpenAI(
                model="deepseek-chat",
                api_key=api_key,
                base_url="https://api.deepseek.com/v1",
                temperature=0.7,
                max_tokens=2000
            )
            
            self.logger.info(f"✓ LLM初始化成功: deepseek-chat")
            
        except Exception as e:
            self.logger.error(f"❌ LLM初始化失败: {e}")
            raise
    
    def _initialize_controllers(self):
        """初始化控制器"""
        try:
            from adapter.blender.blender_controller import BlenderController
            from adapter.comfyui.comfyui_controller import ComfyUIController
            
            blender_config = config_loader.get_blender_config()
            comfyui_config = config_loader.get_comfyui_config()
            
            self.blender_controller = BlenderController(config=blender_config)
            self.comfyui_controller = ComfyUIController(config=comfyui_config)
            
            self.logger.info("✓ 控制器初始化成功")
            
        except Exception as e:
            self.logger.warning(f"⚠️ 控制器初始化失败: {e}")
            # 控制器不是必需的，可以继续
    
    def _create_tools(self) -> List[Callable]:
        """创建工具列表"""
        tools = []
        
        # Blender工具
        @tool
        def update_bone_pose(bone_name: str, rotation: str) -> str:
            """更新Blender中骨骼的旋转姿势
            
            Args:
                bone_name: 骨骼名称
                rotation: 旋转值，格式为"[x, y, z]"
            
            Returns:
                操作结果
            """
            try:
                if not self.blender_controller:
                    return "Blender控制器未初始化"
                
                rotation_list = json.loads(rotation)
                success = self.blender_controller.update_bone_pose(
                    bone_name, rotation=rotation_list
                )
                return "成功更新骨骼姿势" if success else "更新失败"
            except Exception as e:
                return f"错误: {e}"
        
        tools.append(update_bone_pose)
        
        # ComfyUI工具
        @tool
        def generate_video(prompt: str) -> str:
            """使用ComfyUI生成视频
            
            Args:
                prompt: 视频生成提示词
            
            Returns:
                任务ID或错误信息
            """
            try:
                if not self.comfyui_controller:
                    return "ComfyUI控制器未初始化"
                
                task_id = self.comfyui_controller.submit_task(
                    prompt=prompt,
                    model_params={"steps": 20}
                )
                return f"任务已提交，ID: {task_id}"
            except Exception as e:
                return f"错误: {e}"
        
        tools.append(generate_video)
        
        return tools
    
    def _create_fusion_agent(self):
        """创建融合决策Agent"""
        if not self.llm:
            return
        
        try:
            tools = self._create_tools()
            
            # 创建Agent（使用LangChain 1.0的create_agent）
            agent = create_agent(
                self.llm,
                tools,
                system_prompt="你是一个多模态融合决策系统。根据CV和语音输入，做出智能决策并调用相应工具。"
            )
            
            self.agents['fusion'] = agent
            self.logger.info("✓ 融合Agent创建成功")
            
        except Exception as e:
            self.logger.error(f"❌ 创建融合Agent失败: {e}")
    
    def make_fusion_decision(self, fusion_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        进行融合决策
        
        Args:
            fusion_data: 融合后的多模态数据
        
        Returns:
            决策结果
        """
        if not self.initialized or 'fusion' not in self.agents:
            return self._fallback_fusion_decision(fusion_data)
        
        try:
            # 构建输入
            input_text = self._format_fusion_input(fusion_data)
            
            # 调用Agent
            agent = self.agents['fusion']
            result = agent.invoke({
                "messages": [HumanMessage(content=input_text)]
            })
            
            # 解析结果
            return self._parse_fusion_result(result, fusion_data)
            
        except Exception as e:
            self.logger.error(f"❌ 融合决策失败: {e}")
            return self._fallback_fusion_decision(fusion_data)
    
    def _format_fusion_input(self, data: Dict[str, Any]) -> str:
        """格式化融合输入"""
        cv_data = data.get('cv', {})
        stt_data = data.get('stt', {})
        text_data = data.get('text', {})
        
        parts = ["多模态输入分析："]
        
        if cv_data:
            emotion = cv_data.get('emotion', 'unknown')
            conf = cv_data.get('confidence', 0.0)
            parts.append(f"- CV情感: {emotion} (置信度: {conf:.2f})")
        
        if stt_data:
            text = stt_data.get('text', '')
            parts.append(f"- 语音内容: {text}")
        
        if text_data:
            text = text_data.get('text', '')
            emotion = text_data.get('emotion', 'unknown')
            parts.append(f"- 文本: {text}")
            parts.append(f"- 文本情感: {emotion}")
        
        parts.append("\n请基于以上信息，返回JSON格式的融合结果：")
        parts.append('{"emotion": "...", "confidence": 0.0-1.0, "action": "..."}')
        
        return "\n".join(parts)
    
    def _parse_fusion_result(self, result: Dict[str, Any], 
                            original_data: Dict[str, Any]) -> Dict[str, Any]:
        """解析融合结果"""
        try:
            # 提取最后一条AI消息
            messages = result.get('messages', [])
            if messages:
                last_message = messages[-1]
                content = last_message.content if hasattr(last_message, 'content') else str(last_message)
                
                # 尝试解析JSON
                import re
                json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', content, re.DOTALL)
                if json_match:
                    parsed = json.loads(json_match.group())
                    return {
                        'emotion': parsed.get('emotion', 'neutral'),
                        'confidence': float(parsed.get('confidence', 0.5)),
                        'action': parsed.get('action', 'observe'),
                        'ai_powered': True
                    }
            
            # 解析失败，使用回退
            return self._fallback_fusion_decision(original_data)
            
        except Exception as e:
            self.logger.error(f"解析融合结果失败: {e}")
            return self._fallback_fusion_decision(original_data)
    
    def _fallback_fusion_decision(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """回退决策（基于规则）"""
        # 简单的多数投票
        emotions = []
        confidences = []
        
        if 'cv' in data:
            emotions.append(data['cv'].get('emotion', 'neutral'))
            confidences.append(data['cv'].get('confidence', 0.0))
        
        if 'text' in data:
            emotions.append(data['text'].get('emotion', 'neutral'))
            confidences.append(data['text'].get('confidence', 0.0))
        
        if emotions:
            # 使用置信度最高的情感
            max_idx = confidences.index(max(confidences)) if confidences else 0
            return {
                'emotion': emotions[max_idx] if max_idx < len(emotions) else 'neutral',
                'confidence': confidences[max_idx] if max_idx < len(confidences) else 0.5,
                'action': 'observe',
                'ai_powered': False
            }
        
        return {
            'emotion': 'neutral',
            'confidence': 0.5,
            'action': 'observe',
            'ai_powered': False
        }
    
    def test_connection(self) -> bool:
        """测试LLM连接"""
        if not self.llm:
            return False
        
        try:
            response = self.llm.invoke([HumanMessage(content="Hello")])
            self.logger.info("✓ LLM连接测试成功")
            return True
        except Exception as e:
            self.logger.error(f"❌ LLM连接测试失败: {e}")
            return False
