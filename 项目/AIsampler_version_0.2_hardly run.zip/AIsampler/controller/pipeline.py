#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
端到端流程管道
实现完整的CV/STT输入 → 融合 → 骨骼控制 → 视频生成流程
"""

import time
import threading
import logging
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
import os
import sys
from pathlib import Path

# 设置项目根目录路径
PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent

# 确保项目根目录在 sys.path 中
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 添加项目路径
from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)

# 导入模块 - 处理直接运行和作为模块导入两种情况
# 当直接运行 pipeline.py 时，__name__ 是 '__main__'，需要使用绝对导入
# 当作为模块导入时，可以使用相对导入
if __name__ == "__main__":
    # 直接运行时，使用绝对导入
    from controller.controller import MainController
    from controller.agent_manager import AgentManager
else:
    # 作为模块导入时，使用相对导入
    try:
        from .controller import MainController
        from .agent_manager import AgentManager
    except ImportError:
        # 如果相对导入失败，回退到绝对导入
        from controller.controller import MainController
        from controller.agent_manager import AgentManager

from parts.fusion.fusion_controller import FusionController, FusionResult
from parts.fusion.emotion_bone_mapper import EmotionToBoneMapper
from adapter.blender.blender_controller import BlenderController
from adapter.comfyui.comfyui_controller import ComfyUIController
config_loader = get_config_loader()


@dataclass
class PipelineStatus:
    """管道状态"""
    is_running: bool = False
    cv_active: bool = False
    stt_active: bool = False
    fusion_active: bool = False
    blender_active: bool = False
    comfyui_active: bool = False
    last_update_time: float = 0.0
    total_frames: int = 0
    total_fusions: int = 0
    total_bone_updates: int = 0
    total_video_generations: int = 0


class FeedbackLoop:
    """
    反馈循环
    分析生成结果，自适应调整参数
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化反馈循环
        
        Args:
            config: 配置字典
        """
        if config is None:
            config = {}
        
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # 历史数据
        self.generation_history: List[Dict[str, Any]] = []
        self.max_history_size = config.get('max_history_size', 100)
        
        # 自适应参数
        self.adaptive_params = {
            'emotion_sensitivity': 1.0,  # 情绪敏感度
            'bone_update_frequency': 1.0,  # 骨骼更新频率
            'video_generation_interval': 10.0,  # 视频生成间隔（秒）
        }
    
    def analyze_result(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        分析生成结果
        
        Args:
            result: 生成结果字典
            
        Returns:
            Dict[str, Any]: 分析结果和建议
        """
        # 记录历史
        self.generation_history.append({
            'timestamp': time.time(),
            'result': result
        })
        
        # 限制历史大小
        if len(self.generation_history) > self.max_history_size:
            self.generation_history.pop(0)
        
        return {
            'adaptive_params': self.adaptive_params.copy()
        }
    
    def get_adaptive_params(self) -> Dict[str, float]:
        """获取自适应参数"""
        return self.adaptive_params.copy()
    
    def reset(self):
        """重置反馈循环"""
        self.generation_history.clear()
        self.adaptive_params = {
            'emotion_sensitivity': 1.0,
            'bone_update_frequency': 1.0,
            'video_generation_interval': 10.0,
        }


class EndToEndPipeline:
    """
    端到端流程管道
    实现完整的输入到输出流程
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化端到端流程管道
        
        Args:
            config: 配置字典
        """
        # 加载配置
        if config is None:
            config = {}
        
        self.config = config
        
        # 初始化日志（避免重复配置）
        self.logger = logging.getLogger(__name__)
        
        # 尝试使用预加载的模块实例
        preloader = None
        try:
            from utils.model_preloader import ModelPreloader
            preloader = ModelPreloader(config=config)
            preload_status = preloader.preload_all()
            self.logger.info(f"模型预加载完成，状态: {[f'{k}:{v.status}' for k, v in preload_status.items()]}")
        except Exception as e:
            self.logger.warning(f"模型预加载失败，将使用常规初始化: {e}")
        
        # 初始化主控制器
        self.main_controller = MainController()
        
        # 初始化融合控制器
        fusion_config = config_loader.get_fusion_config()
        self.fusion_controller = FusionController(config=fusion_config)
        
        # 初始化情绪到骨骼映射器（使用增强版203骨骼映射）
        enhanced_mapping_file = PROJECT_ROOT / "config" / "enhanced_bone_mapping.yaml"
        if enhanced_mapping_file.exists():
            self.emotion_mapper = EmotionToBoneMapper(mapping_file=str(enhanced_mapping_file))
            self.logger.info(f"✓ 使用增强版骨骼映射: {enhanced_mapping_file.name}")
        else:
            self.emotion_mapper = EmotionToBoneMapper()
            self.logger.warning("⚠️ 增强版映射不存在，使用默认映射（8骨骼）")
        
        # 初始化Blender控制器
        blender_config = config_loader.get_blender_config()
        self.logger.info("🔧 [初始化] 开始初始化BlenderController...")
        self.blender_controller = BlenderController(config=blender_config)
        self.logger.info(f"🔧 [初始化] BlenderController创建完成")
        self.logger.info(f"🔧 [初始化] Blender模式: {'内部' if self.blender_controller.blender_internal else 'Socket'}")
        self.logger.info(f"🔧 [初始化] Socket客户端: {self.blender_controller.socket_client}")
        
        # ⭐ 关键修复：加载骨骼文件
        self.logger.info("🦴 [初始化] 加载OpenPose骨骼文件...")
        try:
            load_success = self.blender_controller.load_openpose_file()
            if load_success:
                self.logger.info("✅ [初始化] 骨骼文件加载成功")
                # 验证骨骼数量
                bone_positions = self.blender_controller.get_bone_position()
                bone_count = len(bone_positions) if bone_positions else 0
                self.logger.info(f"✅ [初始化] 检测到 {bone_count} 个骨骼")
            else:
                self.logger.warning("⚠️ [初始化] 骨骼文件加载失败，骨骼控制可能不可用")
        except Exception as e:
            self.logger.error(f"❌ [初始化] 加载骨骼文件时出错: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
        
        # 使用预加载的ComfyUI控制器（如果可用）
        if preloader:
            comfyui_preloaded = preloader.get_module('comfyui')
            if comfyui_preloaded:
                self.comfyui_controller = comfyui_preloaded
                self.logger.info("使用预加载的ComfyUI控制器")
            else:
                comfyui_config = config_loader.get_comfyui_config()
                self.comfyui_controller = ComfyUIController(config=comfyui_config)
        else:
            comfyui_config = config_loader.get_comfyui_config()
            self.comfyui_controller = ComfyUIController(config=comfyui_config)
        
        # 初始化反馈循环
        self.feedback_loop = FeedbackLoop()
        
        # 使用预加载的Agent管理器（如果可用）
        if preloader:
            agent_preloaded = preloader.get_module('agent')
            if agent_preloaded:
                self.agent_manager = agent_preloaded
                self.logger.info("使用预加载的Agent管理器")
            else:
                agent_config = config.get('agent', {})
                self.agent_manager = AgentManager(config=agent_config)
        else:
            agent_config = config.get('agent', {})
            self.agent_manager = AgentManager(config=agent_config)
        
        # 保存预加载器引用（用于后续获取其他模块）
        self.preloader = preloader
        
        # 状态管理
        self.status = PipelineStatus()
        self._lock = threading.RLock()
        self._running = False
        
        # 检测Blender是否可用（在BlenderController初始化后）
        self.logger.info("🔧 [初始化] 开始检查Blender可用性...")
        self.blender_available = self._check_blender_available()
        self.logger.info(f"🔧 [初始化] ✅ 最终状态: blender_available={self.blender_available}")
        
        if not self.blender_available:
            self.logger.warning("⚠️⚠️⚠️ Blender不可用，骨骼控制功能将被禁用！⚠️⚠️⚠️")
        
        # 视频生成相关
        self.last_video_generation_time = 0.0
        self.video_generation_interval = config.get('video_generation_interval', 10.0)
        self.current_task_id: Optional[str] = None
        
        # 注册回调
        self._setup_callbacks()
        
        self.logger.info("端到端流程管道初始化完成")
    
    def _check_blender_available(self) -> bool:
        """
        检查Blender是否可用
        
        Returns:
            bool: Blender是否可用
        """
        self.logger.info("   步骤1: 检查BlenderController...")
        try:
            # 检查BlenderController是否初始化
            if not hasattr(self, 'blender_controller') or not self.blender_controller:
                self.logger.error("   ❌ BlenderController属性不存在或为None")
                return False
            
            self.logger.info(f"   ✅ BlenderController已初始化: {self.blender_controller}")
            
            # 检查是否在Blender内部运行
            self.logger.info("   步骤2: 检查运行模式...")
            if self.blender_controller.blender_internal:
                self.logger.info("   ✅ Blender内部模式，直接可用")
                return True
            
            self.logger.info("   ℹ️ Socket外部模式")
            
            # 检查Socket连接
            self.logger.info("   步骤3: 检查Socket客户端...")
            if not self.blender_controller.socket_client:
                self.logger.error("   ❌ Socket客户端未初始化")
                self.logger.error("   💡 可能需要安装blender_socket_client模块")
                return False
            
            self.logger.info(f"   ✅ Socket客户端已初始化: {self.blender_controller.socket_client}")
            
            # 测试连接
            self.logger.info("   步骤4: 测试Socket连接（ping）...")
            ping_result = self.blender_controller.socket_client.ping()
            self.logger.info(f"   Ping结果: {ping_result}")
            
            if ping_result:
                self.logger.info("   ✅✅✅ Blender Socket连接成功！")
                return True
            else:
                self.logger.error("   ❌ Blender Socket连接失败（ping返回False）")
                self.logger.error("   ⚠️ 请确保：")
                self.logger.error("      1. Blender已启动")
                self.logger.error("      2. Socket服务器插件已启动")
                self.logger.error("      3. 端口8888未被占用")
                return False
        
        except Exception as e:
            self.logger.error(f"   ❌ 检查过程出错: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return False
    
    def _setup_callbacks(self):
        """设置回调函数"""
        # 注册融合回调
        def fusion_callback(result: FusionResult):
            """融合结果回调"""
            try:
                self._handle_fusion_result(result)
            except Exception as e:
                self.logger.error(f"融合回调处理失败: {e}")
        
        self.fusion_controller.register_callback(fusion_callback)
    
    def _handle_fusion_result(self, result: FusionResult):
        """
        处理融合结果
        
        Args:
            result: 融合结果
        """
        self.logger.info(f"🎬 [流程开始] 收到融合结果: emotion={result.emotion}, confidence={result.confidence:.2f}")
        
        try:
            with self._lock:
                self.status.total_fusions += 1
                self.status.last_update_time = time.time()
            
            # 使用Agent系统进行智能决策
            self.logger.info("🤖 [步骤1] 调用Agent进行决策...")
            decision = self._make_agent_decision(result)
            self.logger.info(f"🤖 [步骤1完成] Agent决策: {decision}")
            
            # 根据Agent决策执行操作
            action = decision.get('action')
            self.logger.info(f"🎯 [步骤2] 执行动作: {action}")
            
            if action == 'update_bones':
                # Agent决定更新骨骼
                emotion = decision.get('emotion', result.emotion)
                confidence = decision.get('confidence', result.confidence)
                
                self.logger.info(f"🦴 [步骤2.1] 准备更新骨骼: emotion={emotion}, confidence={confidence:.2f}")
                
                # 获取自适应参数
                adaptive_params = self.feedback_loop.get_adaptive_params()
                emotion_sensitivity = adaptive_params.get('emotion_sensitivity', 1.0)
                
                # 调整置信度
                adjusted_confidence = confidence * emotion_sensitivity
                
                # 映射到骨骼
                self.logger.info(f"🎯 [步骤2.2] 映射情感到骨骼...")
                bone_poses = self.emotion_mapper.map_emotion_to_bones(
                    emotion, 
                    min(adjusted_confidence, 1.0)
                )
                self.logger.info(f"🎯 [步骤2.2完成] 映射了{len(bone_poses)}个骨骼姿势")
                
                # 更新Blender骨骼
                self.logger.info(f"🔄 [步骤2.3] 调用Blender更新...")
                self._update_blender_bones(bone_poses)
                self.logger.info(f"✅ [步骤2.3完成] Blender更新调用完成")
            else:
                self.logger.warning(f"⚠️ 未知动作类型: {action}，跳过骨骼更新")
            
            if decision.get('action') == 'generate_video' or decision.get('should_generate'):
                # Agent决定生成视频
                current_time = time.time()
                if (current_time - self.last_video_generation_time >= 
                    self.video_generation_interval):
                    self._generate_video_with_agent(decision)
                    self.last_video_generation_time = current_time
        
        except Exception as e:
            self.logger.error(f"处理融合结果失败: {e}")
    
    def _update_blender_bones(self, bone_poses: List):
        """
        更新Blender骨骼
        
        Args:
            bone_poses: 骨骼姿势列表
        """
        self.logger.info(f"[Blender更新] 开始，共{len(bone_poses)}个骨骼")
        self.logger.info(f"[Blender状态] blender_available={self.blender_available}")
        
        if not self.blender_available:
            self.logger.error("[Blender更新失败] blender_available=False，跳过")
            return
            
        try:
            success_count = 0
            for i, bone_pose in enumerate(bone_poses):
                self.logger.info(f"  [BONE {i+1}/{len(bone_poses)}] 更新骨骼: {bone_pose.bone_name}")
                self.logger.info(f"     参数: pos={bone_pose.position}, rot={bone_pose.rotation}")
                
                self.logger.info(f"     调用 blender_controller.update_bone_pose...")
                success = self.blender_controller.update_bone_pose(
                    bone_pose.bone_name,
                    bone_pose.position,
                    bone_pose.rotation
                )
                self.logger.info(f"     返回值: success={success}")
                
                if success:
                    success_count += 1
                    self.logger.info(f"  [SUCCESS {i+1}/{len(bone_poses)}] 骨骼更新成功")
                    with self._lock:
                        self.status.total_bone_updates += 1
                else:
                    self.logger.warning(f"  [FAILED {i+1}/{len(bone_poses)}] 更新骨骼 {bone_pose.bone_name} 失败")
                    self.logger.warning(f"  跳过此骨骼，继续处理下一个...")
                    # 注释掉：不要因为单个骨骼失败就禁用整个Blender
                    # self.blender_available = False
                    # self.logger.error("[ERROR] Blender骨骼更新不可用，将暂停后续骨骼同步")
                    # break
            
            self.logger.info(f"[Blender更新完成] {success_count}/{len(bone_poses)} 成功")
        
        except Exception as e:
            self.logger.error(f"[Blender更新异常] {e}")
            import traceback
            self.logger.error(traceback.format_exc())
    
    def _make_agent_decision(self, fusion_result: FusionResult) -> Dict[str, Any]:
        """
        使用Agent系统做出智能决策
        
        Args:
            fusion_result: 融合结果
            
        Returns:
            Dict[str, Any]: Agent决策结果
        """
        try:
            self.logger.info("🤖 [Agent决策] ============================================")
            self.logger.info(f"📥 [Agent输入]")
            self.logger.info(f"   情感: {fusion_result.emotion}")
            self.logger.info(f"   置信度: {fusion_result.confidence:.2f}")
            self.logger.info(f"   来源: CV={fusion_result.sources.get('cv', {})}, STT={fusion_result.sources.get('stt', {})}")
            
            # 准备输入数据
            input_data = {
                'cv': fusion_result.sources.get('cv', {}),
                'stt': fusion_result.sources.get('stt', {}),
                'emotion': fusion_result.emotion,
                'confidence': fusion_result.confidence
            }
            
            # 调用Fusion Agent做出决策
            decision_task = {
                'type': 'fusion_decision',
                'input': input_data
            }
            
            self.logger.info("🧠 [Agent思考] 正在调用大模型进行推理...")
            result = self.agent_manager.orchestrate(decision_task)
            
            # 解析Agent决策
            if not isinstance(result, dict):
                raise ValueError(f"Agent返回了无效的结果类型: {type(result)}")
            
            decision = {
                'action': result.get('action', 'update_bones'),
                'emotion': result.get('emotion', fusion_result.emotion),
                'confidence': result.get('confidence', fusion_result.confidence),
                'should_generate': result.get('should_generate', False),
                'reasoning': result.get('decision', '')
            }
            
            # 输出Agent的思考逻辑
            self.logger.info("💭 [Agent推理过程] =====================================")
            self.logger.info(f"   决策动作: {decision['action']}")
            self.logger.info(f"   最终情感: {decision['emotion']}")
            self.logger.info(f"   调整置信度: {decision['confidence']:.2f}")
            self.logger.info(f"   是否生成视频: {decision['should_generate']}")
            if decision['reasoning']:
                self.logger.info(f"   推理原因:")
                for line in decision['reasoning'].split('\n'):
                    if line.strip():
                        self.logger.info(f"      {line.strip()}")
            self.logger.info("📤 [Agent输出] 决策完成")
            self.logger.info("=" * 60)
            
            return decision
        
        except Exception as e:
            self.logger.error(f"❌ [Agent决策失败] {e}")
            raise RuntimeError(f"Agent决策失败，系统无法继续: {e}")
    
    def _generate_video_with_agent(self, decision: Dict[str, Any]):
        """
        使用Agent系统生成视频
        
        Args:
            decision: Agent决策结果
        """
        try:
            # 创建骨骼快照
            snapshot = self.blender_controller.create_pose_shot()
            
            # 使用Generation Agent生成提示词和配置
            generation_task = {
                'type': 'video_generation',
                'input': {
                    'emotion': decision.get('emotion', 'neutral'),
                    'snapshot': snapshot
                }
            }
            
            generation_result = self.agent_manager.orchestrate(generation_task)
            
            # 从Agent结果中获取提示词（Agent应返回字典）
            if not isinstance(generation_result, dict):
                raise ValueError(f"Agent返回了无效的结果类型: {type(generation_result)}")
            
            prompt = generation_result.get('prompt', 
                f"a character with {decision.get('emotion', 'neutral')} emotion, high quality, detailed")
            negative_prompt = generation_result.get('negative_prompt', '')
            
            # 确保工作流已加载
            if not getattr(self.comfyui_controller, 'workflow_data', None):
                self.comfyui_controller.load_workflow()
            
            # 设置提示词
            self.comfyui_controller.set_prompt(prompt)
            if negative_prompt:
                self.comfyui_controller.set_negative_prompt(negative_prompt)
            
            # 执行工作流
            task_id = self.comfyui_controller.execute_workflow()
            
            if task_id:
                self.current_task_id = task_id
                self.logger.info(f"视频生成任务已提交，任务ID: {task_id}")
                
                # 在后台检查任务状态
                threading.Thread(
                    target=self._check_video_generation_status,
                    args=(task_id,),
                    daemon=True
                ).start()
            else:
                self.logger.error("视频生成任务提交失败")
        
        except Exception as e:
            self.logger.error(f"使用Agent生成视频失败: {e}")
            raise
    
    def _check_video_generation_status(self, task_id: str):
        """
        检查视频生成状态
        
        Args:
            task_id: 任务ID
        """
        try:
            max_wait_time = 300  # 最大等待时间（秒）
            check_interval = 2.0  # 检查间隔（秒）
            start_time = time.time()
            
            while time.time() - start_time < max_wait_time:
                status = self.comfyui_controller.get_task_status(task_id)
                
                if status.get('status') == 'success':
                    # 获取视频路径
                    video_path = self.comfyui_controller.get_output_video(task_id)
                    
                    if video_path:
                        self.logger.info(f"视频生成成功: {video_path}")
                        
                        # 反馈循环分析
                        result = {
                            'task_id': task_id,
                            'video_path': video_path
                        }
                        
                        analysis = self.feedback_loop.analyze_result(result)
                        self.logger.info(f"反馈分析: {analysis}")
                        
                        with self._lock:
                            self.status.total_video_generations += 1
                    
                    break
                elif status.get('status') == 'error':
                    self.logger.error(f"视频生成失败: {status.get('message', '未知错误')}")
                    break
                
                time.sleep(check_interval)
            
        except Exception as e:
            self.logger.error(f"检查视频生成状态失败: {e}")
    
    def start(self) -> bool:
        """
        启动端到端流程
        
        Returns:
            bool: 是否启动成功
        """
        try:
            with self._lock:
                if self._running:
                    self.logger.warning("流程已经在运行")
                    return False
                
                self._running = True
                self.status.is_running = True
            
            # 初始化主控制器
            if not self.main_controller.initialize():
                self.logger.error("主控制器初始化失败")
                return False
            
            # 启动主控制器
            if not self.main_controller.start():
                self.logger.error("主控制器启动失败")
                return False
            
            # 初始化Agent系统（必需）
            if not self.agent_manager.initialize_agents():
                raise RuntimeError("Agent系统初始化失败，系统无法运行")
            self.logger.info("Agent系统初始化成功，AI判断能力已启用")
            
            # 加载Blender骨骼文件
            try:
                self.blender_controller.load_openpose_file()
                with self._lock:
                    self.status.blender_active = True
            except Exception as e:
                self.logger.warning(f"加载Blender骨骼文件失败: {e}")
            
            # 启动CV流（直接使用回调，不使用事件队列）
            def cv_callback(data: Dict[str, Any]):
                """CV数据回调"""
                try:
                    timestamp = data.get('timestamp', time.time())
                    self.fusion_controller.add_cv_data(timestamp, data)
                    with self._lock:
                        self.status.total_frames += 1
                        self.status.cv_active = True
                except Exception as e:
                    self.logger.error(f"CV回调处理失败: {e}")
            
            def stt_callback(data: Dict[str, Any]):
                """STT数据回调"""
                try:
                    timestamp = data.get('timestamp', time.time())
                    self.fusion_controller.add_stt_data(timestamp, data)
                    with self._lock:
                        self.status.stt_active = True
                        self.status.fusion_active = True
                except Exception as e:
                    self.logger.error(f"STT回调处理失败: {e}")
            
            def text_callback(data: Dict[str, Any]):
                """Text数据回调"""
                try:
                    timestamp = data.get('timestamp', time.time())
                    self.fusion_controller.add_text_data(timestamp, data)
                    with self._lock:
                        self.status.fusion_active = True
                    self.logger.info(f"文本输入: {data.get('text', '')[:50]}... [情感: {data.get('emotion', 'N/A')}]")
                except Exception as e:
                    self.logger.error(f"Text回调处理失败: {e}")
            
            self.main_controller.start_cv_stream(callback=cv_callback, show_window=False)
            self.main_controller.start_stt_stream(callback=stt_callback)
            self.main_controller.start_text_stream(callback=text_callback)
            
            self.logger.info("端到端流程已启动")
            return True
            
        except Exception as e:
            self.logger.error(f"启动流程失败: {e}")
            with self._lock:
                self._running = False
                self.status.is_running = False
            return False
    
    def stop(self):
        """停止端到端流程"""
        try:
            with self._lock:
                if not self._running:
                    return
                
                self._running = False
                self.status.is_running = False
                self.status.cv_active = False
                self.status.stt_active = False
                self.status.fusion_active = False
                self.status.blender_active = False
                self.status.comfyui_active = False
            
            # 停止主控制器
            self.main_controller.stop()
            
            # 清理资源
            self.fusion_controller.clear()
            self.emotion_mapper.reset()
            
            self.logger.info("端到端流程已停止")
            
        except Exception as e:
            self.logger.error(f"停止流程失败: {e}")
    
    def get_status(self) -> PipelineStatus:
        """获取流程状态"""
        with self._lock:
            # 使用dataclass的replace方法创建副本
            from dataclasses import replace
            return replace(self.status)
    
    def cleanup(self):
        """清理资源"""
        try:
            self.stop()
            self.main_controller.cleanup()
            self.feedback_loop.reset()
            self.logger.info("资源清理完成")
        except Exception as e:
            self.logger.error(f"清理资源失败: {e}")


# 测试代码已移除，请使用专门的测试文件

