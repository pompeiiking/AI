#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主控制器 - 系统核心协调器
实现模块生命周期管理、事件循环、健康检查等功能
"""

import time
import threading
import queue
import logging
from typing import Dict, Any, Optional, Callable, List, Tuple
from enum import Enum
from dataclasses import dataclass, field
from collections import deque
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 添加项目路径
from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)
config_loader = get_config_loader()

# 必需模块
from parts.cv.cv_controller import CVController
from parts.text.text_controller import TextController

# 可选模块：STT（语音识别）
try:
    from parts.stt.stt_controller import STTController
    STT_AVAILABLE = True
except ImportError as e:
    STT_AVAILABLE = False
    STTController = None
    import warnings
    warnings.warn(f"STT模块不可用，将跳过语音识别功能: {e}")


class ModuleStatus(Enum):
    """模块状态枚举"""
    UNINITIALIZED = "uninitialized"
    INITIALIZING = "initializing"
    READY = "ready"
    RUNNING = "running"
    ERROR = "error"
    STOPPED = "stopped"


@dataclass
class Event:
    """事件数据类"""
    event_type: str
    timestamp: float
    sequence_id: int
    data: Dict[str, Any]
    priority: int = 0  # 优先级，数字越大优先级越高
    source: str = ""  # 事件来源（cv/stt/fusion等）
    
    def __hash__(self):
        """用于去重"""
        return hash((self.event_type, self.sequence_id, self.source))


@dataclass
class ModuleHealth:
    """模块健康状态"""
    module_name: str
    status: ModuleStatus
    last_check_time: float
    response_time: float = 0.0
    error_count: int = 0
    last_error: Optional[str] = None
    resource_usage: Dict[str, Any] = field(default_factory=dict)


class EventQueue:
    """
    线程安全的事件队列
    实现事件优先级、去重、超时处理、背压处理
    """
    
    def __init__(self, max_size: int = 1000, dedup_window: float = 0.1):
        """
        初始化事件队列
        
        Args:
            max_size: 队列最大大小
            dedup_window: 去重时间窗口（秒）
        """
        self._queue = queue.PriorityQueue(maxsize=max_size)
        self._lock = threading.RLock()
        self._max_size = max_size
        self._dedup_window = dedup_window
        self._recent_events: deque = deque()  # 用于去重
        self._sequence_counter = 0
        self._sequence_lock = threading.Lock()
        
    def put(self, event: Event, timeout: float = 1.0) -> bool:
        """
        添加事件到队列
        
        Args:
            event: 事件对象
            timeout: 超时时间（秒）
            
        Returns:
            bool: 是否成功添加
        """
        try:
            # 检查去重
            if self._should_deduplicate(event):
                return False
            
            # 添加序列号（如果没有）
            if event.sequence_id == 0:
                with self._sequence_lock:
                    self._sequence_counter += 1
                    event.sequence_id = self._sequence_counter
            
            # 添加时间戳（如果没有）
            if event.timestamp == 0:
                event.timestamp = time.time()
            
            # 使用负优先级实现最大堆（优先级高的先处理）
            priority_item = (-event.priority, event.timestamp, event)
            
            self._queue.put(priority_item, timeout=timeout)
            
            # 记录到去重窗口
            with self._lock:
                self._recent_events.append((time.time(), event))
                # 清理过期事件
                current_time = time.time()
                while self._recent_events and current_time - self._recent_events[0][0] > self._dedup_window:
                    self._recent_events.popleft()
            
            return True
            
        except queue.Full:
            logging.warning(f"事件队列已满，丢弃事件: {event.event_type}")
            return False
        except Exception as e:
            logging.error(f"添加事件失败: {e}")
            return False
    
    def get(self, timeout: float = 1.0) -> Optional[Event]:
        """
        从队列获取事件
        
        Args:
            timeout: 超时时间（秒）
            
        Returns:
            Event: 事件对象，如果超时返回None
        """
        try:
            priority_item = self._queue.get(timeout=timeout)
            return priority_item[2]  # 返回事件对象
        except queue.Empty:
            return None
        except Exception as e:
            logging.error(f"获取事件失败: {e}")
            return None
    
    def _should_deduplicate(self, event: Event) -> bool:
        """
        检查是否应该去重
        
        Args:
            event: 事件对象
            
        Returns:
            bool: 如果应该去重返回True
        """
        with self._lock:
            current_time = time.time()
            for event_time, recent_event in self._recent_events:
                # 检查时间窗口
                if current_time - event_time > self._dedup_window:
                    continue
                
                # 检查是否相同事件
                if (recent_event.event_type == event.event_type and
                    recent_event.sequence_id == event.sequence_id and
                    recent_event.source == event.source):
                    return True
            
            return False
    
    def size(self) -> int:
        """获取队列大小"""
        return self._queue.qsize()
    
    def empty(self) -> bool:
        """检查队列是否为空"""
        return self._queue.empty()
    
    def clear(self):
        """清空队列"""
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except queue.Empty:
                break
        with self._lock:
            self._recent_events.clear()


class HealthChecker:
    """
    模块健康检查器
    定期检查模块状态、响应时间、资源使用情况
    """
    
    def __init__(self, check_interval: float = 5.0, timeout: float = 1.0):
        """
        初始化健康检查器
        
        Args:
            check_interval: 检查间隔（秒）
            timeout: 检查超时时间（秒）
        """
        self.check_interval = check_interval
        self.timeout = timeout
        self._modules: Dict[str, ModuleHealth] = {}
        self._lock = threading.RLock()
        self._running = False
        self._check_thread: Optional[threading.Thread] = None
        self._check_callbacks: Dict[str, Callable[[], bool]] = {}
        
    def register_module(self, module_name: str, check_callback: Optional[Callable[[], bool]] = None):
        """
        注册模块
        
        Args:
            module_name: 模块名称
            check_callback: 健康检查回调函数，返回True表示健康
        """
        with self._lock:
            self._modules[module_name] = ModuleHealth(
                module_name=module_name,
                status=ModuleStatus.UNINITIALIZED,
                last_check_time=0.0
            )
            if check_callback:
                self._check_callbacks[module_name] = check_callback
    
    def update_module_status(self, module_name: str, status: ModuleStatus, 
                            error: Optional[str] = None):
        """
        更新模块状态
        
        Args:
            module_name: 模块名称
            status: 模块状态
            error: 错误信息（如果有）
        """
        with self._lock:
            if module_name in self._modules:
                health = self._modules[module_name]
                health.status = status
                health.last_check_time = time.time()
                if error:
                    health.error_count += 1
                    health.last_error = error
                elif status == ModuleStatus.READY or status == ModuleStatus.RUNNING:
                    health.error_count = 0
                    health.last_error = None
    
    def check_module(self, module_name: str) -> bool:
        """
        检查单个模块健康状态
        
        Args:
            module_name: 模块名称
            
        Returns:
            bool: 是否健康
        """
        with self._lock:
            if module_name not in self._modules:
                return False
            
            health = self._modules[module_name]
            start_time = time.time()
            
            try:
                # 调用检查回调
                if module_name in self._check_callbacks:
                    is_healthy = self._check_callbacks[module_name]()
                else:
                    # 默认检查：状态不是ERROR
                    is_healthy = health.status != ModuleStatus.ERROR
                
                # 更新响应时间
                health.response_time = time.time() - start_time
                health.last_check_time = time.time()
                
                if not is_healthy:
                    health.status = ModuleStatus.ERROR
                    health.error_count += 1
                
                return is_healthy
                
            except Exception as e:
                health.status = ModuleStatus.ERROR
                health.error_count += 1
                health.last_error = str(e)
                health.response_time = time.time() - start_time
                logging.error(f"检查模块 {module_name} 健康状态失败: {e}")
                return False
    
    def get_module_health(self, module_name: str) -> Optional[ModuleHealth]:
        """
        获取模块健康状态
        
        Args:
            module_name: 模块名称
            
        Returns:
            ModuleHealth: 健康状态对象
        """
        with self._lock:
            return self._modules.get(module_name)
    
    def get_all_health(self) -> Dict[str, ModuleHealth]:
        """获取所有模块健康状态"""
        with self._lock:
            return self._modules.copy()
    
    def start(self):
        """启动健康检查线程"""
        if self._running:
            return
        
        self._running = True
        self._check_thread = threading.Thread(target=self._check_loop, daemon=True)
        self._check_thread.start()
        logging.info("健康检查器已启动")
    
    def stop(self):
        """停止健康检查线程"""
        self._running = False
        if self._check_thread:
            self._check_thread.join(timeout=2.0)
        logging.info("健康检查器已停止")
    
    def _check_loop(self):
        """健康检查循环"""
        while self._running:
            try:
                with self._lock:
                    module_names = list(self._modules.keys())
                
                for module_name in module_names:
                    self.check_module(module_name)
                
                time.sleep(self.check_interval)
                
            except Exception as e:
                logging.error(f"健康检查循环错误: {e}")
                time.sleep(self.check_interval)


class MainController:
    """
    主控制器 - 系统核心协调器
    管理所有模块的生命周期、事件循环、健康检查
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化主控制器
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
        """
        # 加载配置
        if config is None:
            # 可以添加主控制器配置
            config = {}
        
        self.config = config
        
        # 初始化日志
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
        
        # 初始化组件
        self.event_queue = EventQueue(
            max_size=config.get('event_queue_size', 1000),
            dedup_window=config.get('event_dedup_window', 0.1)
        )
        self.health_checker = HealthChecker(
            check_interval=config.get('health_check_interval', 5.0),
            timeout=config.get('health_check_timeout', 1.0)
        )
        
        # 模块实例
        self.cv_controller: Optional[CVController] = None
        self.stt_controller: Optional[STTController] = None
        self.text_controller: Optional[TextController] = None
        
        # 状态管理
        self._status = ModuleStatus.UNINITIALIZED
        self._lock = threading.RLock()
        self._running = False
        self._event_thread: Optional[threading.Thread] = None
        
        # 回调函数
        self._callbacks: Dict[str, List[Callable[[Event], None]]] = {}
        
        # 序列号计数器
        self._sequence_counter = 0
        self._sequence_lock = threading.Lock()
        
        self.logger.info("主控制器初始化完成")
    
    def initialize(self, use_preload: bool = True) -> bool:
        """
        初始化所有模块
        
        Args:
            use_preload: 是否使用预加载的模块实例
        
        Returns:
            bool: 是否初始化成功
        """
        try:
            with self._lock:
                if self._status != ModuleStatus.UNINITIALIZED:
                    self.logger.warning("模块已经初始化")
                    return False
                
                self._status = ModuleStatus.INITIALIZING
                self.logger.info("开始初始化模块...")
            
            # 尝试使用预加载的模块实例
            preloader = None
            if use_preload:
                try:
                    from utils.model_preloader import ModelPreloader
                    preloader = ModelPreloader()
                    preloader.preload_all()
                except Exception as e:
                    self.logger.warning(f"模型预加载失败，将使用常规初始化: {e}")
            
            # 初始化CV模块
            try:
                cv_preloaded = preloader.get_module('cv') if preloader else None
                if cv_preloaded:
                    self.cv_controller = cv_preloaded
                    self.logger.info("使用预加载的CV模块")
                else:
                    cv_config = config_loader.get_cv_config()
                    self.cv_controller = CVController(config=cv_config)
                    if not self.cv_controller.initialize_models():
                        raise RuntimeError("CV模型初始化失败")
                
                self.health_checker.register_module("cv", self._check_cv_health)
                self.health_checker.update_module_status("cv", ModuleStatus.READY)
                self.logger.info("CV模块初始化成功")
            except Exception as e:
                self.logger.error(f"CV模块初始化失败: {e}")
                self.health_checker.update_module_status("cv", ModuleStatus.ERROR, str(e))
            
            # 初始化STT模块（可选）
            if STT_AVAILABLE:
                try:
                    stt_preloaded = preloader.get_module('stt') if preloader else None
                    if stt_preloaded:
                        self.stt_controller = stt_preloaded
                        self.logger.info("使用预加载的STT模块")
                    else:
                        stt_config = config_loader.get_stt_config()
                        self.stt_controller = STTController(config=stt_config)
                    
                    self.health_checker.register_module("stt", self._check_stt_health)
                    self.health_checker.update_module_status("stt", ModuleStatus.READY)
                    self.logger.info("STT模块初始化成功")
                except Exception as e:
                    self.logger.error(f"STT模块初始化失败: {e}")
                    self.health_checker.update_module_status("stt", ModuleStatus.ERROR, str(e))
            else:
                self.logger.warning("⚠️ STT模块不可用，语音识别功能已禁用")
            
            # 初始化Text模块
            try:
                text_config = config_loader.get_text_config()
                self.text_controller = TextController(config=text_config)
                
                self.health_checker.register_module("text", self._check_text_health)
                self.health_checker.update_module_status("text", ModuleStatus.READY)
                self.logger.info("Text模块初始化成功")
            except Exception as e:
                self.logger.error(f"Text模块初始化失败: {e}")
                self.health_checker.update_module_status("text", ModuleStatus.ERROR, str(e))
            
            with self._lock:
                self._status = ModuleStatus.READY
            
            self.logger.info("所有模块初始化完成")
            return True
            
        except Exception as e:
            self.logger.error(f"初始化失败: {e}")
            with self._lock:
                self._status = ModuleStatus.ERROR
            return False
    
    def start(self) -> bool:
        """
        启动主控制器
        
        Returns:
            bool: 是否启动成功
        """
        try:
            with self._lock:
                if self._status != ModuleStatus.READY:
                    self.logger.error(f"模块状态不正确，无法启动。当前状态: {self._status}")
                    return False
                
                if self._running:
                    self.logger.warning("主控制器已经在运行")
                    return False
                
                self._running = True
                self._status = ModuleStatus.RUNNING
            
            # 启动健康检查器
            self.health_checker.start()
            
            # 启动事件处理线程
            self._event_thread = threading.Thread(target=self._event_loop, daemon=True)
            self._event_thread.start()
            
            self.logger.info("主控制器已启动")
            return True
            
        except Exception as e:
            self.logger.error(f"启动失败: {e}")
            with self._lock:
                self._running = False
                self._status = ModuleStatus.ERROR
            return False
    
    def stop(self):
        """停止主控制器"""
        try:
            with self._lock:
                if not self._running:
                    return
                
                self._running = False
                self._status = ModuleStatus.STOPPED
            
            # 停止健康检查器
            self.health_checker.stop()
            
            # 停止CV和STT
            if self.cv_controller:
                try:
                    self.cv_controller.stop_camera()
                except Exception as e:
                    self.logger.error(f"停止CV模块失败: {e}")
            
            # 等待事件线程结束
            if self._event_thread:
                self._event_thread.join(timeout=2.0)
            
            self.logger.info("主控制器已停止")
            
        except Exception as e:
            self.logger.error(f"停止失败: {e}")
    
    def cleanup(self):
        """清理资源"""
        try:
            self.stop()
            
            # 清理模块
            if self.cv_controller:
                try:
                    self.cv_controller.stop_camera()
                except Exception:
                    pass
            
            # 清空事件队列
            self.event_queue.clear()
            
            with self._lock:
                self._status = ModuleStatus.UNINITIALIZED
                self._callbacks.clear()
            
            self.logger.info("资源清理完成")
            
        except Exception as e:
            self.logger.error(f"清理失败: {e}")
    
    def register_callback(self, event_type: str, callback: Callable[[Event], None]):
        """
        注册事件回调
        
        Args:
            event_type: 事件类型
            callback: 回调函数
        """
        with self._lock:
            if event_type not in self._callbacks:
                self._callbacks[event_type] = []
            self._callbacks[event_type].append(callback)
    
    def unregister_callback(self, event_type: str, callback: Callable[[Event], None]):
        """
        取消注册事件回调
        
        Args:
            event_type: 事件类型
            callback: 回调函数
        """
        with self._lock:
            if event_type in self._callbacks:
                try:
                    self._callbacks[event_type].remove(callback)
                except ValueError:
                    pass
    
    def start_cv_stream(self, callback: Optional[Callable[[Dict[str, Any]], None]] = None,
                       show_window: bool = False):
        """
        启动CV流式处理
        
        Args:
            callback: CV回调函数
            show_window: 是否显示窗口
        """
        if not self.cv_controller:
            self.logger.error("CV控制器未初始化")
            return
        
        def cv_wrapper(result: Dict[str, Any]):
            """CV结果包装器，添加时间戳和序列号"""
            with self._sequence_lock:
                self._sequence_counter += 1
                sequence_id = self._sequence_counter
            
            # 确保数据包包含时间戳和序列号
            result['timestamp'] = result.get('timestamp', time.time())
            result['sequence_id'] = result.get('sequence_id', sequence_id)
            
            # 创建事件
            event = Event(
                event_type='cv_result',
                timestamp=result['timestamp'],
                sequence_id=result['sequence_id'],
                data=result,
                source='cv'
            )
            
            # 添加到事件队列
            self.event_queue.put(event)
            
            # 调用用户回调
            if callback:
                try:
                    callback(result)
                except Exception as e:
                    self.logger.error(f"CV回调执行失败: {e}")
        
        # 启动摄像头
        try:
            self.cv_controller.start_camera()
            self.health_checker.update_module_status("cv", ModuleStatus.RUNNING)
        except Exception as e:
            self.logger.error(f"启动摄像头失败: {e}")
            self.health_checker.update_module_status("cv", ModuleStatus.ERROR, str(e))
            return
        
        # 在单独线程中运行CV流式处理
        def cv_thread():
            try:
                self.cv_controller.cv(callback=cv_wrapper, show_window=show_window)
            except Exception as e:
                self.logger.error(f"CV流式处理失败: {e}")
                self.health_checker.update_module_status("cv", ModuleStatus.ERROR, str(e))
        
        threading.Thread(target=cv_thread, daemon=True).start()
        self.logger.info("CV流式处理已启动")
    
    def start_stt_stream(self, callback: Optional[Callable[[Dict[str, Any]], None]] = None):
        """
        启动STT流式处理
        
        Args:
            callback: STT回调函数
        """
        if not STT_AVAILABLE:
            self.logger.warning("⚠️ STT模块不可用，语音识别已禁用。请使用Text模块进行文本输入")
            return
        
        if not self.stt_controller:
            self.logger.error("STT控制器未初始化")
            return
        
        def stt_wrapper(result: str):
            """STT结果包装器，添加时间戳和序列号"""
            with self._sequence_lock:
                self._sequence_counter += 1
                sequence_id = self._sequence_counter
            
            # 创建数据包
            data = {
                'timestamp': time.time(),
                'sequence_id': sequence_id,
                'text': result,
                'confidence': 1.0,  # STT模块可以后续添加置信度
                'is_final': True
            }
            
            # 创建事件
            event = Event(
                event_type='stt_result',
                timestamp=data['timestamp'],
                sequence_id=data['sequence_id'],
                data=data,
                source='stt'
            )
            
            # 添加到事件队列
            self.event_queue.put(event)
            
            # 调用用户回调
            if callback:
                try:
                    callback(data)
                except Exception as e:
                    self.logger.error(f"STT回调执行失败: {e}")
        
        # 在单独线程中运行STT流式处理
        def stt_thread():
            try:
                self.health_checker.update_module_status("stt", ModuleStatus.RUNNING)
                self.logger.info("STT持续监听线程已启动，等待语音输入...")
                
                # 循环接收语音，而不是只执行一次
                while self._running:
                    try:
                        result = self.stt_controller.stt()
                        if result:
                            stt_wrapper(result)
                            self.logger.info(f"STT识别结果: {result}")
                    except Exception as e:
                        self.logger.error(f"STT单次处理失败: {e}，继续监听...")
                        import time
                        time.sleep(0.5)  # 失败后短暂休息，避免死循环
                        
            except Exception as e:
                self.logger.error(f"STT流式处理失败: {e}")
                self.health_checker.update_module_status("stt", ModuleStatus.ERROR, str(e))
        
        threading.Thread(target=stt_thread, daemon=True).start()
        self.logger.info("STT流式处理已启动")
    
    def start_text_stream(self, callback: Optional[Callable[[Dict[str, Any]], None]] = None):
        """
        启动Text流式处理
        
        Args:
            callback: Text回调函数
        """
        if not self.text_controller:
            self.logger.error("Text控制器未初始化")
            return
        
        def text_wrapper(result: Dict[str, Any]):
            """Text结果包装器，添加时间戳和序列号"""
            with self._sequence_lock:
                self._sequence_counter += 1
                sequence_id = self._sequence_counter
            
            # 确保数据包包含必要字段
            if 'timestamp' not in result:
                result['timestamp'] = time.time()
            if 'sequence_id' not in result:
                result['sequence_id'] = sequence_id
            
            # 创建事件
            event = Event(
                event_type='text_result',
                timestamp=result['timestamp'],
                sequence_id=result['sequence_id'],
                data=result,
                source='text'
            )
            
            # 添加到事件队列
            self.event_queue.put(event)
            
            # 调用用户回调
            if callback:
                try:
                    callback(result)
                except Exception as e:
                    self.logger.error(f"Text回调执行失败: {e}")
        
        # 在单独线程中运行Text流式处理
        def text_thread():
            try:
                self.health_checker.update_module_status("text", ModuleStatus.RUNNING)
                self.logger.info("Text流式输入已启动，等待用户输入...")
                
                # 使用流式输入模式
                self.text_controller.stream_input(callback=text_wrapper)
                
            except Exception as e:
                self.logger.error(f"Text流式处理失败: {e}")
                self.health_checker.update_module_status("text", ModuleStatus.ERROR, str(e))
        
        threading.Thread(target=text_thread, daemon=True).start()
        self.logger.info("Text流式处理已启动")
    
    def _event_loop(self):
        """事件处理循环"""
        while self._running:
            try:
                # 从队列获取事件
                event = self.event_queue.get(timeout=0.1)
                if event is None:
                    continue
                
                # 处理事件（执行时间必须 < 50ms）
                start_time = time.time()
                self._process_event(event)
                elapsed = time.time() - start_time
                
                if elapsed > 0.05:
                    self.logger.warning(f"事件处理时间过长: {elapsed:.3f}s, 事件类型: {event.event_type}")
                
            except Exception as e:
                self.logger.error(f"事件处理循环错误: {e}")
    
    def _process_event(self, event: Event):
        """
        处理事件
        
        Args:
            event: 事件对象
        """
        try:
            # 调用注册的回调函数
            with self._lock:
                callbacks = self._callbacks.get(event.event_type, [])
            
            for callback in callbacks:
                try:
                    callback(event)
                except Exception as e:
                    self.logger.error(f"事件回调执行失败: {e}")
        
        except Exception as e:
            self.logger.error(f"处理事件失败: {e}")
    
    def _check_cv_health(self) -> bool:
        """检查CV模块健康状态"""
        if not self.cv_controller:
            return False
        return self.cv_controller.is_running if hasattr(self.cv_controller, 'is_running') else True
    
    def _check_stt_health(self) -> bool:
        """检查STT模块健康状态"""
        return self.stt_controller is not None
    
    def _check_text_health(self) -> bool:
        """检查Text模块健康状态"""
        return self.text_controller is not None
    
    def get_status(self) -> ModuleStatus:
        """获取当前状态"""
        with self._lock:
            return self._status
    
    def is_running(self) -> bool:
        """检查是否在运行"""
        with self._lock:
            return self._running


# 测试代码已移除，请使用专门的测试文件

