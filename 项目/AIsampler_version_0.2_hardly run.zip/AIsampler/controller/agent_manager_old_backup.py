#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Agent管理器
集成LangChain Agent框架，实现智能决策和任务编排
"""

import logging
import json
from typing import Dict, Any, Optional, List
from dataclasses import dataclass
import os
import sys
from pathlib import Path
import threading
from functools import partial

try:
    import numpy as np
except ImportError:
    np = None

PROJECT_ROOT = Path(__file__).resolve()
for parent in PROJECT_ROOT.parents:
    if parent.name == "AIsampler":
        PROJECT_ROOT = parent
        break
else:
    PROJECT_ROOT = PROJECT_ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# 添加项目路径
from utils.path_utils import setup_project_path, get_config_loader
setup_project_path(__file__)
config_loader = get_config_loader()

# LangChain导入（必需）
try:
    from langchain.agents import AgentExecutor, create_structured_chat_agent
    from langchain.tools import Tool
    from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
    # LangChain 0.3.x: ChatOpenAI 从 langchain_openai 导入
    try:
        from langchain_openai import ChatOpenAI
    except ImportError:
        # 兼容旧版本
        try:
            from langchain.chat_models import ChatOpenAI
        except ImportError:
            raise ImportError("无法导入ChatOpenAI，请安装: pip install langchain-openai")
    # 尝试导入消息类型（用于agent_scratchpad）
    try:
        from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
    except ImportError:
        # 如果导入失败，使用None，后续会处理
        HumanMessage = AIMessage = SystemMessage = None
except ImportError as e:
    raise ImportError(f"LangChain未安装，这是必需的依赖。请运行: pip install langchain langchain-openai openai\n错误: {e}")


@dataclass
class AgentTask:
    """Agent任务数据类"""
    task_id: str
    task_type: str
    description: str
    input_data: Dict[str, Any]
    status: str = "pending"
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class MCPToolWrapper:
    """
    MCP工具封装器
    将MCP服务器工具封装为LangChain工具
    """
    
    def __init__(self, mcp_client=None):
        """
        初始化MCP工具封装器
        
        Args:
            mcp_client: MCP客户端，如果为None则直接调用控制器
        """
        self.mcp_client = mcp_client
        self.logger = logging.getLogger(__name__)
        
        # 直接导入控制器（如果MCP客户端不可用）
        if mcp_client is None:
            try:
                from adapter.blender.blender_controller import BlenderController
                from adapter.comfyui.comfyui_controller import ComfyUIController
                
                blender_config = config_loader.get_blender_config()
                comfyui_config = config_loader.get_comfyui_config()
                
                self.blender_controller = BlenderController(config=blender_config)
                self.comfyui_controller = ComfyUIController(config=comfyui_config)
            except Exception as e:
                self.logger.error(f"初始化控制器失败: {e}")
                self.blender_controller = None
                self.comfyui_controller = None
    
    def get_tools(self) -> List[Any]:
        """
        获取所有MCP工具（封装为LangChain工具）
        
        Returns:
            List[Tool]: LangChain工具列表
        """
        tools = []
        
        # Blender工具
        blender_tools = self._create_blender_tools()
        tools.extend(blender_tools)
        
        # ComfyUI工具
        comfyui_tools = self._create_comfyui_tools()
        tools.extend(comfyui_tools)
        
        return tools
    
    def _create_blender_tools(self) -> List[Any]:
        """创建Blender工具"""
        tools = []
        
        def blender_load_openpose_file(file_path: Optional[str] = None) -> str:
            """加载OpenPose骨骼文件到Blender"""
            try:
                if self.blender_controller:
                    success = self.blender_controller.load_openpose_file(file_path)
                    return "成功加载骨骼文件" if success else "加载骨骼文件失败"
                return "Blender控制器未初始化"
            except Exception as e:
                return f"加载骨骼文件失败: {e}"
        
        def blender_update_bone_pose(bone_name: str, position: Optional[List[float]] = None, 
                                    rotation: Optional[List[float]] = None) -> str:
            """更新Blender中指定骨骼的姿势"""
            try:
                if self.blender_controller:
                    success = self.blender_controller.update_bone_pose(bone_name, position, rotation)
                    return "成功更新骨骼姿势" if success else "更新骨骼姿势失败"
                return "Blender控制器未初始化"
            except Exception as e:
                return f"更新骨骼姿势失败: {e}"
        
        def blender_get_bone_position() -> str:
            """获取Blender中所有骨骼的位置"""
            try:
                if self.blender_controller:
                    positions = self.blender_controller.get_bone_position()
                    return json.dumps(positions, ensure_ascii=False)
                return "Blender控制器未初始化"
            except Exception as e:
                return f"获取骨骼位置失败: {e}"
        
        def blender_create_pose_shot() -> str:
            """创建Blender中的姿势快照"""
            try:
                if self.blender_controller:
                    snapshot = self.blender_controller.create_pose_shot()
                    return json.dumps(snapshot, ensure_ascii=False)
                return "Blender控制器未初始化"
            except Exception as e:
                return f"创建姿势快照失败: {e}"
        
        # 创建LangChain工具
        tools.append(Tool(
            name="blender_load_openpose_file",
            func=blender_load_openpose_file,
            description="加载OpenPose骨骼文件到Blender。参数：file_path（可选，文件路径）"
        ))
        
        tools.append(Tool(
            name="blender_update_bone_pose",
            func=blender_update_bone_pose,
            description="更新Blender中指定骨骼的姿势。参数：bone_name（骨骼名称），position（位置，可选），rotation（旋转，可选）"
        ))
        
        tools.append(Tool(
            name="blender_get_bone_position",
            func=blender_get_bone_position,
            description="获取Blender中所有骨骼的位置信息"
        ))
        
        tools.append(Tool(
            name="blender_create_pose_shot",
            func=blender_create_pose_shot,
            description="创建Blender中的姿势快照，包含骨骼、相机、光照信息"
        ))
        
        return tools
    
    def _create_comfyui_tools(self) -> List[Any]:
        """创建ComfyUI工具"""
        tools = []
        
        def comfyui_load_workflow(workflow_path: Optional[str] = None) -> str:
            """加载ComfyUI工作流"""
            try:
                if self.comfyui_controller:
                    success = self.comfyui_controller.load_workflow(workflow_path)
                    return "成功加载工作流" if success else "加载工作流失败"
                return "ComfyUI控制器未初始化"
            except Exception as e:
                return f"加载工作流失败: {e}"
        
        def comfyui_set_prompt(prompt: str) -> str:
            """设置ComfyUI中的提示词"""
            try:
                if self.comfyui_controller:
                    success = self.comfyui_controller.set_prompt(prompt)
                    return "成功设置提示词" if success else "设置提示词失败"
                return "ComfyUI控制器未初始化"
            except Exception as e:
                return f"设置提示词失败: {e}"
        
        def comfyui_set_negative_prompt(negative_prompt: str) -> str:
            """设置ComfyUI中的负面提示词"""
            try:
                if self.comfyui_controller:
                    success = self.comfyui_controller.set_negative_prompt(negative_prompt)
                    return "成功设置负面提示词" if success else "设置负面提示词失败"
                return "ComfyUI控制器未初始化"
            except Exception as e:
                return f"设置负面提示词失败: {e}"
        
        def comfyui_execute_workflow() -> str:
            """执行ComfyUI中的工作流"""
            try:
                if self.comfyui_controller:
                    task_id = self.comfyui_controller.execute_workflow()
                    return f"工作流已提交执行，任务ID: {task_id}" if task_id else "执行工作流失败"
                return "ComfyUI控制器未初始化"
            except Exception as e:
                return f"执行工作流失败: {e}"
        
        def comfyui_get_task_status(task_id: str) -> str:
            """获取ComfyUI中的任务状态"""
            try:
                if self.comfyui_controller:
                    status = self.comfyui_controller.get_task_status(task_id)
                    return json.dumps(status, ensure_ascii=False)
                return "ComfyUI控制器未初始化"
            except Exception as e:
                return f"获取任务状态失败: {e}"
        
        def comfyui_get_output_video(task_id: str) -> str:
            """获取ComfyUI中的输出视频"""
            try:
                if self.comfyui_controller:
                    video_path = self.comfyui_controller.get_output_video(task_id)
                    return video_path if video_path else "未找到视频输出"
                return "ComfyUI控制器未初始化"
            except Exception as e:
                return f"获取视频失败: {e}"
        
        # 创建LangChain工具
        tools.append(Tool(
            name="comfyui_load_workflow",
            func=comfyui_load_workflow,
            description="加载ComfyUI工作流。参数：workflow_path（可选，工作流文件路径）"
        ))
        
        tools.append(Tool(
            name="comfyui_set_prompt",
            func=comfyui_set_prompt,
            description="设置ComfyUI中的提示词。参数：prompt（提示词文本）"
        ))
        
        tools.append(Tool(
            name="comfyui_set_negative_prompt",
            func=comfyui_set_negative_prompt,
            description="设置ComfyUI中的负面提示词。参数：negative_prompt（负面提示词文本）"
        ))
        
        tools.append(Tool(
            name="comfyui_execute_workflow",
            func=comfyui_execute_workflow,
            description="执行ComfyUI中的工作流，返回任务ID"
        ))
        
        tools.append(Tool(
            name="comfyui_get_task_status",
            func=comfyui_get_task_status,
            description="获取ComfyUI中的任务状态。参数：task_id（任务ID）"
        ))
        
        tools.append(Tool(
            name="comfyui_get_output_video",
            func=comfyui_get_output_video,
            description="获取ComfyUI中的输出视频路径。参数：task_id（任务ID）"
        ))
        
        return tools


class AgentManager:
    """
    Agent管理器
    管理多个Agent（CV Agent、STT Agent、Fusion Agent、Generation Agent）
    实现任务编排和Agent间通信
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, 
                 llm_model: Optional[str] = None):
        """
        初始化Agent管理器
        
        Args:
            config: 配置字典
            llm_model: LLM模型名称（如果使用LangChain）
        """
        # 加载配置
        if config is None:
            config = {}
        
        self.config = config
        
        # 初始化日志（避免重复配置）
        self.logger = logging.getLogger(__name__)
        
        # 任务递归控制
        self._execution_context = threading.local()
        self.max_orchestration_depth = config.get('max_task_depth', 3)
        
        # 初始化MCP工具封装器
        self.tool_wrapper = MCPToolWrapper()
        
        # 初始化LLM（必需）
        llm_model = llm_model or config.get('llm_model', 'deepseek-chat')
        
        # 读取API密钥
        key_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                               'config', 'deepseek_key')
        api_key = None
        
        if os.path.exists(key_file):
            with open(key_file, 'rb') as f:
                content = f.read()
            # 尝试多种编码解码
            for encoding in ['utf-8', 'utf-8-sig', 'gbk']:
                try:
                    api_key = content.decode(encoding).strip()
                    if api_key.startswith('\ufeff'):
                        api_key = api_key[1:].strip()
                    if api_key:
                        break
                except (UnicodeDecodeError, UnicodeError):
                    continue
        
        # 从环境变量或配置获取
        if not api_key:
            api_key = config.get('api_key') or os.getenv('DEEPSEEK_API_KEY')
        
        if not api_key or len(api_key) < 10:
            raise RuntimeError("未找到有效的API密钥，请确保config/deepseek_key文件存在或配置api_key")
        
        # 初始化ChatOpenAI（支持DeepSeek）
        api_base = config.get('api_base', 'https://api.deepseek.com/v1')
        try:
            self.llm = ChatOpenAI(model=llm_model, temperature=0, api_key=api_key, base_url=api_base)
        except (TypeError, ValueError):
            # 兼容旧版本参数
            self.llm = ChatOpenAI(model_name=llm_model, temperature=0, 
                                openai_api_key=api_key, openai_api_base=api_base)
        
        self.use_llm = True
        try:
            self.logger.info(f"尝试初始化LLM模型: {llm_model}")
            self.llm = ChatOpenAI(model=llm_model, temperature=0, api_key=api_key, base_url=api_base)
        except (TypeError, ValueError):
            self.llm = ChatOpenAI(model_name=llm_model, temperature=0, 
                                openai_api_key=api_key, openai_api_base=api_base)
        except Exception as e:
            self.logger.error(f"LLM初始化失败，将使用内置规则运行。错误: {e}")
            self.use_llm = False
            self.llm = None
        
        if self.use_llm:
            self.logger.info(f"LLM初始化成功，模型: {llm_model}")
        else:
            self.logger.warning("LLM未启用，AgentManager将使用Fallback逻辑。")
        
        # Agent实例
        self.cv_agent = None
        self.stt_agent = None
        self.fusion_agent = None
        self.generation_agent = None
        
        # Agent配置
        self.verbose = config.get('verbose', False)  # 统一verbose配置
        
        # 任务队列
        self.task_queue: List[AgentTask] = []
        self.completed_tasks: List[AgentTask] = []
        
        self.logger.info("Agent管理器初始化完成")

    # ------------------------------------------------------------------
    # 辅助方法
    # ------------------------------------------------------------------
    def _format_tools_description(self, tools: List[Any]) -> str:
        if not tools:
            return "当前任务没有可用的工具。"
        lines = ["可用工具："]
        for tool in tools:
            lines.append(f"- {tool.name}: {tool.description}")
        return "\n".join(lines)
    
    def _format_tool_names(self, tools: List[Any]) -> str:
        if not tools:
            return "无"
        return ", ".join(tool.name for tool in tools)
    
    def _normalize_data(self, data: Any) -> Any:
        if np is not None and isinstance(data, np.generic):
            return data.item()
        if np is not None and isinstance(data, np.ndarray):
            return data.tolist()
        if isinstance(data, dict):
            return {k: self._normalize_data(v) for k, v in data.items()}
        if isinstance(data, list):
            return [self._normalize_data(v) for v in data]
        if isinstance(data, tuple):
            return [self._normalize_data(v) for v in data]
        return data
    
    def _safe_json_dumps(self, data: Any) -> str:
        normalized = self._normalize_data(data)
        try:
            return json.dumps(normalized, ensure_ascii=False)
        except TypeError:
            return json.dumps(str(normalized), ensure_ascii=False)
    
    def _invoke_agent(self, agent_executor: Optional[Any], prompt_text: str) -> Dict[str, Any]:
        """
        调用Agent执行器
        
        注意：LangChain 0.3.x 版本存在 agent_scratchpad 类型错误的已知问题。
        如果检测到该错误，将返回特定错误码，由上层调用者使用Fallback逻辑处理。
        """
        if agent_executor is None:
            return {"error": "agent_not_initialized"}
        
        # 检测 agent_scratchpad 错误的特征字符串
        agent_scratchpad_error_patterns = [
            "agent_scratchpad should be a list",
            "agent_scratchpad",
            "base messages"
        ]
        
        try:
            # 方法1: 标准调用（不传递agent_scratchpad）
            result = agent_executor.invoke({"input": prompt_text})
            return result
        except Exception as e:
            error_str = str(e)
            
            # 检查是否是 agent_scratchpad 类型错误（LangChain 0.3.x 已知问题）
            is_scratchpad_error = any(pattern in error_str for pattern in agent_scratchpad_error_patterns)
            
            if is_scratchpad_error:
                # 这是 LangChain 0.3.x 的已知兼容性问题
                # 返回特定错误码，让上层使用 Fallback 逻辑
                self.logger.debug(
                    "检测到 LangChain agent_scratchpad 类型错误（已知兼容性问题），"
                    "将使用 Fallback 逻辑。错误: %s", error_str
                )
                return {
                    "error": "langchain_scratchpad_compatibility_error",
                    "message": "LangChain 0.3.x agent_scratchpad 类型错误，已自动切换到 Fallback 逻辑",
                    "original_error": error_str
                }
            else:
                # 其他类型的错误
                self.logger.error("Agent执行失败: %s", e)
                return {"error": str(e)}
    
    def create_cv_agent(self) -> Any:
        """
        创建CV处理Agent
        
        Returns:
            Agent: CV处理Agent
        """
        if not self.use_llm:
            return None
        # 创建CV Agent提示词
        system_prompt = """你是一个CV（计算机视觉）处理专家。
你的任务是：
1. 分析视觉输入数据（情绪、表情、人脸位置等）
2. 判断情绪类型和置信度
3. 提供情绪分析结果

你可以使用的工具：
{tools}

工具名称列表：{tool_names}

如果没有需要调用的工具，请直接给出结论。

请根据输入的CV数据，分析情绪并返回结果。"""
        
        # CV Agent主要处理输入数据，不需要外部工具
        tools = []
        
        # 创建Agent
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]).partial(
            tools=self._format_tools_description(tools),
            tool_names=self._format_tool_names(tools)
        )
        
        agent = create_structured_chat_agent(self.llm, tools, prompt)
        agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=self.verbose)
        
        self.cv_agent = agent_executor
        return agent_executor
    
    def create_stt_agent(self) -> Any:
        """
        创建STT处理Agent
        
        Returns:
            Agent: STT处理Agent
        """
        if not self.use_llm:
            return None
        # 创建STT Agent提示词
        system_prompt = """你是一个STT（语音转文本）处理专家。
你的任务是：
1. 分析语音识别结果
2. 提取情绪和意图信息
3. 将文本转换为情绪标签

你可以使用的工具：
{tools}

工具名称列表：{tool_names}

如果没有需要调用的工具，请直接给出结论。

请根据输入的STT数据，分析情绪和意图并返回结果。"""
        
        tools = []
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]).partial(
            tools=self._format_tools_description(tools),
            tool_names=self._format_tool_names(tools)
        )
        
        agent = create_structured_chat_agent(self.llm, tools, prompt)
        agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=self.verbose)
        
        self.stt_agent = agent_executor
        return agent_executor
    
    def create_fusion_agent(self) -> Any:
        """
        创建融合决策Agent
        
        Returns:
            Agent: 融合决策Agent
        """
        if not self.use_llm:
            return None
        # 创建Fusion Agent提示词
        system_prompt = """你是一个多模态融合决策专家。
你的任务是：
1. 融合CV和STT的输入数据
2. 做出智能决策（情绪判断、动作选择等）
3. 决定下一步操作（更新骨骼、生成视频等）

你可以使用的工具：
{tools}

工具名称列表：{tool_names}

请根据融合后的数据，做出智能决策并执行相应操作。"""
        
        # 获取相关工具
        tools = [tool for tool in self.tool_wrapper.get_tools() 
                if tool.name.startswith('blender_')]
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]).partial(
            tools=self._format_tools_description(tools),
            tool_names=self._format_tool_names(tools)
        )
        
        agent = create_structured_chat_agent(self.llm, tools, prompt)
        agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=self.verbose)
        
        self.fusion_agent = agent_executor
        return agent_executor
    
    def create_generation_agent(self) -> Any:
        """
        创建视频生成Agent
        
        Returns:
            Agent: 视频生成Agent
        """
        if not self.use_llm:
            return None
        # 创建Generation Agent提示词
        system_prompt = """你是一个视频生成专家。
你的任务是：
1. 根据情绪和骨骼快照生成合适的提示词
2. 配置ComfyUI工作流参数
3. 执行视频生成任务
4. 监控生成状态

你可以使用的工具：
{tools}

工具名称列表：{tool_names}

请根据输入的情绪和快照信息，生成合适的视频。"""
        
        # 获取ComfyUI工具
        tools = [tool for tool in self.tool_wrapper.get_tools() 
                if tool.name.startswith('comfyui_')]
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]).partial(
            tools=self._format_tools_description(tools),
            tool_names=self._format_tool_names(tools)
        )
        
        agent = create_structured_chat_agent(self.llm, tools, prompt)
        agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=self.verbose)
        
        self.generation_agent = agent_executor
        return agent_executor
    
    def orchestrate(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        任务编排
        
        Args:
            task: 任务字典，包含任务类型和输入数据
            
        Returns:
            Dict[str, Any]: 执行结果
        """
        try:
            task_type = task.get('type', 'unknown')
            input_data = task.get('input', {})
            
            self.logger.info(f"开始执行任务: {task_type}")
            
            current_depth = getattr(self._execution_context, "depth", 0)
            if current_depth >= self.max_orchestration_depth:
                self.logger.error(
                    "任务编排递归深度超过限制 (当前: %s, 限制: %s)，已终止执行。",
                    current_depth,
                    self.max_orchestration_depth,
                )
                return {
                    "error": "orchestration_depth_exceeded",
                    "message": "任务编排递归深度超过限制，执行已终止。"
                }
            
            self._execution_context.depth = current_depth + 1
            
            # 根据任务类型选择Agent
            if task_type == 'cv_analysis':
                result = self._execute_cv_agent(input_data)
            elif task_type == 'stt_analysis':
                result = self._execute_stt_agent(input_data)
            elif task_type == 'fusion_decision':
                result = self._execute_fusion_agent(input_data)
            elif task_type == 'video_generation':
                result = self._execute_generation_agent(input_data)
            elif task_type == 'full_pipeline':
                result = self._execute_full_pipeline(input_data)
            else:
                result = {'error': f'未知任务类型: {task_type}'}
            
            # 检查result是否为None或包含错误
            if result is None:
                self.logger.warning("任务 %s 返回None，切换到Fallback逻辑", task_type)
                result = {}
            
            # 检查是否是 LangChain 兼容性错误（agent_scratchpad）
            is_langchain_compat_error = (
                isinstance(result, dict) and 
                result.get('error') == 'langchain_scratchpad_compatibility_error'
            )
            
            # 检查其他类型的错误
            has_other_error = (
                isinstance(result, dict) and 
                result.get('error') and 
                not is_langchain_compat_error and
                self.use_llm
            )
            
            # 如果是 LangChain 兼容性错误，静默切换到 Fallback（不记录为警告）
            if is_langchain_compat_error:
                self.logger.debug(
                    "检测到 LangChain 兼容性问题（agent_scratchpad），"
                    "自动使用 Fallback 逻辑处理任务: %s", task_type
                )
            elif has_other_error:
                self.logger.warning(
                    "任务 %s 使用LLM失败，切换到Fallback逻辑。错误: %s", 
                    task_type, result.get('message', result.get('error'))
                )
            
            # 如果result有错误或为None，使用Fallback逻辑
            if (result is None or 
                (isinstance(result, dict) and result.get('error'))):
                if task_type == 'cv_analysis':
                    result = self._fallback_cv_analysis(input_data)
                elif task_type == 'stt_analysis':
                    result = self._fallback_stt_analysis(input_data)
                elif task_type == 'fusion_decision':
                    result = self._fallback_fusion_decision(input_data)
                elif task_type == 'video_generation':
                    result = self._fallback_generation(input_data)
            
            # 确保返回的是字典
            if result is None:
                result = {'error': 'unknown_error', 'message': '任务执行返回None'}
            elif not isinstance(result, dict):
                result = {'error': 'invalid_result_type', 'message': f'任务执行返回了非字典类型: {type(result)}'}
            
            return result
        
        except Exception as e:
            self.logger.error(f"任务编排失败: {e}")
            return {'error': str(e)}
        finally:
            current_depth = getattr(self._execution_context, "depth", 1)
            new_depth = max(current_depth - 1, 0)
            if new_depth == 0 and hasattr(self._execution_context, "depth"):
                del self._execution_context.depth
            else:
                self._execution_context.depth = new_depth
    
    def _execute_cv_agent(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行CV Agent"""
        if self.use_llm:
            if self.cv_agent is None:
                self.cv_agent = self.create_cv_agent()
            
            return self._invoke_agent(
                self.cv_agent,
                f"分析以下CV数据: {self._safe_json_dumps(input_data)}"
            )
        
        return self._fallback_cv_analysis(input_data)
    
    def _execute_stt_agent(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行STT Agent"""
        if self.use_llm:
            if self.stt_agent is None:
                self.stt_agent = self.create_stt_agent()
            
            return self._invoke_agent(
                self.stt_agent,
                f"分析以下STT数据: {self._safe_json_dumps(input_data)}"
            )
        
        return self._fallback_stt_analysis(input_data)
    
    def _execute_fusion_agent(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行Fusion Agent - 使用直接LLM调用"""
        if not self.use_llm or self.llm is None:
            return self._fallback_fusion_decision(input_data)
        
        try:
            # 获取输入数据
            emotion = input_data.get('emotion', 'neutral')
            confidence = input_data.get('confidence', 0.5)
            cv_data = input_data.get('cv', {})
            stt_data = input_data.get('stt', {})
            
            # 构建详细的提示词
            prompt = f"""你是一个多模态情感融合专家。请分析以下输入并做出决策：

【输入情感】
- 情感类型: {emotion}
- 置信度: {confidence:.2f}

【CV数据】
{self._safe_json_dumps(cv_data)}

【STT数据】
{self._safe_json_dumps(stt_data)}

【任务要求】
1. 综合分析CV和STT数据
2. 判断最终情感类型（happy/sad/angry/neutral/surprise/fear/disgust）
3. 评估置信度（0.0-1.0）
4. 决定是否需要更新骨骼动作（update_bones）
5. 说明你的推理过程

【输出格式】
请以JSON格式返回：
{{
    "action": "update_bones",
    "emotion": "情感类型",
    "confidence": 置信度数值,
    "should_generate": false,
    "reasoning": "详细的推理过程"
}}

请开始分析："""
            
            # 记录调用
            self.logger.info("🤖 [DeepSeek调用] 正在请求大模型分析...")
            self.logger.debug(f"提示词: {prompt[:200]}...")
            
            # 直接调用LLM
            from langchain_core.messages import HumanMessage
            messages = [HumanMessage(content=prompt)]
            
            response = self.llm.invoke(messages)
            
            # 获取响应内容
            response_text = response.content if hasattr(response, 'content') else str(response)
            
            self.logger.info("💭 [DeepSeek响应] 收到大模型分析结果")
            self.logger.info(f"原始响应:\n{response_text}")
            
            # 解析JSON响应
            try:
                # 尝试提取JSON部分
                import re
                json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', response_text, re.DOTALL)
                if json_match:
                    result = json.loads(json_match.group())
                    self.logger.info("✅ [DeepSeek解析] 成功解析JSON响应")
                    return result
                else:
                    self.logger.warning("⚠️ [DeepSeek解析] 响应中未找到有效JSON")
                    # 尝试从文本中提取信息
                    return self._parse_text_response(response_text, input_data)
            except json.JSONDecodeError as e:
                self.logger.warning(f"⚠️ [DeepSeek解析] JSON解析失败: {e}")
                return self._parse_text_response(response_text, input_data)
        
        except Exception as e:
            self.logger.error(f"❌ [DeepSeek调用] 失败: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return self._fallback_fusion_decision(input_data)
    
    def _execute_generation_agent(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行Generation Agent"""
        if self.use_llm:
            if self.generation_agent is None:
                self.generation_agent = self.create_generation_agent()
        
            emotion = input_data.get('emotion', 'neutral')
            snapshot = input_data.get('snapshot', {})
        
            return self._invoke_agent(
                self.generation_agent,
                f"根据情绪 {emotion} 和快照生成视频:\n{self._safe_json_dumps(snapshot)}"
            )
        
        return self._fallback_generation(input_data)

    # ------------------------------------------------------------------
    # Fallback 逻辑 - 当LLM不可用或执行失败时使用
    # ------------------------------------------------------------------
    def _fallback_cv_analysis(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        data = input_data.get('cv') if 'cv' in input_data else input_data
        emotion = data.get('emotion', 'neutral')
        confidence = float(data.get('confidence', 0.0))
        return {
            "emotion": emotion,
            "confidence": confidence,
            "analysis": f"基于视觉数据的简单判断，情绪为 {emotion}，置信度 {confidence:.2f}"
        }
    
    def _fallback_stt_analysis(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        data = input_data.get('stt') if 'stt' in input_data else input_data
        text = data.get('text', '')
        emotion = "neutral"
        if any(word in text for word in ["开心", "happy", "高兴"]):
            emotion = "happy"
        elif any(word in text for word in ["伤心", "sad", "难过"]):
            emotion = "sad"
        return {
            "emotion": emotion,
            "confidence": 0.6 if emotion != "neutral" else 0.3,
            "analysis": f"基于语音文本的简单判断，情绪为 {emotion}"
        }
    
    def _parse_text_response(self, text: str, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """从文本响应中解析决策信息"""
        # 提取情感
        emotion = input_data.get('emotion', 'neutral')
        for emo in ['happy', 'sad', 'angry', 'surprise', 'fear', 'disgust', 'neutral']:
            if emo in text.lower():
                emotion = emo
                break
        
        # 提取置信度
        import re
        conf_match = re.search(r'confidence.*?(\d\.\d+|\d+)', text, re.IGNORECASE)
        confidence = float(conf_match.group(1)) if conf_match else input_data.get('confidence', 0.5)
        
        return {
            "action": "update_bones",
            "emotion": emotion,
            "confidence": confidence,
            "should_generate": False,
            "reasoning": text
        }
    
    def _fallback_fusion_decision(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        # 安全地获取数据，处理None值
        cv_result = input_data.get('cv') if input_data else {}
        stt_result = input_data.get('stt') if input_data else {}
        
        # 确保是字典类型
        if not isinstance(cv_result, dict):
            cv_result = {}
        if not isinstance(stt_result, dict):
            stt_result = {}
        
        # 直接使用输入的emotion，不要覆盖
        emotion = input_data.get('emotion', 'neutral')
        confidence = input_data.get('confidence', 0.5)
        
        return {
            "action": "update_bones",
            "emotion": emotion,
            "confidence": confidence,
            "should_generate": False,
            "reasoning": "⚠️ DeepSeek不可用，使用简化逻辑：保持原始情感"
        }
    
    def _fallback_generation(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        emotion = input_data.get('emotion', 'neutral')
        prompt = f"A portrait of a character showing {emotion} emotion, high quality, detailed."
        return {
            "prompt": prompt,
            "negative_prompt": "low quality, blurry",
            "strategy": "使用默认提示词生成"
        }
    
    def _execute_full_pipeline(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行完整流程"""
        results = {}
        
        # 1. CV分析
        if 'cv' in input_data:
            cv_result = self._execute_cv_agent({'cv': input_data['cv']})
            results['cv'] = cv_result
        
        # 2. STT分析
        if 'stt' in input_data:
            stt_result = self._execute_stt_agent({'stt': input_data['stt']})
            results['stt'] = stt_result
        
        # 3. 融合决策
        if 'cv' in results and 'stt' in results:
            fusion_result = self._execute_fusion_agent({
                'cv': results['cv'],
                'stt': results['stt']
            })
            results['fusion'] = fusion_result
        
        # 4. 视频生成（如果需要）
        if 'fusion' in results:
            generation_result = self._execute_generation_agent({
                'emotion': results['fusion'].get('emotion', 'neutral'),
                'snapshot': input_data.get('snapshot', {})
            })
            results['generation'] = generation_result
        
        return results
    
    def initialize_agents(self):
        """初始化所有Agent"""
        try:
            self.logger.info("开始初始化Agent...")
            
            self.cv_agent = self.create_cv_agent()
            self.stt_agent = self.create_stt_agent()
            self.fusion_agent = self.create_fusion_agent()
            self.generation_agent = self.create_generation_agent()
            
            self.logger.info("所有Agent初始化完成")
            return True
        
        except Exception as e:
            self.logger.error(f"初始化Agent失败: {e}")
            return False


# 测试代码已移除，请使用专门的测试文件

