#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
对比原版和增强版骨骼映射
直观展示动作幅度的差异
"""

import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from parts.fusion.emotion_bone_mapper import EmotionToBoneMapper
from adapter.blender.blender_controller import BlenderController


def compare_mappings():
    """对比两个映射版本"""
    print("=" * 80)
    print("🎬 骨骼映射对比测试")
    print("=" * 80)
    
    # 文件路径
    original_file = PROJECT_ROOT / "config" / "full_bone_mapping.yaml"
    enhanced_file = PROJECT_ROOT / "config" / "enhanced_bone_mapping.yaml"
    
    if not enhanced_file.exists():
        print(f"\n✗ 增强版映射文件不存在")
        print("  请先运行: python generate_enhanced_bone_mapping.py")
        return False
    
    # 初始化
    print("\n[1] 初始化...")
    blender = BlenderController()
    
    if not (hasattr(blender, 'socket_client') and blender.socket_client):
        print("  ✗ Blender未连接")
        return False
    print("  ✓ Blender已连接")
    
    # 测试情感列表
    emotions = ['happy', 'angry', 'fear']
    
    for emotion in emotions:
        print("\n" + "=" * 80)
        print(f"🎭 测试情感: {emotion.upper()}")
        print("=" * 80)
        
        # 原版映射
        if original_file.exists():
            print(f"\n[原版映射] 使用原始幅度...")
            mapper_original = EmotionToBoneMapper(mapping_file=str(original_file))
            bone_pose = mapper_original.get_bone_pose_dict(emotion, confidence=0.85)
            
            # 更新骨骼
            success = 0
            for bone_name, pose_data in bone_pose.items():
                result = blender.update_bone_pose(
                    bone_name=bone_name,
                    rotation=pose_data.get('rotation', [0, 0, 0]),
                    position=pose_data.get('position', [0, 0, 0])
                )
                if result:
                    success += 1
            
            print(f"  ✓ 更新了 {success} 个骨骼")
            print("  ⏸️ 观察动作...")
            time.sleep(3)  # 暂停让用户观察
        
        # 增强版映射
        print(f"\n[增强版映射] 使用大幅度动作...")
        mapper_enhanced = EmotionToBoneMapper(mapping_file=str(enhanced_file))
        bone_pose = mapper_enhanced.get_bone_pose_dict(emotion, confidence=0.85)
        
        # 更新骨骼
        success = 0
        for bone_name, pose_data in bone_pose.items():
            result = blender.update_bone_pose(
                bone_name=bone_name,
                rotation=pose_data.get('rotation', [0, 0, 0]),
                position=pose_data.get('position', [0, 0, 0])
            )
            if result:
                success += 1
        
        print(f"  ✓ 更新了 {success} 个骨骼")
        
        # 分析差异
        print(f"\n[差异分析]")
        analyze_differences(mapper_original if original_file.exists() else None, 
                          mapper_enhanced, emotion)
        
        print("  ⏸️ 观察增强动作...")
        time.sleep(3)
    
    # 回到中性位置
    print("\n" + "=" * 80)
    print("🔄 回到中性位置...")
    print("=" * 80)
    
    mapper = EmotionToBoneMapper(mapping_file=str(enhanced_file))
    bone_pose = mapper.get_bone_pose_dict('neutral', confidence=1.0)
    
    for bone_name, pose_data in bone_pose.items():
        blender.update_bone_pose(
            bone_name=bone_name,
            rotation=pose_data.get('rotation', [0, 0, 0]),
            position=pose_data.get('position', [0, 0, 0])
        )
    
    print("✓ 对比测试完成！")
    return True


def analyze_differences(mapper_original, mapper_enhanced, emotion):
    """分析两个映射的差异"""
    if not mapper_original:
        print("  ℹ️ 原版映射文件不存在，跳过对比")
        return
    
    # 获取手臂骨骼的旋转值进行对比
    test_bones = ['arm_stretch.l', 'forearm.l', 'c_arm_fk.l']
    
    original_pose = mapper_original.get_bone_pose_dict(emotion, confidence=0.85)
    enhanced_pose = mapper_enhanced.get_bone_pose_dict(emotion, confidence=0.85)
    
    print("  示例骨骼旋转对比:")
    print(f"  {'骨骼':<20} {'原版(X,Y,Z)':<25} {'增强(X,Y,Z)':<25}")
    print("  " + "-" * 70)
    
    for bone in test_bones:
        if bone in original_pose and bone in enhanced_pose:
            orig_rot = original_pose[bone].get('rotation', [0, 0, 0])
            enh_rot = enhanced_pose[bone].get('rotation', [0, 0, 0])
            
            orig_str = f"({orig_rot[0]:.2f},{orig_rot[1]:.2f},{orig_rot[2]:.2f})"
            enh_str = f"({enh_rot[0]:.2f},{enh_rot[1]:.2f},{enh_rot[2]:.2f})"
            
            print(f"  {bone:<20} {orig_str:<25} {enh_str:<25}")
            
            # 计算增幅
            if orig_rot[0] != 0:
                increase_x = (enh_rot[0] / orig_rot[0] - 1) * 100
                print(f"  {'':20} {'X轴增加: +' + f'{increase_x:.0f}%':<25}")


def main():
    """主函数"""
    success = compare_mappings()
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
