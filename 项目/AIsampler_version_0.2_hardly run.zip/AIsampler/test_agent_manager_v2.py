#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试AgentManager v2.0"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from utils.path_utils import setup_project_path
setup_project_path(__file__)

print("=" * 80)
print("测试AgentManager v2.0")
print("=" * 80)

try:
    print("\n【1. 导入AgentManager v2】")
    from controller.agent_manager_v2 import AgentManager
    print("✓ AgentManager导入成功")
    
    print("\n【2. 创建AgentManager实例】")
    agent_manager = AgentManager(verbose=True)
    print("✓ AgentManager实例创建成功")
    
    print("\n【3. 初始化Agents】")
    success = agent_manager.initialize_agents()
    if success:
        print("✓ Agent系统初始化成功")
    else:
        print("⚠️ Agent系统初始化失败（可能是配置问题）")
    
    print("\n【4. 测试LLM连接】")
    if agent_manager.llm:
        conn_ok = agent_manager.test_connection()
        if conn_ok:
            print("✓ LLM连接正常")
        else:
            print("✗ LLM连接失败")
    else:
        print("⚠️ LLM未初始化")
    
    print("\n【5. 测试融合决策】")
    test_data = {
        'cv': {'emotion': 'happy', 'confidence': 0.8},
        'text': {'emotion': 'happy', 'confidence': 0.9, 'text': '我很开心'}
    }
    
    result = agent_manager.make_fusion_decision(test_data)
    print(f"✓ 融合决策完成")
    print(f"  • 情感: {result.get('emotion')}")
    print(f"  • 置信度: {result.get('confidence'):.2f}")
    print(f"  • AI驱动: {result.get('ai_powered', False)}")
    
    print("\n" + "=" * 80)
    print("✅ AgentManager v2.0 测试完成")
    print("=" * 80)
    
except ImportError as e:
    print(f"\n✗ 导入失败: {e}")
    import traceback
    traceback.print_exc()
    
except Exception as e:
    print(f"\n✗ 测试失败: {e}")
    import traceback
    traceback.print_exc()
