#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检查Blender中实际存在的骨骼名称
找出哪些骨骼名称可用
"""

import json
import socket

def check_bones():
    """检查骨骼名称"""
    print("=" * 80)
    print("🔍 Blender骨骼名称检查工具")
    print("=" * 80)
    
    # 连接到Blender
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.settimeout(5.0)
    
    try:
        client.connect(('localhost', 8888))
        print("\n✓ 已连接到Blender Socket服务器")
        
        # 获取所有骨骼
        get_cmd = json.dumps({'type': 'get_bone_position'})
        client.send(get_cmd.encode('utf-8'))
        
        # 接收响应
        response_data = b""
        while True:
            try:
                chunk = client.recv(16384)
                if not chunk:
                    break
                response_data += chunk
                if len(chunk) < 16384:
                    break
            except socket.timeout:
                break
        
        response = response_data.decode('utf-8')
        result = json.loads(response)
        
        if not result.get('success'):
            print(f"\n✗ 获取骨骼失败: {result.get('error')}")
            return
        
        all_bones = set(result.get('data', {}).keys())
        print(f"\n✓ 骨架中有 {len(all_bones)} 个骨骼")
        
        # 检查emotion_bone_mapper中使用的骨骼名称
        print("\n" + "=" * 80)
        print("📋 检查emotion_bone_mapper中使用的骨骼名称")
        print("=" * 80)
        
        # rig骨架骨骼（应该存在）
        rig_bones = ['c_head.x', 'c_spine_01.x', 'c_shoulder.l', 'c_shoulder.r']
        
        # Armature_Old骨架骨骼（可能不存在）
        old_bones = ['Head', 'Spine', 'Shoulder_L', 'Shoulder_R']
        
        print("\n【rig骨架骨骼】")
        for bone in rig_bones:
            status = "✓ 存在" if bone in all_bones else "✗ 不存在"
            print(f"  {bone:20s} {status}")
        
        print("\n【Armature_Old骨架骨骼】")
        for bone in old_bones:
            status = "✓ 存在" if bone in all_bones else "✗ 不存在"
            print(f"  {bone:20s} {status}")
        
        # 查找相似的骨骼名称
        print("\n" + "=" * 80)
        print("🔎 查找相似的骨骼名称")
        print("=" * 80)
        
        keywords = ['head', 'spine', 'shoulder']
        for keyword in keywords:
            matching = [b for b in all_bones if keyword.lower() in b.lower()]
            if matching:
                print(f"\n包含 '{keyword}' 的骨骼:")
                for bone in sorted(matching)[:10]:
                    print(f"  • {bone}")
                if len(matching) > 10:
                    print(f"  ... 还有 {len(matching) - 10} 个")
        
        # 总结
        print("\n" + "=" * 80)
        print("📊 总结")
        print("=" * 80)
        
        rig_exists = sum(1 for b in rig_bones if b in all_bones)
        old_exists = sum(1 for b in old_bones if b in all_bones)
        
        print(f"\nrig骨架骨骼: {rig_exists}/4 存在")
        print(f"Armature_Old骨架骨骼: {old_exists}/4 存在")
        
        if rig_exists == 4 and old_exists == 0:
            print("\n✅ 建议：使用rig骨架骨骼名称")
            print("   • 移除emotion_bone_mapper中的Armature_Old骨骼名称")
            print("   • 只保留rig骨架骨骼（c_head.x等）")
        elif old_exists == 4 and rig_exists == 0:
            print("\n✅ 建议：使用Armature_Old骨架骨骼名称")
            print("   • 移除emotion_bone_mapper中的rig骨骼名称")
            print("   • 只保留Armature_Old骨骼（Head等）")
        elif rig_exists > 0 and old_exists > 0:
            print("\n⚠️ 两种骨架的骨骼都部分存在")
            print("   • 可能是混合骨架")
        else:
            print("\n❌ 预期的骨骼名称都不存在")
            print("   • 需要查看实际骨架的骨骼命名规则")
        
    except ConnectionRefusedError:
        print("\n✗ 无法连接到Blender Socket服务器")
        print("  请确保Blender中的Socket服务器已启动")
    except Exception as e:
        print(f"\n✗ 错误: {e}")
    finally:
        client.close()


if __name__ == "__main__":
    check_bones()
