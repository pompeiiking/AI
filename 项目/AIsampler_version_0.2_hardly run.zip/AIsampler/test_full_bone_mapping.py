#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试完整的203骨骼映射
验证所有骨骼都能成功更新
"""

import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from parts.fusion.emotion_bone_mapper import EmotionToBoneMapper
from adapter.blender.blender_controller import BlenderController


def test_full_mapping():
    """测试完整骨骼映射"""
    print("=" * 80)
    print("🎬 完整骨骼映射测试（203个骨骼）")
    print("=" * 80)
    
    # 初始化
    print("\n[1] 初始化模块...")
    
    # 使用完整映射文件
    mapping_file = PROJECT_ROOT / "config" / "full_bone_mapping.yaml"
    
    if not mapping_file.exists():
        print(f"  ✗ 映射文件不存在: {mapping_file}")
        print("  ℹ️ 请先运行: python generate_full_bone_mapping.py")
        return False
    
    mapper = EmotionToBoneMapper(mapping_file=str(mapping_file))
    print(f"  ✓ BoneMapper已加载完整映射")
    
    blender = BlenderController()
    if not (hasattr(blender, 'socket_client') and blender.socket_client):
        print("  ✗ Blender未连接")
        return False
    print("  ✓ Blender已连接")
    
    # 测试所有情感
    print("\n[2] 测试所有情感的完整骨骼映射...")
    
    emotions = ['happy', 'sad', 'angry', 'surprise', 'neutral', 'fear', 'disgust']
    
    total_bones = 0
    total_success = 0
    
    for i, emotion in enumerate(emotions, 1):
        print(f"\n[2.{i}] 测试 '{emotion}'...")
        
        # 获取骨骼姿势
        bone_pose = mapper.get_bone_pose_dict(emotion, confidence=0.85)
        
        print(f"  • 骨骼数量: {len(bone_pose)}")
        
        # 更新到Blender
        success = 0
        failed = []
        
        for bone_name, pose_data in bone_pose.items():
            result = blender.update_bone_pose(
                bone_name=bone_name,
                rotation=pose_data.get('rotation', [0, 0, 0]),
                position=pose_data.get('position', [0, 0, 0])
            )
            
            if result:
                success += 1
            else:
                failed.append(bone_name)
        
        success_rate = (success / len(bone_pose) * 100) if len(bone_pose) > 0 else 0
        print(f"  • 成功更新: {success}/{len(bone_pose)} ({success_rate:.1f}%)")
        
        if failed:
            print(f"  • 失败数量: {len(failed)}")
            if len(failed) <= 5:
                print(f"  • 失败骨骼: {failed}")
            else:
                print(f"  • 失败骨骼（前5个）: {failed[:5]}")
        
        total_bones += len(bone_pose)
        total_success += success
        
        # 短暂暂停让动画可见
        time.sleep(0.3)
    
    # 总结
    print("\n" + "=" * 80)
    print("📊 测试总结")
    print("=" * 80)
    
    overall_rate = (total_success / total_bones * 100) if total_bones > 0 else 0
    
    print(f"\n总体统计:")
    print(f"  • 测试情感: {len(emotions)} 种")
    print(f"  • 总骨骼数: {total_bones}")
    print(f"  • 成功更新: {total_success}")
    print(f"  • 成功率: {overall_rate:.1f}%")
    
    if overall_rate >= 95:
        print("\n✅ 完整骨骼映射测试通过！")
        return True
    elif overall_rate >= 80:
        print(f"\n⚠️ 大部分骨骼成功更新 ({overall_rate:.1f}%)")
        return True
    else:
        print(f"\n❌ 骨骼更新成功率较低 ({overall_rate:.1f}%)")
        return False


if __name__ == "__main__":
    success = test_full_mapping()
    sys.exit(0 if success else 1)
