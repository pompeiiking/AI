#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
快速启动检查
验证所有修改是否正确集成到启动流程中
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def check_startup_integration():
    """检查启动集成"""
    print("=" * 80)
    print("🔍 快速启动检查")
    print("=" * 80)
    
    all_passed = True
    
    # 1. 检查启动脚本
    print("\n[1] 检查启动脚本...")
    start_script = PROJECT_ROOT / "runner" / "start.py"
    if start_script.exists():
        print(f"  ✓ 主启动脚本存在: {start_script.name}")
    else:
        print(f"  ✗ 主启动脚本不存在")
        all_passed = False
    
    # 2. 检查StartupManager
    print("\n[2] 检查StartupManager...")
    try:
        from runner.startup.manager import StartupManager
        print("  ✓ StartupManager可导入")
        
        # 检查是否使用EndToEndPipeline
        import inspect
        source = inspect.getsource(StartupManager._stage_init)
        if 'EndToEndPipeline' in source:
            print("  ✓ StartupManager使用EndToEndPipeline")
        else:
            print("  ✗ StartupManager未使用EndToEndPipeline")
            all_passed = False
    except Exception as e:
        print(f"  ✗ StartupManager导入失败: {e}")
        all_passed = False
    
    # 3. 检查Pipeline配置
    print("\n[3] 检查Pipeline配置...")
    try:
        # 读取pipeline.py源码检查
        pipeline_file = PROJECT_ROOT / "controller" / "pipeline.py"
        with open(pipeline_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
        if 'enhanced_bone_mapping.yaml' in content:
            print("  ✓ Pipeline已配置使用增强版映射")
        else:
            print("  ✗ Pipeline未配置增强版映射")
            all_passed = False
    except Exception as e:
        print(f"  ✗ Pipeline检查失败: {e}")
        all_passed = False
    
    # 4. 检查映射文件
    print("\n[4] 检查映射文件...")
    enhanced_mapping = PROJECT_ROOT / "config" / "enhanced_bone_mapping.yaml"
    if enhanced_mapping.exists():
        print(f"  ✓ 增强版映射存在: {enhanced_mapping.name}")
        
        # 检查文件大小（应该很大，因为有203个骨骼）
        size = enhanced_mapping.stat().st_size
        if size > 10000:  # 至少10KB
            print(f"  ✓ 映射文件大小正常: {size/1024:.1f}KB")
        else:
            print(f"  ⚠️ 映射文件可能不完整: {size}字节")
    else:
        print("  ✗ 增强版映射不存在")
        print("    运行: python generate_enhanced_bone_mapping.py")
        all_passed = False
    
    # 5. 检查ComfyUI修复
    print("\n[5] 检查ComfyUI节点发现器修复...")
    try:
        comfyui_file = PROJECT_ROOT / "adapter" / "comfyui" / "comfyui_controller.py"
        with open(comfyui_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 检查特殊映射处理
        if "elif category == 'text_encoder':" in content:
            print("  ✓ ComfyUI节点发现器已修复")
        else:
            print("  ✗ ComfyUI节点发现器未修复")
            all_passed = False
    except Exception as e:
        print(f"  ✗ ComfyUI检查失败: {e}")
        all_passed = False
    
    # 6. 模拟Pipeline初始化（不实际启动）
    print("\n[6] 测试Pipeline初始化...")
    try:
        print("  • 导入Pipeline类...")
        from controller.pipeline import EndToEndPipeline
        print("  ✓ Pipeline类导入成功")
        
        # 不实际创建实例（避免长时间初始化）
        print("  ℹ️ 跳过实际初始化（避免长时间等待）")
        
    except Exception as e:
        print(f"  ✗ Pipeline导入失败: {e}")
        all_passed = False
    
    # 总结
    print("\n" + "=" * 80)
    print("📊 检查结果")
    print("=" * 80)
    
    if all_passed:
        print("\n✅ 所有检查通过！")
        print("\n可以启动完整项目：")
        print("  python runner/start.py")
        print("\n或带进度显示：")
        print("  python runner/start.py --show-progress")
        return True
    else:
        print("\n❌ 部分检查未通过")
        print("\n请检查上述问题后再启动")
        return False


def main():
    """主函数"""
    success = check_startup_integration()
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
