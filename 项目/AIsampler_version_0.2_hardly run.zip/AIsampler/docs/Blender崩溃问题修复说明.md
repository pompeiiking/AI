# Blender崩溃问题修复说明

## ⚠️ 问题描述

在自动加载骨骼文件时，Blender可能崩溃，显示"Blender has stopped working"错误。

## 🔍 原因分析

1. **文件加载方法不当**：使用`bpy.ops.wm.open_mainfile()`会替换整个场景，可能导致崩溃
2. **对象重复链接**：尝试链接已存在的对象会导致错误
3. **缺少错误处理**：某些操作没有适当的异常处理
4. **线程安全问题**：在后台线程中操作Blender可能导致崩溃

## ✅ 修复方案

### 1. 改进文件加载方法

**修复前**：
- 使用`bpy.ops.import_scene.blend()`（不存在的方法）
- 失败后尝试`bpy.ops.wm.open_mainfile()`（会替换场景）

**修复后**：
- 使用`bpy.data.libraries.load()`的append方法（更安全）
- 只导入armature对象，避免导入不必要的内容
- 检查对象是否已存在，避免重复链接
- 不再使用`open_mainfile()`，避免替换场景

### 2. 增强错误处理

- 添加详细的异常捕获
- 记录错误堆栈信息
- 避免在错误时继续执行危险操作

### 3. 改进自动加载策略

- 在后台线程中加载，避免阻塞
- 添加延迟，确保初始化完成
- 不等待加载完成，让它在后台运行

## 🔧 修复的代码

### blender_socket_server.py

```python
# 修复前
bpy.ops.import_scene.blend(filepath=file_path)  # 不存在的方法

# 修复后
with bpy.data.libraries.load(file_path) as (data_from, data_to):
    data_to.objects = data_from.objects  # 只导入对象

for obj in data_to.objects:
    if obj is not None and obj.type == 'ARMATURE':
        if obj.name not in bpy.context.scene.objects:  # 检查是否已存在
            bpy.context.collection.objects.link(obj)
```

### blender_controller.py

```python
# 修复前
bpy.ops.wm.open_mainfile(filepath=file_path)  # 会替换场景

# 修复后
with bpy.data.libraries.load(file_path) as (data_from, data_to):
    # 只导入armature对象
    # 检查是否已存在
    # 安全链接
```

## 📝 使用建议

### 1. 如果Blender崩溃了

1. **重启Blender**
2. **重新安装插件**（确保使用最新代码）
3. **禁用自动加载**（在配置文件中设置`auto_load_on_init: false`）
4. **手动加载文件**（在Blender中手动导入）

### 2. 安全的使用方式

**方式1：禁用自动加载，手动加载**

```yaml
# config/blender_config.yaml
paths:
  auto_load_on_init: false  # 禁用自动加载
```

然后在需要时手动调用：
```python
controller.load_openpose_file()
```

**方式2：在Blender插件面板中禁用自动加载**

1. 在N面板中
2. 取消勾选"启动时自动加载骨骼"
3. 手动点击加载按钮

### 3. 检查文件格式

确保`.blend`文件：
- 格式正确
- 包含armature对象
- 文件未损坏

## 🐛 故障排除

### 问题1：Blender仍然崩溃

**解决**：
1. 检查崩溃日志：`C:\Users\POMPEII\AppData\Roaming\Blender Foundation\Blender\[版本]\crash.txt`
2. 禁用自动加载
3. 手动在Blender中导入文件，检查文件是否有问题

### 问题2：文件加载失败但没有崩溃

**解决**：
1. 检查文件路径是否正确
2. 检查文件是否存在
3. 检查文件中是否有armature对象
4. 查看Blender控制台的错误信息

### 问题3：对象重复

**解决**：
- 代码已自动检查对象是否已存在
- 如果已存在，会跳过导入
- 可以手动删除旧对象后重新导入

## ✅ 验证修复

运行测试脚本：

```bash
python adapter/blender/test_blender.py
```

如果测试通过，说明修复成功。

## 📚 相关文档

- [Blender连接说明.md](./Blender连接说明.md)
- [Blender自动加载说明.md](./Blender自动加载说明.md)

