# 云端ComfyUI API对接说明

## 📋 概述

系统支持两种云端ComfyUI对接方式：

1. **SSH隧道模式**（默认）：通过SSH隧道连接到云端ComfyUI服务器
2. **API模式**（推荐）：通过ComfyOne API直接对接云端服务

本文档说明如何使用API模式对接云端ComfyUI。

## 🔧 配置方式

### 1. 启用API模式

在 `config/comfyui_config.yaml` 中设置：

```yaml
server:
  cloud_api:
    use_cloud_api: true  # 启用API模式
    base_url: "https://pandora-server-cf.onethingai.com"
    api_key_path: "config/comfyui_cloud/api_key"  # API密钥文件路径
    instance_id_path: "config/comfyui_cloud/instance_id"  # 实例ID文件路径
```

### 2. 配置API密钥和实例ID

创建以下文件：

**`config/comfyui_cloud/api_key`**：
```
your-api-key-here
```

**`config/comfyui_cloud/instance_id`**：
```
your-instance-id-here
```

## 🚀 工作流程

### 初始化阶段（只执行一次）

1. **注册后端实例**
   - 系统启动时自动注册后端实例到ComfyOne服务

2. **创建工作流**
   - 调用 `load_workflow()` 时自动上传工作流JSON到云端
   - 获得工作流ID并保存
   - 后续不再重新上传工作流

### 运行阶段（多次调用）

1. **修改参数**
   - 使用 `set_prompt()`, `set_negative_prompt()`, `set_model_parameters()` 等方法修改参数
   - 参数保存在本地工作流数据中

2. **执行工作流**
   - 调用 `execute_workflow()` 时：
     - 从工作流数据中提取输入参数
     - 转换为API格式
     - 发送prompt请求到云端
     - 返回任务ID

## 📝 使用示例

### 基本使用

```python
from adapter.comfyui.comfyui_controller import ComfyUIController
from config.config_loader import get_config_loader

# 加载配置
config_loader = get_config_loader()
config = config_loader.get_comfyui_config()

# 初始化控制器（自动启用API模式）
controller = ComfyUIController(config=config)

# 加载工作流（初始化时上传到云端，只执行一次）
controller.load_workflow()

# 修改参数（后续多次调用）
controller.set_prompt("beautiful scenery")
controller.set_negative_prompt("text, watermark")
controller.set_model_parameters({
    'sampler': {
        'steps': 20,
        'cfg_scale': 7.0
    }
})

# 执行工作流（发送参数到云端）
task_id = controller.execute_workflow()
print(f"任务ID: {task_id}")

# 查询任务状态
status = controller.get_task_status(task_id)
print(f"任务状态: {status}")
```

### 工作流复用

如果工作流已创建，系统会自动检测并复用：

```python
# 第一次调用：创建工作流
controller.load_workflow(workflow_name="代播视频生成")
# 输出：云端工作流已创建，ID: workflow_123

# 后续调用：复用已存在的工作流
controller.load_workflow(workflow_name="代播视频生成")
# 输出：使用已存在的云端工作流，ID: workflow_123
```

## 🔍 工作原理

### 工作流上传（初始化）

```python
# 1. 读取工作流JSON文件
workflow_data = json.load(workflow_file)

# 2. 自动提取输入和输出节点
inputs, outputs = extract_workflow_inputs_outputs(workflow_data)

# 3. 调用API创建工作流
workflow_id = cloud_api.create_workflow(
    name="代播视频生成",
    workflow_file="adapter/comfyui/workflow/代播视频生成.json",
    inputs=inputs,  # 自动提取
    outputs=outputs  # 自动提取
)
```

### 参数修改（运行中）

```python
# 修改工作流数据（本地）
controller.set_prompt("new prompt")
# 内部：workflow_data[node_id]['inputs']['text'] = "new prompt"

# 执行时提取参数
inputs = extract_workflow_inputs_for_api(workflow_data)
# 返回：[{"id": "64", "params": {"text": "new prompt"}}]
```

### 执行工作流（运行中）

```python
# 发送prompt到云端
task_id = cloud_api.prompt_workflow(
    inputs=[{"id": "64", "params": {"text": "new prompt"}}],
    free_cache=False
)
```

## ⚙️ 配置说明

### API模式 vs SSH隧道模式

| 特性 | API模式 | SSH隧道模式 |
|------|---------|-------------|
| 连接方式 | HTTP API | SSH隧道 |
| 工作流上传 | 初始化时一次 | 每次执行都发送 |
| 参数修改 | 本地修改后发送 | 直接修改工作流 |
| 性能 | 更高效 | 需要SSH连接 |
| 适用场景 | 生产环境 | 开发调试 |

### 自动提取输入输出

系统会自动从工作流JSON中识别：

**输入节点**：
- `CLIPTextEncode` - 文本编码器
- `KSampler` - 采样器
- `EmptyLatentImage` - 潜在图像
- `LoadImage` - 图像加载

**输出节点**：
- `SaveImage` - 保存图像
- `SaveVideo` - 保存视频
- `PreviewImage` - 预览图像

## 🛠️ 故障排查

### 问题1：API密钥未配置

**错误**：`API密钥或实例ID未配置`

**解决**：
1. 检查 `config/comfyui_cloud/api_key` 文件是否存在
2. 检查 `config/comfyui_cloud/instance_id` 文件是否存在
3. 确保文件内容不为空

### 问题2：后端注册失败

**错误**：`后端注册失败`

**解决**：
1. 检查API密钥是否正确
2. 检查网络连接
3. 检查实例ID是否有效

### 问题3：工作流创建失败

**错误**：`云端工作流创建失败`

**解决**：
1. 检查工作流JSON文件格式是否正确
2. 检查工作流文件路径是否正确
3. 查看详细错误日志

### 问题4：参数提取失败

**错误**：执行时参数为空

**解决**：
1. 确保已调用 `load_workflow()` 加载工作流
2. 确保已调用参数设置方法（如 `set_prompt()`）
3. 检查工作流数据是否正确

## 📚 相关文档

- [ComfyUI云端连接说明](./ComfyUI云端连接说明.md)
- [ComfyUI适配器配置](../config/comfyui_config.yaml)

## ✅ 最佳实践

1. **初始化一次**：工作流只在系统启动时上传一次
2. **参数本地修改**：使用 `set_*` 方法修改参数，保存在本地
3. **执行时发送**：调用 `execute_workflow()` 时自动提取并发送参数
4. **工作流复用**：系统会自动检测并复用已存在的工作流
5. **错误处理**：检查返回值，处理异常情况

## 🎯 总结

API模式提供了更高效的云端ComfyUI对接方式：

- ✅ **初始化一次**：工作流只上传一次
- ✅ **参数灵活修改**：本地修改参数，执行时发送
- ✅ **自动提取**：自动识别输入输出节点
- ✅ **工作流复用**：自动检测并复用已存在的工作流
- ✅ **接口兼容**：保持原有接口不变，无缝切换

