# 🎯 完全对齐 stream_stt.py 参数

## 📋 对齐目标

将所有测试工具和控制器完全对齐到 `stream_stt.py` 的参数设置，以获得最优性能和速度。

---

## ✅ 已完成的对齐

### 1. **预热参数**

**stream_stt.py 设置:**
```python
warmup_iters = 120  # 120次迭代，约4秒
```

**已更新文件:**
- ✅ `parts/stt/stt_controller.py` - `warmup_iters = 120`
- ✅ `scripts/test_stt_stream.py` - `warmup_iters = 120`
- ✅ `scripts/test_stt_optimized.py` - `warmup_iters = 120`

**变化:** 40次 → 120次 (1.3秒 → 4秒)

---

### 2. **VAD参数**

**stream_stt.py 设置:**
```python
threshold = 0.5        # VAD阈值
max_silence_cnt = 10   # 静音判断帧数
```

**已更新文件:**
- ✅ `config/stt_config.yaml`
  ```yaml
  vad:
    threshold: 0.5
    max_silence_cnt: 10
  ```
- ✅ `parts/stt/stt_controller.py` - 使用配置默认值
- ✅ `scripts/test_stt_stream.py` - 使用配置默认值
- ✅ `scripts/test_stt_optimized.py` - 显式设置0.5

**变化:** threshold 0.3 → 0.5, max_silence_cnt 8 → 10

---

### 3. **ASR参数**

**stream_stt.py 设置:**
```python
chunk_size = [5, 10, 5]     # [left_chunk, right_chunk, encoder_chunk]
chunk_interval = 10
```

**已更新文件:**
- ✅ `config/stt_config.yaml`
  ```yaml
  asr:
    chunk_size: [5, 10, 5]
    chunk_interval: 10
  ```
- ✅ `parts/stt/asr.py` - 自动使用配置

**变化:** chunk_size 512 → [5, 10, 5], chunk_interval 32 → 10

---

### 4. **显示更新频率**

**stream_stt.py 设置:**
```python
if display.frame_count % 3 == 0:  # 每3帧更新一次显示
    display.update_audio_level(...)
```

**已更新文件:**
- ✅ `scripts/test_stt_stream.py` - 每3帧更新
- ✅ `scripts/test_stt_optimized.py` - 每3帧更新
- ✅ `scripts/test_stt_realtime.py` - 每0.5秒更新（不同风格）

---

### 5. **显示样式**

**stream_stt.py 风格:**
```
================================================================================
🎤 流式语音识别 | 运行时间: 7.7s | 帧数: 135 | 状态: 继续录音中...
📊 音频电平: RMS=0.0132 | Peak=0.0893 | #####
🔇 静音时长: 0.1s
💬 当前识别: 我说怎么样
================================================================================
✅ 最终识别结果: ok了停止
```

**已实现文件:**
- ✅ `scripts/test_stt_stream.py`
- ✅ `scripts/test_stt_optimized.py`

---

## 📊 参数对比表

| 参数 | 优化前 | stream_stt.py | 当前设置 |
|------|--------|---------------|---------|
| **预热迭代次数** | 40 | 120 | ✅ 120 |
| **预热时长** | 1.3秒 | 4秒 | ✅ 4秒 |
| **VAD阈值** | 0.3 | 0.5 | ✅ 0.5 |
| **max_silence_cnt** | 8 | 10 | ✅ 10 |
| **chunk_size** | 512 | [5,10,5] | ✅ [5,10,5] |
| **chunk_interval** | 32 | 10 | ✅ 10 |
| **显示更新** | 0.5秒 | 每3帧 | ✅ 每3帧 |

---

## 🚀 性能提升

### 1. **识别速度**

**chunk_interval 32 → 10:**
- 更小的间隔意味着更快的响应
- 实时性提升约 **3.2倍**

**chunk_size [5,10,5]:**
- 优化的chunk配置
- 更适合流式识别

### 2. **稳定性**

**预热 40 → 120:**
- 更充分的设备预热
- 减少初始不稳定
- 首次识别更准确

**VAD阈值 0.3 → 0.5:**
- 减少噪音误触发
- 提高识别准确率
- 减少无效识别

### 3. **准确率**

**max_silence_cnt 8 → 10:**
- 更长的静音容忍
- 避免句子被截断
- 完整句子识别率提升

---

## 🧪 测试工具

### 推荐：test_stt_optimized.py（完全对齐版）

```bash
python scripts/test_stt_optimized.py
```

**特点:**
- ✅ 完全使用 stream_stt.py 的参数
- ✅ 相同的显示风格
- ✅ 120次预热迭代
- ✅ VAD阈值0.5
- ✅ 每3帧更新显示

**预期输出:**
```
================================================================================
🎤 流式语音识别 | 运行时间: 7.7s | 帧数: 135 | 状态: 继续录音中...
📊 音频电平: RMS=0.0132 | Peak=0.0893 | #################
🔇 静音时长: 0.1s
💬 当前识别: 我说怎么样
================================================================================
✅ 最终识别结果: 我说怎么样
```

---

### 备选：test_stt_stream.py

```bash
python scripts/test_stt_stream.py
```

**特点:**
- ✅ 已更新为stream_stt.py参数
- ✅ 简化的显示
- ✅ 适合长时间测试

---

### 诊断：test_stt_realtime.py

```bash
python scripts/test_stt_realtime.py
```

**特点:**
- ✅ 详细统计信息
- ✅ 音量可视化
- ✅ 诊断建议
- ⚠️ 显示风格不同（保持原样）

---

## 📝 配置文件变化

### config/stt_config.yaml

**修改前:**
```yaml
vad:
  threshold: 0.3
  max_silence_cnt: 8

asr:
  chunk_size: 512
  chunk_interval: 32
```

**修改后:**
```yaml
vad:
  threshold: 0.5           # ✅ 对齐stream_stt.py
  max_silence_cnt: 10      # ✅ 对齐stream_stt.py

asr:
  chunk_size: [5, 10, 5]   # ✅ 对齐stream_stt.py
  chunk_interval: 10       # ✅ 对齐stream_stt.py
```

---

## 🎯 使用建议

### 场景1: 追求速度（推荐）

使用当前配置（已对齐stream_stt.py）：

```bash
python scripts/test_stt_optimized.py
```

**优势:**
- 快速响应
- 高准确率
- 稳定性好

---

### 场景2: 安静环境

如需更灵敏，临时调整：

```python
vad = FunasrVAD(threshold=0.3)  # 降低阈值
```

---

### 场景3: 嘈杂环境

使用默认配置（threshold=0.5）即可，或提高：

```python
vad = FunasrVAD(threshold=0.6)  # 提高阈值
```

---

## 📦 文件清单

### 新增文件
- ✅ `scripts/test_stt_optimized.py` - 完全对齐版测试工具

### 修改文件
- ✅ `config/stt_config.yaml` - 参数对齐
- ✅ `parts/stt/stt_controller.py` - 预热和VAD参数
- ✅ `scripts/test_stt_stream.py` - 预热和显示频率
- ✅ `parts/stt/asr.py` - chunk参数

### 文档
- ✅ `docs/STREAM_STT_ALIGNMENT.md` - 本文档

---

## 🎉 对齐完成

所有关键参数已完全对齐到 `stream_stt.py`：

| 项目 | 状态 |
|------|------|
| 预热迭代 | ✅ 120次 |
| VAD阈值 | ✅ 0.5 |
| 静音帧数 | ✅ 10 |
| chunk_size | ✅ [5,10,5] |
| chunk_interval | ✅ 10 |
| 显示频率 | ✅ 每3帧 |
| 显示风格 | ✅ 完全一致 |

---

## 🚀 立即测试

```bash
# 完全对齐版（推荐）
python scripts/test_stt_optimized.py

# 或使用更新后的流式测试
python scripts/test_stt_stream.py

# 或使用主控制器
python runner/start.py
```

**预期体验:**
- 🚀 更快的识别速度
- 🎯 更高的准确率
- 💪 更好的稳定性
- ✨ 流畅的用户体验

---

**文档版本:** 1.0  
**对齐日期:** 2024-11-17  
**状态:** ✅ 完全对齐
