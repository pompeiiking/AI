# 🔍 Blender骨骼动作响应诊断指南

## 🎯 问题描述

**现象：** 
- ✅ Blender插件已运行
- ✅ 骨骼文件已加载
- ❌ 说话后骨骼动作无响应

---

## 🔬 诊断系统

### 已添加的完整日志追踪

整个数据流现在都有详细日志：

```
用户说话/表情
    ↓
STT/CV采集 
    ↓
多模态融合 → [🔔 触发融合回调]
    ↓
Pipeline接收 → [🎬 流程开始]
    ↓
Agent决策 → [🤖 步骤1]
    ↓
执行动作 → [🎯 步骤2]
    ↓
骨骼映射 → [🎯 步骤2.2]
    ↓
Blender更新 → [🦴 Blender更新]
    ↓
逐个骨骼 → [🔸 更新骨骼: xxx]
    ↓
完成 → [✅ 成功]
```

---

## 🚀 诊断步骤

### 1. **重新运行系统并观察日志**

```bash
cd c:\Users\POMPEII\Desktop\代播
python AI端\AIsampler\runner\start.py
```

### 2. **说话或做表情，观察日志输出**

**正常流程应该看到：**

```
[时间] - parts.fusion.fusion_controller - INFO - 🔔 触发融合回调: emotion=happy, confidence=0.85
[时间] - controller.pipeline - INFO - 🎬 [流程开始] 收到融合结果: emotion=happy, confidence=0.85
[时间] - controller.pipeline - INFO - 🤖 [步骤1] 调用Agent进行决策...
[时间] - controller.agent_manager - INFO - 开始执行任务: fusion_decision
[时间] - controller.pipeline - INFO - 🤖 [步骤1完成] Agent决策: {'action': 'update_bones', 'emotion': 'happy', ...}
[时间] - controller.pipeline - INFO - 🎯 [步骤2] 执行动作: update_bones
[时间] - controller.pipeline - INFO - 🦴 [步骤2.1] 准备更新骨骼: emotion=happy, confidence=0.85
[时间] - controller.pipeline - INFO - 🎯 [步骤2.2] 映射情感到骨骼...
[时间] - controller.pipeline - INFO - 🎯 [步骤2.2完成] 映射了5个骨骼姿势
[时间] - controller.pipeline - INFO - 🔄 [步骤2.3] 调用Blender更新...
[时间] - controller.pipeline - INFO - 🦴 [Blender更新] 开始，共5个骨骼
[时间] - controller.pipeline - INFO - 🦴 [Blender状态] blender_available=True
[时间] - controller.pipeline - INFO -   🔸 [1/5] 更新骨骼: mouth_corner_L
[时间] - adapter.blender.blender_controller - INFO - 🔧 [update_bone_pose] 调用: bone=mouth_corner_L, pos=[0.5, 0.2, 0], rot=[0, 0, 0]
[时间] - controller.pipeline - INFO -   ✅ [1/5] 成功
[时间] - controller.pipeline - INFO -   🔸 [2/5] 更新骨骼: mouth_corner_R
...
[时间] - controller.pipeline - INFO - 🦴 [Blender更新完成] 5/5 成功
[时间] - controller.pipeline - INFO - ✅ [步骤2.3完成] Blender更新调用完成
```

---

## 🔍 常见问题诊断

### 问题1：没有看到"🔔 触发融合回调"

**原因：** 融合控制器没有收到输入数据

**检查：**
- STT是否正常工作？
- CV是否正常工作？
- 查看是否有语音/视觉采集日志

**解决：**
```bash
# 单独测试STT
python scripts/test_stt_optimized.py

# 单独测试CV  
python scripts/test_cv_emotion.py
```

---

### 问题2：看到"🔔 触发融合回调"，但没有"🎬 流程开始"

**原因：** Pipeline回调未注册或崩溃

**检查：**
```python
# 在pipeline.py的_setup_callbacks中
def fusion_callback(result: FusionResult):
    """融合结果回调"""
    try:
        self._handle_fusion_result(result)  # 这里应该被调用
    except Exception as e:
        self.logger.error(f"融合回调处理失败: {e}")
```

**解决：** 检查Pipeline是否正确启动

---

### 问题3：看到"🤖 Agent决策"，action不是'update_bones'

**原因：** Agent返回了错误的动作类型

**检查日志：**
```
🤖 [步骤1完成] Agent决策: {'action': 'xxx', ...}
🎯 [步骤2] 执行动作: xxx
⚠️ 未知动作类型: xxx，跳过骨骼更新
```

**解决：** 检查`agent_manager.py`的返回值

**正确返回格式：**
```python
return {
    "action": "update_bones",  # 必须是这个
    "emotion": emotion,
    "confidence": confidence,
    "should_generate": False
}
```

---

### 问题4：看到"❌ [Blender更新失败] blender_available=False"

**原因：** Blender连接不可用

**检查：**
1. Blender是否真的在运行？
2. Socket服务器插件是否启动？
3. 端口8888是否被占用？

**测试连接：**
```python
# 在Python中测试
from adapter.blender.blender_controller import BlenderController
blender = BlenderController()
print(blender.socket_client.ping())  # 应该返回True
```

**解决：**
- 重启Blender
- 重新加载Socket插件
- 检查防火墙设置

---

### 问题5：看到"🔸 更新骨骼"，但"❌ 失败"

**原因：** 骨骼名称不匹配或Socket通信失败

**检查：**
```
🔸 [1/5] 更新骨骼: mouth_corner_L
🔧 [update_bone_pose] 调用: bone=mouth_corner_L, pos=[0.5, 0.2, 0], rot=[0, 0, 0]
❌ [1/5] 更新骨骼 mouth_corner_L 失败
```

**可能原因：**
1. Blender场景中没有这个骨骼名
2. Socket通信超时
3. Blender在Pose模式之外

**解决：**
- 检查Blender中的骨骼名称
- 确保Blender处于Pose模式
- 查看Blender控制台是否有错误

---

### 问题6：看到"✅ 成功"，但骨骼没动

**原因：** 
1. 骨骼更新值太小看不出变化
2. 视角问题
3. 骨骼约束锁定

**检查：**
- Blender中手动选择骨骼，查看位置/旋转值是否变化
- 增大情感强度测试
- 检查骨骼是否被锁定

---

## 📊 完整诊断流程图

```
开始
  ↓
是否看到"🔔 触发融合回调"？
  ├─ 否 → STT/CV采集问题
  └─ 是 ↓
        是否看到"🎬 流程开始"？
          ├─ 否 → Pipeline回调问题
          └─ 是 ↓
                是否看到"🤖 Agent决策"？
                  ├─ 否 → Agent崩溃
                  └─ 是 ↓
                        action是'update_bones'吗？
                          ├─ 否 → Agent返回值错误
                          └─ 是 ↓
                                blender_available=True？
                                  ├─ 否 → Blender连接问题
                                  └─ 是 ↓
                                        骨骼更新成功吗？
                                          ├─ 否 → 骨骼名称/通信问题
                                          └─ 是 ↓
                                                骨骼有动作吗？
                                                  ├─ 否 → 值太小/视角/锁定
                                                  └─ 是 → ✅ 完全正常！
```

---

## 🛠️ 快速修复建议

### 修复1：强制打印所有日志

```bash
# 启动时使用DEBUG级别
python runner/start.py --log-level DEBUG
```

### 修复2：测试Blender连接

```python
# 创建测试脚本 test_blender_connection.py
from adapter.blender.blender_controller import BlenderController

blender = BlenderController()
print(f"Blender模式: {'内部' if blender.blender_internal else 'Socket'}")
print(f"Socket客户端: {blender.socket_client}")

if blender.socket_client:
    print(f"Ping测试: {blender.socket_client.ping()}")
    
    # 测试更新骨骼
    result = blender.update_bone_pose('Bone', [0, 0, 0], [0, 0, 0])
    print(f"更新测试: {result}")
```

### 修复3：检查emotion_bone_mapper

```python
# 检查映射是否正常
from parts.fusion.emotion_bone_mapper import EmotionToBoneMapper

mapper = EmotionToBoneMapper()
bones = mapper.map_emotion_to_bones('happiness', 0.8)
print(f"映射骨骼数量: {len(bones)}")
for bone in bones:
    print(f"  {bone.bone_name}: pos={bone.position}, rot={bone.rotation}")
```

### 修复4：手动触发测试

```python
# 在pipeline中添加测试函数
def test_bone_update(self):
    """手动测试骨骼更新"""
    from parts.fusion.emotion_bone_mapper import BonePose
    
    test_bones = [
        BonePose(bone_name='Bone', position=[1.0, 0, 0], rotation=[0, 0, 0])
    ]
    
    self._update_blender_bones(test_bones)
```

---

## 📝 需要收集的信息

运行系统后，请截图或复制以下信息：

1. **Blender连接日志**
```
[时间] - adapter.blender.blender_controller - INFO - 🔌 不在Blender内部运行，尝试Socket连接...
[时间] - adapter.blender.blender_controller - INFO - 📡 尝试连接到 localhost:8888
[时间] - adapter.blender.blender_controller - INFO - ✅ 成功连接到Blender Socket服务器 (localhost:8888)
```

2. **融合触发日志**
```
[时间] - parts.fusion.fusion_controller - INFO - 🔔 触发融合回调: emotion=xxx, confidence=x.xx
```

3. **Pipeline处理日志**
```
[时间] - controller.pipeline - INFO - 🎬 [流程开始] ...
[时间] - controller.pipeline - INFO - 🤖 [步骤1] ...
[时间] - controller.pipeline - INFO - 🎯 [步骤2] ...
```

4. **Blender更新日志**
```
[时间] - controller.pipeline - INFO - 🦴 [Blender更新] ...
[时间] - controller.pipeline - INFO - 🦴 [Blender状态] ...
[时间] - controller.pipeline - INFO -   🔸 [x/x] ...
[时间] - controller.pipeline - INFO -   ✅ [x/x] ...
```

---

## ✅ 下一步

1. **重新运行系统**
```bash
python runner/start.py
```

2. **说话或做表情**

3. **观察日志输出**
   - 找到第一个**没有出现**的日志标记
   - 那就是问题所在的位置

4. **根据上面的诊断表定位问题**

5. **提供日志输出以便进一步分析**

---

**文档版本:** 1.0  
**更新日期:** 2024-11-17  
**状态:** 🔍 诊断系统已部署
