# Blender连接说明

## 📋 概述

系统支持两种方式连接Blender：

1. **内部模式**：在Blender内部运行Python脚本，直接使用bpy API
2. **Socket模式**：从外部Python脚本通过Socket连接已打开的Blender实例（推荐）

---

## 🔌 Socket模式（推荐）

### 为什么使用Socket模式？

- ✅ 可以在外部Python脚本中控制Blender
- ✅ Blender可以保持打开状态
- ✅ 不需要在Blender内部运行脚本
- ✅ 支持实时控制

### 安装步骤

#### 1. 安装Blender插件

1. 打开Blender
2. 点击菜单：**编辑 > 偏好设置 > 插件**
3. 点击 **安装** 按钮
4. 选择文件：`adapter/blender/blender_socket_server.py`
5. 安装完成后，在插件列表中找到 **Development: Blender Socket Server**
6. **勾选启用**插件

#### 2. 启动Socket服务器

1. 在Blender中，按 **N** 键打开3D视图侧边栏
2. 找到 **Blender Socket** 选项卡
3. 设置端口号（默认8888，一般无需更改）
4. 点击 **启动服务器** 按钮
5. 看到 "状态: 运行中" 表示服务器已启动

#### 3. 配置Python脚本

在 `config/blender_config.yaml` 中配置Socket连接参数：

```yaml
socket:
  host: "localhost"  # Blender Socket服务器地址
  port: 8888         # Blender Socket服务器端口
```

#### 4. 测试连接

运行以下Python代码测试连接：

```python
from adapter.blender.blender_controller import BlenderController

# 初始化控制器（会自动检测并使用Socket模式）
controller = BlenderController()

# 测试连接
if controller.socket_client and controller.socket_client.ping():
    print("✅ 连接成功！")
else:
    print("❌ 连接失败，请确保Blender插件已启动")
```

---

## 🔧 使用方法

### 基本使用

```python
from adapter.blender.blender_controller import BlenderController

# 初始化控制器
controller = BlenderController()

# 加载OpenPose骨骼文件
controller.load_openpose_file("path/to/openpose_bone.blend")

# 更新骨骼姿势
controller.update_bone_pose(
    bone_name="Bone.001",
    position=[1.0, 2.0, 3.0],
    rotation=[0.5, 0.0, 0.0]
)

# 获取骨骼位置
bone_positions = controller.get_bone_position()

# 创建姿势快照
snapshot = controller.create_pose_shot()
```

### 自动模式检测

`BlenderController` 会自动检测运行模式：

- 如果在Blender内部运行（有bpy模块），使用**内部模式**
- 如果在外部运行（无bpy模块），使用**Socket模式**

---

## 📝 支持的命令

### 1. load_openpose_file
加载OpenPose骨骼文件

```python
controller.load_openpose_file("path/to/file.blend")
```

### 2. update_bone_pose
更新骨骼姿势

```python
controller.update_bone_pose(
    bone_name="Bone.001",
    position=[x, y, z],  # 可选
    rotation=[x, y, z]   # 可选（欧拉角）
)
```

### 3. get_bone_position
获取所有骨骼位置

```python
positions = controller.get_bone_position()
# 返回: {bone_name: {location: [x,y,z], rotation: [x,y,z], scale: [x,y,z]}}
```

### 4. create_pose_shot
创建姿势快照

```python
snapshot = controller.create_pose_shot()
# 返回: {timestamp, bones, camera, lighting}
```

---

## ⚠️ 常见问题

### 1. 连接失败

**问题**：无法连接到Blender服务器

**解决方案**：
- 确保Blender插件已安装并启用
- 确保Socket服务器已启动（在N面板中点击"启动服务器"）
- 检查端口号是否匹配（默认8888）
- 检查防火墙是否阻止连接

### 2. 命令执行失败

**问题**：命令发送成功但执行失败

**解决方案**：
- 检查Blender中是否有armature对象
- 检查骨骼名称是否正确
- 查看Blender控制台的错误信息

### 3. 文件路径问题

**问题**：文件加载失败

**解决方案**：
- 使用绝对路径
- 确保文件存在
- 检查文件格式是否正确（.blend文件）

---

## 🔍 调试

### 查看日志

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### 测试连接

```python
from adapter.blender.blender_socket_client import BlenderSocketClient

client = BlenderSocketClient(host='localhost', port=8888)
if client.ping():
    print("连接成功")
else:
    print("连接失败")
```

### 查看Blender控制台

在Blender中：**窗口 > 切换系统控制台**（Windows）或查看终端输出（Linux/Mac）

---

## 📚 参考

- [Blender Python API文档](https://docs.blender.org/api/current/)
- [Socket编程文档](https://docs.python.org/3/library/socket.html)

---

## ✅ 快速开始

1. 打开Blender
2. 安装插件：`adapter/blender/blender_socket_server.py`
3. 在N面板启动服务器
4. 运行Python脚本：

```python
from adapter.blender.blender_controller import BlenderController
controller = BlenderController()
controller.load_openpose_file()
```

完成！现在可以从外部Python脚本控制Blender了。

