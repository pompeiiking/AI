# Blender自动加载使用指南

## 🎯 快速开始

### 步骤1：重新加载Blender插件

**重要**：如果修改了插件代码，需要重新加载插件！

1. 在Blender中：**编辑 > 偏好设置 > 插件**
2. 找到 **Development: Blender Socket Server**
3. 取消勾选（禁用）
4. 重新勾选（启用）

或者重启Blender。

### 步骤2：配置自动加载

在Blender的N面板中：

1. 按 **N** 键打开侧边栏
2. 找到 **Blender Socket** 选项卡
3. 勾选 **"启动时自动加载骨骼"**
4. 设置 **"骨骼文件路径"**（可以使用相对路径或绝对路径）
5. 点击 **"启动服务器"**

### 步骤3：测试自动加载

运行测试脚本：

```bash
python adapter/blender/test_auto_load.py
```

或者使用Python代码：

```python
from adapter.blender.blender_controller import BlenderController

# 初始化时会自动加载骨骼文件
controller = BlenderController()

# 检查是否加载成功
bone_positions = controller.get_bone_position()
print(f"找到 {len(bone_positions)} 个骨骼")
```

---

## 🔧 配置选项

### 配置文件（config/blender_config.yaml）

```yaml
paths:
  openpose_bone_file: "adapter/blender/openpose/openpose_bone.blend"
  auto_load_on_init: true  # 初始化时自动加载

socket:
  auto_load_on_connect: true  # 连接时自动加载
```

### Blender插件面板

- **启动时自动加载骨骼**：勾选后，启动服务器时自动加载
- **骨骼文件路径**：设置骨骼文件的路径

---

## 📝 自动加载时机

### 时机1：BlenderController初始化

当创建`BlenderController`实例时：

```python
controller = BlenderController()  # 自动加载骨骼文件
```

### 时机2：Blender插件启动服务器

在Blender中点击"启动服务器"时，如果勾选了"启动时自动加载骨骼"。

---

## ⚠️ 常见问题

### 问题1：自动加载失败，提示"bpy.ops.import_scene.blend"错误

**原因**：插件代码已更新，但Blender中的插件未重新加载

**解决**：
1. 重新加载插件（禁用后重新启用）
2. 或重启Blender

### 问题2：找不到骨骼文件

**原因**：文件路径不正确

**解决**：
1. 使用绝对路径
2. 在Blender插件面板中设置正确的路径
3. 检查文件是否存在

### 问题3：加载成功但找不到骨骼

**原因**：文件中没有armature对象

**解决**：
1. 检查.blend文件是否包含armature对象
2. 确认文件格式正确

---

## ✅ 验证自动加载

运行测试脚本验证：

```bash
python adapter/blender/test_auto_load.py
```

如果看到"成功找到 X 个骨骼"，说明自动加载成功！

---

## 📚 相关文档

- [Blender连接说明.md](./Blender连接说明.md)
- [Blender自动加载说明.md](./Blender自动加载说明.md)

