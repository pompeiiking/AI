# DeepSeek API密钥修复说明

## ✅ 修复完成

### 问题描述

Agent管理器和Pipeline模块初始化失败，错误信息：
```
LLM初始化失败: The api_key client option must be set either by passing api_key to the client or by setting the OPENAI_API_KEY environment variable
```

### 问题原因

1. **文件读取问题**：`config/deepseek_key` 文件存在但读取时可能为空
2. **编码问题**：文件可能使用了不同的编码格式
3. **参数传递问题**：LangChain 0.3.x 的ChatOpenAI参数名称已更新

### 修复方案

#### 1. 改进文件读取逻辑

**修复前**：
```python
if os.path.exists(key_file):
    with open(key_file, 'r', encoding='utf-8') as f:
        api_key = f.read().strip()
```

**修复后**：
```python
if os.path.exists(key_file):
    try:
        # 先尝试二进制读取，然后解码
        with open(key_file, 'rb') as f:
            content = f.read()
        
        # 尝试多种编码方式解码
        for encoding in ['utf-8', 'utf-8-sig', 'gbk', 'latin-1', 'cp1252']:
            try:
                api_key = content.decode(encoding).strip()
                # 移除可能的BOM标记
                if api_key.startswith('\ufeff'):
                    api_key = api_key[1:].strip()
                if api_key:
                    self.logger.debug(f"成功使用{encoding}编码读取API密钥")
                    break
            except (UnicodeDecodeError, UnicodeError):
                continue
```

#### 2. 添加API密钥验证

```python
# 验证API密钥
if not api_key:
    raise RuntimeError("未找到API密钥，请确保config/deepseek_key文件存在或配置api_key")

if len(api_key) < 10:  # 简单验证：API密钥应该至少有一定长度
    raise RuntimeError(f"API密钥格式不正确（长度: {len(api_key)}），请检查config/deepseek_key文件")
```

#### 3. 改进错误处理

```python
try:
    # 尝试新版本参数（model, api_key, base_url）
    self.llm = ChatOpenAI(
        model=llm_model,
        temperature=0,
        api_key=api_key,
        base_url=api_base
    )
    self.logger.info(f"LLM初始化成功（新版本参数），模型: {llm_model}, API: {api_base}")
except (TypeError, ValueError) as e:
    # 兼容旧版本参数
    try:
        self.llm = ChatOpenAI(
            model_name=llm_model,
            temperature=0,
            openai_api_key=api_key,
            openai_api_base=api_base
        )
        self.logger.info(f"LLM初始化成功（旧版本参数），模型: {llm_model}, API: {api_base}")
    except Exception as e2:
        raise RuntimeError(f"LLM初始化失败（新旧版本参数都失败）: {e2}")
```

### 修复内容

#### 1. `controller/agent_manager.py`

**改进的功能**：
- ✅ 支持多种编码格式读取（utf-8, utf-8-sig, gbk, latin-1, cp1252）
- ✅ 自动移除BOM标记
- ✅ 添加API密钥格式验证
- ✅ 改进错误处理和日志记录
- ✅ 支持新旧版本LangChain参数

#### 2. API密钥文件

**文件位置**：`config/deepseek_key`

**内容格式**：
```
sk-59afadbe0e224f6eb41040b64d2f189d
```

**注意事项**：
- 文件应只包含API密钥，无换行符
- 建议使用UTF-8编码
- 确保文件有读取权限

### 验证结果

✅ **AgentManager初始化成功**：
```
INFO:controller.agent_manager:LLM初始化成功（新版本参数），模型: deepseek-chat, API: https://api.deepseek.com/v1
INFO:controller.agent_manager:Agent管理器初始化完成
✅ AgentManager初始化成功
```

✅ **所有模块检测通过**：
- CV模块 ✅
- STT模块 ✅
- Fusion模块 ✅
- EmotionMapper模块 ✅
- Blender适配器 ✅
- ComfyUI适配器 ✅
- **Agent管理器 ✅**（已修复）
- MainController ✅
- **Pipeline ✅**（已修复）

### 配置说明

#### 1. API密钥配置方式

**方式1：配置文件（推荐）**
- 文件路径：`config/deepseek_key`
- 文件内容：API密钥（一行，无换行）

**方式2：环境变量**
```bash
export DEEPSEEK_API_KEY="sk-..."
```

**方式3：配置字典**
```python
config = {
    'api_key': 'sk-...'
}
manager = AgentManager(config=config)
```

#### 2. DeepSeek模型配置

**默认配置**：
- 模型：`deepseek-chat`
- API地址：`https://api.deepseek.com/v1`

**自定义配置**：
```python
config = {
    'llm_model': 'deepseek-chat',
    'api_base': 'https://api.deepseek.com/v1'
}
manager = AgentManager(config=config)
```

### 修复效果

1. ✅ **文件读取问题解决**：支持多种编码格式
2. ✅ **API密钥验证**：添加格式验证和错误提示
3. ✅ **参数兼容性**：支持新旧版本LangChain参数
4. ✅ **错误处理改进**：更详细的错误信息和日志
5. ✅ **模块初始化成功**：Agent管理器和Pipeline可以正常初始化

### 注意事项

1. **文件编码**：
   - 建议使用UTF-8编码保存API密钥文件
   - 系统会自动尝试多种编码格式

2. **API密钥安全**：
   - 不要将API密钥提交到版本控制系统
   - 建议将`config/deepseek_key`添加到`.gitignore`

3. **LangChain版本**：
   - 需要安装`langchain-openai`包
   - 支持LangChain 0.3.x版本

4. **DeepSeek API**：
   - 确保API密钥有效
   - 检查网络连接和API服务状态

### 相关文件

- `controller/agent_manager.py` - Agent管理器（已修复）
- `controller/pipeline.py` - Pipeline流程（依赖AgentManager）
- `config/deepseek_key` - API密钥文件
- `requirements.txt` - 依赖列表（包含langchain-openai）

### 测试建议

1. **基础初始化测试**：
   ```python
   from controller.agent_manager import AgentManager
   manager = AgentManager(config={})
   assert manager.llm is not None
   ```

2. **API密钥读取测试**：
   ```python
   import os
   key_file = 'config/deepseek_key'
   assert os.path.exists(key_file)
   with open(key_file, 'r', encoding='utf-8') as f:
       api_key = f.read().strip()
   assert len(api_key) > 10
   ```

3. **完整模块检测**：
   ```bash
   python scripts/check_modules.py
   ```

---

**修复完成时间**：2024年

**修复状态**：✅ 已完成并验证

**影响模块**：Agent管理器、Pipeline

