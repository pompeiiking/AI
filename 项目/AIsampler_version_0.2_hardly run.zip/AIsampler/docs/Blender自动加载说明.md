# Blender自动加载骨骼文件说明

## 📋 概述

系统现在支持自动加载OpenPose骨骼文件，无需手动调用`load_openpose_file()`。

---

## 🔧 自动加载配置

### 1. 配置文件设置

在 `config/blender_config.yaml` 中：

```yaml
paths:
  openpose_bone_file: "adapter/blender/openpose/openpose_bone.blend"
  auto_load_on_init: true  # 初始化时自动加载骨骼文件

socket:
  auto_load_on_connect: true  # 连接时自动加载骨骼文件
```

### 2. Blender插件设置

在Blender的N面板中：

1. **自动加载开关**：勾选"启动时自动加载骨骼"
2. **文件路径**：设置骨骼文件的路径（相对或绝对路径）

---

## 🚀 自动加载时机

### 方式1：BlenderController初始化时

当创建`BlenderController`实例时，如果`auto_load_on_init: true`：

- **内部模式**：直接加载骨骼文件
- **Socket模式**：如果连接成功且`auto_load_on_connect: true`，自动加载

```python
from adapter.blender.blender_controller import BlenderController

# 初始化时会自动加载骨骼文件（如果配置了auto_load_on_init）
controller = BlenderController()
```

### 方式2：Blender插件启动服务器时

在Blender中：

1. 打开N面板（按N键）
2. 找到"Blender Socket Server"面板
3. 勾选"启动时自动加载骨骼"
4. 设置骨骼文件路径
5. 点击"启动服务器"

服务器启动时会自动加载骨骼文件。

---

## 📝 使用示例

### 示例1：自动加载（推荐）

```python
from adapter.blender.blender_controller import BlenderController

# 初始化时自动加载（如果配置了auto_load_on_init）
controller = BlenderController()

# 现在可以直接使用骨骼
bone_positions = controller.get_bone_position()
```

### 示例2：手动加载

```python
from adapter.blender.blender_controller import BlenderController

controller = BlenderController()

# 手动加载（如果自动加载失败或需要重新加载）
controller.load_openpose_file("path/to/openpose_bone.blend")
```

---

## ⚙️ 配置选项

### auto_load_on_init

- **类型**: `bool`
- **默认**: `true`
- **说明**: 在`BlenderController`初始化时是否自动加载骨骼文件

### auto_load_on_connect

- **类型**: `bool`
- **默认**: `true`
- **说明**: 在Socket模式连接成功时是否自动加载骨骼文件

### openpose_bone_file

- **类型**: `str`
- **默认**: `"adapter/blender/openpose/openpose_bone.blend"`
- **说明**: OpenPose骨骼文件的路径（相对或绝对路径）

---

## 🔍 路径解析

系统会按以下顺序查找骨骼文件：

1. 配置文件中指定的路径（相对路径）
2. 项目根目录 + 相对路径
3. 用户主目录 + 相对路径
4. 当前工作目录 + 相对路径
5. Blender文件所在目录 + 相对路径

如果找到文件，使用绝对路径加载；如果找不到，会尝试加载并显示警告。

---

## ⚠️ 注意事项

1. **文件路径**：确保骨骼文件路径正确
2. **文件存在**：如果文件不存在，会自动尝试加载但可能失败
3. **重复加载**：多次加载同一文件可能会创建重复对象
4. **场景清理**：如果需要，可以在加载前清理场景

---

## 🐛 故障排除

### 问题1：自动加载失败

**原因**：文件路径不正确或文件不存在

**解决**：
1. 检查配置文件中的路径
2. 使用绝对路径
3. 在Blender插件面板中设置正确的路径

### 问题2：找不到骨骼

**原因**：文件加载成功但场景中没有armature对象

**解决**：
1. 检查`.blend`文件是否包含armature对象
2. 确认文件格式正确
3. 手动加载文件检查

### 问题3：重复加载

**原因**：多次初始化`BlenderController`或多次启动服务器

**解决**：
1. 在加载前检查是否已存在armature对象
2. 使用`auto_load_on_init: false`禁用自动加载
3. 手动管理加载时机

---

## ✅ 最佳实践

1. **使用绝对路径**：避免路径解析问题
2. **检查文件存在**：在配置文件中使用存在的文件路径
3. **合理使用自动加载**：在开发阶段可以禁用，生产环境启用
4. **错误处理**：检查加载结果，必要时手动加载

---

## 📚 相关文档

- [Blender连接说明.md](./Blender连接说明.md)
- [blender_config.yaml](../config/blender_config.yaml)

