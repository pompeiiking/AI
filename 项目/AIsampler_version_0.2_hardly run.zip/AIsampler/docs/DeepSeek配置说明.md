# DeepSeek配置说明

## ✅ 已完成配置

### 1. DeepSeek密钥配置

系统已自动配置DeepSeek API密钥，从以下位置读取：

1. **配置文件**：`config/deepseek_key`
   - 优先读取此文件
   - 文件内容应为API密钥（一行）

2. **环境变量**：`DEEPSEEK_API_KEY`
   - 如果配置文件不存在，尝试从环境变量读取

3. **配置字典**：`config.get('api_key')`
   - 最后尝试从配置字典中获取

### 2. LangChain集成

系统已自动将DeepSeek密钥配置到LangChain：

```python
# 自动读取deepseek_key文件
key_file = os.path.join(config_dir, 'deepseek_key')
with open(key_file, 'r', encoding='utf-8') as f:
    api_key = f.read().strip()

# 初始化ChatOpenAI（支持DeepSeek）
self.llm = ChatOpenAI(
    model_name='deepseek-chat',
    temperature=0,
    openai_api_key=api_key,
    openai_api_base='https://api.deepseek.com/v1'
)
```

### 3. 配置位置

- **密钥文件**：`AI端/AIsampler/config/deepseek_key`
- **配置代码**：`AI端/AIsampler/controller/agent_manager.py` (第299-323行)

## 📝 使用说明

### 配置密钥

1. 确保 `config/deepseek_key` 文件存在
2. 将API密钥写入文件（一行，无换行）
3. 系统启动时自动读取并配置

### 配置模型

在配置文件中设置：

```yaml
agent:
  llm_model: "deepseek-chat"  # 默认模型
  api_base: "https://api.deepseek.com/v1"  # API基础URL
  verbose: false  # 是否显示详细日志
```

### 验证配置

系统启动时会自动验证：
- 如果密钥文件不存在且环境变量未设置，会抛出异常
- 如果LLM初始化失败，会抛出异常并显示错误信息

## ✨ 优势

1. **自动配置**：无需手动设置环境变量
2. **多源支持**：支持文件、环境变量、配置字典三种方式
3. **错误提示**：配置失败时提供清晰的错误信息
4. **统一管理**：密钥集中管理，便于维护

## 🔒 安全建议

1. **不要提交密钥文件到Git**
   - 将 `config/deepseek_key` 添加到 `.gitignore`
   
2. **使用环境变量（生产环境）**
   - 生产环境建议使用环境变量而非文件

3. **权限控制**
   - 确保密钥文件权限为 600（仅所有者可读）

