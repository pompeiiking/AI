# Blender插件重新安装指南

## ⚠️ 问题说明

如果遇到错误：`Calling operator "bpy.ops.import_scene.blend" error, could not be found`

这说明Blender中的插件还在使用旧代码，需要完全重新安装插件。

---

## 🔧 完全重新安装插件

### 步骤1：完全卸载旧插件

1. 在Blender中：**编辑 > 偏好设置 > 插件**
2. 搜索：**Blender Socket Server**
3. 找到插件后，点击右侧的 **"移除"** 或 **"删除"** 按钮
4. 如果找不到删除按钮，取消勾选禁用插件

### 步骤2：清理插件缓存（可选）

1. 关闭Blender
2. 删除Blender的插件缓存目录（如果存在）：
   - Windows: `%APPDATA%\Blender Foundation\Blender\[版本]\scripts\addons\`
   - 查找 `blender_socket_server` 相关文件夹并删除

### 步骤3：重新安装插件

1. 打开Blender
2. **编辑 > 偏好设置 > 插件**
3. 点击 **"安装"** 按钮
4. 选择文件：`AI端/AIsampler/adapter/blender/blender_socket_server.py`
5. 安装完成后，在插件列表中找到 **Development: Blender Socket Server**
6. **勾选启用**插件

### 步骤4：验证插件版本

在Blender的Python控制台（**窗口 > 切换系统控制台**）中运行：

```python
import bpy
# 检查插件是否加载了新代码
# 新代码应该使用 bpy.data.libraries.load()，而不是 bpy.ops.import_scene.blend
```

---

## 🔍 验证插件是否正确加载

### 方法1：查看Blender控制台

1. 在Blender中：**窗口 > 切换系统控制台**（Windows）
2. 启动Socket服务器
3. 查看控制台输出，应该看到：
   ```
   Blender Socket Server插件已注册
   Blender Socket服务器已启动，监听端口: 8888
   ```

### 方法2：测试加载功能

运行测试脚本：

```bash
python adapter/blender/quick_test.py
```

如果仍然报错 `bpy.ops.import_scene.blend`，说明插件还没有更新。

---

## 🛠️ 手动验证插件代码

### 检查插件文件

确认 `adapter/blender/blender_socket_server.py` 文件中的 `execute_command` 函数使用的是：

```python
# ✅ 正确（新代码）
with bpy.data.libraries.load(file_path) as (data_from, data_to):
    data_to.objects = data_from.objects
    ...

# ❌ 错误（旧代码）
bpy.ops.import_scene.blend(filepath=file_path)
```

### 如果文件正确但插件仍报错

1. **完全关闭Blender**
2. **重新打开Blender**
3. **重新安装插件**（按照上面的步骤）

---

## 📝 快速检查清单

- [ ] 已完全卸载旧插件
- [ ] 已重新安装插件文件
- [ ] 插件已启用
- [ ] 已重启Blender（如果修改了插件代码）
- [ ] Socket服务器已启动
- [ ] 测试脚本可以连接

---

## ✅ 成功标志

如果插件正确加载，运行测试时应该看到：

```
✅ 连接成功！
✅ 文件加载成功！
✅ 找到 X 个骨骼！
```

而不是：

```
❌ Calling operator "bpy.ops.import_scene.blend" error
```

---

## 🆘 如果仍然失败

1. **检查文件路径**：确认 `blender_socket_server.py` 文件确实已更新
2. **查看Blender控制台**：查看详细的错误信息
3. **尝试手动加载**：在Blender中手动导入.blend文件，确认文件格式正确
4. **检查Blender版本**：确保Blender版本 >= 3.0

