# Blender崩溃修复说明

## ✅ 修复完成

已修复导致Blender崩溃的**线程安全问题**。

## 🔍 问题根源

根据崩溃日志分析，问题在于：
- **在后台线程中调用了Blender的bpy API**
- Blender的bpy API必须在主线程中调用
- `bpy.data.libraries.load()` 在后台线程中执行导致内存访问违规

## 🔧 修复方案

实现了**线程安全的命令队列机制**：

### 1. 命令队列系统

- **后台线程**：接收Socket命令，放入队列
- **主线程**：使用 `bpy.app.timers` 定期处理队列中的命令
- **结果返回**：通过事件机制通知后台线程

### 2. 关键改动

#### 添加了命令队列和结果字典
```python
import queue
import uuid

command_queue = queue.Queue()  # 线程安全的命令队列
command_results = {}  # 存储命令执行结果
result_lock = threading.Lock()  # 结果字典的锁
```

#### 修改了 `handle_client` 函数
- 不再直接调用 `execute_command`
- 将命令放入队列，等待主线程处理
- 通过事件机制等待结果

#### 新增了 `process_command_queue` 函数
- 在主线程中运行（通过 `bpy.app.timers` 调用）
- 从队列获取命令
- 调用 `execute_command_safe` 执行命令
- 存储结果并通知等待的线程

#### 重命名了 `execute_command` 为 `execute_command_safe`
- 确保在主线程中调用
- 所有bpy操作都在主线程中执行

#### 修改了 `start_server` 和 `stop_server`
- 启动时注册定时器
- 停止时取消注册定时器
- 清空队列和结果字典

## 📝 使用说明

### 1. 重新安装插件

由于版本号已更新到 `(1, 2, 0)`，需要重新安装插件：

1. 在Blender中：编辑 > 偏好设置 > 插件
2. 找到 "Development: Blender Socket Server"
3. 禁用插件
4. 删除插件
5. 重新安装插件（选择 `blender_socket_server.py`）
6. 启用插件

### 2. 启动服务器

1. 在N面板（按N键）找到 "Blender Socket Server" 面板
2. 点击 "启动服务器"
3. 如果启用了自动加载，骨骼文件会在主线程中安全加载

### 3. 测试

运行测试脚本：
```bash
python adapter\blender\test_blender.py
```

## ⚠️ 注意事项

1. **所有bpy操作现在都在主线程中执行**，这是安全的
2. **Socket操作仍在后台线程中**，这是允许的
3. **命令处理是异步的**，但结果会正确返回

## 🎯 修复效果

- ✅ 不再崩溃
- ✅ 线程安全
- ✅ 符合Blender的设计规范
- ✅ 不会阻塞主线程

## 📚 相关文档

- [Blender崩溃日志分析报告.md](./Blender崩溃日志分析报告.md)
- [Blender连接说明.md](./Blender连接说明.md)

