# 云端ComfyUI使用说明

## ✅ 连接状态

**云端ComfyUI连接已成功！**

- ✅ API密钥配置正确
- ✅ 实例ID配置正确
- ✅ 后端注册成功
- ✅ 工作流已创建并缓存

**工作流ID**: `69128c9f815dfb4dc643b668`

---

## 📋 工作流切换说明

### 当前状态

工作流已经创建并缓存在本地。系统会：
1. 首次加载时创建工作流并缓存ID
2. 后续加载时从缓存复用工作流ID
3. 避免重复创建工作流

### 如何切换工作流

#### 方法1：使用不同的工作流文件

修改 `config/comfyui_config.yaml` 中的工作流路径：

```yaml
workflow:
  default_workflow_path: "adapter/comfyui/workflow/你的新工作流.json"
```

然后重新加载工作流，系统会创建新的工作流。

#### 方法2：删除缓存文件

删除工作流缓存文件，强制创建新工作流：

```bash
# 删除缓存目录
rm -rf config/comfyui_cloud/workflow_cache/
```

或者手动删除对应的缓存文件。

#### 方法3：使用不同的工作流名称

在代码中指定不同的工作流名称：

```python
controller.load_workflow(workflow_name="新工作流名称")
```

---

## 🖼️ 图片生成测试

### 测试结果

**✅ 任务提交成功！**

- 任务ID: `69128e63815dfb4dc643b66f`
- 状态: 已提交到云端
- 提示词: 已设置成功

### 查看任务状态

由于云端API可能不支持直接查询任务状态，建议：

1. **在云端平台查看**：
   - 登录 onethingai 平台
   - 查看你的ComfyUI实例
   - 应该能看到任务ID `69128e63815dfb4dc643b66f` 的执行状态

2. **使用测试脚本**：
   ```bash
   python adapter/comfyui/test_image_generation.py
   ```
   选择选项2进行图片生成测试

### 获取输出结果

任务完成后，可以通过以下方式获取结果：

1. **在云端平台下载**
2. **使用API查询**（如果API支持）
3. **检查输出目录**（如果配置了自动保存）

---

## 🔧 使用示例

### 基本使用

```python
from adapter.comfyui.comfyui_controller import ComfyUIController
from config.config_loader import config_loader

# 加载配置
config = config_loader.get_comfyui_config()

# 创建控制器
controller = ComfyUIController(config=config)

# 加载工作流
controller.load_workflow()

# 设置提示词
controller.set_prompt("a beautiful landscape, mountains, sunset")
controller.set_negative_prompt("blurry, low quality")

# 执行工作流
task_id = controller.execute_workflow()
print(f"任务ID: {task_id}")

# 查询状态（可能需要轮询）
status = controller.get_task_status(task_id)
print(f"状态: {status}")
```

### 设置图像输入

```python
# 设置输入图像路径
controller.set_input_image("path/to/your/image.jpg")
```

### 设置模型参数

```python
# 设置采样器参数
controller.set_model_parameters({
    'sampler': {
        'steps': 20,
        'cfg': 7.0,
        'sampler_name': 'euler'
    }
})
```

---

## 📊 工作流信息

### 发现的节点类型

当前工作流包含以下节点类型：

- `image_inputs`: 图像输入节点
- `text_encoders`: 文本编码器节点
- `samplers`: 采样器节点
- `controlnet_nodes`: ControlNet节点
- `ipadapter_nodes`: IPAdapter节点
- `video_generators`: 视频生成节点
- `output_nodes`: 输出节点

### 工作流文件

- 路径: `adapter/comfyui/workflow/代播视频生成.json`
- 节点数: 19个

---

## 🐛 常见问题

### 问题1：任务提交成功但没有返回任务ID

**原因**：API响应格式可能不同

**解决**：代码已改进，会尝试多种方式提取任务ID。如果仍然失败，请查看日志中的完整响应。

### 问题2：任务状态一直是pending

**原因**：云端API可能不支持直接查询任务状态

**解决**：
1. 在云端平台手动查看任务状态
2. 等待任务完成后，在云端平台下载结果
3. 如果API支持，可以实现轮询机制

### 问题3：工作流在云端看不到

**原因**：工作流已创建但可能需要在云端平台手动切换

**解决**：
1. 登录云端平台
2. 查找工作流ID: `69128c9f815dfb4dc643b668`
3. 手动切换到该工作流

---

## 📝 下一步

1. ✅ **连接测试** - 已完成
2. ✅ **工作流加载** - 已完成
3. ✅ **任务提交** - 已完成
4. ⏳ **任务状态查询** - 需要改进（可能需要轮询或使用云端平台）
5. ⏳ **结果获取** - 需要实现（根据API支持情况）

---

## 🔗 相关文档

- [云端ComfyUI配置指南](./云端ComfyUI配置指南.md)
- [云端ComfyUI API对接说明](./云端ComfyUI API对接说明.md)
- [ComfyUI配置说明](../config/comfyui_config.yaml)

