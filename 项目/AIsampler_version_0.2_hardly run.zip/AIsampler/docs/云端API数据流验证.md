# 云端ComfyUI API数据流验证文档

## 📋 概述

本文档验证云端API模式作为唯一连接方式的整体逻辑和数据流是否正确。

## ✅ 修复内容总结

### 1. 配置强制启用API模式

**修复前**：
- `use_cloud_api: false`（默认）
- 支持SSH隧道和本地模式

**修复后**：
- `use_cloud_api: true`（默认，唯一连接方式）
- 移除SSH隧道和本地模式逻辑
- API密钥和实例ID为必需配置

### 2. 初始化逻辑

**修复前**：
- API模式可选
- 有fallback机制

**修复后**：
- API模式强制启用
- API密钥和实例ID必需，缺失直接抛出异常
- 后端注册必需，失败直接抛出异常
- 无fallback机制

### 3. 工作流管理

**修复前**：
- 只检查workflow_id是否存在
- 没有查询已存在工作流的逻辑

**修复后**：
- 添加`get_workflow_by_name()`方法（预留接口）
- 先查询已存在工作流，再创建新工作流
- 工作流ID正确保存和复用

### 4. 参数提取

**修复前**：
- 只提取基本参数（text, width, height等）
- 可能遗漏某些参数类型

**修复后**：
- 根据节点类型智能提取参数
- 支持采样器参数（steps, cfg, sampler_name等）
- 支持潜在图像参数（width, height, batch_size）
- 支持图像路径参数
- 支持其他常见参数（strength, weight等）
- 正确跳过连接引用（避免提取错误数据）

### 5. 执行逻辑

**修复前**：
- 支持多种模式（API、SSH隧道、本地）
- 逻辑复杂

**修复后**：
- 只支持API模式
- 逻辑简化，直接调用云端API
- 完整的错误检查

### 6. 任务状态查询

**修复前**：
- 只支持传统ComfyUI API

**修复后**：
- 优先使用云端API查询
- 预留接口（待API支持）

## 🔄 完整数据流

### 初始化阶段（系统启动）

```
1. ComfyUIController.__init__()
   ├─ 读取配置
   ├─ 强制启用API模式（use_cloud_api = True）
   ├─ 读取API密钥和实例ID（必需，缺失抛异常）
   ├─ 初始化CloudComfyUIAPI
   └─ 注册后端（必需，失败抛异常）
   
   结果：cloud_api对象已初始化，后端已注册
```

### 工作流加载阶段（初始化时一次）

```
2. load_workflow()
   ├─ 读取工作流JSON文件
   ├─ 检查workflow_id是否存在
   │  ├─ 如果不存在：
   │  │  ├─ 查询已存在的工作流（get_workflow_by_name）
   │  │  ├─ 如果找到：复用workflow_id
   │  │  └─ 如果未找到：创建新工作流（create_workflow）
   │  └─ 如果已存在：直接使用
   ├─ 保存workflow_id
   └─ 分析工作流节点
   
   结果：workflow_id已保存，工作流数据已加载
```

### 参数修改阶段（运行中多次调用）

```
3. set_prompt(), set_model_parameters() 等
   ├─ 修改本地workflow_data
   ├─ 更新节点参数
   └─ 参数保存在内存中
   
   结果：workflow_data已更新，参数已修改
```

### 执行阶段（运行中多次调用）

```
4. execute_workflow()
   ├─ 检查cloud_api是否初始化
   ├─ 检查workflow_id是否存在
   ├─ 检查workflow_data是否加载
   ├─ 提取输入参数（_extract_workflow_inputs_for_api）
   │  ├─ 遍历所有节点
   │  ├─ 根据节点类型提取参数
   │  ├─ 跳过连接引用
   │  └─ 转换为API格式
   ├─ 发送prompt到云端（cloud_api.prompt_workflow）
   └─ 返回task_id
   
   结果：任务已提交到云端，返回task_id
```

### 状态查询阶段（运行中多次调用）

```
5. get_task_status()
   ├─ 检查task_id
   ├─ 使用cloud_api查询状态（如果支持）
   └─ 返回状态信息
   
   结果：任务状态已查询
```

## ✅ 逻辑验证清单

### 初始化逻辑

- [x] API模式强制启用
- [x] API密钥和实例ID必需检查
- [x] 后端注册必需检查
- [x] 初始化失败直接抛异常（无fallback）
- [x] SSH隧道和本地模式逻辑已移除

### 工作流管理逻辑

- [x] 工作流只在初始化时上传一次
- [x] 工作流ID正确保存
- [x] 工作流ID正确复用
- [x] 工作流创建失败正确处理
- [x] 预留查询已存在工作流的接口

### 参数修改逻辑

- [x] 参数修改方法正常工作
- [x] 参数保存在workflow_data中
- [x] 参数修改不影响工作流结构

### 参数提取逻辑

- [x] 正确提取文本参数
- [x] 正确提取采样器参数
- [x] 正确提取潜在图像参数
- [x] 正确提取图像路径参数
- [x] 正确提取其他常见参数
- [x] 正确跳过连接引用
- [x] 根据节点类型智能提取

### 执行逻辑

- [x] 只支持API模式
- [x] 完整的错误检查
- [x] 参数正确提取和发送
- [x] 任务ID正确返回

### 状态查询逻辑

- [x] 优先使用云端API
- [x] 预留接口（待API支持）

## 🔍 数据流验证

### 验证点1：初始化流程

```python
# 测试代码
controller = ComfyUIController(config=config)

# 验证：
# 1. cloud_api已初始化
assert controller.cloud_api is not None
# 2. use_cloud_api为True
assert controller.use_cloud_api == True
# 3. use_cloud为False
assert controller.use_cloud == False
```

### 验证点2：工作流加载流程

```python
# 测试代码
success = controller.load_workflow()

# 验证：
# 1. 工作流加载成功
assert success == True
# 2. workflow_id已保存
assert controller.cloud_api.get_workflow_id() is not None
# 3. workflow_data已加载
assert controller.workflow_data is not None
```

### 验证点3：参数修改流程

```python
# 测试代码
controller.set_prompt("new prompt")
controller.set_model_parameters({'sampler': {'steps': 20}})

# 验证：
# 1. workflow_data已更新
# 2. 参数已修改
```

### 验证点4：执行流程

```python
# 测试代码
task_id = controller.execute_workflow()

# 验证：
# 1. task_id不为None
assert task_id is not None
# 2. current_task_id已保存
assert controller.current_task_id == task_id
```

### 验证点5：参数提取流程

```python
# 测试代码
inputs = controller._extract_workflow_inputs_for_api()

# 验证：
# 1. inputs不为空
assert len(inputs) > 0
# 2. 每个input包含id和params
for input_item in inputs:
    assert 'id' in input_item
    assert 'params' in input_item
    assert len(input_item['params']) > 0
```

## ⚠️ 注意事项

### 1. API密钥和实例ID必需

- 必须创建 `config/comfyui_cloud/api_key` 文件
- 必须创建 `config/comfyui_cloud/instance_id` 文件
- 文件内容不能为空

### 2. 工作流只上传一次

- 工作流在`load_workflow()`时上传
- 后续调用`load_workflow()`会复用已存在的工作流
- 不要重复创建工作流

### 3. 参数修改在本地

- 使用`set_*`方法修改参数
- 参数保存在`workflow_data`中
- 执行时自动提取并发送

### 4. 任务状态查询

- 当前API可能不支持直接查询
- 预留了接口，待API支持后实现

## 📊 数据流图

```
初始化
  │
  ├─> 读取配置
  ├─> 强制启用API模式
  ├─> 读取API密钥和实例ID（必需）
  ├─> 初始化CloudComfyUIAPI
  └─> 注册后端（必需）
      │
      └─> [成功] cloud_api已就绪
          │
          └─> load_workflow()
              │
              ├─> 读取工作流JSON
              ├─> 查询已存在工作流
              ├─> 创建新工作流（如果不存在）
              └─> 保存workflow_id
                  │
                  └─> [就绪] 可以执行工作流
                      │
                      └─> set_prompt() / set_model_parameters()
                          │
                          └─> 修改workflow_data
                              │
                              └─> execute_workflow()
                                  │
                                  ├─> 提取参数
                                  ├─> 发送prompt到云端
                                  └─> 返回task_id
                                      │
                                      └─> get_task_status()
                                          │
                                          └─> 查询任务状态
```

## ✅ 总结

整体逻辑和数据流已验证正确：

1. ✅ **初始化逻辑**：强制启用API模式，必需配置检查完整
2. ✅ **工作流管理**：只上传一次，正确复用
3. ✅ **参数修改**：本地修改，执行时发送
4. ✅ **参数提取**：智能提取，支持多种参数类型
5. ✅ **执行逻辑**：简化流程，直接调用云端API
6. ✅ **状态查询**：预留接口，待API支持

**云端API模式作为唯一连接方式已正确实现！**

