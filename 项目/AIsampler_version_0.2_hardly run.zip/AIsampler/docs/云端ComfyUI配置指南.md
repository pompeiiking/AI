# 云端ComfyUI配置指南

## 📋 概述

系统使用**ComfyOne API**连接云端ComfyUI，需要配置以下信息：
1. **API密钥**：onethingai开发者密钥
2. **实例ID**：ComfyUI实例标识符

---

## 🔧 配置步骤

### 步骤1：获取API密钥和实例ID

请从onethingai平台获取：
- **API密钥**：开发者密钥，用于API认证
- **实例ID**：你的ComfyUI实例标识符

### 步骤2：创建配置文件

在项目目录下创建以下两个文件：

#### 1. API密钥文件

**文件路径**：`config/comfyui_cloud/api_key`

**文件内容**：直接写入你的API密钥（纯文本，不要换行）

```
你的API密钥内容
```

**示例**：
```
sk-1234567890abcdefghijklmnopqrstuvwxyz
```

#### 2. 实例ID文件

**文件路径**：`config/comfyui_cloud/instance_id`

**文件内容**：直接写入你的实例ID（纯文本，不要换行）

```
你的实例ID
```

**示例**：
```
my-comfyui-instance-001
```

---

## 📁 目录结构

配置完成后，目录结构应该是：

```
AI端/AIsampler/
├── config/
│   └── comfyui_cloud/
│       ├── api_key          ← API密钥文件（必需）
│       ├── instance_id      ← 实例ID文件（必需）
│       └── workflow_cache/  ← 工作流缓存目录（自动创建）
```

---

## ✅ 验证配置

运行测试脚本验证配置：

```bash
cd AI端/AIsampler
python adapter/comfyui/test_cloud_connection.py
```

测试脚本会：
1. ✅ 检查配置文件是否存在
2. ✅ 验证配置内容是否正确
3. ✅ 测试云端API连接
4. ✅ 测试后端注册
5. ✅ 测试工作流加载（可选）

---

## 🔐 安全建议

### 1. 保护配置文件

确保配置文件权限正确（Linux/Mac）：

```bash
chmod 600 config/comfyui_cloud/api_key
chmod 600 config/comfyui_cloud/instance_id
```

### 2. 不要提交到Git

确保以下文件在 `.gitignore` 中：

```
config/comfyui_cloud/api_key
config/comfyui_cloud/instance_id
```

### 3. 使用环境变量（可选）

如果不想使用文件，可以在代码中直接配置（不推荐，但可以用于测试）：

修改 `config/comfyui_config.yaml`：

```yaml
cloud_api:
  api_key: "你的API密钥"  # 直接配置（不推荐）
  instance_id: "你的实例ID"  # 直接配置（不推荐）
```

---

## 🚀 使用示例

配置完成后，可以直接使用：

```python
from adapter.comfyui.comfyui_controller import ComfyUIController
from config.config_loader import config_loader

# 加载配置
config = config_loader.get_comfyui_config()

# 创建控制器（自动使用云端API）
controller = ComfyUIController(config=config)

# 加载工作流
controller.load_workflow()

# 设置参数
controller.set_prompt("一个美丽的风景")
controller.set_negative_prompt("模糊, 低质量")

# 执行工作流
task_id = controller.execute_workflow()
print(f"任务ID: {task_id}")

# 查询任务状态
status = controller.get_task_status(task_id)
print(f"任务状态: {status}")
```

---

## 🐛 故障排查

### 问题1：配置文件不存在

**错误信息**：
```
API密钥文件不存在: .../api_key，这是必需配置
```

**解决方法**：
1. 创建 `config/comfyui_cloud/api_key` 文件
2. 写入你的API密钥
3. 确保文件编码为UTF-8

### 问题2：API密钥或实例ID为空

**错误信息**：
```
API密钥文件为空，这是必需配置
```

**解决方法**：
1. 检查文件内容是否正确
2. 确保文件没有多余的空格或换行
3. 使用文本编辑器（如Notepad++）检查文件编码

### 问题3：后端注册失败

**错误信息**：
```
后端注册失败，这是必需步骤
```

**可能原因**：
- API密钥无效
- 实例ID不存在
- 网络连接问题
- API服务器不可达

**解决方法**：
1. 验证API密钥是否正确
2. 验证实例ID是否存在
3. 检查网络连接
4. 查看详细错误日志

### 问题4：连接超时

**错误信息**：
```
连接超时
```

**解决方法**：
1. 检查网络连接
2. 验证API服务器地址是否正确：`https://pandora-server-cf.onethingai.com`
3. 检查防火墙设置

---

## 📝 配置检查清单

- [ ] API密钥文件已创建：`config/comfyui_cloud/api_key`
- [ ] 实例ID文件已创建：`config/comfyui_cloud/instance_id`
- [ ] API密钥内容正确（非空）
- [ ] 实例ID内容正确（非空）
- [ ] 文件编码为UTF-8
- [ ] 配置文件已添加到 `.gitignore`
- [ ] 测试脚本运行成功

---

## 📚 相关文档

- [ComfyUI配置说明](../config/comfyui_config.yaml)
- [云端ComfyUI API对接说明](./云端ComfyUI API对接说明.md)
- [ComfyUI控制器代码](../adapter/comfyui/comfyui_controller.py)

---

## 🔄 更新日志

- **2024-11-10**：初始版本，支持ComfyOne API连接

