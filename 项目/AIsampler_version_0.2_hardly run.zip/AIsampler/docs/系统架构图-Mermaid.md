# 系统架构图 (Mermaid格式)

本文档包含使用Mermaid语法绘制的系统架构图，可在支持Mermaid的Markdown查看器中显示。

## 整体架构图

```mermaid
graph TB
    subgraph "应用层"
        Pipeline[EndToEndPipeline<br/>端到端流程管道]
    end
    
    subgraph "控制层"
        MainCtrl[MainController<br/>主控制器]
        AgentMgr[AgentManager<br/>Agent管理器]
        EventQ[EventQueue<br/>事件队列]
        Health[HealthChecker<br/>健康检查器]
    end
    
    subgraph "输入处理层"
        CV[CVController<br/>计算机视觉]
        STT[STTController<br/>语音识别]
    end
    
    subgraph "融合处理层"
        Fusion[FusionController<br/>多模态融合]
        Sync[TemporalSynchronizer<br/>时间同步器]
        Feature[FeatureFusion<br/>特征融合器]
        Mapper[EmotionToBoneMapper<br/>情绪到骨骼映射]
    end
    
    subgraph "适配器层"
        Blender[BlenderController<br/>Blender适配器]
        ComfyUI[ComfyUIController<br/>ComfyUI适配器]
    end
    
    subgraph "工具层"
        Preloader[ModelPreloader<br/>模型预加载器]
        Config[ConfigLoader<br/>配置加载器]
    end
    
    Pipeline --> MainCtrl
    Pipeline --> AgentMgr
    Pipeline --> Fusion
    Pipeline --> Blender
    Pipeline --> ComfyUI
    
    MainCtrl --> EventQ
    MainCtrl --> Health
    MainCtrl --> CV
    MainCtrl --> STT
    
    AgentMgr --> CV
    AgentMgr --> STT
    AgentMgr --> Fusion
    AgentMgr --> ComfyUI
    
    CV --> Fusion
    STT --> Fusion
    
    Fusion --> Sync
    Fusion --> Feature
    Fusion --> Mapper
    
    Mapper --> Blender
    AgentMgr --> Blender
    AgentMgr --> ComfyUI
    
    Preloader --> CV
    Preloader --> STT
    Preloader --> ComfyUI
    Preloader --> AgentMgr
    
    Config --> CV
    Config --> STT
    Config --> Fusion
    Config --> Blender
    Config --> ComfyUI
```

## 数据流图

```mermaid
sequenceDiagram
    participant Camera as 摄像头
    participant CV as CVController
    participant Mic as 麦克风
    participant STT as STTController
    participant Fusion as FusionController
    participant Agent as AgentManager
    participant Mapper as EmotionToBoneMapper
    participant Blender as BlenderController
    participant GenAgent as Generation Agent
    participant ComfyUI as ComfyUIController
    participant Output as 视频输出
    
    loop 实时处理循环
        Camera->>CV: 视频帧
        CV->>CV: 人脸检测
        CV->>CV: 表情识别
        CV->>Fusion: CV数据(emotion, confidence)
        
        Mic->>STT: 音频流
        STT->>STT: VAD处理
        STT->>STT: ASR识别
        STT->>Fusion: STT数据(text, confidence)
        
        Fusion->>Fusion: 时间同步
        Fusion->>Fusion: 特征融合
        Fusion->>Agent: FusionResult
        
        Agent->>Agent: Fusion Agent决策
        Agent->>Mapper: 决策结果
        
        Mapper->>Mapper: 情绪→骨骼映射
        Mapper->>Blender: 骨骼姿势
        
        Blender->>Blender: 更新骨骼
        
        alt 定时触发视频生成
            Blender->>Blender: 创建姿势快照
            Blender->>GenAgent: 快照数据
            
            GenAgent->>GenAgent: 生成提示词
            GenAgent->>ComfyUI: 提示词和配置
            
            ComfyUI->>ComfyUI: 执行工作流
            ComfyUI->>Output: 生成视频
        end
    end
```

## Agent系统架构

```mermaid
graph LR
    subgraph "AgentManager"
        CVAgent[CV Agent<br/>视觉分析]
        STTAgent[STT Agent<br/>语音分析]
        FusionAgent[Fusion Agent<br/>融合决策]
        GenAgent[Generation Agent<br/>视频生成]
        
        LLM[DeepSeek LLM<br/>LangChain]
        
        Tools[工具封装<br/>MCPToolWrapper]
    end
    
    subgraph "工具"
        BlenderTools[Blender工具<br/>- load_openpose_file<br/>- update_bone_pose<br/>- create_pose_shot]
        ComfyUITools[ComfyUI工具<br/>- load_workflow<br/>- set_prompt<br/>- execute_workflow]
    end
    
    CVAgent --> LLM
    STTAgent --> LLM
    FusionAgent --> LLM
    FusionAgent --> Tools
    GenAgent --> LLM
    GenAgent --> Tools
    
    Tools --> BlenderTools
    Tools --> ComfyUITools
```

## 模块状态机

```mermaid
stateDiagram-v2
    [*] --> UNINITIALIZED: 创建
    UNINITIALIZED --> INITIALIZING: initialize()
    INITIALIZING --> READY: 初始化成功
    INITIALIZING --> ERROR: 初始化失败
    READY --> RUNNING: start()
    RUNNING --> READY: stop()
    RUNNING --> ERROR: 运行时错误
    ERROR --> READY: 恢复成功
    READY --> STOPPED: cleanup()
    STOPPED --> [*]
```

## 融合处理流程

```mermaid
flowchart TD
    Start([开始]) --> CVData[CV数据输入]
    Start --> STTData[STT数据输入]
    
    CVData --> SyncWindow[时间同步窗口]
    STTData --> SyncWindow
    
    SyncWindow --> Align[时间戳对齐]
    Align --> Interpolate{需要插值?}
    
    Interpolate -->|是| Interp[数据插值]
    Interpolate -->|否| Extract[提取特征]
    
    Interp --> Extract
    
    Extract --> FusionMethod{融合方法}
    
    FusionMethod -->|加权平均| Weighted[加权平均融合]
    FusionMethod -->|多数投票| Vote[多数投票融合]
    FusionMethod -->|注意力| Attention[注意力融合]
    
    Weighted --> CheckConf[检查置信度]
    Vote --> CheckConf
    Attention --> CheckConf
    
    CheckConf --> Threshold{置信度<br/>>= 阈值?}
    
    Threshold -->|是| Result[生成FusionResult]
    Threshold -->|否| Neutral[使用neutral]
    
    Neutral --> Result
    Result --> Callback[触发回调]
    Callback --> End([结束])
```

## 视频生成流程

```mermaid
flowchart TD
    Start([定时触发]) --> Snapshot[创建姿势快照]
    Snapshot --> GenAgent[Generation Agent]
    
    GenAgent --> Analyze[分析情绪和快照]
    Analyze --> Generate[生成提示词]
    Generate --> Config[配置工作流参数]
    
    Config --> LoadWF{工作流已加载?}
    LoadWF -->|否| Load[加载工作流]
    LoadWF -->|是| SetPrompt[设置提示词]
    Load --> SetPrompt
    
    SetPrompt --> SetNeg[设置负面提示词]
    SetNeg --> Execute[执行工作流]
    
    Execute --> TaskID[获取任务ID]
    TaskID --> Monitor[监控任务状态]
    
    Monitor --> Status{任务状态}
    Status -->|进行中| Wait[等待]
    Wait --> Monitor
    Status -->|成功| GetVideo[获取视频路径]
    Status -->|失败| Error[记录错误]
    
    GetVideo --> Feedback[反馈循环分析]
    Feedback --> End([完成])
    Error --> End
```

## 模型预加载流程

```mermaid
flowchart TD
    Start([系统启动]) --> CheckConfig{预加载启用?}
    CheckConfig -->|否| Skip[跳过预加载]
    CheckConfig -->|是| Mode{加载模式}
    
    Mode -->|并行| Parallel[并行预加载]
    Mode -->|串行| Sequential[串行预加载]
    
    Parallel --> CVThread[CV线程]
    Parallel --> STTThread[STT线程]
    Parallel --> ComfyUIThread[ComfyUI线程]
    Parallel --> AgentThread[Agent线程]
    
    Sequential --> CVSeq[CV预加载]
    CVSeq --> STTSeq[STT预加载]
    STTSeq --> ComfyUISeq[ComfyUI预加载]
    ComfyUISeq --> AgentSeq[Agent预加载]
    
    CVThread --> CVResult[CV结果]
    STTThread --> STTResult[STT结果]
    ComfyUIThread --> ComfyUIResult[ComfyUI结果]
    AgentThread --> AgentResult[Agent结果]
    
    CVSeq --> CVResult
    STTSeq --> STTResult
    ComfyUISeq --> ComfyUIResult
    AgentSeq --> AgentResult
    
    CVResult --> Cache[缓存模块实例]
    STTResult --> Cache
    ComfyUIResult --> Cache
    AgentResult --> Cache
    
    Cache --> Ready[预加载完成]
    Skip --> Ready
    Ready --> End([系统就绪])
```

## 健康检查流程

```mermaid
flowchart TD
    Start([健康检查启动]) --> Loop[检查循环]
    Loop --> GetModules[获取所有模块]
    GetModules --> CheckModule[检查单个模块]
    
    CheckModule --> HasCallback{有回调函数?}
    HasCallback -->|是| Callback[调用回调函数]
    HasCallback -->|否| Default[默认检查]
    
    Callback --> Result{检查结果}
    Default --> Result
    
    Result -->|健康| UpdateOK[更新状态为READY]
    Result -->|不健康| UpdateError[更新状态为ERROR]
    
    UpdateOK --> NextModule[下一个模块]
    UpdateError --> RecordError[记录错误信息]
    RecordError --> NextModule
    
    NextModule --> More{还有模块?}
    More -->|是| CheckModule
    More -->|否| Wait[等待检查间隔]
    
    Wait --> Loop
```

## 事件队列处理流程

```mermaid
flowchart TD
    Start([事件产生]) --> CheckDedup{检查去重}
    CheckDedup -->|重复| Discard[丢弃事件]
    CheckDedup -->|不重复| AddSeq[添加序列号]
    
    AddSeq --> AddTime[添加时间戳]
    AddTime --> CalcPriority[计算优先级]
    CalcPriority --> Enqueue[加入队列]
    
    Enqueue --> QueueFull{队列满?}
    QueueFull -->|是| DropLow[丢弃低优先级]
    QueueFull -->|否| Success[成功]
    
    DropLow --> Success
    Discard --> End1([结束])
    Success --> End2([结束])
    
    subgraph "事件处理线程"
        GetEvent[获取事件] --> Process[处理事件]
        Process --> Callbacks[调用回调函数]
        Callbacks --> CheckTime{处理时间<br/>< 50ms?}
        CheckTime -->|是| Next[下一个事件]
        CheckTime -->|否| Warn[记录警告]
        Warn --> Next
        Next --> GetEvent
    end
```

---

## 使用说明

这些Mermaid图表可以在以下环境中查看：

1. **GitHub**: 直接在GitHub的Markdown文件中查看
2. **VS Code**: 安装Mermaid预览插件
3. **在线工具**: 
   - https://mermaid.live/
   - https://mermaid-js.github.io/mermaid-live-editor/

## 图表说明

1. **整体架构图**: 展示系统的层次结构和模块关系
2. **数据流图**: 展示数据在系统中的流动过程
3. **Agent系统架构**: 展示Agent系统的内部结构
4. **模块状态机**: 展示模块的状态转换
5. **融合处理流程**: 展示多模态融合的详细流程
6. **视频生成流程**: 展示视频生成的完整流程
7. **模型预加载流程**: 展示模型预加载的过程
8. **健康检查流程**: 展示健康检查的流程
9. **事件队列处理流程**: 展示事件队列的处理机制

