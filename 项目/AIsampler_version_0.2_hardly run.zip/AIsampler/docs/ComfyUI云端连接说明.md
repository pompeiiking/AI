# ComfyUI云端连接说明

## 📋 概述

**系统默认使用云端ComfyUI**，通过SSH隧道连接，无需在本地运行ComfyUI服务器。系统启动时会自动建立SSH隧道并连接云端服务。

---

## 🔧 配置方式

### 1. 配置文件位置

云端配置文件位于：`config/comfyui_cloud/comfyui_cloud`

### 2. 配置文件格式

```
代理命令:ssh -p 14662 root@proxy-ai.onethingai.com -CNg -L 8188:127.0.0.1:8188
密钥:k0h*yBrG^+
```

**说明**：
- `代理命令`：SSH隧道命令
- `密钥`：SSH连接密码（建议使用SSH密钥认证，更安全）

### 3. 云端模式（默认启用）

系统默认启用云端模式，在 `config/comfyui_config.yaml` 中已配置：

```yaml
server:
  url: "http://127.0.0.1:8188"       # 本地端口（SSH隧道转发）
  use_cloud: true                     # 默认启用云端模式
  cloud_config_path: "config/comfyui_cloud/comfyui_cloud"  # 云端配置文件路径
```

**注意**：如果云端配置文件存在，系统会自动启用云端模式，无需手动配置。

---

## 🚀 使用方法

### 方法1：自动启用（默认）

系统默认使用云端ComfyUI，无需任何配置：
1. 确保云端配置文件存在：`config/comfyui_cloud/comfyui_cloud`
2. 系统启动时会自动检测并启动SSH隧道
3. 直接使用即可

```python
from adapter.comfyui.comfyui_controller import ComfyUIController

# 默认使用云端ComfyUI
controller = ComfyUIController()
```

### 方法2：明确指定

```python
from adapter.comfyui.comfyui_controller import ComfyUIController

# 明确指定使用云端
controller = ComfyUIController(use_cloud=True)

# 或使用本地（如果已安装）
controller = ComfyUIController(use_cloud=False)
```

### 方法3：手动启动SSH隧道

```python
from utils.ssh_tunnel import SSHTunnel

# 启动SSH隧道
tunnel = SSHTunnel()
tunnel.start()

# 使用完毕后停止
tunnel.stop()
```

---

## 🔍 SSH隧道工作原理

### 端口转发

SSH隧道将本地端口 `8188` 转发到远程服务器的 `127.0.0.1:8188`：

```
本地应用 → localhost:8188 → SSH隧道 → 远程服务器:8188 → ComfyUI服务
```

### 命令解析

SSH命令参数说明：
- `-p 14662`：SSH服务器端口
- `root@proxy-ai.onethingai.com`：SSH服务器地址和用户名
- `-CNg`：SSH选项
  - `-C`：启用压缩
  - `-N`：不执行远程命令
  - `-g`：允许远程主机连接本地转发的端口
- `-L 8188:127.0.0.1:8188`：本地端口转发
  - 本地端口：8188
  - 远程地址：127.0.0.1:8188

---

## ⚙️ 系统要求

### Windows系统

**推荐方式**：使用SSH密钥认证

1. 生成SSH密钥对：
   ```bash
   ssh-keygen -t rsa -b 4096
   ```

2. 将公钥添加到远程服务器：
   ```bash
   ssh-copy-id -p 14662 root@proxy-ai.onethingai.com
   ```

3. 使用密钥认证（无需密码）

**备选方式**：安装 `paramiko` 库支持密码认证
```bash
pip install paramiko
```

### Linux/Mac系统

**推荐方式**：使用 `sshpass` 工具
```bash
# Ubuntu/Debian
sudo apt-get install sshpass

# macOS
brew install sshpass
```

**备选方式**：使用SSH密钥认证（更安全）

---

## 🔐 安全建议

### 1. 使用SSH密钥认证

密码认证存在安全风险，建议使用SSH密钥：

```bash
# 生成密钥对
ssh-keygen -t rsa -b 4096 -f ~/.ssh/comfyui_cloud

# 将公钥添加到服务器
ssh-copy-id -i ~/.ssh/comfyui_cloud.pub -p 14662 root@proxy-ai.onethingai.com

# 修改配置文件，使用密钥
# 代理命令:ssh -p 14662 -i ~/.ssh/comfyui_cloud root@proxy-ai.onethingai.com -CNg -L 8188:127.0.0.1:8188
```

### 2. 保护配置文件

确保配置文件权限正确：

```bash
chmod 600 config/comfyui_cloud/comfyui_cloud
```

### 3. 使用环境变量（可选）

可以将敏感信息存储在环境变量中：

```bash
export COMFYUI_CLOUD_PASSWORD="your-password"
```

---

## 🐛 故障排查

### 问题1：SSH隧道启动失败

**可能原因**：
- SSH服务器不可达
- 端口被占用
- 认证失败

**解决方法**：
```bash
# 测试SSH连接
ssh -p 14662 root@proxy-ai.onethingai.com

# 检查本地端口是否被占用
netstat -an | grep 8188

# 查看详细日志
# 系统会输出SSH错误信息
```

### 问题2：连接超时

**可能原因**：
- 网络不稳定
- SSH服务器负载高

**解决方法**：
- 增加超时时间（在 `comfyui_config.yaml` 中）
- 检查网络连接
- 联系服务器管理员

### 问题3：Windows系统密码认证失败

**解决方法**：
1. 安装 `paramiko`：`pip install paramiko`
2. 或使用SSH密钥认证
3. 或使用 `plink`（PuTTY工具）

---

## 📝 使用示例

### 完整示例

```python
from adapter.comfyui.comfyui_controller import ComfyUIController
from config.config_loader import config_loader

# 加载配置
config = config_loader.get_comfyui_config()

# 创建控制器（自动检测云端配置）
controller = ComfyUIController(config=config)

# 或明确指定使用云端
controller = ComfyUIController(use_cloud=True)

# 正常使用
controller.load_workflow()
# ... 其他操作

# 清理资源（会自动关闭SSH隧道）
controller.cleanup()
```

### 手动管理SSH隧道

```python
from utils.ssh_tunnel import SSHTunnel

# 使用上下文管理器（推荐）
with SSHTunnel() as tunnel:
    # 隧道已启动
    controller = ComfyUIController()
    # ... 使用控制器
    # 退出时自动关闭隧道

# 或手动管理
tunnel = SSHTunnel()
if tunnel.start():
    try:
        controller = ComfyUIController()
        # ... 使用控制器
    finally:
        tunnel.stop()
```

---

## ✅ 检查清单

- [ ] 云端配置文件存在：`config/comfyui_cloud/comfyui_cloud`
- [ ] SSH服务器可访问
- [ ] 本地端口8188未被占用
- [ ] 配置文件中 `use_cloud: true`
- [ ] SSH密钥或密码正确
- [ ] 系统依赖已安装（sshpass或paramiko）

---

## 📚 相关文档

- [依赖与配置检查清单](./依赖与配置检查清单.md)
- [ComfyUI配置说明](../config/comfyui_config.yaml)

---

## 🔄 更新日志

- **2024-11-10**：初始版本，支持SSH隧道连接云端ComfyUI

