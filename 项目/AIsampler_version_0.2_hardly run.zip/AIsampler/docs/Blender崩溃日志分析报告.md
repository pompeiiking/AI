# Blender崩溃日志分析报告

## 🔍 崩溃概述

**崩溃时间**: 2025-11-10  
**Blender版本**: 4.5.3  
**异常类型**: `EXCEPTION_ACCESS_VIOLATION` (内存访问违规)  
**崩溃地址**: `0x00007FF706BD3B01` (blender.exe)

## 📊 关键信息

### 1. 异常记录

```
ExceptionCode         : EXCEPTION_ACCESS_VIOLATION
Exception Address     : 0x00007FF706BD3B01
Exception Module      : blender.exe
Exception Parameters  : 0x2
    Parameters[0] : 0x0000000000000001
    Parameters[1] : 0x0000000000000078
```

### 2. 调用栈分析

崩溃发生在以下调用链中：

```
blender.exe : blender::deg::graph_id_tag_update
    ↓
blender.exe : DEG_relations_tag_update
    ↓
blender.exe : BKE_lib_id_make_local_generic
    ↓
blender.exe : BKE_lib_id_make_local
    ↓
blender.exe : BKE_blendfile_append  ⚠️ 关键位置
    ↓
blender.exe : bpy_lib_exit  ⚠️ 关键位置（bpy.data.libraries.load()退出时）
    ↓
python311.dll : PyCFunction_GetFlags
    ↓
... (Python调用栈)
    ↓
blender_socket_server.py : line 227 in execute_command
    ↓
blender_socket_server.py : line 187 in handle_client
    ↓
threading.py : 在后台线程中执行
```

### 3. Python调用栈

```
File "blender_socket_server.py", line 227 in execute_command
File "blender_socket_server.py", line 187 in handle_client
File "threading.py", line 982 in run
File "threading.py", line 1045 in _bootstrap_inner
File "threading.py", line 1002 in _bootstrap
```

## 🎯 根本原因

### **线程安全问题** ⚠️

崩溃的根本原因是：**在后台线程中调用了Blender的bpy API**

1. **问题位置**：
   - `handle_client` 函数在**后台线程**中运行（通过 `threading.Thread` 创建）
   - `execute_command` 在后台线程中被调用
   - `bpy.data.libraries.load()` 在后台线程中执行

2. **Blender的限制**：
   - Blender的 `bpy` API **必须在主线程中调用**
   - 在后台线程中调用会导致内存访问违规和崩溃
   - `bpy.data.libraries.load()` 的上下文管理器退出时（`bpy_lib_exit`）会更新依赖图（DEG），这必须在主线程中进行

3. **崩溃触发点**：
   - 当 `with bpy.data.libraries.load(file_path) as (data_from, data_to):` 退出时
   - Blender尝试更新依赖图（`DEG_relations_tag_update`）
   - 但此时在后台线程中，导致内存访问违规

## ✅ 解决方案

### 方案1：使用命令队列 + bpy.app.timers（推荐）

将命令执行从后台线程移到主线程：

1. **后台线程**：接收Socket命令，放入队列
2. **主线程**：使用 `bpy.app.timers` 定期处理队列中的命令
3. **结果返回**：通过事件机制通知后台线程

**优点**：
- 完全线程安全
- 符合Blender的设计规范
- 不会阻塞主线程

**实现要点**：
```python
# 命令队列（线程安全）
command_queue = queue.Queue()

# 结果字典（带锁）
command_results = {}
result_lock = threading.Lock()

def handle_client(client_socket, address):
    """在后台线程中：接收命令，放入队列"""
    command = json.loads(data.decode('utf-8'))
    command_id = str(uuid.uuid4())
    result_event = threading.Event()
    
    # 放入队列（主线程会处理）
    command_queue.put({
        'id': command_id,
        'command': command,
        'event': result_event
    })
    
    # 等待结果
    result_event.wait(timeout=30.0)
    result = command_results.pop(command_id)
    # 发送响应...

def process_command_queue():
    """在主线程中：处理队列中的命令"""
    try:
        queue_item = command_queue.get_nowait()
        command = queue_item['command']
        result = execute_command_safe(command)  # 在主线程中执行
        command_results[queue_item['id']] = result
        queue_item['event'].set()  # 通知等待的线程
    except queue.Empty:
        pass
    return 0.01  # 0.01秒后再次检查

# 注册定时器（在主线程中）
bpy.app.timers.register(process_command_queue)
```

### 方案2：禁用自动加载（临时方案）

如果暂时无法修复线程安全问题，可以禁用自动加载：

```yaml
# config/blender_config.yaml
paths:
  auto_load_on_init: false
socket:
  auto_load_on_connect: false
```

然后手动在Blender中导入文件。

## 🔧 修复状态

### 当前代码问题

查看用户修改后的代码，发现：
- 用户已经**回退**到了旧版本（版本1.1.0）
- 旧版本**没有**使用命令队列机制
- 仍然在后台线程中直接调用 `bpy.data.libraries.load()`

### 需要修复的代码

`blender_socket_server.py` 需要实现：

1. ✅ 命令队列机制
2. ✅ `bpy.app.timers` 定时器
3. ✅ 线程安全的结果传递
4. ✅ 在主线程中执行所有bpy操作

## 📝 修复步骤

1. **实现命令队列**：
   ```python
   import queue
   command_queue = queue.Queue()
   command_results = {}
   result_lock = threading.Lock()
   ```

2. **修改 `handle_client`**：
   - 接收命令后放入队列
   - 等待结果事件
   - 发送响应

3. **实现 `process_command_queue`**：
   - 使用 `bpy.app.timers.register()` 注册
   - 从队列获取命令
   - 在主线程中执行
   - 存储结果并通知等待的线程

4. **修改 `start_server`**：
   - 注册定时器

5. **修改 `stop_server`**：
   - 取消注册定时器

## ⚠️ 注意事项

1. **所有bpy操作必须在主线程**：
   - `bpy.data.libraries.load()`
   - `bpy.context.collection.objects.link()`
   - `bpy.ops.object.mode_set()`
   - 任何访问 `bpy.context` 的操作

2. **Socket操作可以在后台线程**：
   - `socket.recv()`
   - `socket.send()`
   - JSON解析

3. **测试建议**：
   - 在修复后，多次测试文件加载
   - 测试并发连接
   - 监控内存使用

## 📚 参考

- [Blender Python API文档](https://docs.blender.org/api/current/)
- [Blender线程安全说明](https://docs.blender.org/api/current/info_gotcha.html#threading)
- [bpy.app.timers文档](https://docs.blender.org/api/current/bpy.app.timers.html)

