# Blender骨骼设置指南

## 问题描述

测试时出现错误：`骨骼更新失败: 未找到armature对象`

## 原因

Blender Socket服务器已连接，但场景中没有加载armature（骨架）对象。

## 解决方案

### 方法1：在Blender中手动加载骨架

1. **打开Blender**
2. **导入骨架文件**：
   - File → Import → FBX (.fbx) 或 BVH (.bvh)
   - 选择你的骨架文件（如OpenPose骨骼文件）
   
3. **确认Armature对象**：
   - 在Outliner中应该看到一个"Armature"对象
   - 选中它，在Properties面板应该看到骨骼列表

4. **启动Socket服务器**：
   - 运行Blender插件的Socket服务器脚本
   - 确保端口是8888（或配置文件中指定的端口）

### 方法2：使用程序自动加载

使用 `BlenderController.load_openpose_file()` 方法：

```python
from adapter.blender.blender_controller import BlenderController

blender = BlenderController()
blender.load_openpose_file("path/to/openpose_skeleton.json")
```

### 方法3：创建默认骨架

如果没有骨架文件，可以在Blender中创建一个简单的骨架：

```python
# 在Blender中运行（Python控制台）:
import bpy

# 添加Armature
bpy.ops.object.armature_add(location=(0, 0, 0))
armature = bpy.context.active_object
armature.name = "Body_Armature"

# 进入编辑模式创建基本骨骼
bpy.ops.object.mode_set(mode='EDIT')
edit_bones = armature.data.edit_bones

# 创建头部骨骼
head = edit_bones.new('Head')
head.head = (0, 0, 1.5)
head.tail = (0, 0, 1.7)

# 创建脊柱骨骼
spine = edit_bones.new('Spine')
spine.head = (0, 0, 0.8)
spine.tail = (0, 0, 1.5)

# 创建肩膀骨骼
shoulder_l = edit_bones.new('Shoulder_L')
shoulder_l.head = (0.2, 0, 1.4)
shoulder_l.tail = (0.5, 0, 1.4)

shoulder_r = edit_bones.new('Shoulder_R')
shoulder_r.head = (-0.2, 0, 1.4)
shoulder_r.tail = (-0.5, 0, 1.4)

# 返回对象模式
bpy.ops.object.mode_set(mode='OBJECT')
```

## 验证设置

运行以下Python代码验证Blender连接和骨架：

```python
from adapter.blender.blender_controller import BlenderController

blender = BlenderController()

# 检查连接
if blender.socket_client:
    print("✓ Blender Socket已连接")
    
    # 测试骨骼更新
    result = blender.update_bone_pose('Head', rotation=[0.1, 0.0, 0.0])
    if result:
        print("✓ 骨骼更新成功")
    else:
        print("✗ 骨骼更新失败 - 请确保场景中有Armature对象")
else:
    print("✗ Blender未连接")
```

## Blender Socket服务器脚本

在Blender中运行以下脚本启动Socket服务器：

```python
import bpy
import socket
import json
import threading

class BlenderSocketServer:
    def __init__(self, host='localhost', port=8888):
        self.host = host
        self.port = port
        self.server = None
        self.running = False
        
    def start(self):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.bind((self.host, self.port))
        self.server.listen(5)
        self.running = True
        print(f"Blender Socket服务器启动: {self.host}:{self.port}")
        
        def accept_connections():
            while self.running:
                try:
                    client, addr = self.server.accept()
                    threading.Thread(target=self.handle_client, args=(client,)).start()
                except:
                    break
        
        threading.Thread(target=accept_connections, daemon=True).start()
    
    def handle_client(self, client):
        try:
            data = client.recv(4096).decode('utf-8')
            command = json.loads(data)
            
            if command['action'] == 'update_bone':
                bone_name = command['bone_name']
                rotation = command.get('rotation')
                
                # 更新骨骼
                armature = bpy.data.objects.get('Body_Armature')
                if armature and bone_name in armature.pose.bones:
                    bone = armature.pose.bones[bone_name]
                    if rotation:
                        bone.rotation_euler = rotation
                    
                    response = {'success': True}
                else:
                    response = {'success': False, 'error': '未找到armature对象'}
            else:
                response = {'success': False, 'error': '未知命令'}
            
            client.send(json.dumps(response).encode('utf-8'))
        finally:
            client.close()

# 启动服务器
server = BlenderSocketServer()
server.start()
```

## 推荐骨架命名规范

确保骨骼名称与系统中的映射一致：

```
c_head.x       → Head
c_spine_01.x   → Spine
c_shoulder.l   → Shoulder_L
c_shoulder.r   → Shoulder_R
```

或在配置中调整骨骼名称映射。
