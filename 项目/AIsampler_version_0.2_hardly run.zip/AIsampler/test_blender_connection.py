#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Blender连接和骨骼加载诊断工具
测试Blender Socket连接、骨骼加载和更新功能
"""

import sys
import os
from pathlib import Path

# 添加项目根目录到路径
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

import json
import socket
import time


def test_blender_connection():
    """测试Blender Socket连接"""
    print("=" * 80)
    print("🔍 Blender Socket连接诊断工具")
    print("=" * 80)
    
    host = 'localhost'
    port = 8888
    
    print(f"\n[1] 测试连接到 {host}:{port}...")
    
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.settimeout(5.0)
        client.connect((host, port))
        print("  ✓ 连接成功！")
        
        # 测试ping
        print("\n[2] 测试ping命令...")
        ping_cmd = json.dumps({'type': 'ping'})
        client.send(ping_cmd.encode('utf-8'))
        response = client.recv(4096).decode('utf-8')
        result = json.loads(response)
        
        if result.get('success'):
            print(f"  ✓ Ping成功: {result.get('message')}")
        else:
            print(f"  ✗ Ping失败: {result.get('error')}")
            return False
        
        # 测试获取骨骼位置（这会告诉我们是否有armature）
        print("\n[3] 检查是否存在Armature...")
        get_bone_cmd = json.dumps({'type': 'get_bone_position'})
        client.send(get_bone_cmd.encode('utf-8'))
        
        # 接收可能很大的响应
        response_data = b""
        while True:
            chunk = client.recv(8192)
            response_data += chunk
            if len(chunk) < 8192:
                break
        
        response = response_data.decode('utf-8')
        result = json.loads(response)
        
        if result.get('success'):
            bones = result.get('data', {})
            
            if bones:
                print(f"  ✓ 发现Armature对象，包含 {len(bones)} 个骨骼")
                print(f"    示例骨骼: {list(bones.keys())[:3]}")
                return True, client
            else:
                print(f"  ⚠️ 场景中没有Armature对象或骨骼")
                print(f"  ℹ️ 需要加载骨骼文件")
                
                # 尝试加载骨骼文件
                print("\n[4] 尝试加载骨骼文件...")
                return load_bone_file(client)
        else:
            # get_bone_position失败通常意味着没有armature
            print(f"  ⚠️ 无法获取骨骼信息（可能没有Armature）")
            print(f"  ℹ️ 尝试加载骨骼文件...")
            
            # 尝试加载骨骼文件
            print("\n[4] 尝试加载骨骼文件...")
            return load_bone_file(client)
            
    except socket.timeout:
        print("  ✗ 连接超时")
        print("  ℹ️ 请确认Blender Socket服务器已启动")
        return False, None
    except ConnectionRefusedError:
        print("  ✗ 连接被拒绝")
        print("  ℹ️ 请在Blender中启动Socket服务器")
        print("     1. 按N键打开侧边栏")
        print("     2. 找到'Blender Socket'标签")
        print("     3. 点击'启动服务器'")
        return False, None
    except Exception as e:
        print(f"  ✗ 连接失败: {e}")
        return False, None


def load_bone_file(client):
    """加载骨骼文件"""
    # 获取骨骼文件的绝对路径
    bone_file = PROJECT_ROOT / "adapter" / "blender" / "openpose" / "openpose_bone.blend"
    
    if not bone_file.exists():
        print(f"  ✗ 骨骼文件不存在: {bone_file}")
        return False, None
    
    print(f"  • 骨骼文件路径: {bone_file}")
    
    # 发送加载命令
    load_cmd = json.dumps({
        'type': 'load_openpose_file',
        'file_path': str(bone_file)
    })
    
    try:
        client.send(load_cmd.encode('utf-8'))
        response = client.recv(8192).decode('utf-8')
        result = json.loads(response)
        
        if result.get('success'):
            print(f"  ✓ 骨骼文件加载成功！")
            print(f"    {result.get('message')}")
            return True, client
        else:
            print(f"  ✗ 骨骼文件加载失败: {result.get('error')}")
            return False, None
    except Exception as e:
        print(f"  ✗ 加载命令发送失败: {e}")
        return False, None


def test_bone_update(client):
    """测试骨骼更新"""
    print("\n[5] 测试骨骼更新...")
    
    # 测试更新Head骨骼
    test_bones = ['Head', 'c_head.x', 'Spine', 'c_spine_01.x']
    
    for bone_name in test_bones:
        update_cmd = json.dumps({
            'type': 'update_bone_pose',
            'bone_name': bone_name,
            'rotation': [0.1, 0.0, 0.0]
        })
        
        try:
            client.send(update_cmd.encode('utf-8'))
            response = client.recv(4096).decode('utf-8')
            result = json.loads(response)
            
            if result.get('success'):
                print(f"  ✓ 骨骼 '{bone_name}' 更新成功")
                return True
            else:
                error = result.get('error', 'Unknown')
                if '未找到骨骼' in error:
                    # 继续尝试其他骨骼名称
                    continue
                else:
                    print(f"  ⚠️ 骨骼 '{bone_name}' 更新失败: {error}")
        except Exception as e:
            print(f"  ✗ 更新命令发送失败: {e}")
            return False
    
    print(f"  ✗ 未找到任何可用的骨骼名称")
    print(f"  ℹ️ 尝试的骨骼: {test_bones}")
    return False


def get_available_bones(client):
    """获取可用的骨骼列表"""
    print("\n[6] 获取可用骨骼列表...")
    
    get_cmd = json.dumps({'type': 'get_bone_position'})
    
    try:
        client.send(get_cmd.encode('utf-8'))
        
        # 接收可能很大的响应
        response_data = b""
        client.settimeout(5.0)
        while True:
            try:
                chunk = client.recv(16384)
                if not chunk:
                    break
                response_data += chunk
                if len(chunk) < 16384:
                    break
            except socket.timeout:
                break
        
        response = response_data.decode('utf-8')
        result = json.loads(response)
        
        if result.get('success'):
            bones = result.get('data', {})
            print(f"  ✓ 发现 {len(bones)} 个骨骼:")
            for i, bone_name in enumerate(list(bones.keys())[:10], 1):
                print(f"    {i}. {bone_name}")
            
            if len(bones) > 10:
                print(f"    ... 还有 {len(bones) - 10} 个骨骼")
            
            return True, bones
        else:
            print(f"  ✗ 获取骨骼列表失败: {result.get('error')}")
            return False, {}
    except Exception as e:
        print(f"  ✗ 获取命令发送失败: {e}")
        return False, {}


def main():
    """主函数"""
    has_armature, client = test_blender_connection()
    
    if not client:
        print("\n" + "=" * 80)
        print("❌ Blender连接失败")
        print("=" * 80)
        return 1
    
    if not has_armature:
        print("\n" + "=" * 80)
        print("❌ 骨骼加载失败")
        print("=" * 80)
        client.close()
        return 1
    
    # 获取骨骼列表
    success, bones = get_available_bones(client)
    
    if success:
        # 测试骨骼更新
        if test_bone_update(client):
            print("\n" + "=" * 80)
            print("✅ Blender连接和骨骼功能完全正常！")
            print("=" * 80)
            client.close()
            return 0
        else:
            print("\n" + "=" * 80)
            print("⚠️ Blender连接正常，但骨骼更新失败")
            print("=" * 80)
            client.close()
            return 1
    else:
        print("\n" + "=" * 80)
        print("⚠️ Blender连接正常，但无法获取骨骼信息")
        print("=" * 80)
        client.close()
        return 1


if __name__ == "__main__":
    sys.exit(main())
