# 文本输入模块 - 快速开始

## ✨ 新增功能

系统现已支持**文本输入**作为第三种多模态输入通道（与CV和STT并列）！

```
原来：CV（视觉）+ STT（语音）
现在：CV（视觉）+ STT（语音）+ Text（文本）✨
```

---

## 🚀 快速测试

### 1. 基础功能测试（2分钟）

```bash
python test_text_input.py
```

**测试内容**：
- ✅ 情感检测
- ✅ 文本处理
- ✅ 融合集成

### 2. 流式输入测试（交互式）

```bash
python test_text_stream.py
```

**操作示例**：
```
> 我今天很开心！
✓ 情感: happy (0.90)

> 有点担心明天的事情
✓ 情感: fear (0.75)

> quit
```

### 3. 多模态融合测试（3分钟）

```bash
python test_multimodal_text_fusion.py
```

**测试内容**：
- ✅ CV + STT + Text 三模态融合
- ✅ 数据源权重计算
- ✅ 冲突检测

---

## 💡 使用示例

### 方式1: 独立使用

```python
from parts.text.text_controller import TextController

text_controller = TextController()

# 单次输入
result = text_controller.console_input()

# 或流式输入
text_controller.stream_input(callback=my_callback)
```

### 方式2: 集成到Pipeline（推荐）

```python
from controller.pipeline import EndToEndPipeline

pipeline = EndToEndPipeline()
pipeline.start()  # 自动启动CV、STT、Text三种输入
```

文本输入会**自动**参与多模态融合！

---

## 📋 核心特性

| 特性 | 说明 |
|------|------|
| **多种输入模式** | 控制台、文件、API、流式 |
| **情感检测** | 6种情感类型，基于关键词 |
| **多模态融合** | 与CV/STT自动融合 |
| **线程安全** | 内置异步处理 |
| **灵活配置** | YAML配置文件 |

---

## 🎯 情感检测

支持的情感类型：

| 情感 | 示例关键词 |
|------|-----------|
| `happy` | 开心、高兴、快乐、太好了 |
| `sad` | 难过、低落、伤心、失望 |
| `angry` | 生气、愤怒、讨厌、不爽 |
| `surprise` | 意外、惊讶、震惊、天哪 |
| `fear` | 害怕、担心、紧张、焦虑 |
| `neutral` | 嗯、好的、知道了、明白 |

---

## 📁 新增文件

```
parts/text/
  ├── __init__.py                        # 模块初始化
  └── text_controller.py                 # 核心控制器 ⭐

config/
  └── text_config.yaml                   # 配置文件

测试脚本:
  ├── test_text_input.py                 # 基础功能测试
  ├── test_text_stream.py                # 流式输入测试
  └── test_multimodal_text_fusion.py    # 多模态融合测试

文档:
  ├── TEXT_INPUT_GUIDE.md                # 完整使用指南 📖
  └── TEXT_INPUT_QUICK_START.md          # 快速开始（本文件）
```

---

## 🔧 配置

配置文件位于 `config/text_config.yaml`

```yaml
input:
  mode: stream                      # 输入模式
  enable_emotion_detection: true    # 启用情感检测
  min_text_length: 1
  max_text_length: 500

emotion_keywords:
  happy: [开心, 高兴, 快乐, ...]
  sad: [难过, 低落, 伤心, ...]
  # ... 更多配置
```

---

## ⚡ 集成说明

### MainController 更新

新增方法：
- `start_text_stream()` - 启动文本流式输入

### Pipeline 更新

自动启动文本输入流，数据自动融合到 `FusionController`

### 数据流

```
文本输入 → TextController → 情感检测 → FusionController
                                          ↓
                              CV + STT + Text 融合
                                          ↓
                              AgentManager → Blender → ComfyUI
```

---

## 📚 详细文档

完整使用指南请查看：[TEXT_INPUT_GUIDE.md](TEXT_INPUT_GUIDE.md)

内容包括：
- 详细API参考
- 配置说明
- 使用示例
- 常见问题
- 版本历史

---

## ❓ 常见问题

### Q: 如何添加自定义情感关键词？

编辑 `config/text_config.yaml`：

```yaml
emotion_keywords:
  my_emotion:
    - 关键词1
    - 关键词2
```

### Q: 如何在Pipeline中使用文本输入？

直接启动Pipeline即可，文本输入已自动集成：

```python
pipeline = EndToEndPipeline()
pipeline.start()  # 包含Text输入
```

### Q: 文本输入如何与CV/STT融合？

自动融合！系统会：
1. 检测文本情感
2. 添加到 `FusionController`
3. 与CV/STT数据时间同步
4. 按权重融合（默认权重 cv:0.4, stt:0.4, text:0.2）

---

## 🎉 总结

✅ **已完成**：
- [x] TextController 核心模块
- [x] 配置文件和加载器
- [x] MainController 集成
- [x] Pipeline 集成
- [x] 多模态融合支持
- [x] 完整测试套件
- [x] 使用文档

🎯 **下一步**：
- 运行测试脚本验证功能
- 根据需求调整配置
- 集成到实际应用场景

---

**享受多模态文本输入带来的新能力！** 🚀
