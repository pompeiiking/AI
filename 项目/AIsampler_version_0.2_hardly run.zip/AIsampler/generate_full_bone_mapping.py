#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动生成完整的骨骼映射配置
从Blender获取所有骨骼并生成情感映射
"""

import json
import socket
import yaml
from pathlib import Path
from typing import Dict, List, Tuple

PROJECT_ROOT = Path(__file__).resolve().parent


class BoneMappingGenerator:
    """骨骼映射生成器"""
    
    def __init__(self):
        # 骨骼分类规则（基于名称关键词）
        self.bone_categories = {
            'head': ['head', 'neck', 'c_head'],
            'spine': ['spine', 'c_spine', 'torso', 'chest'],
            'shoulder': ['shoulder', 'c_shoulder', 'clavicle'],
            'arm_upper': ['arm', 'c_arm', 'upperarm'],
            'arm_lower': ['forearm', 'c_forearm'],
            'hand': ['hand', 'c_hand', 'wrist'],
            'finger_thumb': ['thumb'],
            'finger_index': ['index'],
            'finger_middle': ['middle'],
            'finger_ring': ['ring'],
            'finger_pinky': ['pinky', 'little'],
            'leg_upper': ['thigh', 'upleg'],
            'leg_lower': ['shin', 'calf', 'leg.', 'leg_'],
            'foot': ['foot', 'ankle'],
            'toe': ['toe'],
            'eye': ['eye'],
            'jaw': ['jaw', 'mouth'],
            'pelvis': ['pelvis', 'hip'],
        }
        
        # 每种情感的骨骼类别旋转模板
        self.emotion_templates = {
            'happy': {
                'head': [0.3, 0.0, 0.45],      # 头部上扬
                'spine': [0.15, 0.0, 0.0],     # 挺直
                'shoulder': [0.0, 0.0, -0.6],  # 放松（左右相反）
                'arm_upper': [0.0, -0.3, 0.2], # 手臂微张
                'arm_lower': [0.0, 0.0, -0.2],
                'hand': [0.0, 0.0, 0.1],       # 手掌微展
                'finger_thumb': [0.0, 0.0, 0.2],
                'finger_index': [0.0, 0.0, 0.1],
                'finger_middle': [0.0, 0.0, 0.1],
                'finger_ring': [0.0, 0.0, 0.1],
                'finger_pinky': [0.0, 0.0, 0.1],
            },
            'sad': {
                'head': [-0.45, 0.0, 0.0],     # 低头
                'spine': [-0.3, 0.0, 0.0],     # 弯曲
                'shoulder': [0.3, 0.0, 0.45],  # 耸肩
                'arm_upper': [0.0, 0.2, -0.3], # 手臂下垂
                'arm_lower': [0.0, 0.0, 0.3],
                'hand': [0.0, 0.0, -0.2],      # 手掌内收
                'finger_thumb': [0.0, 0.0, -0.1],
                'finger_index': [0.0, 0.0, -0.1],
                'finger_middle': [0.0, 0.0, -0.1],
                'finger_ring': [0.0, 0.0, -0.1],
                'finger_pinky': [0.0, 0.0, -0.1],
            },
            'angry': {
                'head': [0.15, 0.0, 0.0],      # 前倾
                'spine': [0.15, 0.0, 0.0],     # 身体前倾
                'shoulder': [0.45, 0.0, 0.9],  # 紧张
                'arm_upper': [0.0, -0.5, 0.5], # 手臂张开
                'arm_lower': [0.0, 0.0, -0.4],
                'hand': [0.0, 0.0, 0.3],       # 握拳姿态
                'finger_thumb': [0.0, 0.0, 0.4],
                'finger_index': [0.0, 0.0, 0.5],
                'finger_middle': [0.0, 0.0, 0.5],
                'finger_ring': [0.0, 0.0, 0.5],
                'finger_pinky': [0.0, 0.0, 0.5],
            },
            'surprise': {
                'head': [0.2, 0.0, 0.0],       # 后仰
                'spine': [-0.05, 0.0, 0.0],
                'shoulder': [-0.1, 0.0, -0.15],
                'arm_upper': [0.0, -0.4, 0.3],
                'arm_lower': [0.0, 0.0, -0.3],
                'hand': [0.0, 0.0, 0.2],
                'finger_thumb': [0.0, 0.0, 0.3],
                'finger_index': [0.0, 0.0, 0.2],
                'finger_middle': [0.0, 0.0, 0.2],
                'finger_ring': [0.0, 0.0, 0.2],
                'finger_pinky': [0.0, 0.0, 0.2],
            },
            'neutral': {
                # 所有骨骼回到中性位置
                'head': [0.0, 0.0, 0.0],
                'spine': [0.0, 0.0, 0.0],
                'shoulder': [0.0, 0.0, 0.0],
                'arm_upper': [0.0, 0.0, 0.0],
                'arm_lower': [0.0, 0.0, 0.0],
                'hand': [0.0, 0.0, 0.0],
                'finger_thumb': [0.0, 0.0, 0.0],
                'finger_index': [0.0, 0.0, 0.0],
                'finger_middle': [0.0, 0.0, 0.0],
                'finger_ring': [0.0, 0.0, 0.0],
                'finger_pinky': [0.0, 0.0, 0.0],
            },
            'fear': {
                'head': [-0.1, 0.0, 0.0],
                'spine': [-0.15, 0.0, 0.0],
                'shoulder': [0.2, 0.0, 0.2],
                'arm_upper': [0.0, 0.3, -0.4],  # 手臂护胸
                'arm_lower': [0.0, 0.0, 0.5],
                'hand': [0.0, 0.0, -0.3],
                'finger_thumb': [0.0, 0.0, -0.2],
                'finger_index': [0.0, 0.0, -0.2],
                'finger_middle': [0.0, 0.0, -0.2],
                'finger_ring': [0.0, 0.0, -0.2],
                'finger_pinky': [0.0, 0.0, -0.2],
            },
            'disgust': {
                'head': [0.0, 0.1, -0.15],     # 头部偏转
                'spine': [0.0, 0.0, -0.05],
                'shoulder': [0.1, 0.0, 0.1],
                'arm_upper': [0.0, 0.2, -0.2],
                'arm_lower': [0.0, 0.0, 0.2],
                'hand': [0.0, 0.0, -0.1],
                'finger_thumb': [0.0, 0.0, -0.1],
                'finger_index': [0.0, 0.0, -0.1],
                'finger_middle': [0.0, 0.0, -0.1],
                'finger_ring': [0.0, 0.0, -0.1],
                'finger_pinky': [0.0, 0.0, -0.1],
            },
        }
    
    def get_all_bones_from_blender(self) -> List[str]:
        """从Blender获取所有骨骼名称"""
        try:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.settimeout(5.0)
            client.connect(('localhost', 8888))
            
            # 发送获取骨骼命令
            get_cmd = json.dumps({'type': 'get_bone_position'})
            client.send(get_cmd.encode('utf-8'))
            
            # 接收响应
            response_data = b""
            while True:
                try:
                    chunk = client.recv(16384)
                    if not chunk:
                        break
                    response_data += chunk
                    if len(chunk) < 16384:
                        break
                except socket.timeout:
                    break
            
            response = response_data.decode('utf-8')
            result = json.loads(response)
            
            if result.get('success'):
                bones = list(result.get('data', {}).keys())
                print(f"✓ 从Blender获取到 {len(bones)} 个骨骼")
                return bones
            else:
                print(f"✗ 获取骨骼失败: {result.get('error')}")
                return []
        
        except Exception as e:
            print(f"✗ 连接Blender失败: {e}")
            return []
        finally:
            client.close()
    
    def classify_bone(self, bone_name: str) -> str:
        """将骨骼分类"""
        bone_lower = bone_name.lower()
        
        # 检查是否匹配任何类别
        for category, keywords in self.bone_categories.items():
            if any(kw in bone_lower for kw in keywords):
                return category
        
        return 'other'
    
    def generate_rotation_for_bone(self, bone_name: str, emotion: str) -> List[float]:
        """为特定骨骼和情感生成旋转值"""
        category = self.classify_bone(bone_name)
        template = self.emotion_templates.get(emotion, {})
        rotation = template.get(category, [0.0, 0.0, 0.0]).copy()
        
        # 左右侧对称处理
        if '.r' in bone_name.lower() or '_r' in bone_name.lower() or 'right' in bone_name.lower():
            # 右侧骨骼，Z轴旋转反向
            rotation[2] = -rotation[2]
        
        return rotation
    
    def generate_full_mapping(self, bones: List[str]) -> Dict:
        """生成完整的骨骼映射"""
        print("\n开始生成完整骨骼映射...")
        
        mapping = {}
        
        for emotion in self.emotion_templates.keys():
            print(f"\n生成 '{emotion}' 的映射...")
            bone_list = []
            
            # 统计分类
            category_counts = {}
            
            for bone_name in bones:
                rotation = self.generate_rotation_for_bone(bone_name, emotion)
                bone_list.append({
                    'name': bone_name,
                    'rotation': rotation
                })
                
                category = self.classify_bone(bone_name)
                category_counts[category] = category_counts.get(category, 0) + 1
            
            mapping[emotion] = {
                'bones': bone_list,
                'intensity_scale': 1.0
            }
            
            print(f"  ✓ 生成了 {len(bone_list)} 个骨骼映射")
            print(f"  分类统计: {dict(sorted(category_counts.items(), key=lambda x: x[1], reverse=True)[:5])}")
        
        return mapping
    
    def save_to_yaml(self, mapping: Dict, output_file: Path):
        """保存映射到YAML文件"""
        with open(output_file, 'w', encoding='utf-8') as f:
            yaml.dump(mapping, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
        print(f"\n✓ 映射已保存到: {output_file}")
    
    def save_to_python(self, mapping: Dict, output_file: Path):
        """保存映射到Python文件"""
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("#!/usr/bin/env python3\n")
            f.write("# -*- coding: utf-8 -*-\n")
            f.write('"""\n')
            f.write("自动生成的完整骨骼映射配置\n")
            f.write(f"包含 {len(mapping)} 种情感的完整骨骼映射\n")
            f.write('"""\n\n')
            f.write("FULL_BONE_MAPPINGS = ")
            f.write(json.dumps(mapping, indent=4, ensure_ascii=False))
            f.write("\n")
        print(f"✓ Python映射已保存到: {output_file}")
    
    def generate_summary(self, mapping: Dict):
        """生成映射摘要"""
        print("\n" + "=" * 80)
        print("📊 完整骨骼映射摘要")
        print("=" * 80)
        
        for emotion, config in mapping.items():
            bones = config['bones']
            print(f"\n{emotion.upper()}:")
            print(f"  • 映射骨骼数: {len(bones)}")
            
            # 统计非零旋转的骨骼
            non_zero = sum(1 for b in bones if any(abs(r) > 0.01 for r in b['rotation']))
            print(f"  • 非零旋转: {non_zero}")
            
            # 显示前5个骨骼
            print(f"  • 示例骨骼:")
            for bone in bones[:5]:
                rot = bone['rotation']
                print(f"    - {bone['name']}: [{rot[0]:.2f}, {rot[1]:.2f}, {rot[2]:.2f}]")


def main():
    """主函数"""
    print("=" * 80)
    print("🎬 完整骨骼映射生成器")
    print("=" * 80)
    
    generator = BoneMappingGenerator()
    
    # 1. 从Blender获取所有骨骼
    print("\n[步骤1] 从Blender获取所有骨骼...")
    bones = generator.get_all_bones_from_blender()
    
    if not bones:
        print("\n❌ 无法获取骨骼列表")
        print("请确保:")
        print("  1. Blender正在运行")
        print("  2. Blender Socket服务器已启动")
        print("  3. 骨架文件已加载")
        return 1
    
    # 2. 生成完整映射
    print("\n[步骤2] 生成完整骨骼映射...")
    mapping = generator.generate_full_mapping(bones)
    
    # 3. 保存映射
    print("\n[步骤3] 保存映射文件...")
    
    # 保存为YAML
    yaml_file = PROJECT_ROOT / "config" / "full_bone_mapping.yaml"
    yaml_file.parent.mkdir(exist_ok=True)
    generator.save_to_yaml(mapping, yaml_file)
    
    # 保存为Python
    py_file = PROJECT_ROOT / "config" / "full_bone_mapping.py"
    generator.save_to_python(mapping, py_file)
    
    # 4. 生成摘要
    generator.generate_summary(mapping)
    
    print("\n" + "=" * 80)
    print("✅ 完整骨骼映射生成完成！")
    print("=" * 80)
    print(f"\n使用方法:")
    print(f"  1. YAML配置: mapper = EmotionToBoneMapper(mapping_file='{yaml_file}')")
    print(f"  2. Python导入: from config.full_bone_mapping import FULL_BONE_MAPPINGS")
    
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
