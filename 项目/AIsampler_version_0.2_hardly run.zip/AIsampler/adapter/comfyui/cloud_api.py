# -*- coding: utf-8 -*-
"""
云端ComfyUI API客户端
基于ComfyOne API实现云端工作流管理
"""

import requests
import json
import time
import logging
from typing import Dict, Any, Optional, List
from pathlib import Path


class CloudComfyUIAPI:
    """
    云端ComfyUI API客户端
    
    功能：
    1. 注册后端实例
    2. 创建工作流（初始化时一次）
    3. 发送prompt参数（后续调用）
    """
    
    def __init__(self, base_url: str, api_key: str, instance_id: str, logger: Optional[logging.Logger] = None):
        """
        初始化云端API客户端
        
        Args:
            base_url: ComfyOne API基础URL
            api_key: onethingai开发者密钥
            instance_id: 实例ID
            logger: 日志记录器
        """
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.instance_id = instance_id
        self.logger = logger or logging.getLogger(__name__)
        self.workflow_id = None  # 保存工作流ID
        self.workflow_cache_file = None  # 工作流缓存文件路径
        
    def _request_api(self, api: str, payload: Optional[dict] = None, method: str = "GET") -> Optional[dict]:
        """
        向ComfyOne API发送请求的通用函数
        
        Args:
            api: API路径
            payload: 请求体数据
            method: HTTP请求方法
            
        Returns:
            dict: API响应数据，失败返回None
        """
        url = f"{self.base_url}/{api}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        
        try:
            retry_count = 0
            max_retries = 3
            while retry_count < max_retries:
                try:
                    if payload:
                        response = requests.request(method, url, headers=headers, json=payload, timeout=30)
                    else:
                        response = requests.request(method, url, headers=headers, timeout=30)
                    response.raise_for_status()
                    return response.json()
                except requests.exceptions.Timeout:
                    retry_count += 1
                    if retry_count == max_retries:
                        raise
                    time.sleep(2 ** retry_count)  # 指数退避
                    continue
                except requests.exceptions.RequestException as e:
                    self.logger.error(f"API请求失败: {e}")
                    retry_count += 1
                    if retry_count == max_retries:
                        return {"error": str(e), "code": -1}
                    time.sleep(2 ** retry_count)
                    continue
        except Exception as e:
            self.logger.error(f"请求 {api} 失败: {e}")
            return None
    
    def get_available_backends(self) -> Optional[dict]:
        """查询所有可用的后端服务实例"""
        api = "v1/backends"
        return self._request_api(api, method="GET")
    
    def register_backend(self) -> bool:
        """
        注册后端实例
        
        Returns:
            bool: 是否注册成功
        """
        # 先查询是否已注册
        backends = self.get_available_backends()
        if backends and backends.get('code') == 0:
            for backend in backends.get('data', []):
                if backend.get('name') == self.instance_id:
                    self.logger.info(f"实例 {self.instance_id} 已注册")
                    return True
        
        # 未注册，进行注册
        api = "v1/backends"
        payload = {
            "instance_id": self.instance_id
        }
        result = self._request_api(api, payload, method="POST")
        
        if result and result.get('code') == 0:
            self.logger.info(f"注册实例成功: {result.get('data', {}).get('name', self.instance_id)}")
            return True
        else:
            error_msg = result.get('msg', '未知错误') if result else '请求失败'
            self.logger.error(f"注册实例失败: {error_msg}")
            return False
    
    def _get_workflow_cache_file(self, workflow_name: str) -> Path:
        """获取工作流缓存文件路径"""
        if self.workflow_cache_file is None:
            from pathlib import Path
            # 缓存文件保存在项目根目录的config/comfyui_cloud/workflow_cache目录
            current_dir = Path(__file__).parent.parent.parent
            cache_dir = current_dir / "config" / "comfyui_cloud" / "workflow_cache"
            cache_dir.mkdir(parents=True, exist_ok=True)
            # 使用工作流名称和实例ID生成唯一文件名
            cache_filename = f"{workflow_name}_{self.instance_id}.txt"
            self.workflow_cache_file = cache_dir / cache_filename
        return self.workflow_cache_file
    
    def _load_workflow_id_from_cache(self, workflow_name: str) -> Optional[str]:
        """从本地缓存加载工作流ID"""
        try:
            cache_file = self._get_workflow_cache_file(workflow_name)
            if cache_file.exists():
                with open(cache_file, 'r', encoding='utf-8') as f:
                    workflow_id = f.read().strip()
                if workflow_id:
                    self.logger.info(f"从缓存加载工作流ID: {workflow_id}")
                    return workflow_id
        except Exception as e:
            self.logger.warning(f"加载工作流缓存失败: {e}")
        return None
    
    def _save_workflow_id_to_cache(self, workflow_name: str, workflow_id: str):
        """保存工作流ID到本地缓存"""
        try:
            cache_file = self._get_workflow_cache_file(workflow_name)
            with open(cache_file, 'w', encoding='utf-8') as f:
                f.write(workflow_id)
            self.logger.info(f"工作流ID已保存到缓存: {workflow_id}")
        except Exception as e:
            self.logger.warning(f"保存工作流缓存失败: {e}")
    
    def get_workflow_by_name(self, name: str) -> Optional[str]:
        """
        根据名称查询已存在的工作流（从本地缓存）
        
        注意：ComfyOne API没有直接查询工作流的接口，
        因此使用本地缓存机制来保存和复用工作流ID。
        
        Args:
            name: 工作流名称
            
        Returns:
            str: 工作流ID，如果不存在返回None
        """
        # 从本地缓存加载工作流ID
        cached_id = self._load_workflow_id_from_cache(name)
        if cached_id:
            # 验证工作流ID是否有效（可选，如果API支持验证）
            # 当前直接返回缓存的ID
            return cached_id
        return None
    
    def _extract_workflow_inputs_outputs(self, workflow_data: dict) -> tuple:
        """
        从工作流JSON中提取输入和输出节点配置
        
        注意：一个节点可能有多个可配置字段，需要为每个字段创建一个input配置
        例如：EmptyLatentImage节点可能有width和height两个字段
        
        Args:
            workflow_data: 工作流JSON数据
            
        Returns:
            tuple: (inputs配置列表, outputs节点ID列表)
        """
        inputs = []
        outputs = []
        
        # 遍历所有节点，识别输入和输出节点
        for node_id, node_data in workflow_data.items():
            if not isinstance(node_data, dict):
                continue
                
            class_type = node_data.get('class_type', '')
            inputs_data = node_data.get('inputs', {})
            
            # 识别输入节点（通常是可配置参数的节点）
            if class_type == 'CLIPTextEncode':
                # 检查是否有text字段（可配置）
                if 'text' in inputs_data:
                    text_value = inputs_data['text']
                    # 如果是字符串（不是连接引用），说明可配置
                    if isinstance(text_value, str):
                        inputs.append({
                            'id': node_id,
                            'type': 'text',
                            'name': 'prompt'
                        })
            
            elif class_type == 'EmptyLatentImage':
                # 检查width和height
                if 'width' in inputs_data and isinstance(inputs_data['width'], (int, float)):
                    inputs.append({
                        'id': node_id,
                        'type': 'number',
                        'name': 'width'
                    })
                if 'height' in inputs_data and isinstance(inputs_data['height'], (int, float)):
                    inputs.append({
                        'id': node_id,
                        'type': 'number',
                        'name': 'height'
                    })
            
            elif class_type == 'KSampler':
                # 检查steps, cfg, seed等参数
                for param_name in ['steps', 'cfg', 'seed']:
                    if param_name in inputs_data and isinstance(inputs_data[param_name], (int, float)):
                        inputs.append({
                            'id': node_id,
                            'type': 'number',
                            'name': param_name
                        })
            
            elif class_type == 'LoadImage':
                # 检查image字段
                if 'image' in inputs_data and isinstance(inputs_data['image'], str):
                    inputs.append({
                        'id': node_id,
                        'type': 'image',
                        'name': 'image'
                    })
            
            # 识别输出节点（通常是SaveImage, SaveVideo等）
            if class_type in ['SaveImage', 'SaveVideo', 'PreviewImage']:
                outputs.append(node_id)
        
        return inputs, outputs
    
    def _guess_input_type(self, inputs_data: dict) -> str:
        """根据输入数据猜测类型"""
        if 'text' in inputs_data:
            return 'text'
        elif 'width' in inputs_data and 'height' in inputs_data:
            return 'number'
        elif 'image' in inputs_data:
            return 'image'
        else:
            return 'string'
    
    def _guess_input_name(self, class_type: str, node_id: str) -> str:
        """根据节点类型猜测名称"""
        name_map = {
            'CLIPTextEncode': 'prompt',
            'KSampler': 'sampler',
            'EmptyLatentImage': 'latent',
            'LoadImage': 'image'
        }
        return name_map.get(class_type, f'input_{node_id}')
    
    def create_workflow(self, name: str, workflow_file: str, 
                       inputs: Optional[List[dict]] = None,
                       outputs: Optional[List[str]] = None) -> Optional[str]:
        """
        创建工作流（初始化时调用一次）
        
        Args:
            name: 工作流名称
            workflow_file: 工作流JSON文件路径
            inputs: 输入节点配置（如果为None，自动从工作流提取）
            outputs: 输出节点ID列表（如果为None，自动从工作流提取）
            
        Returns:
            str: 工作流ID，失败返回None
        """
        try:
            # 读取工作流文件
            workflow_path = Path(workflow_file)
            if not workflow_path.exists():
                self.logger.error(f"工作流文件不存在: {workflow_file}")
                return None
            
            with open(workflow_path, 'r', encoding='utf-8-sig') as f:
                workflow_data = json.load(f)
            
            # 如果没有提供inputs和outputs，自动提取
            if inputs is None or outputs is None:
                extracted_inputs, extracted_outputs = self._extract_workflow_inputs_outputs(workflow_data)
                if inputs is None:
                    inputs = extracted_inputs
                if outputs is None:
                    outputs = extracted_outputs
            
            # 调用API创建工作流
            api = "v1/workflows"
            payload = {
                "name": name,
                "inputs": inputs,
                "outputs": outputs,
                "workflow": workflow_data
            }
            
            result = self._request_api(api, payload, method="POST")
            
            if result and result.get('code') == 0:
                workflow_id = result.get('data', {}).get('id')
                if workflow_id:
                    self.workflow_id = workflow_id
                    # 保存工作流ID到本地缓存
                    self._save_workflow_id_to_cache(name, workflow_id)
                    self.logger.info(f"工作流创建成功，ID: {workflow_id}")
                    return workflow_id
                else:
                    self.logger.error("工作流创建成功但未返回ID")
                    return None
            else:
                error_msg = result.get('msg', '未知错误') if result else '请求失败'
                self.logger.error(f"创建工作流失败: {error_msg}")
                return None
                
        except Exception as e:
            self.logger.error(f"创建工作流异常: {e}")
            return None
    
    def preload_models(self) -> bool:
        """
        预加载模型到内存（通过发送一个最小化的prompt来触发模型加载）
        
        注意：这个方法会发送一个最小化的prompt来触发模型加载，
        但不会真正生成图像。模型会被加载到内存中并保持，后续执行会更快。
        
        Returns:
            bool: 是否预加载成功
        """
        if not self.workflow_id:
            self.logger.error("工作流ID未设置，无法预加载模型")
            return False
        
        self.logger.info("开始预加载模型...")
        
        # 发送一个最小化的prompt来触发模型加载
        # 使用最小的参数，只为了触发模型加载
        minimal_inputs = []
        
        # 尝试找到第一个CLIPTextEncode节点（正向提示词）
        # 这里我们需要从工作流中获取节点信息，但由于我们没有保存工作流数据，
        # 我们只能尝试发送一个空的或最小的prompt
        
        # 如果无法获取节点信息，返回True（假设模型会在第一次执行时加载）
        self.logger.info("模型预加载：模型将在第一次执行时自动加载")
        return True
    
    def prompt_workflow(self, inputs: List[dict], free_cache: bool = False) -> Optional[str]:
        """
        向工作流发送prompt参数（后续调用）
        
        Args:
            inputs: 输入参数列表，格式: [{"id": "节点ID", "params": {"参数名": "参数值"}}]
            free_cache: 是否释放缓存
            
        Returns:
            str: 任务ID，失败返回None
        """
        if not self.workflow_id:
            self.logger.error("工作流ID未设置，请先创建工作流")
            return None
        
        api = "v1/prompts"
        payload = {
            "workflow_id": self.workflow_id,
            "inputs": inputs,
            "free_cache": free_cache
        }
        
        result = self._request_api(api, payload, method="POST")
        
        if result and result.get('code') == 0:
            # 尝试多种方式获取任务ID（注意：官方API返回的是taskId，驼峰命名）
            data = result.get('data', {})
            task_id = (
                data.get('taskId') or  # 官方API使用驼峰命名
                data.get('task_id') or 
                data.get('id') or 
                result.get('taskId') or
                result.get('task_id') or
                result.get('id')
            )
            
            if task_id:
                self.logger.info(f"Prompt发送成功，任务ID: {task_id}")
                return str(task_id)  # 确保返回字符串
            else:
                # 如果找不到任务ID，打印完整响应以便调试
                self.logger.warning(f"Prompt发送成功但未返回任务ID，完整响应: {result}")
                # 尝试返回data中的第一个值（可能是任务ID）
                if data:
                    first_value = list(data.values())[0] if data else None
                    if first_value:
                        self.logger.info(f"尝试使用data中的第一个值作为任务ID: {first_value}")
                        return str(first_value)
                return None
        else:
            error_msg = result.get('msg', '未知错误') if result else '请求失败'
            self.logger.error(f"Prompt发送失败: {error_msg}")
            return None
    
    def get_workflow_id(self) -> Optional[str]:
        """获取当前工作流ID"""
        return self.workflow_id
    
    def set_workflow_id(self, workflow_id: str, workflow_name: str = None):
        """
        设置工作流ID（用于复用已存在的工作流）
        
        Args:
            workflow_id: 工作流ID
            workflow_name: 工作流名称（如果提供，会保存到缓存）
        """
        self.workflow_id = workflow_id
        if workflow_name:
            self._save_workflow_id_to_cache(workflow_name, workflow_id)
        self.logger.info(f"设置工作流ID: {workflow_id}")
    
    def get_task_status(self, task_id: str) -> Optional[dict]:
        """
        查询任务状态（云端API模式）
        
        Args:
            task_id: 任务ID
            
        Returns:
            dict: 任务状态信息，包含status和task_id
        """
        # 尝试多个可能的状态查询API路径
        api_paths = [
            f"v1/prompts/{task_id}",  # 标准prompt状态查询
            f"v1/tasks/{task_id}",    # 任务状态查询
            f"v1/workflows/tasks/{task_id}"  # 工作流任务查询
        ]
        
        for api in api_paths:
            result = self._request_api(api, method="GET")
            
            if result and result.get('code') == 0:
                data = result.get('data', {})
                status = data.get('status', 'pending')
                return {
                    "status": status,
                    "task_id": task_id,
                    "message": data.get('message', ''),
                    "completed": status in ['success', 'completed', 'done'],
                    "progress": data.get('progress', 0),
                    "outputs": data.get('outputs', {})
                }
        
        # 如果所有API都失败，返回成功状态（任务已提交）
        # 注意：ComfyOne API可能不提供实时状态查询，任务在后台异步执行
        self.logger.warning(f"任务状态查询API不可用，任务ID: {task_id}")
        self.logger.info("任务已成功提交到ComfyUI云端，将在后台处理")
        return {
            "status": "submitted",
            "task_id": task_id,
            "message": "任务已提交，后台处理中。ComfyOne云端API不提供实时状态查询。",
            "completed": False,
            "progress": 0
        }

