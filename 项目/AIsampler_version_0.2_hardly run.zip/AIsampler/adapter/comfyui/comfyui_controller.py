import logging
import json
import requests
from typing import Dict, Any, Optional

class ComfyUIController:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化ComfyUI控制器（云端API模式，唯一连接方式）
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
            
        注意：
            - 云端API模式是唯一连接方式
            - 必须配置API密钥和实例ID
            - 初始化失败会直接抛出异常
        """
        # 加载配置
        if config is None:
            from utils.path_utils import setup_project_path, get_config_loader
            setup_project_path(__file__)
            config_loader = get_config_loader()
            config = config_loader.get_comfyui_config()
        
        self.config = config
        
        # 从配置中读取服务器URL和云端设置
        server_config = config.get('server', {})
        cloud_api_config = server_config.get('cloud_api', {})
        
        # 云端API模式是唯一连接方式，强制启用
        self.use_cloud_api = cloud_api_config.get('use_cloud_api', True)  # 默认启用API模式
        
        # 初始化日志
        self.logger = logging.getLogger(__name__)
        
        # 云端API模式是唯一连接方式，必须初始化
        if not self.use_cloud_api:
            raise RuntimeError("云端API模式是唯一连接方式，请确保配置中 use_cloud_api: true")
        
        # 初始化云端API客户端（必需）
        from adapter.comfyui.cloud_api import CloudComfyUIAPI
        from pathlib import Path
        
        # 读取API密钥和实例ID
        current_dir = Path(__file__).parent.parent.parent
        api_key_path = cloud_api_config.get('api_key_path', 'config/comfyui_cloud/api_key')
        instance_id_path = cloud_api_config.get('instance_id_path', 'config/comfyui_cloud/instance_id')
        
        api_key = cloud_api_config.get('api_key', '')
        if not api_key:
            api_key_file = current_dir / api_key_path
            if not api_key_file.exists():
                raise ValueError(f"API密钥文件不存在: {api_key_file}")
            with open(api_key_file, 'r', encoding='utf-8') as f:
                api_key = f.read().strip()
            if not api_key:
                raise ValueError("API密钥文件为空")
        
        instance_id = cloud_api_config.get('instance_id', '')
        if not instance_id:
            instance_id_file = current_dir / instance_id_path
            if not instance_id_file.exists():
                raise ValueError(f"实例ID文件不存在: {instance_id_file}")
            with open(instance_id_file, 'r', encoding='utf-8') as f:
                instance_id = f.read().strip()
            if not instance_id:
                raise ValueError("实例ID文件为空")
        
        base_url = cloud_api_config.get('base_url', 'https://pandora-server-cf.onethingai.com')
        self.cloud_api = CloudComfyUIAPI(base_url, api_key, instance_id, self.logger)
        
        if not self.cloud_api.register_backend():
            raise RuntimeError("后端注册失败")
        
        self.logger.info("云端API客户端初始化成功")
        
        self.workflow_data = None
        self.current_task_id = None

        self.node_discover = WorkflowNodeDiscoverer(config.get('node_mapping', {}))
        self.dynamic_mapping = {}
        self.discovered_nodes = {}
    
    def cleanup(self):
        """清理资源"""
        pass

        
    def load_workflow(self, workflow_path: str = None, workflow_name: str = None) -> bool:
        """
        加载工作流
        
        Args:
            workflow_path: 工作流文件路径
            workflow_name: 工作流名称（云端API模式使用，如果为None则使用文件名）
            
        Returns:
            bool: 是否加载成功
        """
        try:
            # 如果未提供路径，使用配置文件中的默认路径
            if workflow_path is None:
                workflow_config = self.config.get('workflow', {})
                workflow_path = workflow_config.get('default_workflow_path', 
                                                    "adapter/comfyui/workflow/代播视频生成.json")
            
            # 转换为绝对路径
            from pathlib import Path
            current_dir = Path(__file__).parent.parent.parent
            workflow_file = current_dir / workflow_path
            
            with open(workflow_file, 'r', encoding='utf-8') as file:
                self.workflow_data = json.load(file)

            # 云端API模式：创建工作流（只初始化一次）
            if not self.cloud_api:
                raise RuntimeError("云端API客户端未初始化，这是必需组件")
            
            if not self.cloud_api.get_workflow_id():
                # 生成工作流名称
                if workflow_name is None:
                    workflow_name = Path(workflow_path).stem
                
                # 先尝试从本地缓存加载工作流ID（避免重复创建）
                existing_workflow_id = self.cloud_api.get_workflow_by_name(workflow_name)
                if existing_workflow_id:
                    self.cloud_api.set_workflow_id(existing_workflow_id, workflow_name)
                    self.logger.info(f"从缓存复用工作流，ID: {existing_workflow_id}")
                else:
                    # 创建新工作流（初始化时只执行一次）
                    workflow_id = self.cloud_api.create_workflow(
                        name=workflow_name,
                        workflow_file=str(workflow_file)
                    )
                    if not workflow_id:
                        self.logger.error("云端工作流创建失败")
                        return False
                    self.logger.info(f"云端工作流已创建并缓存，ID: {workflow_id}")
            else:
                self.logger.info(f"使用已存在的云端工作流，ID: {self.cloud_api.get_workflow_id()}")

            #使用节点发现器分析工作流
            discovered_nodes = self.node_discover.discover_nodes(self.workflow_data)
            self.logger.info(f"发现{len(discovered_nodes)}个节点")
            
            self.discovered_nodes = discovered_nodes
            
            # 预加载模型（可选，提高首次执行速度）
            # 注意：这会在第一次执行时加载模型，后续执行会更快
            preload_config = self.config.get('performance', {}).get('preload_models', False)
            if preload_config and self.cloud_api:
                self.logger.info("启用模型预加载...")
                # 模型会在第一次执行时自动加载，这里只是标记
                # 实际预加载通过 free_cache=False 来实现
            
            return True

        except Exception as e:
            self.logger.error(f"加载工作流失败: {e}")
            return False

    def update_workflow_parameters(self,workflow_path:str) -> bool:
        try:
            # 可从文件加载workflow并应用配置中的默认模型参数
            if workflow_path:
                with open(workflow_path, 'r', encoding='utf-8') as file:
                    self.workflow_data = json.load(file)

            if not self.workflow_data:
                self.logger.error("工作流数据未加载")
                return False

            model_defaults = self.config.get('model_defaults', {})
            if not model_defaults:
                self.logger.info("未在配置中找到model_defaults，跳过自动参数更新")
                return True

            # 使用动态适配器进行分发
            adapter = DynamicParameterAdapter(self.node_discover)
            ok = adapter.auto_configure_workflow(self.workflow_data, model_defaults)
            if ok:
                self.logger.info("已应用model_defaults到工作流")
                return True
            else:
                self.logger.error("自动配置工作流失败")
                return False
        except Exception as e:
            self.logger.error(f"更新工作流参数失败: {e}")
            return False

    def set_input_image(self,image_path:str) -> bool:
        try:
            if not self.workflow_data:
                self.logger.error("未加载工作流")
                return False
            if not self.discovered_nodes:
                self.logger.error("未发现节点")
                return False
            
            #找到图像输入节点
            input_nodes = self.discovered_nodes.get('image_inputs',[])
            if not input_nodes:
                self.logger.error("未找到图像输入节点")
                return False

            updated_count = 0
            for node_info in input_nodes:
                node_id = node_info['id']
                if node_id in self.workflow_data:
                    if 'inputs' not in self.workflow_data[node_id]:
                        self.workflow_data[node_id]['inputs'] = {}
                    self.workflow_data[node_id]['inputs']['image'] = image_path
                    updated_count += 1
                    self.logger.info(f"更新了{updated_count}个图像输入节点")
                    return True

            if updated_count > 0:
                self.logger.info(f"更新了{updated_count}个图像输入节点")
                return True
            else:
                self.logger.error("未找到可更新的图像输入节点")
                return False
        except Exception as e:
            self.logger.error(f"设置图像输入失败: {e}")
            return False


    def set_prompt(self,prompt:str) -> bool:
        """
        设置正向提示词
        
        注意：在云端API模式下，参数修改会保存在工作流数据中，
        执行时通过_extract_workflow_inputs_for_api提取并发送
        """
        try:
            if not self.workflow_data:
                self.logger.error("工作流数据未加载")
                return False

            if not self.discovered_nodes:
                self.logger.error("节点未发现")
                return False

            text_encoder_nodes = self.discovered_nodes.get('text_encoders',[])
            positive_nodes = self.discovered_nodes.get('positive_prompt',[])

            all_text_nodes = text_encoder_nodes + positive_nodes

            if not all_text_nodes:
                self.logger.warning("未找到文本编码器或正向提示节点")
                return False

            updated_count = 0
            for node_info in all_text_nodes:
                node_id = node_info['id']
                node_title = node_info.get('title','').lower()
                if 'negative' in node_title:
                    continue

                if node_id in self.workflow_data:
                    if 'inputs' not in self.workflow_data[node_id]:
                        self.workflow_data[node_id]['inputs'] = {}

                    self.workflow_data[node_id]['inputs']['text'] = prompt
                    updated_count += 1
                    self.logger.info(f"更新了{updated_count}个文本编码器或正向提示节点")
                    
            if updated_count > 0:
                self.logger.info(f"更新了{updated_count}个文本编码器或正向提示节点")
                return True
            else:
                self.logger.error("未找到可更新的文本编码器或正向提示节点")
                return False
        except Exception as e:
            self.logger.error(f"设置正向提示失败: {e}")
            return False
            

    def set_negative_prompt(self, negative_prompt: str) -> bool:
        try:
            if not self.workflow_data:
                self.logger.error("工作流未加载，请先调用load_workflow")
                return False
                
            if not self.discovered_nodes:
                self.logger.error("节点信息未发现，请先调用load_workflow")
                return False
            
            text_encoder_nodes = self.discovered_nodes.get('text_encoders', [])
            negative_prompt_nodes = self.discovered_nodes.get('negative_prompt', [])
            
            # 合并所有文本编码节点
            all_text_nodes = text_encoder_nodes + negative_prompt_nodes
            
            if not all_text_nodes:
                self.logger.warning("未找到文本编码节点")
                return False
            updated_count = 0
            for node_info in all_text_nodes:
                node_id = node_info['id']
                node_title = node_info.get('title', '').lower()

                if 'negative' in node_title:
                    if node_id in self.workflow_data:
                        if 'inputs' not in self.workflow_data[node_id]:
                            self.workflow_data[node_id]['inputs'] = {}
                        
                        self.workflow_data[node_id]['inputs']['text'] = negative_prompt
                        updated_count += 1
                        self.logger.info(f"更新节点 {node_id} 的负面提示词: {negative_prompt[:50]}...")
            
            if updated_count > 0:
                self.logger.info(f"成功更新 {updated_count} 个负面提示词节点")
                return True
            else:
                self.logger.error("未能更新任何负面提示词节点")
                return False
                
        except Exception as e:
            self.logger.error(f"设置负面提示词失败: {e}")
            return False

    def set_model_parameters(self,model_config:dict) -> bool:
        try:
            if not self.workflow_data:
                self.logger.error("工作流未加载")
                return False

            if not self.discovered_nodes:
                self.logger.error("信息节点未发现")
                return False

            updated_count = 0

            if 'sampler' in model_config:
                sampler_params = model_config['sampler']
                sampler_nodes = self.discovered_nodes.get('samplers',[])

                for node_info in sampler_nodes:
                    node_id = node_info['id']
                    if node_id in self.workflow_data:
                        if 'inputs' not in self.workflow_data[node_id]:
                            self.workflow_data[node_id]['inputs'] = {}

                        for param_name, param_value in sampler_params.items():
                            self.workflow_data[node_id]['inputs'][param_name] = param_value

                    updated_count += 1
                    self.logger.info(f"更新采样器节点 {node_id} 参数: {sampler_params}")

            if 'controlnet' in model_config:
                controlnet_params = model_config['controlnet']
                controlnet_nodes = self.discovered_nodes.get('controlnet_nodes', [])
                
                for node_info in controlnet_nodes:
                    node_id = node_info['id']
                    if node_id in self.workflow_data:
                        if 'inputs' not in self.workflow_data[node_id]:
                            self.workflow_data[node_id]['inputs'] = {}
                        
                        # 更新ControlNet参数
                        for param_name, param_value in controlnet_params.items():
                            self.workflow_data[node_id]['inputs'][param_name] = param_value
                        
                        updated_count += 1
                        self.logger.info(f"更新ControlNet节点 {node_id} 参数: {controlnet_params}")
            
            if 'vae' in model_config:
                vae_params = model_config['vae']
                # 查找VAE相关节点
                for node_id, node_data in self.workflow_data.items():
                    if isinstance(node_data, dict):
                        class_type = node_data.get('class_type', '')
                        if 'VAE' in class_type or 'vae' in class_type.lower():
                            if 'inputs' not in node_data:
                                node_data['inputs'] = {}
                            
                            for param_name, param_value in vae_params.items():
                                node_data['inputs'][param_name] = param_value
                            
                            updated_count += 1
                            self.logger.info(f"更新VAE节点 {node_id} 参数: {vae_params}")
            
            if 'ipadapter' in model_config:
                ipadapter_params = model_config['ipadapter']
                ipadapter_nodes = self.discovered_nodes.get('ipadapter_nodes', [])
                
                for node_info in ipadapter_nodes:
                    node_id = node_info['id']
                    if node_id in self.workflow_data:
                        if 'inputs' not in self.workflow_data[node_id]:
                            self.workflow_data[node_id]['inputs'] = {}
                        
                        # 更新IPAdapter参数
                        for param_name, param_value in ipadapter_params.items():
                            self.workflow_data[node_id]['inputs'][param_name] = param_value
                        
                        updated_count += 1
                        self.logger.info(f"更新IPAdapter节点 {node_id} 参数: {ipadapter_params}")
            
            if updated_count > 0:
                self.logger.info(f"成功更新 {updated_count} 个模型参数")
                return True
            else:
                self.logger.error("未能更新任何模型参数")
                return False
        except Exception as e:
            self.logger.error(f"设置模型参数失败: {e}")
            return False

    def execute_workflow(self) -> str:
        """
        执行工作流,返回任务id（云端API模式）
        
        Returns:
            str: 任务ID，失败返回None
        """
        try:
            # 云端API模式是唯一连接方式
            if not self.cloud_api:
                self.logger.error("云端API客户端未初始化")
                return None
            
            if not self.cloud_api.get_workflow_id():
                self.logger.error("云端工作流未创建，请先调用load_workflow")
                return None
            
            if not self.workflow_data:
                self.logger.error("工作流数据未加载")
                return None
            
            # 从工作流数据中提取输入参数
            inputs = self._extract_workflow_inputs_for_api()
            
            if not inputs:
                self.logger.warning("未提取到任何输入参数，可能工作流中没有可配置的节点")
            
            # 发送prompt到云端
            # free_cache=False 表示不释放缓存，保持模型在内存中，提高后续执行速度
            task_id = self.cloud_api.prompt_workflow(inputs=inputs, free_cache=False)
            if task_id:
                self.current_task_id = task_id
                self.logger.info(f"工作流执行成功，任务ID: {task_id}")
                return task_id
            else:
                self.logger.error("工作流执行失败，未返回任务ID")
                return None
                
        except Exception as e:
            self.logger.error(f"工作流执行失败: {e}")
            return None
    
    def _extract_workflow_inputs_for_api(self) -> list:
        """
        从工作流数据中提取输入参数，转换为API格式
        
        提取所有可配置的参数，包括：
        - 文本参数（prompt, negative_prompt）
        - 数值参数（width, height, steps, cfg, seed, denoise等）
        - 采样器参数（sampler_name, scheduler等）
        - 其他可配置参数
        
        注意：同一个节点的多个参数应该合并到一个params对象中
        
        Returns:
            list: 输入参数列表，格式: [{"id": "节点ID", "params": {"参数名": "参数值"}}]
        """
        # 使用字典来收集每个节点的参数，避免重复
        node_params_map = {}
        
        if not self.workflow_data:
            return []
        
        # 遍历所有节点，提取可配置的参数
        for node_id, node_data in self.workflow_data.items():
            if not isinstance(node_data, dict):
                continue
                
            node_inputs = node_data.get('inputs', {})
            if not isinstance(node_inputs, dict):
                continue
            
            params = {}
            class_type = node_data.get('class_type', '')
            
            # 提取文本参数（prompt）
            if 'text' in node_inputs:
                text_value = node_inputs['text']
                # 跳过连接引用（格式为 ["节点ID", 输出索引]）
                if not isinstance(text_value, list) or (isinstance(text_value, list) and len(text_value) == 0):
                    params['text'] = text_value
            
            # 提取采样器参数
            if class_type == 'KSampler':
                for key in ['steps', 'cfg', 'sampler_name', 'scheduler', 'denoise', 'seed']:
                    if key in node_inputs:
                        value = node_inputs[key]
                        # 跳过连接引用
                        if not isinstance(value, list):
                            params[key] = value
            
            # 提取潜在图像参数
            if class_type == 'EmptyLatentImage':
                for key in ['width', 'height', 'batch_size']:
                    if key in node_inputs:
                        value = node_inputs[key]
                        if not isinstance(value, list):
                            params[key] = value
            
            # 提取图像路径（LoadImage）
            if class_type == 'LoadImage' and 'image' in node_inputs:
                image_value = node_inputs['image']
                if isinstance(image_value, str):
                    params['image'] = image_value
            
            # 提取其他常见参数
            for key in ['strength', 'weight', 'guidance_start', 'guidance_end']:
                if key in node_inputs:
                    value = node_inputs[key]
                    if not isinstance(value, list):
                        params[key] = value
            
            # 如果有参数，合并到该节点的params中
            if params:
                if node_id not in node_params_map:
                    node_params_map[node_id] = {}
                node_params_map[node_id].update(params)
        
        # 转换为列表格式
        inputs = []
        for node_id, params in node_params_map.items():
            inputs.append({
                "id": node_id,
                "params": params
            })
        
        return inputs


    def get_task_status(self, task_id: str) -> dict:
        """
        查询任务状态
        
        Args:
            task_id: 任务ID
            
        Returns:
            dict: 任务状态信息
        """
        try:
            if not task_id:
                self.logger.error("任务ID为空")
                return {"status": "error", "message": "任务ID为空"}
            
            # 云端API模式：使用云端API查询状态
            if self.cloud_api:
                status = self.cloud_api.get_task_status(task_id)
                if status:
                    return status
                # 如果返回None（不应该发生），返回默认状态
                return {
                    "status": "pending",
                    "message": "任务状态未知",
                    "task_id": task_id,
                    "completed": False,
                    "progress": 0
                }
            
        except Exception as e:
            self.logger.error(f"获取任务状态失败: {e}")
            return {"status": "error", "message": f"系统错误: {e}"}

    def get_output_image(self,task_id:str) -> str:
        try:
            if not task_id:
                self.logger.error("任务ID为空")
                return None

            task_status = self.get_task_status(task_id)

            if task_status.get('status') != "success":
                self.logger.info(f"任务 {task_id} 未完成，状态: {task_status.get('status')}")
                return None

            outputs = task_status.get('outputs',{})

            for node_id , node_output in outputs.items():
                if isinstance(node_output, dict):
                    if "images" in node_output:
                        images = node_output["images"]
                        if isinstance(images, list) and len(images) > 0:
                            image_path = images[0]
                            self.logger.info(f"获取到图像: {image_path}")
                            return image_path

            self.logger.warning(f"任务 {task_id} 未找到图像输出")
            return None
        except Exception as e:
            self.logger.error(f"获取图像文件失败: {e}")
            return None

    def get_output_video(self,task_id:str) -> str:
        try:
            if not task_id:
                self.logger.error("任务ID为空")
                return None

            task_status = self.get_task_status(task_id)

            if task_status.get('status') != "success":
                self.logger.info(f"任务 {task_id} 未完成，状态: {task_status.get('status')}")
                return None

            outputs = task_status.get('outputs',{})

            for node_id , node_output in outputs.items():
                if isinstance(node_output, dict):
                    if "videos" in node_output:
                        video = node_output["videos"]
                        if isinstance(video, list) and len(video) > 0:
                            video_path = video[0]
                            self.logger.info(f"获取到视频: {video_path}")
                            return video_path

            self.logger.warning(f"任务 {task_id} 未找到视频输出")
            return None
        except Exception as e:
            self.logger.error(f"获取视频文件失败: {e}")
            return None
                            

class WorkflowNodeDiscoverer:
    def __init__(self, node_mapping_config: Dict[str, Any] = None):
        """
        初始化节点发现器
        
        Args:
            node_mapping_config: 节点映射配置
        """
        if node_mapping_config is None:
            node_mapping_config = {}
        
        #节点关系映射表 - 从配置中读取或使用默认值
        types_config = node_mapping_config.get('types', {})
        self.node_type_mapping = types_config if types_config else {
            'LoadImage': 'image_input',
            'CLIPTextEncode': 'text_encoder',
            'KSampler': 'sampler',
            'ControlNetLoader': 'controlnet_loader',
            'IPAdapterModelLoader': 'ipadapter_loader',
            'WanImageToVideo': 'video_generator',
            'SaveVideo': 'video_saver',
            'CannyEdgePreprocessor': 'canny_processor'
        }

        #语义关键词映射 - 从配置中读取或使用默认值
        semantic_config = node_mapping_config.get('semantic_keywords', {})
        self.semantic_keywords = semantic_config if semantic_config else {
            'positive_prompt': ['positive', '正面', 'prompt'],
            'negative_prompt': ['negative', '负面', 'bad'],
            'input_image': ['input', '输入', 'image'],
            'style_image': ['style', '风格', 'ipadapter'],
            'video_prompt': ['video', '视频', 'motion']
        }

    def discover_nodes(self, workflow_data: dict) -> dict:
        #自动记录节点
        discovered_nodes = {
            'image_inputs': [],
            'text_encoders': [],
            'samplers': [],
            'controlnet_nodes': [],
            'ipadapter_nodes': [],
            'video_generators': [],
            'output_nodes': []
        }

        for node_id , node_data in workflow_data.items():
            if not isinstance(node_data, dict):
                continue

            class_type = node_data.get('class_type','')
            node_title = node_data.get('_meta',{}).get('title','')

            # 基于节点类型分类
            if class_type in self.node_type_mapping:
                category = self.node_type_mapping[class_type]
                # 动态创建键（如果不存在）
                key = f'{category}_nodes'
                if key not in discovered_nodes:
                    discovered_nodes[key] = []
                
                # 特殊处理映射
                if category == 'image_input':
                    # image_input → image_inputs
                    discovered_nodes['image_inputs'].append({
                        'id': node_id,
                        'class_type' : class_type,
                        'title' : node_title,
                        'data' : node_data
                    })
                elif category == 'text_encoder':
                    # text_encoder → text_encoders (保持复数形式)
                    discovered_nodes['text_encoders'].append({
                        'id': node_id,
                        'class_type' : class_type,
                        'title' : node_title,
                        'data' : node_data
                    })
                elif category == 'sampler':
                    # sampler → samplers (保持复数形式)
                    discovered_nodes['samplers'].append({
                        'id': node_id,
                        'class_type' : class_type,
                        'title' : node_title,
                        'data' : node_data
                    })
                else:
                    # 其他节点使用动态键
                    discovered_nodes[key].append({
                        'id': node_id,
                        'class_type' : class_type,
                        'title' : node_title,
                        'data' : node_data
                    })

            #基于语义关键词分类
            for keyword, matches in self.semantic_keywords.items():
                if any(match in node_title.lower() for match in matches):
                    if keyword not in discovered_nodes:
                        discovered_nodes[keyword] = []
                    discovered_nodes[keyword].append({
                        'id' : node_id,
                        'class_type' : class_type,
                        'title' : node_title,
                        'data' : node_data
                    })

        return discovered_nodes

class DynamicParameterAdapter:
    #动态参数适配器
    def __init__(self, node_discoverer):
        import logging
        self.logger = logging.getLogger(__name__)
        self.discoverer = node_discoverer
        self.discovered_nodes = {}

    def auto_configure_workflow(self,workflow_data: dict,parameters: dict) -> bool:
        #自动装载参数
        try:
            #发现所有节点
            self.discovered_nodes = self.discoverer.discover_nodes(workflow_data)

            #智能参数匹配
            for param_name, param_value in parameters.items():
                # 简单规则：如果是采样器参数，分发到已发现的sampler节点
                if param_name == 'sampler' and isinstance(param_value, dict):
                    for node in self.discovered_nodes.get('samplers', []):
                        node_id = node['id']
                        if node_id in workflow_data:
                            workflow_data[node_id].setdefault('inputs', {})
                            for k, v in param_value.items():
                                workflow_data[node_id]['inputs'][k] = v

                # ControlNet 参数
                elif param_name == 'controlnet' and isinstance(param_value, dict):
                    for node in self.discovered_nodes.get('controlnet_nodes', []):
                        node_id = node['id']
                        if node_id in workflow_data:
                            workflow_data[node_id].setdefault('inputs', {})
                            for k, v in param_value.items():
                                workflow_data[node_id]['inputs'][k] = v

                # VAE 参数：基于 class_type 名称包含 VAE 的节点
                elif param_name == 'vae' and isinstance(param_value, dict):
                    for node_id, node_data in workflow_data.items():
                        if isinstance(node_data, dict):
                            class_type = node_data.get('class_type', '')
                            if 'VAE' in class_type or 'vae' in class_type.lower():
                                node_data.setdefault('inputs', {})
                                for k, v in param_value.items():
                                    node_data['inputs'][k] = v

                # IPAdapter 参数
                elif param_name == 'ipadapter' and isinstance(param_value, dict):
                    for node in self.discovered_nodes.get('ipadapter_nodes', []):
                        node_id = node['id']
                        if node_id in workflow_data:
                            workflow_data[node_id].setdefault('inputs', {})
                            for k, v in param_value.items():
                                workflow_data[node_id]['inputs'][k] = v

                # 提示词
                elif param_name == 'prompt':
                    for node in self.discovered_nodes.get('text_encoders', []) + self.discovered_nodes.get('positive_prompt', []):
                        node_id = node['id']
                        title = node.get('title', '').lower()
                        if 'negative' in title:
                            continue
                        if node_id in workflow_data:
                            workflow_data[node_id].setdefault('inputs', {})
                            workflow_data[node_id]['inputs']['text'] = param_value

                elif param_name == 'negative_prompt':
                    for node in self.discovered_nodes.get('text_encoders', []) + self.discovered_nodes.get('negative_prompt', []):
                        node_id = node['id']
                        title = node.get('title', '').lower()
                        if 'negative' in title and node_id in workflow_data:
                            workflow_data[node_id].setdefault('inputs', {})
                            workflow_data[node_id]['inputs']['text'] = param_value

                # 输入图像
                elif param_name == 'input_image':
                    for node in self.discovered_nodes.get('image_inputs', []):
                        node_id = node['id']
                        if node_id in workflow_data:
                            workflow_data[node_id].setdefault('inputs', {})
                            workflow_data[node_id]['inputs']['image'] = param_value

                else:
                    # 其他键暂不处理
                    continue

            return True
        except Exception as e:
            self.logger.error(f"自动配置工作流失败: {e}")
            return False