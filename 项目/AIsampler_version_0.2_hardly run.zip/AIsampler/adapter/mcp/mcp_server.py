from fastmcp import FastMCP
import sys
import os

project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from config.config_loader import config_loader

mcp = FastMCP("Aisampler_mcp_server")

mcp_config = config_loader.get_mcp_config()

_blender_controller = None
_comfyui_controller = None

def get_blender_controller():
    """获取Blender控制器实例（懒加载）"""
    global _blender_controller
    if _blender_controller is None:
        from adapter.blender.blender_controller import BlenderController
        blender_config = config_loader.get_blender_config()
        _blender_controller = BlenderController(config=blender_config)
    return _blender_controller

def get_comfyui_controller():
    """获取ComfyUI控制器实例（懒加载）"""
    global _comfyui_controller
    if _comfyui_controller is None:
        from adapter.comfyui.comfyui_controller import ComfyUIController
        comfyui_config = config_loader.get_comfyui_config()
        _comfyui_controller = ComfyUIController(config=comfyui_config)
    return _comfyui_controller

@mcp.tool()
def blender_load_openpose_file(file_path: str = None) -> str:
    """加载OpenPose骨骼文件到Blender"""
    blender_controller = get_blender_controller()
    success = blender_controller.load_openpose_file(file_path)

    if success:
        return "成功加载骨骼文件"
    else:
        return "加载骨骼文件失败"

@mcp.tool()
def blender_update_bone_pose(bone_name: str, position: list[float] = None, rotation: list[float] = None) -> str:
    """更新Blender中指定骨骼的姿势"""
    blender_controller = get_blender_controller()
    success = blender_controller.update_bone_pose(bone_name, position, rotation)

    if success:
        return "成功更新骨骼姿势"
    else:
        return "更新骨骼姿势失败"

@mcp.tool()
def blender_get_bone_position() -> dict:
    """获取Blender中所有骨骼的位置"""
    blender_controller = get_blender_controller()
    positions = blender_controller.get_bone_position()
    return positions

@mcp.tool()
def blender_create_pose_shot() -> str:
    """创建Blender中的姿势快照"""
    blender_controller = get_blender_controller()
    snapshot = blender_controller.create_pose_shot()
    return snapshot

@mcp.tool()
def blender_get_camera_info() -> dict:
    """获取Blender中的相机信息"""
    blender_controller = get_blender_controller()
    camera_info = blender_controller.get_camera_info()
    return camera_info

@mcp.tool()
def blender_get_lighting_info() -> dict:
    """获取Blender中的光照信息"""
    blender_controller = get_blender_controller()
    lighting_info = blender_controller.get_lighting_info()
    return lighting_info



@mcp.tool()
def comfyui_load_workflow(workflow_path: str = None) -> str:
    """加载ComfyUI工作流"""
    comfyui_controller = get_comfyui_controller()
    success = comfyui_controller.load_workflow(workflow_path)

    if success:
        return "成功加载工作流"
    else:
        return "加载工作流失败"

@mcp.tool()
def comfyui_set_prompt(prompt: str) -> str:
    """设置ComfyUI中的提示词"""
    comfyui_controller = get_comfyui_controller()
    success = comfyui_controller.set_prompt(prompt)

    if success:
        return "成功设置提示词"
    else:
        return "设置提示词失败"

@mcp.tool()
def comfyui_set_negative_prompt(negative_prompt: str) -> str:
    """设置ComfyUI中的负面提示词"""
    comfyui_controller = get_comfyui_controller()
    success = comfyui_controller.set_negative_prompt(negative_prompt)

    if success:
        return "成功设置负面提示词"
    else:
        return "设置负面提示词失败"

@mcp.tool()
def comfyui_set_input_image(image_path: str) -> str:
    """设置ComfyUI中的输入图像"""
    comfyui_controller = get_comfyui_controller()
    success = comfyui_controller.set_input_image(image_path)

    if success:
        return "成功设置输入图像"
    else:
        return "设置输入图像失败"
        
@mcp.tool()
def comfyui_set_model_parameters(model_parameters: dict) -> str:
    """设置ComfyUI中的模型参数"""
    comfyui_controller = get_comfyui_controller()
    success = comfyui_controller.set_model_parameters(model_parameters)

    if success:
        return "成功设置模型参数"
    else:
        return "设置模型参数失败"

@mcp.tool()
def comfyui_execute_workflow() -> str:
    """执行ComfyUI中的工作流"""
    comfyui_controller = get_comfyui_controller()
    task_id = comfyui_controller.execute_workflow()
    if task_id:
        return f"工作流已提交执行，任务ID: {task_id}"
    else:
        return "执行工作流失败"

@mcp.tool()
def comfyui_get_task_status(task_id: str) -> dict:
    """获取ComfyUI中的任务状态"""
    comfyui_controller = get_comfyui_controller()
    status = comfyui_controller.get_task_status(task_id)
    return status

@mcp.tool()
def comfyui_get_output_image(task_id: str) -> str:
    """获取ComfyUI中的输出图像"""
    comfyui_controller = get_comfyui_controller()
    image_path = comfyui_controller.get_output_image(task_id)
    return image_path

@mcp.tool()
def comfyui_get_output_video(task_id: str) -> str:
    """获取ComfyUI中的输出视频"""
    comfyui_controller = get_comfyui_controller()
    video_path = comfyui_controller.get_output_video(task_id)
    return video_path

if __name__ == "__main__":
    mcp.run()
        