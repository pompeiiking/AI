import logging
from typing import Dict, Any, Optional
import os
import sys
from pathlib import Path

# 尝试导入bpy（仅在Blender内部可用）
try:
    import bpy
    BLENDER_INTERNAL = True
except ImportError:
    BLENDER_INTERNAL = False
    bpy = None

# 导入Socket客户端（用于外部连接）
try:
    from .blender_socket_client import BlenderSocketClient
    SOCKET_AVAILABLE = True
except ImportError:
    SOCKET_AVAILABLE = False
    BlenderSocketClient = None


class BlenderController:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化Blender控制器
        
        支持两种模式：
        1. 内部模式：在Blender内部运行，直接使用bpy API
        2. 外部模式：通过Socket连接已打开的Blender实例
        
        Args:
            config: 配置字典，如果为None则从配置文件加载
        """
        # 加载配置
        if config is None:
            from utils.path_utils import setup_project_path, get_config_loader
            setup_project_path(__file__)
            config_loader = get_config_loader()
            config = config_loader.get_blender_config()
        
        self.config = config
        
        # 初始化日志
        self.logger = logging.getLogger(__name__)
        
        # 检测运行模式
        self.blender_internal = BLENDER_INTERNAL
        self.socket_client = None
        
        # 如果不在Blender内部，尝试使用Socket连接
        if not self.blender_internal:
            if SOCKET_AVAILABLE and BlenderSocketClient:
                # 从配置读取Socket连接参数
                socket_config = config.get('socket', {})
                host = socket_config.get('host', 'localhost')
                port = socket_config.get('port', 8888)
                
                self.socket_client = BlenderSocketClient(host=host, port=port)
                
                # 测试连接
                if self.socket_client.ping():
                    self.logger.info(f"成功连接到Blender Socket服务器 ({host}:{port})")
                else:
                    self.logger.warning(f"无法连接到Blender Socket服务器 ({host}:{port})，请确保Blender插件已启动")
            else:
                self.logger.warning("Socket客户端不可用，将无法连接Blender")
        
        #基本初始化参数
        self.openpose_bones = {}
        #骨骼信息
        #{bone_name: {position,rotation,parent}}
        self.scene_objects = {}
        #场景对象
        #{object_name: {position,rotation,scale}}

        self.active_armature = None 
        #手臂对象（示例）
        
        # 从配置中读取路径设置
        paths_config = config.get('paths', {})
        self.openpose_bone_file = paths_config.get('openpose_bone_file', 
                                                    "adapter/blender/openpose/openpose_bone.blend")
        self.auto_load_on_init = paths_config.get('auto_load_on_init', True)
        
        # Socket配置
        socket_config = config.get('socket', {})
        self.auto_load_on_connect = socket_config.get('auto_load_on_connect', True)
        
        mode_str = "内部模式" if self.blender_internal else "Socket模式"
        self.logger.info(f"BlenderController初始化完成 ({mode_str})")
        
        # 自动加载骨骼文件
        if self.auto_load_on_init and self.blender_internal:
            try:
                self.load_openpose_file()
            except Exception as e:
                self.logger.warning(f"自动加载骨骼文件失败: {e}")
        
    def _get_absolute_path(self, file_path: str) -> str:
        """获取文件的绝对路径"""
        candidate = Path(file_path.strip())
        if candidate.is_absolute():
            return str(candidate)
        
        module_path = Path(__file__).resolve()
        project_root = next((p for p in module_path.parents if p.name == "AIsampler"), module_path.parent)
        possible_paths = [
            project_root / candidate,
            module_path.parent / candidate,
            Path.cwd() / candidate,
            Path.home() / candidate,
        ]
        
        for path in possible_paths:
            if path.exists():
                return str(path.resolve())
        
        self.logger.warning("骨骼文件未找到: %s，尝试使用项目根目录拼接路径。", file_path)
        return str((project_root / candidate).resolve())
    
    def load_openpose_file(self, file_path: str = None) -> bool:
        """读取骨骼文件"""
        try:
            # 如果未提供路径，使用配置文件中的默认路径
            if file_path is None:
                file_path = self.openpose_bone_file
            
            # 转换为绝对路径
            file_path = self._get_absolute_path(file_path)
            
            # 检查文件是否存在
            if not os.path.exists(file_path):
                self.logger.warning(f"骨骼文件不存在: {file_path}，将尝试加载（可能路径不正确）")
            
            if self.blender_internal:
                # 内部模式：直接使用bpy
                try:
                    # 检查是否是初始化加载（场景中没有armature对象）
                    existing_armatures = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE']
                    is_initial_load = len(existing_armatures) == 0
                    
                    # 只在初始化时清除场景
                    if is_initial_load:
                        bpy.ops.object.select_all(action='SELECT')
                        bpy.ops.object.delete(use_global=False)
                        self.logger.info("初始化加载：已清除场景")
                    
                    # 使用append方法导入.blend文件（更安全）
                    with bpy.data.libraries.load(file_path) as (data_from, data_to):
                        # 只导入armature对象
                        armature_names = [name for name in data_from.objects]
                        data_to.objects = armature_names
                    
                    # 将导入的对象添加到场景
                    imported_count = 0
                    imported_objects = []
                    for obj in data_to.objects:
                        if obj is not None and obj.type == 'ARMATURE':
                            # 检查是否已存在
                            if obj.name not in bpy.context.scene.objects:
                                bpy.context.collection.objects.link(obj)
                                imported_count += 1
                                imported_objects.append(obj)
                    
                    if imported_count > 0:
                        # 自动聚焦到第一个导入的armature对象
                        first_armature = imported_objects[0]
                        bpy.ops.object.select_all(action='DESELECT')
                        first_armature.select_set(True)
                        bpy.context.view_layer.objects.active = first_armature
                        bpy.ops.view3d.view_selected()
                        
                        self._extract_openpose_bones()
                        self.logger.info(f"骨骼文件加载成功，导入了 {imported_count} 个armature对象")
                        return True
                    else:
                        # 检查是否因为对象已存在
                        existing_armatures = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE']
                        if existing_armatures:
                            first_existing = existing_armatures[0]
                            bpy.ops.object.select_all(action='DESELECT')
                            first_existing.select_set(True)
                            bpy.context.view_layer.objects.active = first_existing
                            bpy.ops.view3d.view_selected()
                            
                            self._extract_openpose_bones()
                            self.logger.info(f"场景中已有armature对象，跳过导入")
                            return True
                        else:
                            self.logger.error(f"文件中没有armature对象")
                            return False
                except Exception as e:
                    self.logger.error(f"加载文件失败: {e}")
                    import traceback
                    self.logger.error(traceback.format_exc())
                    return False
            elif self.socket_client:
                # Socket模式：通过Socket发送命令
                # 注意：清除场景的操作会在服务器端执行
                success = self.socket_client.load_openpose_file(file_path)
                if success:
                    # 提取骨骼信息（通过Socket获取）
                    self._extract_openpose_bones_socket()
                    self.logger.info("Socket模式骨骼文件加载成功: %s", file_path)
                else:
                    self.logger.error("Socket模式骨骼文件加载失败: %s", file_path)
                return success
            else:
                self.logger.error("无法加载文件：既不在Blender内部，也没有Socket连接")
                return False

        except Exception as e:
            self.logger.error(f"骨骼文件{file_path}加载失败: {e}")
            return False

    def _extract_openpose_bones(self):
        #更新骨骼动作
        self.openpose_bones = {}

        #遍历场景对象
        for obj in bpy.context.scene.objects:
            if obj.type== 'ARMATURE':
                #找到手臂对象
                armature = obj
                self.active_armature = armature

                #遍历手臂中的所有骨骼
                # head_local：骨骼的起始点（相对于父骨骼）
                # tail_local：骨骼的结束点
                # matrix_local：骨骼的变换矩阵（包含位置、旋转、缩放信息）
                # parent：父骨骼的引用，用于构建骨骼层次
                for bone in armature.data.bones:
                    self.openpose_bones[bone.name] = {
                        'head' : list(bone.head_local),
                        #骨骼头部
                        'tail' : list(bone.tail_local),
                        #骨骼尾部
                        'matrix' : [list(row) for row in bone.matrix_local],
                        #骨骼矩阵,用于变换
                        'parent' : bone.parent.name if bone.parent else None 
                        #骨骼父节点
                    }
                    self.logger.info(f"骨骼{bone.name}信息提取成功")
                break 
                #找到第一个手臂对象后退出循环


    def update_bone_pose(self, bone_name: str, position: Optional[list] = None, rotation: Optional[list] = None) -> bool:
        self.logger.info(f" [update_bone_pose] 调用: bone={bone_name}, pos={position}, rot={rotation}")
        """进行骨骼动作的更新"""
        try:
            if self.blender_internal:
                # 内部模式：直接使用bpy
                if not self.active_armature:
                    self.logger.error("未找到目标手臂对象")
                    return False
                
                #切换到姿势模式
                bpy.context.view_layer.objects.active = self.active_armature
                bpy.ops.object.mode_set(mode='POSE')
                
                #获取目标骨骼
                if bone_name in self.active_armature.pose.bones:
                    bone = self.active_armature.pose.bones[bone_name]

                    #更新骨骼位置
                    if position:
                        bone.location = position
                    
                    #更新骨骼旋转
                    if rotation:
                        bone.rotation_euler = rotation

                    bpy.ops.object.mode_set(mode='OBJECT')
                    self.logger.info(f"成功更新骨骼{bone_name}")
                    return True
                else:
                    self.logger.warning(f"未找到骨骼：{bone_name}")
                    return False
            elif self.socket_client:
                # Socket模式：通过Socket发送命令
                return self.socket_client.update_bone_pose(bone_name, position, rotation)
            else:
                self.logger.error("无法更新骨骼：既不在Blender内部，也没有Socket连接")
                return False

        except Exception as e:
            self.logger.error(f"骨骼动作更新失败: {e}")
            return False
    
    def get_bone_position(self) -> Dict[str, Dict[str, list]]:
        """获取骨骼位置"""
        try:
            if self.blender_internal:
                # 内部模式：直接使用bpy
                bone_positions = {}
                if self.active_armature:
                    #确保在姿势模式
                    bpy.context.view_layer.objects.active = self.active_armature
                    bpy.ops.object.mode_set(mode='POSE')

                    #收集所有骨骼的当前状态
                    for bone in self.active_armature.pose.bones:
                        bone_positions[bone.name] = {
                            'location': list(bone.location),
                            'rotation': list(bone.rotation_euler),
                            'scale': list(bone.scale)
                        }
                return bone_positions
            elif self.socket_client:
                # Socket模式：通过Socket获取
                return self.socket_client.get_bone_position()
            else:
                self.logger.error("无法获取骨骼位置：既不在Blender内部，也没有Socket连接")
                return {}
        except Exception as e:
            self.logger.error(f"获取骨骼位置失败: {e}")
            return {}
    
    def create_pose_shot(self) -> Dict[str, Any]:
        """创建当前姿势的快照"""
        try:
            if self.blender_internal:
                # 内部模式：直接使用bpy
                snapshot = {
                    'timestamp': bpy.context.scene.frame_current,
                    'bones': self.get_bone_position(),
                    'camera': self.get_camera_info(),
                    'lighting': self.get_lighting_info(),
                }
                return snapshot
            elif self.socket_client:
                # Socket模式：通过Socket获取
                return self.socket_client.create_pose_shot()
            else:
                self.logger.error("无法创建姿势快照：既不在Blender内部，也没有Socket连接")
                return {}
        except Exception as e:
            self.logger.error(f"创建姿势快照失败: {e}")
            return {}
    
    def _extract_openpose_bones_socket(self):
        """通过Socket提取骨骼信息"""
        if self.socket_client:
            bone_positions = self.socket_client.get_bone_position()
            # 将获取的骨骼信息转换为内部格式
            self.openpose_bones = {}
            for bone_name, bone_data in bone_positions.items():
                self.openpose_bones[bone_name] = {
                    'head': bone_data.get('location', [0, 0, 0]),
                    'tail': [0, 0, 0],  # Socket模式无法获取tail
                    'matrix': [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]],  # 默认矩阵
                    'parent': None  # Socket模式无法获取parent
                }

    def get_camera_info(self) -> Dict[str, Any]:
        """获取相机信息"""
        if self.blender_internal and bpy:
            camera_info = {}
            for obj in bpy.context.scene.objects:
                if obj.type == 'CAMERA':
                    camera_info = {
                        'location': list(obj.location),
                        'rotation': list(obj.rotation_euler),
                        'focal_length': obj.data.lens
                    }
                    break
            return camera_info
        elif self.socket_client:
            # Socket模式：从快照中获取相机信息
            snapshot = self.socket_client.create_pose_shot()
            return snapshot.get('camera', {})
        else:
            return {}

    def get_lighting_info(self) -> Dict[str, Any]:
        """获取光照信息"""
        if self.blender_internal and bpy:
            lighting_info = {}
            for obj in bpy.context.scene.objects:
                if obj.type == 'LIGHT':
                    lighting_info[obj.name] = {
                        'location': list(obj.location),
                        'rotation': list(obj.rotation_euler),
                        'energy': obj.data.energy,
                        'type': obj.data.type
                    }
            return lighting_info
        elif self.socket_client:
            # Socket模式：从快照中获取光照信息
            snapshot = self.socket_client.create_pose_shot()
            return snapshot.get('lighting', {})
        else:
            return {}
    
