"""
Blender Socket服务器插件
在Blender内部运行，接收外部Python脚本的命令
安装方法：
1. 在Blender中：编辑 > 偏好设置 > 插件 > 安装
2. 选择此文件安装
3. 启用插件
4. 在N面板（按N键）找到"Blender Socket Server"面板
5. 点击"Start Server"启动服务器
"""

bl_info = {
    "name": "Blender Socket Server",
    "author": "AIsampler",
    "version": (1, 2, 0),  # 更新版本号，修复线程安全问题
    "blender": (3, 0, 0),
    "location": "View3D > N Panel > Blender Socket Server",
    "description": "Socket服务器，用于接收外部Python脚本的控制命令（支持自动加载骨骼文件，线程安全）",
    "category": "Development",
}

import bpy
import socket
import threading
import json
import logging
import queue
import uuid
from typing import Dict, Any, Optional

# 全局变量
server_thread = None
server_socket = None
is_running = False
PORT = 8888  # 默认端口

# 命令队列（线程安全）- 用于将命令从Socket线程传递到主线程
command_queue = queue.Queue()
# 结果字典 - 用于存储命令执行结果
command_results = {}
result_lock = threading.Lock()


class BlenderSocketServerOperator(bpy.types.Operator):
    """启动/停止Socket服务器"""
    bl_idname = "blender_socket.start_server"
    bl_label = "Start/Stop Server"
    
    def execute(self, context):
        global server_thread, server_socket, is_running
        
        if is_running:
            # 停止服务器
            is_running = False
            if server_socket:
                try:
                    server_socket.close()
                except:
                    pass
            self.report({'INFO'}, "服务器已停止")
        else:
            # 启动服务器
            port = context.scene.blender_socket_port
            start_server(port)
            
            # 如果启用了自动加载，尝试加载骨骼文件
            if context.scene.blender_socket_auto_load:
                auto_load_bone_file(context)
            
            self.report({'INFO'}, f"服务器已启动，端口: {port}")
        
        return {'FINISHED'}


def auto_load_bone_file(context):
    """自动加载骨骼文件"""
    try:
        import os
        
        # 获取文件路径
        file_path = context.scene.blender_socket_bone_file_path
        
        if not file_path or file_path == "":
            # 使用默认路径
            default_path = "adapter/blender/openpose/openpose_bone.blend"
            file_path = default_path
        
        # 转换为绝对路径（如果可能）
        if not os.path.isabs(file_path):
            # 尝试在常见位置查找
            possible_paths = [
                file_path,
                os.path.join(os.path.expanduser("~"), file_path),
                os.path.join(os.getcwd(), file_path),
                # 尝试从Blender脚本目录查找
                os.path.join(os.path.dirname(bpy.data.filepath) if bpy.data.filepath else "", file_path),
            ]
            
            found = False
            for path in possible_paths:
                if os.path.exists(path):
                    file_path = os.path.abspath(path)
                    found = True
                    break
            
            if not found:
                # 如果都不存在，尝试使用第一个路径（让Blender尝试加载）
                file_path = os.path.abspath(possible_paths[0])
        
        # 检查文件是否存在
        if os.path.exists(file_path):
            try:
                # 先清除场景中的所有对象，防止模型覆盖阻挡
                try:
                    # 取消所有选择
                    bpy.ops.object.select_all(action='SELECT')
                    # 删除所有选中的对象
                    bpy.ops.object.delete(use_global=False)
                    print("✅ 已清除场景中的所有对象")
                except Exception as clear_error:
                    print(f"⚠️  清除场景失败: {clear_error}，继续加载文件")
                
                # 方法1：使用append方法导入.blend文件（更安全，不会替换场景）
                try:
                    with bpy.data.libraries.load(file_path) as (data_from, data_to):
                        # 只导入armature对象，避免导入过多不必要的内容
                        data_to.objects = [name for name in data_from.objects]
                        # 不导入集合，只导入对象
                        # data_to.collections = data_from.collections
                    
                    # 将导入的对象添加到场景
                    imported_count = 0
                    imported_objects = []
                    for obj in data_to.objects:
                        if obj is not None and obj.type == 'ARMATURE':
                            # 检查是否已存在同名对象
                            if obj.name not in bpy.context.scene.objects:
                                bpy.context.collection.objects.link(obj)
                                imported_count += 1
                                imported_objects.append(obj)
                    
                    if imported_count > 0:
                        # 自动选中并聚焦到第一个导入的armature对象
                        try:
                            first_armature = imported_objects[0]
                            # 取消所有选择
                            bpy.ops.object.select_all(action='DESELECT')
                            # 选中导入的armature对象
                            first_armature.select_set(True)
                            # 设置为活动对象
                            bpy.context.view_layer.objects.active = first_armature
                            # 聚焦到选中的对象（让视口跳转到对象）
                            bpy.ops.view3d.view_selected()
                            print(f"✅ 自动加载骨骼文件成功: {file_path}，导入了 {imported_count} 个armature对象")
                            print(f"   已自动聚焦到armature对象: {first_armature.name}")
                        except Exception as focus_error:
                            print(f"✅ 自动加载骨骼文件成功: {file_path}，导入了 {imported_count} 个armature对象")
                            print(f"   聚焦到对象失败: {focus_error}")
                        return True
                    else:
                        # 检查是否因为对象已存在
                        existing_armatures = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE']
                        if existing_armatures:
                            # 如果已存在，也聚焦到第一个
                            try:
                                first_existing = existing_armatures[0]
                                bpy.ops.object.select_all(action='DESELECT')
                                first_existing.select_set(True)
                                bpy.context.view_layer.objects.active = first_existing
                                bpy.ops.view3d.view_selected()
                                print(f"⚠️  文件中没有新的armature对象，场景中已有: {[obj.name for obj in existing_armatures]}")
                                print(f"   已自动聚焦到armature对象: {first_existing.name}")
                            except Exception as focus_error:
                                print(f"⚠️  文件中没有新的armature对象或对象已存在")
                                print(f"   聚焦到已存在对象失败: {focus_error}")
                        else:
                            print(f"⚠️  文件中没有armature对象或对象已存在")
                        return False
                except Exception as e:
                    print(f"⚠️  Append方法失败: {e}，尝试其他方法...")
                    # 如果append失败，不尝试打开文件（会替换场景），而是返回失败
                    print(f"❌ 自动加载骨骼文件失败: {e}")
                    print("   建议：手动在Blender中导入文件，或检查文件格式")
                    return False
            except Exception as e:
                print(f"❌ 自动加载骨骼文件异常: {e}")
                import traceback
                traceback.print_exc()
                return False
        else:
            print(f"⚠️  骨骼文件不存在: {file_path}")
            print("   请检查文件路径，或在面板中设置正确的路径")
            return False
    except Exception as e:
        print(f"❌ 自动加载骨骼文件异常: {e}")
        return False


class BlenderSocketPanel(bpy.types.Panel):
    """Blender Socket服务器面板"""
    bl_label = "Blender Socket Server"
    bl_idname = "VIEW3D_PT_blender_socket"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Blender Socket"
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        layout.prop(scene, "blender_socket_port")
        layout.prop(scene, "blender_socket_auto_load")
        
        if scene.blender_socket_auto_load:
            layout.prop(scene, "blender_socket_bone_file_path")
        
        layout.separator()
        
        global is_running
        if is_running:
            layout.label(text="状态: 运行中", icon='CHECKMARK')
            layout.operator("blender_socket.start_server", text="停止服务器")
        else:
            layout.label(text="状态: 已停止", icon='X')
            layout.operator("blender_socket.start_server", text="启动服务器")


def handle_client(client_socket, address):
    """处理客户端连接（在后台线程中运行）"""
    global is_running, command_queue, command_results
    
    try:
        # 设置socket超时，避免长时间阻塞
        client_socket.settimeout(60.0)  # 60秒超时
        
        while is_running:
            try:
                # 接收数据（可能需要多次接收）
                data = b""
                while True:
                    chunk = client_socket.recv(4096)
                    if not chunk:
                        break
                    data += chunk
                    # 尝试解析JSON，如果成功说明数据接收完毕
                    try:
                        json.loads(data.decode('utf-8'))
                        break
                    except json.JSONDecodeError:
                        # 继续接收
                        if len(chunk) < 4096:
                            break
                        continue
                
                if not data:
                    break
                
                # 解析JSON命令
                try:
                    command = json.loads(data.decode('utf-8'))
                except json.JSONDecodeError as e:
                    error_response = json.dumps({
                        'success': False,
                        'error': f'JSON解析错误: {str(e)}'
                    })
                    client_socket.send(error_response.encode('utf-8'))
                    continue
                
                # 生成命令ID
                command_id = str(uuid.uuid4())
                
                # 创建结果事件
                result_event = threading.Event()
                
                # 将命令放入队列（在主线程中执行）
                command_queue.put({
                    'id': command_id,
                    'command': command,
                    'event': result_event
                })
                
                # 等待结果（最多等待30秒）
                if result_event.wait(timeout=30.0):
                    # 获取结果
                    with result_lock:
                        result = command_results.pop(command_id, {'success': False, 'error': '结果未找到'})
                else:
                    result = {'success': False, 'error': '操作超时（30秒）'}
                
                # 发送响应
                try:
                    response = json.dumps(result, ensure_ascii=False)
                    response_bytes = response.encode('utf-8')
                    
                    # 分块发送（如果数据较大）
                    total_sent = 0
                    while total_sent < len(response_bytes):
                        sent = client_socket.send(response_bytes[total_sent:])
                        if sent == 0:
                            raise RuntimeError("Socket连接断开")
                        total_sent += sent
                except Exception as e:
                    print(f"发送响应失败: {e}")
                    break
                        
            except socket.timeout:
                print(f"客户端 {address} 请求超时")
                break
            except Exception as e:
                print(f"处理客户端请求时出错: {e}")
                try:
                    error_response = json.dumps({
                        'success': False,
                        'error': f'处理错误: {str(e)}'
                    })
                    client_socket.send(error_response.encode('utf-8'))
                except:
                    pass
                break
                
    except Exception as e:
        print(f"客户端连接错误: {e}")
    finally:
        client_socket.close()


def process_command_queue():
    """处理命令队列（在主线程中运行，由bpy.app.timers调用）"""
    global command_queue, command_results
    
    processed_count = 0
    max_process_per_frame = 1  # 每帧最多处理1个命令，避免阻塞
    
    while processed_count < max_process_per_frame:
        try:
            # 从队列中获取命令
            queue_item = command_queue.get_nowait()
            command_id = queue_item['id']
            command = queue_item['command']
            result_event = queue_item['event']
            
            # 在主线程中执行命令
            try:
                result = execute_command_safe(command)
            except Exception as e:
                result = {'success': False, 'error': f'执行命令失败: {str(e)}'}
                import traceback
                print(f"执行命令异常: {traceback.format_exc()}")
            
            # 存储结果
            with result_lock:
                command_results[command_id] = result
            
            # 通知等待的线程
            result_event.set()
            processed_count += 1
            
        except queue.Empty:
            break
    
    # 返回间隔时间（秒），0.01秒后再次检查
    return 0.01


def execute_command_safe(command: Dict[str, Any]) -> Dict[str, Any]:
    """安全执行Blender命令（必须在主线程中调用）"""
    cmd_type = command.get('type')
    
    try:
        if cmd_type == 'load_openpose_file':
            file_path = command.get('file_path')
            if file_path:
                import os
                # 检查文件是否存在
                if not os.path.exists(file_path):
                    return {'success': False, 'error': f'文件不存在: {file_path}'}
                
                try:
                    # 检查是否是初始化加载（场景中没有armature对象）
                    existing_armatures = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE']
                    is_initial_load = len(existing_armatures) == 0
                    
                    # 只在初始化时清除场景，持续调整时保留场景
                    if is_initial_load:
                        try:
                            # 取消所有选择
                            bpy.ops.object.select_all(action='SELECT')
                            # 删除所有选中的对象
                            bpy.ops.object.delete(use_global=False)
                            print("✅ 初始化加载：已清除场景中的所有对象")
                        except Exception as clear_error:
                            print(f"⚠️  清除场景失败: {clear_error}，继续加载文件")
                    else:
                        print(f"ℹ️  持续调整：场景中已有armature对象，保留场景内容")
                    
                    # 使用append方法导入.blend文件（更安全）
                    with bpy.data.libraries.load(file_path) as (data_from, data_to):
                        # 导入所有对象，稍后过滤armature类型
                        data_to.objects = data_from.objects
                    
                    # 将导入的对象添加到场景（只添加armature类型）
                    imported_count = 0
                    imported_names = []
                    imported_objects = []
                    for obj in data_to.objects:
                        if obj is not None and obj.type == 'ARMATURE':
                            # 检查是否已存在
                            if obj.name not in bpy.context.scene.objects:
                                try:
                                    bpy.context.collection.objects.link(obj)
                                    imported_count += 1
                                    imported_names.append(obj.name)
                                    imported_objects.append(obj)
                                except Exception as link_error:
                                    print(f"链接对象 {obj.name} 失败: {link_error}")
                    
                    if imported_count > 0:
                        # 自动选中并聚焦到第一个导入的armature对象
                        try:
                            first_armature = imported_objects[0]
                            # 取消所有选择
                            bpy.ops.object.select_all(action='DESELECT')
                            # 选中导入的armature对象
                            first_armature.select_set(True)
                            # 设置为活动对象
                            bpy.context.view_layer.objects.active = first_armature
                            # 聚焦到选中的对象（让视口跳转到对象）
                            bpy.ops.view3d.view_selected()
                            print(f"已自动聚焦到armature对象: {first_armature.name}")
                        except Exception as focus_error:
                            print(f"聚焦到对象失败: {focus_error}")
                        
                        return {'success': True, 'message': f'文件加载成功: {file_path}，导入了 {imported_count} 个armature对象: {imported_names}'}
                    else:
                        # 检查是否因为对象已存在
                        existing_armatures = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE']
                        if existing_armatures:
                            # 如果已存在，也聚焦到第一个
                            try:
                                first_existing = existing_armatures[0]
                                bpy.ops.object.select_all(action='DESELECT')
                                first_existing.select_set(True)
                                bpy.context.view_layer.objects.active = first_existing
                                bpy.ops.view3d.view_selected()
                                print(f"已自动聚焦到已存在的armature对象: {first_existing.name}")
                            except Exception as focus_error:
                                print(f"聚焦到已存在对象失败: {focus_error}")
                            
                            return {'success': True, 'message': f'文件中没有新的armature对象，场景中已有: {[obj.name for obj in existing_armatures]}'}
                        else:
                            return {'success': False, 'error': f'文件中没有armature对象'}
                except Exception as e:
                    # 不尝试打开文件（会替换场景），直接返回错误
                    error_msg = str(e)
                    import traceback
                    traceback_str = traceback.format_exc()
                    print(f"加载文件失败: {error_msg}")
                    print(f"详细错误: {traceback_str}")
                    return {'success': False, 'error': f'加载文件失败: {error_msg}'}
            else:
                return {'success': False, 'error': '文件路径为空'}
        
        elif cmd_type == 'update_bone_pose':
            bone_name = command.get('bone_name')
            position = command.get('position')
            rotation = command.get('rotation')
            
            # 查找armature对象
            armature = None
            for obj in bpy.context.scene.objects:
                if obj.type == 'ARMATURE':
                    armature = obj
                    break
            
            if not armature:
                return {'success': False, 'error': '未找到armature对象'}
            
            # 切换到POSE模式
            bpy.context.view_layer.objects.active = armature
            bpy.ops.object.mode_set(mode='POSE')
            
            # 更新骨骼
            if bone_name in armature.pose.bones:
                bone = armature.pose.bones[bone_name]
                if position:
                    bone.location = position
                if rotation:
                    bone.rotation_euler = rotation
                
                bpy.ops.object.mode_set(mode='OBJECT')
                return {'success': True, 'message': f'骨骼 {bone_name} 更新成功'}
            else:
                return {'success': False, 'error': f'未找到骨骼: {bone_name}'}
        
        elif cmd_type == 'get_bone_position':
            # 获取所有骨骼位置
            bone_positions = {}
            armature = None
            
            for obj in bpy.context.scene.objects:
                if obj.type == 'ARMATURE':
                    armature = obj
                    break
            
            if armature:
                bpy.context.view_layer.objects.active = armature
                bpy.ops.object.mode_set(mode='POSE')
                
                for bone in armature.pose.bones:
                    bone_positions[bone.name] = {
                        'location': list(bone.location),
                        'rotation': list(bone.rotation_euler),
                        'scale': list(bone.scale)
                    }
                
                bpy.ops.object.mode_set(mode='OBJECT')
            
            return {'success': True, 'data': bone_positions}
        
        elif cmd_type == 'create_pose_shot':
            # 创建姿势快照
            snapshot = {
                'timestamp': bpy.context.scene.frame_current,
                'bones': {},
                'camera': {},
                'lighting': {}
            }
            
            # 获取骨骼信息
            armature = None
            for obj in bpy.context.scene.objects:
                if obj.type == 'ARMATURE':
                    armature = obj
                    break
            
            if armature:
                bpy.context.view_layer.objects.active = armature
                bpy.ops.object.mode_set(mode='POSE')
                
                for bone in armature.pose.bones:
                    snapshot['bones'][bone.name] = {
                        'location': list(bone.location),
                        'rotation': list(bone.rotation_euler),
                        'scale': list(bone.scale)
                    }
                
                bpy.ops.object.mode_set(mode='OBJECT')
            
            # 获取相机信息
            for obj in bpy.context.scene.objects:
                if obj.type == 'CAMERA':
                    snapshot['camera'] = {
                        'location': list(obj.location),
                        'rotation': list(obj.rotation_euler),
                        'focal_length': obj.data.lens
                    }
                    break
            
            # 获取光照信息
            for obj in bpy.context.scene.objects:
                if obj.type == 'LIGHT':
                    snapshot['lighting'][obj.name] = {
                        'location': list(obj.location),
                        'rotation': list(obj.rotation_euler),
                        'energy': obj.data.energy,
                        'type': obj.data.type
                    }
            
            return {'success': True, 'data': snapshot}
        
        elif cmd_type == 'ping':
            return {'success': True, 'message': 'pong'}
        
        elif cmd_type == 'list_scene_objects':
            # 列出场景中的所有对象（用于调试）
            objects_info = {}
            for obj in bpy.context.scene.objects:
                objects_info[obj.name] = {
                    'type': obj.type,
                    'visible': obj.visible_get(),
                    'location': list(obj.location) if hasattr(obj, 'location') else None
                }
            return {'success': True, 'data': objects_info}
        
        else:
            return {'success': False, 'error': f'未知命令类型: {cmd_type}'}
            
    except Exception as e:
        return {'success': False, 'error': f'执行命令失败: {str(e)}'}


def server_loop(port: int):
    """服务器主循环"""
    global server_socket, is_running
    
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind(('localhost', port))
        server_socket.listen(5)
        server_socket.settimeout(1.0)  # 设置超时，以便检查is_running
        
        print(f"Blender Socket服务器已启动，监听端口: {port}")
        
        while is_running:
            try:
                client_socket, address = server_socket.accept()
                print(f"客户端连接: {address}")
                
                # 在新线程中处理客户端
                client_thread = threading.Thread(
                    target=handle_client,
                    args=(client_socket, address),
                    daemon=True
                )
                client_thread.start()
                
            except socket.timeout:
                continue
            except Exception as e:
                if is_running:
                    print(f"服务器错误: {e}")
                
    except Exception as e:
        print(f"服务器启动失败: {e}")
    finally:
        if server_socket:
            try:
                server_socket.close()
            except:
                pass
        is_running = False
        print("Blender Socket服务器已停止")


def start_server(port: int):
    """启动服务器"""
    global server_thread, is_running
    
    if is_running:
        return
    
    is_running = True
    
    # 注册命令处理定时器（在主线程中运行）
    if not bpy.app.timers.is_registered(process_command_queue):
        bpy.app.timers.register(process_command_queue)
        print("命令处理定时器已注册")
    
    server_thread = threading.Thread(
        target=server_loop,
        args=(port,),
        daemon=True
    )
    server_thread.start()


def stop_server():
    """停止服务器"""
    global is_running, server_socket, command_queue, command_results
    
    is_running = False
    
    # 取消注册定时器
    if bpy.app.timers.is_registered(process_command_queue):
        bpy.app.timers.unregister(process_command_queue)
        print("命令处理定时器已取消注册")
    
    if server_socket:
        try:
            server_socket.close()
        except:
            pass
    
    # 清空队列
    while not command_queue.empty():
        try:
            command_queue.get_nowait()
        except queue.Empty:
            break
    
    with result_lock:
        command_results.clear()


# Blender插件注册
classes = [
    BlenderSocketServerOperator,
    BlenderSocketPanel,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # 添加端口属性
    bpy.types.Scene.blender_socket_port = bpy.props.IntProperty(
        name="端口",
        default=8888,
        min=1024,
        max=65535
    )
    
    # 添加自动加载属性
    bpy.types.Scene.blender_socket_auto_load = bpy.props.BoolProperty(
        name="启动时自动加载骨骼",
        default=True,
        description="启动服务器时自动加载OpenPose骨骼文件"
    )
    
    # 添加骨骼文件路径属性
    bpy.types.Scene.blender_socket_bone_file_path = bpy.props.StringProperty(
        name="骨骼文件路径",
        default="adapter/blender/openpose/openpose_bone.blend",
        description="OpenPose骨骼文件路径（相对或绝对路径）",
        subtype='FILE_PATH'
    )
    
    print("Blender Socket Server插件已注册")


def unregister():
    stop_server()
    
    # 清空队列
    global command_queue, command_results
    while not command_queue.empty():
        try:
            command_queue.get_nowait()
        except queue.Empty:
            break
    
    with result_lock:
        command_results.clear()
    
    for cls in classes:
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.blender_socket_port
    del bpy.types.Scene.blender_socket_auto_load
    del bpy.types.Scene.blender_socket_bone_file_path
    
    print("Blender Socket Server插件已卸载")


if __name__ == "__main__":
    register()

