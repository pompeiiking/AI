"""
Blender Socket客户端
用于从外部Python脚本连接Blender Socket服务器
"""

import socket
import json
import logging
from typing import Dict, Any, Optional


class BlenderSocketClient:
    """Blender Socket客户端"""
    
    def __init__(self, host: str = 'localhost', port: int = 8888):
        """
        初始化Socket客户端
        
        Args:
            host: Blender服务器地址，默认localhost
            port: Blender服务器端口，默认8888
        """
        self.host = host
        self.port = port
        self.logger = logging.getLogger(__name__)
        self.timeout = 30.0  # 连接超时时间（增加到30秒，因为文件加载可能需要时间）
    
    def _send_command(self, command: Dict[str, Any]) -> Dict[str, Any]:
        """
        发送命令到Blender服务器
        
        Args:
            command: 命令字典
            
        Returns:
            dict: 服务器响应
        """
        try:
            # 创建socket连接
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.settimeout(self.timeout)
            client_socket.connect((self.host, self.port))
            
            # 发送命令
            command_json = json.dumps(command, ensure_ascii=False)
            client_socket.send(command_json.encode('utf-8'))
            
            # 接收响应（可能需要多次接收）
            response_data = b""
            while True:
                chunk = client_socket.recv(4096)
                if not chunk:
                    break
                response_data += chunk
                # 如果数据量较小，可能已经接收完毕
                if len(chunk) < 4096:
                    break
            
            client_socket.close()
            
            # 解析响应
            response = json.loads(response_data.decode('utf-8'))
            return response
            
        except socket.timeout:
            self.logger.error(f"连接Blender服务器超时 ({self.host}:{self.port})")
            return {'success': False, 'error': '连接超时'}
        except ConnectionRefusedError:
            self.logger.error(f"无法连接到Blender服务器 ({self.host}:{self.port})，请确保Blender插件已启动")
            return {'success': False, 'error': '连接被拒绝，请确保Blender Socket服务器已启动'}
        except (ConnectionResetError, OSError) as e:
            error_code = getattr(e, 'winerror', getattr(e, 'errno', None))
            if error_code == 10054:  # Windows: 远程主机强迫关闭连接
                self.logger.error(f"Blender服务器关闭了连接 ({self.host}:{self.port})，可能服务器在处理请求时出错")
            else:
                self.logger.error(f"连接错误: {e}")
            return {'success': False, 'error': f'连接错误: {str(e)}'}
        except Exception as e:
            self.logger.error(f"发送命令失败: {e}")
            return {'success': False, 'error': str(e)}
    
    def ping(self) -> bool:
        """
        测试连接
        
        Returns:
            bool: 是否连接成功
        """
        response = self._send_command({'type': 'ping'})
        return response.get('success', False)
    
    def load_openpose_file(self, file_path: str) -> bool:
        """
        加载OpenPose骨骼文件
        
        Args:
            file_path: 文件路径
            
        Returns:
            bool: 是否加载成功
        """
        response = self._send_command({
            'type': 'load_openpose_file',
            'file_path': file_path
        })
        
        if response.get('success'):
            self.logger.info(f"文件加载成功: {file_path}")
            return True
        else:
            self.logger.error(f"文件加载失败: {response.get('error')}")
            return False
    
    def update_bone_pose(self, bone_name: str, 
                        position: Optional[list] = None,
                        rotation: Optional[list] = None) -> bool:
        """
        更新骨骼姿势
        
        Args:
            bone_name: 骨骼名称
            position: 位置 [x, y, z]
            rotation: 旋转 [x, y, z] (欧拉角)
            
        Returns:
            bool: 是否更新成功
        """
        command = {
            'type': 'update_bone_pose',
            'bone_name': bone_name
        }
        
        if position:
            command['position'] = position
        if rotation:
            command['rotation'] = rotation
        
        response = self._send_command(command)
        
        if response.get('success'):
            self.logger.info(f"骨骼 {bone_name} 更新成功")
            return True
        else:
            self.logger.error(f"骨骼更新失败: {response.get('error')}")
            return False
    
    def get_bone_position(self) -> Dict[str, Dict[str, list]]:
        """
        获取所有骨骼位置
        
        Returns:
            dict: 骨骼位置字典 {bone_name: {location, rotation, scale}}
        """
        response = self._send_command({'type': 'get_bone_position'})
        
        if response.get('success'):
            return response.get('data', {})
        else:
            self.logger.error(f"获取骨骼位置失败: {response.get('error')}")
            return {}
    
    def create_pose_shot(self) -> Dict[str, Any]:
        """
        创建姿势快照
        
        Returns:
            dict: 姿势快照数据
        """
        response = self._send_command({'type': 'create_pose_shot'})
        
        if response.get('success'):
            return response.get('data', {})
        else:
            self.logger.error(f"创建姿势快照失败: {response.get('error')}")
            return {}

