---
name: member-b-microservices
description: 成员B（微服务组件）的AI开发边界规范。负责service-auth、service-supplier、service-order、service-data、common-core、common-feign模块开发时加载此skill。包含开发边界、接口实现、Feign调用、对接要求。
metadata:
  priority: L1
  category: team
  depends: team-development-boundary, interface-contract, file-structure
---

# 成员B - 微服务组件开发边界

> **版本：V1.0 | 负责人：成员B | 最后更新：2026-04-01**

---

## 1. 模块边界

### 1.1 负责范围

```
┌─────────────────────────────────────────────────────────────────┐
│                    成员B 的开发边界                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   common-core/                                                  │
│   ├── Result<T>                # 统一响应封装                    │
│   ├── ResultCode               # 统一状态码枚举                  │
│   ├── BaseEntity              # 实体基类（id, createdAt等）     │
│   ├── BizException            # 业务异常基类                    │
│   ├── PageQuery               # 分页查询基类                   │
│   └── Constants               # 全局常量                        │
│                                                                 │
│   common-feign/                                                 │
│   ├── OrderFeignClient        # 订单服务Feign客户端           │
│   ├── SupplierFeignClient      # 供应商服务Feign客户端         │
│   ├── AuthFeignClient         # 认证服务Feign客户端           │
│   └── FallbackFactory         # Feign降级工厂                  │
│                                                                 │
│   service-auth/ (8081)                                        │
│   ├── 用户注册/登录/登出                                        │
│   ├── JWT Token生成与验证                                       │
│   ├── 角色与权限管理                                           │
│   └── 用户信息查询                                             │
│                                                                 │
│   service-supplier/ (8082)                                     │
│   ├── 供应商CRUD                                              │
│   ├── 联系人管理                                               │
│   ├── 资质管理                                                │
│   ├── 评分计算（基础数据）                                     │
│   └── 服务响应记录                                             │
│                                                                 │
│   service-order/ (8083)                                        │
│   ├── 订单CRUD                                              │
│   ├── 订单明细管理                                            │
│   ├── 交货记录                                                │
│   ├── 状态流转控制                                            │
│   └── 订单统计                                                │
│                                                                 │
│   service-data/ (8092)                                         │
│   ├── 仪表盘数据聚合                                          │
│   ├── 供应评估计算                                            │
│   ├── 五维度得分计算                                          │
│   ├── 单品溯源聚合                                            │
│   └── 数据统计分析                                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 禁止操作

```
┌─────────────────────────────────────────────────────────────────┐
│                    绝对禁止事项                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ❌ 禁止修改 project-frontend 的任何代码                       │
│   ❌ 禁止修改 project-gateway 的代码                            │
│   ❌ 禁止修改前端代码                                           │
│   ❌ 禁止在服务中直接操作其他服务的数据库表                      │
│   ❌ 禁止绕过Feign接口进行服务间调用（禁止RestTemplate直接调用） │
│   ❌ 禁止在业务代码中硬编码数据库连接信息                        │
│   ❌ 禁止修改 rules/ 下的规范文档（除非授权）                   │
│   ❌ 禁止修改成员C负责的数据库表结构（除非授权）                 │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. 公共模块开发规范

### 2.1 common-core 统一响应

```java
// common-core/Result.java
@Data
public class Result<T> implements Serializable {
    private int code;
    private String message;
    private T data;
    private long timestamp;
    private String traceId;

    public static <T> Result<T> success(T data) {
        Result<T> r = new Result<>();
        r.code = 200;
        r.message = "success";
        r.data = data;
        r.timestamp = System.currentTimeMillis();
        return r;
    }

    public static <T> Result<T> success() {
        return success(null);
    }

    public static <T> Result<T> fail(int code, String message) {
        Result<T> r = new Result<>();
        r.code = code;
        r.message = message;
        r.timestamp = System.currentTimeMillis();
        return r;
    }

    public static <T> Result<T> fail(ResultCode resultCode) {
        return fail(resultCode.getCode(), resultCode.getMessage());
    }
}
```

```java
// common-core/ResultCode.java
public enum ResultCode {
    SUCCESS(200, "success"),
    BAD_REQUEST(400, "请求参数错误"),
    UNAUTHORIZED(401, "未认证"),
    FORBIDDEN(403, "无权限"),
    NOT_FOUND(404, "资源不存在"),
    INTERNAL_ERROR(500, "服务器内部错误"),
    TOKEN_INVALID(401, "Token无效或已过期"),
    // 业务状态码
    USER_NOT_FOUND(404, "用户不存在"),
    PASSWORD_ERROR(401, "密码错误"),
    USERNAME_EXISTS(409, "用户名已存在"),
    ;

    private final int code;
    private final String message;
}
```

### 2.2 common-feign Feign客户端声明

```java
// common-feign/OrderFeignClient.java
@FeignClient(name = "order-service", fallbackFactory = OrderFeignClientFallbackFactory.class)
public interface OrderFeignClient {

    @GetMapping("/orders")
    Result<List<OrderBaseVO>> getOrders(@RequestParam Map<String, Object> params);

    @GetMapping("/orders/{id}")
    Result<OrderDetailVO> getOrderById(@PathVariable("id") Long id);

    @GetMapping("/orders/delivery-stats")
    Result<DeliveryStatsVO> getDeliveryStats(
        @RequestParam("supplierId") Long supplierId,
        @RequestParam("startDate") String startDate,
        @RequestParam("endDate") String endDate
    );

    @GetMapping("/orders/{id}/deliveries")
    Result<List<DeliveryVO>> getDeliveries(@PathVariable("id") Long orderId);
}

// FallbackFactory实现
@Component
public class OrderFeignClientFallbackFactory implements FallbackFactory<OrderFeignClient> {
    @Override
    public OrderFeignClient create(Throwable cause) {
        return new OrderFeignClient() {
            @Override
            public Result<List<OrderBaseVO>> getOrders(Map<String, Object> params) {
                log.error("调用order-service失败: {}", cause.getMessage());
                return Result.fail(ResultCode.INTERNAL_ERROR);
            }
            // ... 其他方法类似
        };
    }
}
```

```java
// common-feign/SupplierFeignClient.java
@FeignClient(name = "supplier-service", fallbackFactory = SupplierFeignClientFallbackFactory.class)
public interface SupplierFeignClient {

    @GetMapping("/suppliers/{id}")
    Result<SupplierBaseVO> getSupplierById(@PathVariable("id") Long id);

    @GetMapping("/suppliers/{id}/score")
    Result<SupplierScoreVO> getSupplierScore(
        @PathVariable("id") Long supplierId,
        @RequestParam(required = false) String period
    );

    @GetMapping("/suppliers/{id}/response-log")
    Result<List<ResponseLogVO>> getResponseLogs(
        @PathVariable("id") Long supplierId,
        @RequestParam("period") String period
    );
}
```

---

## 3. 服务开发规范

### 3.1 各服务职责与边界

#### service-auth (8081)

```
┌─────────────────────────────────────────────────────────────────┐
│                    service-auth 职责                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   数据库表（成员C提供）：                                        │
│   ├── sys_user          # 用户表                                │
│   ├── sys_role          # 角色表                                │
│   ├── sys_permission    # 权限表                                │
│   ├── sys_user_role     # 用户角色关联                          │
│   └── sys_role_permission # 角色权限关联                        │
│                                                                 │
│   提供接口（供网关调用）：                                       │
│   ├── POST /auth/login              # 用户登录                 │
│   ├── POST /auth/logout             # 用户登出                 │
│   ├── POST /auth/refresh            # 刷新Token                │
│   ├── GET  /auth/userinfo           # 获取用户信息             │
│   ├── GET  /auth/permissions        # 获取权限列表             │
│   └── GET  /auth/validate           # Token验证（网关内部调用） │
│                                                                 │
│   提供接口（供其他服务调用 - Feign）：                           │
│   ├── AuthFeignClient                # 声明在common-feign中     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### service-supplier (8082)

```
┌─────────────────────────────────────────────────────────────────┐
│                    service-supplier 职责                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   数据库表（成员C提供）：                                        │
│   ├── supplier_base            # 供应商基础信息                  │
│   ├── supplier_contact         # 供应商联系人                    │
│   ├── supplier_qualification   # 供应商资质                     │
│   ├── supplier_score          # 供应商评分（原始分）             │
│   └── service_response_log     # 服务响应记录                    │
│                                                                 │
│   提供接口（供网关调用）：                                       │
│   ├── GET    /suppliers                    # 供应商列表         │
│   ├── POST   /suppliers                    # 新增供应商         │
│   ├── GET    /suppliers/{id}               # 供应商详情         │
│   ├── PUT    /suppliers/{id}               # 更新供应商         │
│   ├── DELETE /suppliers/{id}               # 删除供应商         │
│   ├── GET    /suppliers/{id}/score         # 供应商评分         │
│   ├── GET    /suppliers/ranking            # 供应商排名         │
│   ├── POST   /suppliers/{id}/response-log  # 记录服务响应      │
│   └── GET    /suppliers/{id}/response-log   # 查询服务响应      │
│                                                                 │
│   提供Feign接口（供data-service调用）：                          │
│   └── SupplierFeignClient        # 声明在common-feign中         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### service-order (8083)

```
┌─────────────────────────────────────────────────────────────────┐
│                    service-order 职责                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   数据库表（成员C提供）：                                        │
│   ├── order_main           # 订单主表                           │
│   ├── order_item          # 订单明细表                          │
│   ├── order_delivery      # 交货记录表                          │
│   └── order_status_log    # 状态变更日志                        │
│                                                                 │
│   提供接口（供网关调用）：                                       │
│   ├── GET    /orders                      # 订单列表            │
│   ├── POST   /orders                      # 创建订单            │
│   ├── GET    /orders/{id}                 # 订单详情            │
│   ├── PUT    /orders/{id}                 # 更新订单            │
│   ├── PUT    /orders/{id}/status          # 更新状态            │
│   ├── POST   /orders/{id}/deliveries      # 添加交货记录       │
│   ├── GET    /orders/{id}/deliveries      # 交货记录列表       │
│   ├── GET    /orders/delivery-stats       # 交货统计           │
│   └── GET    /orders/{id}/status-log      # 状态日志           │
│                                                                 │
│   提供Feign接口（供data-service调用）：                          │
│   └── OrderFeignClient        # 声明在common-feign中            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

#### service-data (8092)

```
┌─────────────────────────────────────────────────────────────────┐
│                    service-data 职责                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   数据库表（成员C提供）：                                        │
│   ├── supplier_evaluation  # 供应商评估（五维度聚合结果）        │
│   ├── monthly_trend       # 月度趋势                           │
│   ├── purchase_summary    # 采购统计汇总                       │
│   └── material_trace_summary # 单品溯源汇总                    │
│                                                                 │
│   依赖Feign接口：                                               │
│   ├── OrderFeignClient     # 调用order-service                 │
│   └── SupplierFeignClient  # 调用supplier-service              │
│                                                                 │
│   提供接口（供网关调用）：                                       │
│   ├── GET /dashboard                   # 仪表盘数据             │
│   ├── GET /statistics/purchase         # 采购统计              │
│   ├── GET /statistics/quality          # 质量统计              │
│   ├── GET /evaluate/supplier/{id}      # 供应商评估详情         │
│   ├── GET /evaluate/ranking            # 供应商排名            │
│   ├── GET /evaluate/trend              # 月度趋势              │
│   ├── GET /trace/material              # 单品溯源              │
│   └── GET /trace/batch/{batchNo}      # 批次溯源              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. 服务开发模板

### 4.1 Controller 开发模板

```java
// service-xxx/src/main/java/.../controller/XxxController.java
@RestController
@RequestMapping("/xxx")
@RequiredArgsConstructor
@Api(tags = "Xxx管理")
@Slf4j
public class XxxController {

    private final XxxService xxxService;

    @GetMapping
    @ApiOperation("获取列表")
    public Result<PageResult<XxxVO>> list(XxxQuery query) {
        IPage<Xxx> page = xxxService.page(query);
        return Result.success(PageResult.of(page));
    }

    @GetMapping("/{id}")
    @ApiOperation("获取详情")
    public Result<XxxDetailVO> getById(@PathVariable Long id) {
        return Result.success(xxxService.getDetailById(id));
    }

    @PostMapping
    @ApiOperation("新增")
    public Result<Long> create(@RequestBody @Valid CreateXxxDTO dto) {
        return Result.success(xxxService.create(dto));
    }

    @PutMapping("/{id}")
    @ApiOperation("更新")
    public Result<Void> update(@PathVariable Long id,
                               @RequestBody @Valid UpdateXxxDTO dto) {
        xxxService.update(id, dto);
        return Result.success();
    }

    @DeleteMapping("/{id}")
    @ApiOperation("删除")
    public Result<Void> delete(@PathVariable Long id) {
        xxxService.delete(id);
        return Result.success();
    }
}
```

### 4.2 Service 开发模板

```java
// service-xxx/src/main/java/.../service/XxxService.java
public interface XxxService {
    IPage<Xxx> page(XxxQuery query);
    XxxDetailVO getDetailById(Long id);
    Long create(CreateXxxDTO dto);
    void update(Long id, UpdateXxxDTO dto);
    void delete(Long id);
}

// service-xxx/src/main/java/.../service/impl/XxxServiceImpl.java
@Service
@RequiredArgsConstructor
@Slf4j
public class XxxServiceImpl implements XxxService {

    private final XxxMapper xxxMapper;

    @Override
    public IPage<Xxx> page(XxxQuery query) {
        return xxxMapper.selectPage(
            new LambdaQueryWrapper<Xxx>()
                .like(StringUtils.hasText(query.getKeyword()),
                      Xxx::getName, query.getKeyword())
                .eq(query.getStatus() != null,
                    Xxx::getStatus, query.getStatus())
                .orderByDesc(Xxx::getCreatedAt),
            new Page<>(query.getPageNum(), query.getPageSize())
        );
    }

    @Override
    public XxxDetailVO getDetailById(Long id) {
        Xxx xxx = xxxMapper.selectById(id);
        if (xxx == null) {
            throw new BizException(ResultCode.NOT_FOUND, "Xxx不存在");
        }
        // 转换详情VO
        return convertToDetailVO(xxx);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long create(CreateXxxDTO dto) {
        // 业务校验
        validateCreate(dto);

        Xxx xxx = new Xxx();
        BeanUtils.copyProperties(dto, xxx);
        xxxMapper.insert(xxx);
        return xxx.getId();
    }

    private void validateCreate(CreateXxxDTO dto) {
        // 唯一性校验等
        if (xxxMapper.exists(new LambdaQueryWrapper<Xxx>()
                .eq(Xxx::getCode, dto.getCode()))) {
            throw new BizException(ResultCode.BAD_REQUEST, "编码已存在");
        }
    }
}
```

### 4.3 Feign 调用示例

```java
// service-data/.../service/EvaluationService.java
@Service
@RequiredArgsConstructor
public class EvaluationService {

    private final OrderFeignClient orderFeignClient;
    private final SupplierFeignClient supplierFeignClient;

    public SupplierEvaluationVO evaluateSupplier(Long supplierId, String period) {
        // 1. 获取供应商基础信息
        Result<SupplierBaseVO> supplierResult = supplierFeignClient.getSupplierById(supplierId);
        if (supplierResult.getCode() != 200) {
            throw new BizException(ResultCode.INTERNAL_ERROR, "获取供应商信息失败");
        }

        // 2. 获取交货统计数据
        Result<DeliveryStatsVO> deliveryResult = orderFeignClient.getDeliveryStats(
            supplierId, period + "-01", period + "-31"
        );

        // 3. 计算五维度得分
        // ... 计算逻辑

        return evaluationVO;
    }
}
```

---

## 5. 接口实现对照表

### 5.1 service-auth 接口实现

| 接口路径 | Controller | Service | Mapper | 数据库表 |
|----------|-----------|---------|--------|----------|
| POST /auth/login | AuthController | AuthService | - | sys_user |
| POST /auth/logout | AuthController | AuthService | - | Redis |
| POST /auth/refresh | AuthController | AuthService | - | Redis |
| GET /auth/userinfo | AuthController | AuthService | - | sys_user |
| GET /auth/validate | AuthController | AuthService | - | Redis |

### 5.2 service-supplier 接口实现

| 接口路径 | Controller | Service | Mapper | 数据库表 |
|----------|-----------|---------|--------|----------|
| GET /suppliers | SupplierController | SupplierService | SupplierMapper | supplier_base |
| POST /suppliers | SupplierController | SupplierService | SupplierMapper | supplier_base |
| GET /suppliers/{id} | SupplierController | SupplierService | SupplierMapper | supplier_base |
| PUT /suppliers/{id} | SupplierController | SupplierService | SupplierMapper | supplier_base |
| DELETE /suppliers/{id} | SupplierController | SupplierService | SupplierMapper | supplier_base |
| GET /suppliers/{id}/score | ScoreController | ScoreService | SupplierScoreMapper | supplier_score |
| GET /suppliers/ranking | RankingController | RankingService | SupplierRankMapper | supplier_rank |
| POST /suppliers/{id}/response-log | ResponseController | ResponseService | ResponseLogMapper | service_response_log |
| GET /suppliers/{id}/response-log | ResponseController | ResponseService | ResponseLogMapper | service_response_log |

### 5.3 service-order 接口实现

| 接口路径 | Controller | Service | Mapper | 数据库表 |
|----------|-----------|---------|--------|----------|
| GET /orders | OrderController | OrderService | OrderMapper | order_main |
| POST /orders | OrderController | OrderService | OrderMapper | order_main, order_item |
| GET /orders/{id} | OrderController | OrderService | OrderMapper | order_main, order_item |
| PUT /orders/{id} | OrderController | OrderService | OrderMapper | order_main, order_item |
| PUT /orders/{id}/status | OrderController | OrderService | OrderMapper | order_main, order_status_log |
| POST /orders/{id}/deliveries | DeliveryController | DeliveryService | DeliveryMapper | order_delivery |
| GET /orders/{id}/deliveries | DeliveryController | DeliveryService | DeliveryMapper | order_delivery |
| GET /orders/delivery-stats | StatsController | StatsService | OrderMapper | order_main, order_delivery |
| GET /orders/{id}/status-log | StatusLogController | StatusLogService | StatusLogMapper | order_status_log |

### 5.4 service-data 接口实现

| 接口路径 | Controller | Service | Feign调用 |
|----------|-----------|---------|-----------|
| GET /dashboard | DashboardController | DashboardService | OrderFeign, SupplierFeign |
| GET /statistics/purchase | StatsController | StatsService | OrderFeign |
| GET /statistics/quality | StatsController | StatsService | - |
| GET /evaluate/supplier/{id} | EvaluationController | EvaluationService | OrderFeign, SupplierFeign |
| GET /evaluate/ranking | RankingController | RankingService | - |
| GET /evaluate/trend | TrendController | TrendService | - |
| GET /trace/material | TraceController | TraceService | OrderFeign, SupplierFeign |
| GET /trace/batch/{batchNo} | TraceController | TraceService | - |

---

## 6. 对接文档要求

### 6.1 必须提供的文档

开发完成后，成员B必须在 `rules/contracts/` 下提供以下文档：

```
rules/contracts/
├── auth-service-test-guide.md      # 认证服务测试指南
├── supplier-service-test-guide.md  # 供应商服务测试指南
├── order-service-test-guide.md     # 订单服务测试指南
├── data-service-test-guide.md     # 数据分析服务测试指南
└── feign-integration-guide.md     # Feign集成测试指南
```

### 6.2 测试指南模板

```markdown
# [服务名] 测试指南

> 版本: 1.0 | 创建日期: YYYY-MM-DD | 创建者: 成员B

## 服务信息

| 项目 | 值 |
|------|---|
| 服务名 | xxx-service |
| 端口 | 808X |
| 数据库 | xxx_db |
| 依赖服务 | xxx |

## 启动顺序

```
1. Nacos (8848)
2. MySQL (3306)
3. Redis (6379)
4. service-auth (8081)
5. service-supplier (8082)
6. service-order (8083)
7. service-data (8092)
```

## 接口测试

### 1. [接口名]

**请求**：
```bash
curl -X POST http://localhost:808X/[路径] \
  -H "Content-Type: application/json" \
  -d '{"field":"value"}'
```

**响应**：
```json
{
  "code": 200,
  "message": "success",
  "data": {}
}
```

## Feign调用测试（仅data-service）

### 1. 调用order-service

```bash
curl -X GET "http://localhost:8092/orders/delivery-stats?supplierId=1&startDate=2026-01-01&endDate=2026-03-31"
```

### 2. 调用supplier-service

```bash
curl -X GET "http://localhost:8092/suppliers/1/score?period=2026-Q1"
```

## 常见问题

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| Feign调用超时 | 被调用服务未启动 | 确保被调用服务已启动 |
| 数据库连接失败 | 数据库未启动或配置错误 | 检查application.yml |
```

---

## 7. 开发自检清单

### common-core/common-feign

- [ ] Result类实现正确
- [ ] ResultCode枚举完整
- [ ] BaseEntity字段正确
- [ ] FeignClient声明与契约一致
- [ ] FallbackFactory实现正确

### service-auth

- [ ] JWT生成和验证正确
- [ ] Token存储到Redis
- [ ] 登录/登出逻辑正确
- [ ] 用户信息查询正确

### service-supplier

- [ ] CRUD操作正确
- [ ] 分页查询正确
- [ ] 评分计算逻辑正确
- [ ] 响应记录管理正确

### service-order

- [ ] 订单创建逻辑正确
- [ ] 状态流转符合规范
- [ ] 交货记录正确
- [ ] 统计计算正确

### service-data

- [ ] Feign调用正确
- [ ] 聚合计算逻辑正确
- [ ] 五维度评分正确
- [ ] 溯源查询正确

### 通用

- [ ] 接口路径与契约一致
- [ ] 请求参数与契约一致
- [ ] 响应格式与契约一致
- [ ] 错误处理正确
- [ ] 日志记录完整
- [ ] 单元测试通过
