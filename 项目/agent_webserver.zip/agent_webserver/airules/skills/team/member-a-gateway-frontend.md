---
name: member-a-gateway-frontend
description: 成员A（前端+网关）的AI开发边界规范。负责project-gateway、project-frontend、common-swagger模块开发时加载此skill。包含开发边界、可调用接口、对接要求、测试流程。
metadata:
  priority: L1
  category: team
  depends: team-development-boundary, interface-contract, file-structure
---

# 成员A - 前端与网关开发边界

> **版本：V1.0 | 负责人：成员A | 最后更新：2026-04-01**

---

## 1. 模块边界

### 1.1 负责范围

```
┌─────────────────────────────────────────────────────────────────┐
│                    成员A 的开发边界                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   project-gateway/                                              │
│   ├── 路由配置（RouteDefinition）                                │
│   ├── 认证过滤器（Token验证、JWT解析）                           │
│   ├── 限流熔断配置                                              │
│   ├── 全局CORS配置                                              │
│   ├── 日志追踪过滤器                                            │
│   └── 异常处理（统一返回格式）                                   │
│                                                                 │
│   common-swagger/                                              │
│   ├── Swagger聚合配置                                          │
│   ├── API文档分组展示                                           │
│   └── knife4j增强配置（如使用）                                  │
│                                                                 │
│   project-frontend/                                            │
│   ├── Vue页面开发（views/）                                     │
│   ├── API请求封装（api/）                                       │
│   ├── 状态管理（store/）                                        │
│   ├── 路由配置（router/）                                       │
│   ├── 公共组件（components/）                                   │
│   └── 样式和资源（assets/）                                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 禁止操作

```
┌─────────────────────────────────────────────────────────────────┐
│                    绝对禁止事项                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ❌ 禁止修改 service-* 的任何代码                               │
│   ❌ 禁止修改 common-core 的代码                                │
│   ❌ 禁止修改 common-feign 的代码                               │
│   ❌ 禁止直接访问数据库（MySQL/Redis）                         │
│   ❌ 禁止在网关中编写业务逻辑代码                                │
│   ❌ 禁止在网关中直接操作其他服务的Mapper                        │
│   ❌ 禁止修改 rules/ 下的规范文档（除非授权）                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. Gateway 开发规范

### 2.1 网关目录结构

```
project-gateway/src/main/
├── java/com/huayou/gateway/
│   ├── GatewayApplication.java           # 启动类
│   ├── config/
│   │   ├── GatewayConfig.java           # 网关配置（CORS、动态路由等）
│   │   ├── AuthFilterProperties.java    # 认证过滤器配置
│   │   └── RateLimitProperties.java    # 限流配置
│   └── filter/
│       ├── AuthFilter.java              # Token认证过滤器
│       ├── LogFilter.java               # 请求日志过滤器
│       └── RateLimitFilter.java         # 限流过滤器
└── resources/
    └── application.yml                   # 网关配置（Nacos或本地）
```

### 2.2 路由配置规范

**路由配置来源**：从 Nacos 配置中心读取（成员C提供配置）

```yaml
# 网关路由配置示例
spring:
  cloud:
    gateway:
      routes:
        # 认证服务
        - id: auth-service
          uri: lb://auth-service
          predicates:
            - Path=/api/auth/**
          filters:
            - StripPrefix=1
            - name: AuthFilter

        # 供应商服务
        - id: supplier-service
          uri: lb://supplier-service
          predicates:
            - Path=/api/suppliers/**
          filters:
            - StripPrefix=1

        # 订单服务
        - id: order-service
          uri: lb://order-service
          predicates:
            - Path=/api/orders/**
          filters:
            - StripPrefix=1

        # 数据分析服务
        - id: data-service
          uri: lb://data-service
          predicates:
            - Path=/api/dashboard/**
            - Path=/api/data/**
            - Path=/api/statistics/**
            - Path=/api/evaluate/**
            - Path=/api/trace/**
          filters:
            - StripPrefix=1

        # Swagger文档（内部访问）
        - id: swagger
          uri: http://localhost:8080
          predicates:
            - Path=/swagger-ui/**
            - Path=/v3/api-docs/**
```

### 2.3 认证过滤器规范

```java
// AuthFilter.java 核心逻辑
@Component
public class AuthFilter implements GlobalFilter, Ordered {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String path = exchange.getRequest().getURI().getPath();

        // 1. 跳过白名单路径
        if (isWhiteListPath(path)) {
            return chain.filter(exchange);
        }

        // 2. 获取Token
        String token = extractToken(exchange.getRequest());

        // 3. 验证Token（调用auth-service）
        // 注意：不直接操作JWT，而是在auth-service验证
        return validateTokenWithAuthService(token)
                .flatMap(valid -> {
                    if (valid) {
                        // 4. 将用户信息传递给下游服务
                        ServerWebExchange modifiedExchange = addUserHeader(exchange, userInfo);
                        return chain.filter(modifiedExchange);
                    } else {
                        // 5. 返回401
                        return unauthorized(exchange);
                    }
                });
    }

    // 白名单路径（登录等不需要认证）
    private boolean isWhiteListPath(String path) {
        return path.startsWith("/api/auth/login")
            || path.startsWith("/swagger")
            || path.startsWith("/v3/api-docs");
    }
}
```

### 2.4 路由表（必须严格遵循）

| 前端路径 | 网关路由 | 后端服务 | 后端路径 |
|----------|----------|----------|----------|
| `/api/auth/login` | `/api/auth/**` | auth-service | `/auth/login` |
| `/api/auth/logout` | `/api/auth/**` | auth-service | `/auth/logout` |
| `/api/auth/refresh` | `/api/auth/**` | auth-service | `/auth/refresh` |
| `/api/auth/userinfo` | `/api/auth/**` | auth-service | `/auth/userinfo` |
| `/api/suppliers/**` | `/api/suppliers/**` | supplier-service | `/**` |
| `/api/orders/**` | `/api/orders/**` | order-service | `/**` |
| `/api/dashboard/**` | `/api/dashboard/**` | data-service | `/**` |
| `/api/data/**` | `/api/data/**` | data-service | `/**` |
| `/api/statistics/**` | `/api/statistics/**` | data-service | `/**` |
| `/api/evaluate/**` | `/api/evaluate/**` | data-service | `/**` |
| `/api/trace/**` | `/api/trace/**` | data-service | `/**` |

---

## 3. 前端开发规范

### 3.1 前端目录结构

```
project-frontend/src/
├── api/                              # API请求封装
│   ├── request.js                   # Axios实例封装
│   ├── auth.js                      # 认证相关API
│   ├── supplier.js                  # 供应商API
│   ├── order.js                    # 订单API
│   └── data.js                      # 数据分析API
│
├── views/                           # 页面组件
│   ├── auth/
│   │   └── Login.vue               # 登录页
│   ├── dashboard/
│   │   └── Dashboard.vue           # 首页仪表盘
│   ├── supplier/
│   │   ├── SupplierList.vue        # 供应商列表
│   │   ├── SupplierDetail.vue      # 供应商详情
│   │   └── SupplierForm.vue        # 供应商表单
│   ├── order/
│   │   ├── OrderList.vue           # 订单列表
│   │   ├── OrderDetail.vue         # 订单详情
│   │   └── OrderForm.vue           # 订单表单
│   └── trace/
│       └── TraceQuery.vue          # 溯源查询
│
├── components/                      # 公共组件
│   ├── layout/
│   │   ├── AppHeader.vue           # 页头
│   │   ├── AppSidebar.vue          # 侧边栏
│   │   └── AppLayout.vue           # 布局
│   ├── common/
│   │   ├── DataCard.vue            # 数据卡片
│   │   ├── StatusBadge.vue         # 状态徽章
│   │   └── ConfirmDialog.vue       # 确认对话框
│   └── charts/
│       ├── BarChart.vue            # 柱状图
│       └── LineChart.vue           # 折线图
│
├── router/
│   └── index.js                    # 路由配置
│
├── store/
│   ├── index.js                    # Store根模块
│   ├── auth.js                     # 认证状态
│   └── app.js                      # 应用状态
│
└── utils/
    ├── storage.js                  # localStorage封装
    ├── date.js                     # 日期格式化
    └── request.js                  # 请求工具（已在api/）
```

### 3.2 API请求封装规范

```javascript
// api/request.js
import axios from 'axios'
import { ElMessage } from 'element-plus'
import router from '@/router'

const request = axios.create({
  baseURL: '/api',  // 走网关
  timeout: 30000
})

// 请求拦截器：添加Token
request.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`
  }
  return config
})

// 响应拦截器：统一处理
request.interceptors.response.use(
  response => {
    const res = response.data
    if (res.code !== 200) {
      ElMessage.error(res.message || '请求失败')
      if (res.code === 401) {
        router.push('/login')
      }
      return Promise.reject(res)
    }
    return res
  },
  error => {
    ElMessage.error(error.message || '网络错误')
    return Promise.reject(error)
  }
)

export default request
```

### 3.3 页面路由（对应后端接口）

```
┌─────────────────────────────────────────────────────────────────┐
│                    前端路由与后端接口映射                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   /login                          → POST /api/auth/login        │
│   /dashboard                       → GET /api/dashboard         │
│                                                                 │
│   /suppliers                       → GET /api/suppliers         │
│   /suppliers/create               → POST /api/suppliers         │
│   /suppliers/:id                  → GET /api/suppliers/:id      │
│   /suppliers/:id/edit             → PUT /api/suppliers/:id     │
│   /suppliers/:id/score            → GET /api/suppliers/:id/score│
│   /suppliers/ranking              → GET /api/suppliers/ranking  │
│                                                                 │
│   /orders                          → GET /api/orders           │
│   /orders/create                  → POST /api/orders            │
│   /orders/:id                     → GET /api/orders/:id         │
│   /orders/:id/edit               → PUT /api/orders/:id        │
│   /orders/:id/status             → PUT /api/orders/:id/status │
│   /orders/:id/deliveries         → POST /api/orders/:id/deliveries
│                                                                 │
│   /trace/material                 → GET /api/trace/material    │
│   /trace/batch/:batchNo           → GET /api/trace/batch/:batchNo
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. Swagger 文档聚合

### 4.1 聚合配置

```java
// common-swagger/src/main/java/.../SwaggerConfig.java
@Configuration
@EnableSwagger2
public class SwaggerConfig {

    @Bean
    public GroupedOpenApi authApi() {
        return GroupedOpenApi.builder()
                .group("认证服务")
                .pathsToMatch("/auth/**")
                .build();
    }

    @Bean
    public GroupedOpenApi supplierApi() {
        return GroupedOpenApi.builder()
                .group("供应商服务")
                .pathsToMatch("/suppliers/**")
                .build();
    }

    @Bean
    public GroupedOpenApi orderApi() {
        return GroupedOpenApi.builder()
                .group("订单服务")
                .pathsToMatch("/orders/**")
                .build();
    }

    @Bean
    public GroupedOpenApi dataApi() {
        return GroupedOpenApi.builder()
                .group("数据分析服务")
                .pathsToMatch("/dashboard/**", "/data/**", "/statistics/**",
                              "/evaluate/**", "/trace/**")
                .build();
    }
}
```

### 4.2 Swagger 访问地址

| 环境 | 地址 |
|------|------|
| 本地开发 | http://localhost:8080/swagger-ui/index.html |
| 生产环境 | http://gateway-server:8080/swagger-ui/index.html |

---

## 5. 对接文档要求

### 5.1 必须提供的文档

开发完成后，成员A必须在 `rules/` 下创建以下对接文档：

```
rules/contracts/
├── gateway-auth-test-guide.md      # 认证接口测试指南
├── gateway-supplier-test-guide.md  # 供应商接口测试指南
├── gateway-order-test-guide.md     # 订单接口测试指南
└── gateway-data-test-guide.md     # 数据分析接口测试指南
```

### 5.2 测试指南模板

```markdown
# 网关 ↔ [服务名] 接口测试指南

> 版本: 1.0 | 创建日期: YYYY-MM-DD | 创建者: 成员A

## 测试环境

| 项目 | 值 |
|------|---|
| 网关地址 | http://localhost:8080 |
| [服务名]地址 | http://localhost:808X |
| 前端地址 | http://localhost:5173 |

## 登录获取Token

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"123456"}'
```

## 接口测试用例

### 1. [接口名]

**请求**：
```bash
curl -X GET http://localhost:8080/api/[路径] \
  -H "Authorization: Bearer [TOKEN]"
```

**预期响应**：
```json
{
  "code": 200,
  "message": "success",
  "data": {}
}
```

**前端调用示例**：
```javascript
// Vue代码示例
import supplierApi from '@/api/supplier'

export default {
  methods: {
    async loadSuppliers() {
      const res = await supplierApi.list({ pageNum: 1, pageSize: 10 })
      this.suppliers = res.data.records
    }
  }
}
```

## 常见问题排查

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| 401 Unauthorized | Token过期或未传递 | 重新登录获取Token |
| 404 Not Found | 路由配置错误 | 检查网关路由配置 |
| CORS跨域 | 网关未配置CORS | 检查GatewayConfig |
```

---

## 6. 联调测试流程

### 6.1 前置条件

- [ ] 所有后端服务已启动
- [ ] Nacos 已启动并配置正确
- [ ] 数据库已初始化
- [ ] 网关已配置路由

### 6.2 联调步骤

```
┌─────────────────────────────────────────────────────────────────┐
│                    联调测试执行步骤                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   步骤1：验证网关连通性                                          │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │ curl http://localhost:8080/api/auth/login              │   │
│   │ 预期：返回401或正常响应                                  │   │
│   └─────────────────────────────────────────────────────────┘   │
│                           ↓                                      │
│   步骤2：验证认证流程                                            │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │ 1. POST /api/auth/login 获取Token                       │   │
│   │ 2. GET /api/auth/userinfo 带Token验证                   │   │
│   │ 3. 验证无Token时返回401                                 │   │
│   └─────────────────────────────────────────────────────────┘   │
│                           ↓                                      │
│   步骤3：验证业务接口                                            │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │ 1. 获取Token                                            │   │
│   │ 2. 调用各业务接口验证路由正确                            │   │
│   │ 3. 验证返回数据格式正确                                 │   │
│   └─────────────────────────────────────────────────────────┘   │
│                           ↓                                      │
│   步骤4：前端联调                                              │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │ 1. 启动前端项目                                          │   │
│   │ 2. 测试登录流程                                         │   │
│   │ 3. 测试各页面数据加载                                   │   │
│   │ 4. 测试增删改查操作                                     │   │
│   └─────────────────────────────────────────────────────────┘   │
│                           ↓                                      │
│   步骤5：问题记录与修复                                        │
│   ┌─────────────────────────────────────────────────────────┐   │
│   │ 1. 记录发现的问题                                        │   │
│   │ 2. 分类：网关问题/前端问题/后端问题                      │   │
│   │ 3. 通知对应负责人                                       │   │
│   │ 4. 验证修复                                             │   │
│   └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 6.3 测试用例清单

| 用例编号 | 用例名称 | 前置条件 | 测试步骤 | 预期结果 |
|----------|----------|----------|----------|----------|
| A-001 | 登录成功 | 无 | POST /api/auth/login | 返回Token和用户信息 |
| A-002 | 登录失败 | 无 | 错误密码登录 | 返回401 |
| A-003 | Token验证 | 已有Token | GET /api/auth/userinfo | 返回用户信息 |
| A-004 | Token过期 | 过期Token | GET /api/auth/userinfo | 返回401 |
| A-005 | 供应商列表 | 已有Token | GET /api/suppliers | 返回分页数据 |
| A-006 | 订单创建 | 已有Token | POST /api/orders | 返回订单ID |
| A-007 | 仪表盘数据 | 已有Token | GET /api/dashboard | 返回统计数据 |

---

## 7. 开发自检清单

### 开发前

- [ ] 阅读接口契约文档，确认要对接的接口
- [ ] 确认后端服务接口已完成开发
- [ ] 确认网关路由配置已获取

### 开发中

- [ ] 严格遵循接口路径和参数定义
- [ ] 请求和响应格式与契约一致
- [ ] Token处理正确
- [ ] 错误处理完善

### 开发后

- [ ] 完成网关路由配置自测
- [ ] 完成前端页面自测
- [ ] 提供测试指南文档
- [ ] 执行联调测试
- [ ] 记录并跟踪问题
- [ ] 更新 STATUS.md
