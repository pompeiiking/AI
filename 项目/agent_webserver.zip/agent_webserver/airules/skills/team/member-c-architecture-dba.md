---
name: member-c-architecture-dba
description: 成员C（架构与数据库）的AI开发边界规范。负责数据库设计、Nacos配置、规范维护、契约审核。包含数据库脚本、Nacos配置、架构决策、规范管理、对接审核。
metadata:
  priority: L1
  category: team
  depends: team-development-boundary, interface-contract
---

# 成员C - 架构与数据库开发边界

> **版本：V1.0 | 负责人：成员C | 最后更新：2026-04-01**

---

## 1. 模块边界

### 1.1 负责范围

```
┌─────────────────────────────────────────────────────────────────┐
│                    成员C 的开发边界                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   sql/                                                         │
│   ├── auth_db.sql          # 认证数据库初始化脚本               │
│   ├── supplier_db.sql      # 供应商数据库初始化脚本             │
│   ├── order_db.sql        # 订单数据库初始化脚本               │
│   ├── data_db.sql         # 数据分析数据库初始化脚本            │
│   └── README.md           # 数据库说明文档                      │
│                                                                 │
│   Nacos 配置                                                   │
│   ├── shared.yaml         # 公共配置                           │
│   ├── auth-service.yaml   # 认证服务配置                       │
│   ├── supplier-service.yaml # 供应商服务配置                    │
│   ├── order-service.yaml  # 订单服务配置                       │
│   ├── data-service.yaml   # 数据分析服务配置                   │
│   └── gateway.yaml        # 网关配置                          │
│                                                                 │
│   规范管理                                                     │
│   ├── rules/RULES.md      # 主规范文件                        │
│   ├── rules/STATUS.md     # 项目状态                          │
│   ├── rules/TEAM.md       # 团队协作规范                      │
│   ├── rules/contracts/    # 接口契约文档                      │
│   └── rules/skills/       # 技能规范库                        │
│                                                                 │
│   架构决策                                                     │
│   ├── 技术选型决策                                             │
│   ├── 项目架构设计                                             │
│   ├── 模块边界划分                                             │
│   └── 接口契约审核                                             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 禁止操作

```
┌─────────────────────────────────────────────────────────────────┐
│                    绝对禁止事项                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ❌ 禁止修改业务代码的实现细节                                  │
│   ❌ 禁止修改前端代码                                           │
│   ❌ 禁止修改网关的业务逻辑代码                                  │
│   ❌ 禁止修改微服务的业务逻辑实现                                │
│   ❌ 禁止在规范文档中引入与项目无关的内容                        │
│   ❌ 禁止未经评审直接修改契约文档                                │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. 数据库设计与脚本

### 2.1 数据库规划

| 数据库 | 服务 | 用途 | 主要表 |
|--------|------|------|--------|
| auth_db | service-auth | 用户认证 | sys_user, sys_role, sys_permission |
| supplier_db | service-supplier | 供应商管理 | supplier_base, supplier_contact, supplier_score |
| order_db | service-order | 订单管理 | order_main, order_item, order_delivery |
| data_db | service-data | 数据分析 | supplier_evaluation, monthly_trend |

### 2.2 数据库目录结构

```
project-parent/
└── sql/
    ├── auth_db.sql              # 认证库建表脚本
    ├── supplier_db.sql          # 供应商库建表脚本
    ├── order_db.sql            # 订单库建表脚本
    ├── data_db.sql             # 数据分析库建表脚本
    ├── init.sql                # 初始化数据（测试数据）
    └── README.md               # SQL脚本说明
```

### 2.3 建表规范

```sql
-- ============================================
-- auth_db 数据库脚本
-- 服务: service-auth
-- 创建日期: 2026-04-01
-- ============================================

CREATE DATABASE IF NOT EXISTS auth_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE auth_db;

-- 用户表
CREATE TABLE sys_user (
    user_id        BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '用户ID',
    username       VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password_hash  VARCHAR(255) NOT NULL COMMENT '密码哈希',
    real_name      VARCHAR(100) NOT NULL COMMENT '真实姓名',
    email          VARCHAR(100) COMMENT '邮箱',
    phone          VARCHAR(20) COMMENT '手机号',
    dept_id        BIGINT COMMENT '部门ID',
    status         TINYINT DEFAULT 1 COMMENT '状态：0禁用 1正常',
    created_at     DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at     DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    last_login_at  DATETIME COMMENT '最后登录时间',
    INDEX idx_username (username),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';

-- 角色表
CREATE TABLE sys_role (
    role_id     BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '角色ID',
    role_name   VARCHAR(50) NOT NULL COMMENT '角色名称',
    role_code   VARCHAR(50) NOT NULL UNIQUE COMMENT '角色编码',
    status      TINYINT DEFAULT 1 COMMENT '状态：0禁用 1正常',
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_role_code (role_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统角色表';

-- 权限表
CREATE TABLE sys_permission (
    perm_id     BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '权限ID',
    perm_code   VARCHAR(100) NOT NULL UNIQUE COMMENT '权限编码',
    perm_name   VARCHAR(100) NOT NULL COMMENT '权限名称',
    perm_type   VARCHAR(20) COMMENT '权限类型：menu/button/api',
    parent_id   BIGINT DEFAULT 0 COMMENT '父权限ID',
    sort_order  INT DEFAULT 0 COMMENT '排序',
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    INDEX idx_perm_code (perm_code),
    INDEX idx_parent (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统权限表';

-- 用户角色关联表
CREATE TABLE sys_user_role (
    id       BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '主键',
    user_id  BIGINT NOT NULL COMMENT '用户ID',
    role_id  BIGINT NOT NULL COMMENT '角色ID',
    UNIQUE KEY uk_user_role (user_id, role_id),
    INDEX idx_user (user_id),
    INDEX idx_role (role_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户角色关联表';

-- 角色权限关联表
CREATE TABLE sys_role_permission (
    id       BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '主键',
    role_id  BIGINT NOT NULL COMMENT '角色ID',
    perm_id  BIGINT NOT NULL COMMENT '权限ID',
    UNIQUE KEY uk_role_perm (role_id, perm_id),
    INDEX idx_role (role_id),
    INDEX idx_perm (perm_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色权限关联表';
```

### 2.4 SQL脚本编写规范

```sql
-- 脚本头部
-- ============================================
-- [数据库名] 数据库脚本
-- 服务: [关联服务名]
-- 创建日期: YYYY-MM-DD
-- 说明: [简要说明]
-- ============================================

-- 使用规范
-- 1. 表名使用小写下划线命名
-- 2. 字段注释必须完整
-- 3. 主键使用 BIGINT AUTO_INCREMENT
-- 4. 字符串默认 VARCHAR(255)，需预估长度
-- 5. 金额使用 DECIMAL(15,2)
-- 6. 日期使用 DATE 或 DATETIME
-- 7. 状态字段使用 TINYINT，注释说明枚举值
-- 8. 必须添加索引，特别是外键和查询条件字段
-- 9. 逻辑删除使用 is_deleted 字段

-- 示例
CREATE TABLE example (
    id            BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '主键ID',
    name          VARCHAR(100) NOT NULL COMMENT '名称',
    status        TINYINT DEFAULT 1 COMMENT '状态：0禁用 1正常',
    amount        DECIMAL(15,2) DEFAULT 0 COMMENT '金额',
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    is_deleted    TINYINT DEFAULT 0 COMMENT '删除标记：0未删 1已删',
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='示例表';
```

---

## 3. Nacos 配置中心

### 3.1 Nacos 配置目录结构

```
Nacos配置命名空间
├── 公共配置 (shared)
│   ├── shared.yaml              # 公共配置
│   ├── redis.yaml              # Redis配置
│   └── mysql.yaml              # MySQL基础配置
│
├── 服务配置 (每个服务一个)
│   ├── auth-service.yaml       # 认证服务
│   ├── supplier-service.yaml    # 供应商服务
│   ├── order-service.yaml      # 订单服务
│   ├── data-service.yaml       # 数据分析服务
│   └── gateway.yaml            # 网关配置
│
└── 环境隔离 (可选)
    ├── dev.yaml                # 开发环境
    ├── test.yaml               # 测试环境
    └── prod.yaml               # 生产环境
```

### 3.2 公共配置 shared.yaml

```yaml
# shared.yaml - 公共配置
spring:
  application:
    name: huayou-material-lifecycle

  # Redis 公共配置
  redis:
    host: ${REDIS_HOST:localhost}
    port: ${REDIS_PORT:6379}
    password: ${REDIS_PASSWORD:}
    database: ${REDIS_DB:0}
    timeout: 5000ms
    lettuce:
      pool:
        max-active: 20
        max-idle: 10
        min-idle: 5

  # Jackson 公共配置
  jackson:
    date-format: yyyy-MM-dd HH:mm:ss
    time-zone: Asia/Shanghai
    serialization:
      write-dates-as-timestamps: false

# MyBatis-Plus 公共配置
mybatis-plus:
  configuration:
    map-underscore-to-camel-case: true
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl
  global-config:
    db-config:
      id-type: auto
      logic-delete-field: isDeleted
      logic-delete-value: 1
      logic-not-delete-value: 0
```

### 3.3 服务配置模板

```yaml
# auth-service.yaml - 认证服务配置
spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://${MYSQL_HOST:localhost}:${MYSQL_PORT:3306}/auth_db?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false
    username: ${MYSQL_USER:root}
    password: ${MYSQL_PASSWORD:root}
    hikari:
      maximum-pool-size: 20
      minimum-idle: 5
      connection-timeout: 30000
      idle-timeout: 600000
      max-lifetime: 1800000

  # Redis配置（覆盖公共配置）
  redis:
    host: ${REDIS_HOST:localhost}
    port: ${REDIS_PORT:6379}

server:
  port: 8081
  servlet:
    context-path: /

# JWT配置
jwt:
  secret: ${JWT_SECRET:your-secret-key-change-in-production}
  expiration: 7200000  # 2小时
  refresh-expiration: 604800000  # 7天

# Nacos服务发现
cloud:
  nacos:
    discovery:
      server-addr: ${NACOS_HOST:localhost}:8848
      namespace: ${NACOS_NAMESPACE:public}
      group: DEFAULT_GROUP
    config:
      server-addr: ${NACOS_HOST:localhost}:8848
      file-extension: yaml
      shared-configs:
        - data-id: shared.yaml
          group: SHARED_GROUP
          refresh: true
```

### 3.4 网关配置 gateway.yaml

```yaml
# gateway.yaml - 网关配置
server:
  port: 8080

spring:
  cloud:
    gateway:
      discovery:
        locator:
          enabled: true
          lower-case-service-id: true

      routes:
        # 认证服务
        - id: auth-service
          uri: lb://auth-service
          predicates:
            - Path=/api/auth/**
          filters:
            - StripPrefix=1

        # 供应商服务
        - id: supplier-service
          uri: lb://supplier-service
          predicates:
            - Path=/api/suppliers/**
          filters:
            - StripPrefix=1

        # 订单服务
        - id: order-service
          uri: lb://order-service
          predicates:
            - Path=/api/orders/**
          filters:
            - StripPrefix=1

        # 数据分析服务
        - id: data-service
          uri: lb://data-service
          predicates:
            - Path=/api/dashboard/**
            - Path=/api/data/**
            - Path=/api/statistics/**
            - Path=/api/evaluate/**
            - Path=/api/trace/**
          filters:
            - StripPrefix=1

  redis:
    host: ${REDIS_HOST:localhost}
    port: ${REDIS_PORT:6379}

# 认证白名单
auth:
  white-list:
    - /api/auth/login
    - /api/auth/refresh
    - /swagger/**
    - /v3/api-docs/**

# Nacos
cloud:
  nacos:
    discovery:
      server-addr: ${NACOS_HOST:localhost}:8848}
```

---

## 4. 契约审核规范

### 4.1 契约审核流程

```
┌─────────────────────────────────────────────────────────────────┐
│                    契约审核流程                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   1. 契约起草                                                   │
│      成员B/成员A 提出接口需求 → 成员C 起草契约                   │
│                           ↓                                      │
│   2. 契约评审                                                   │
│      成员C 组织评审 → 确认接口设计 → 状态改为"已确认"            │
│                           ↓                                      │
│   3. 契约实现                                                   │
│      成员B 按契约开发 → 成员A 按契约对接                        │
│                           ↓                                      │
│   4. 契约验证                                                   │
│      成员C 验证实现与契约一致性 → 状态改为"已实现"               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 契约审核检查项

| 检查项 | 要求 | 是否通过 |
|--------|------|----------|
| 接口路径 | 符合RESTful规范，与架构设计一致 | [ ] |
| 请求参数 | 类型、名称、是否必填与设计一致 | [ ] |
| 响应格式 | 符合Result<T>统一格式 | [ ] |
| 错误码 | 遵循统一错误码规范 | [ ] |
| 业务逻辑 | 符合业务流程设计 | [ ] |
| 性能要求 | 响应时间符合约束 | [ ] |
| 安全要求 | 认证鉴权正确 | [ ] |
| 文档完整性 | 示例代码、错误说明完整 | [ ] |

### 4.3 契约问题处理

```
发现契约问题
     │
     ▼
┌─────────────────┐
│ 标记 CONTRACT-  │
│ ISSUE           │
└────────┬────────┘
          │
          ▼
┌─────────────────┐
│ 评估影响范围     │
└────────┬────────┘
          │
          ▼
┌─────────────────┐
│ 讨论修改方案     │
└────────┬────────┘
          │
          ▼
┌─────────────────┐
│ 成员C 审批       │
└────────┬────────┘
          │
          ▼
    ┌─────┴─────┐
    │  批准/拒绝  │
    └───────────┘
```

---

## 5. 规范管理

### 5.1 规范文件维护

| 文件 | 维护规则 | 更新频率 |
|------|----------|----------|
| RULES.md | 成员C主导，重大变更需全员讨论 | 按需 |
| STATUS.md | 成员C维护，全员可更新进度 | 每次变更 |
| CHANGELOG.md | 全员维护，每次变更追加 | 每次提交 |
| TEAM.md | 成员C主导 | 按需 |
| contracts/*.md | 成员C审核后更新 | 按需 |
| skills/*.md | 成员C维护 | 按需 |

### 5.2 规范变更流程

```markdown
## 规范变更申请模板

### 变更类型
[功能新增/规则修改/文档完善]

### 变更内容
[详细描述变更内容]

### 变更原因
[为什么要变更]

### 影响范围
[会影响哪些模块/成员]

### 变更建议
[具体的变更方案]

### 审核意见
[成员C填写]
```

### 5.3 冲突处理

当成员A或成员B发现边界冲突或规范冲突时：

```
1. 在 STATUS.md 的"已知问题"中记录
2. 描述冲突的具体内容
3. 标记 CONTRACT-ISSUE 或 BOUNDARY-ISSUE
4. 通知成员C处理
5. 等待成员C的仲裁结果
6. 根据结果更新规范文档
```

---

## 6. 对接文档审核

### 6.1 文档审核清单

成员C需要对成员A和成员B提供的对接文档进行审核：

- [ ] 接口列表完整，无遗漏
- [ ] 请求示例正确
- [ ] 响应示例正确
- [ ] 错误处理说明完整
- [ ] 测试用例覆盖关键场景
- [ ] 常见问题有解决方案

### 6.2 联调测试审核

- [ ] 联调测试报告格式正确
- [ ] 所有用例已执行
- [ ] 问题已记录并跟踪
- [ ] 集成测试通过

---

## 7. 交付物清单

### 7.1 数据库交付物

```
sql/
├── README.md               # 数据库说明文档
├── auth_db.sql             # 认证库脚本（含测试数据）
├── supplier_db.sql         # 供应商库脚本
├── order_db.sql           # 订单库脚本
├── data_db.sql            # 数据分析库脚本
└── init_data.sql         # 测试数据初始化脚本
```

### 7.2 配置交付物

```
Nacos配置/
├── shared.yaml            # 公共配置
├── auth-service.yaml      # 认证服务
├── supplier-service.yaml  # 供应商服务
├── order-service.yaml    # 订单服务
├── data-service.yaml     # 数据分析服务
└── gateway.yaml           # 网关配置
```

### 7.3 规范交付物

```
rules/
├── RULES.md               # 主规范
├── STATUS.md              # 项目状态
├── CHANGELOG.md          # 变更日志
├── TEAM.md               # 团队协作规范
├── contracts/             # 接口契约
└── skills/                # 技能规范库（含本目录）
```

---

## 8. 开发自检清单

### 数据库

- [ ] 所有建表脚本符合命名规范
- [ ] 所有字段有注释
- [ ] 索引合理（查询条件、外键）
- [ ] 测试数据完整
- [ ] 外键约束正确

### Nacos配置

- [ ] 配置结构清晰
- [ ] 环境变量使用正确
- [ ] 服务发现配置正确
- [ ] 路由配置完整

### 规范审核

- [ ] 契约文档格式正确
- [ ] 接口定义完整
- [ ] 对接文档符合要求
- [ ] 测试指南可执行

### 整体

- [ ] 架构设计合理
- [ ] 模块边界清晰
- [ ] 规范文档完整
- [ ] 更新 STATUS.md
