---
name: status-management
description: STATUS.md的维护规范：项目状态快照、活跃STUB清单、已知问题、任务交接信息。会话开始或结束时加载。
metadata:
  priority: L2
  category: workflow
  depends: stub-management, changelog
---

# 项目状态管理（STATUS.md）

## 规则

- **STATUS.md 是项目当前状态的快照** — 不是历史记录，是"此刻"的真相
- **每次变更后覆盖更新**（不是追加），保持内容反映最新状态
- **新会话开始时必读** — 这是快速了解项目现状的入口
- **会话结束时必须更新** — 确保下一位开发者/AI获得准确信息

## STATUS.md 格式模板

```markdown
# 华北油田物资生命周期管理系统 — 项目状态

> 最后更新: [YYYY-MM-DD HH:mm] by [操作者标识]

## 当前进度

[一两句话概括项目整体状态]

### 已完成模块
- [模块名] — [完成度/状态]

### 进行中
- [任务描述] — [当前状态/阻塞项]

### 待开始
- [任务描述] — [前置依赖]

## 活跃STUB清单

| 位置 | 原因 | 替换条件 |
|------|------|---------|
| `path/file:行号` | [为什么是STUB] | [何时可替换] |

> 如果清单为空，写"无活跃STUB"

## 已知问题

- [问题描述] — [严重程度: 高/中/低] — [是否阻塞当前开发]

## 架构备忘

[重要的架构决策、技术约束、需要所有开发者知道的信息]

## 下一步建议

[给下一位接手的开发者/AI的建议]
```

## 示例

✅ 正确的STATUS.md：

```markdown
# 华北油田物资生命周期管理系统 — 项目状态

> 最后更新: 2026-04-01 15:00 by AI:Cursor

## 当前进度

规范体系初始化完成（V0.2），Maven项目骨架已搭建，准备开始核心服务开发。

### 已完成模块
- rules/ — ✅ 规范体系完整搭建，11个设计原则+10个工作流+2个项目专属skill
- project-parent/pom.xml — ✅ 父POM完成，依赖版本锁定
- project-common — ✅ 目录骨架已创建
- service-auth — ✅ 目录骨架已创建

### 进行中
- service-supplier — 目录骨架已创建，即将开始实体类和Mapper开发

### 待开始
- service-order — 依赖service-auth完成基础框架后开始
- service-data — 依赖service-supplier和service-order完成Feign接口后开始
- project-gateway — 依赖所有服务完成后配置路由
- project-frontend — 依赖服务API接口定义后开始

## 活跃STUB清单

| 位置 | 原因 | 替换条件 |
|------|------|---------|
| 无活跃STUB | — | — |

## 已知问题

- 无

## 架构备忘

- 当前为纯骨架，无实际业务代码
- 数据库表尚未创建（参考架构设计书第4章SQL脚本）
- Nacos配置中心尚未部署，所有服务暂时使用本地配置

## 下一步建议

1. 开始 service-auth 的核心开发（用户注册/登录/JWT）
2. 创建数据库初始化脚本（auth_db.sql, supplier_db.sql, order_db.sql, data_db.sql）
3. 完成 service-auth 后，再开发 service-supplier
```

## 提交前检查清单

- [ ] STATUS.md 已更新为当前最新状态（不是追加，是覆盖）
- [ ] "最后更新"时间和操作者已更新
- [ ] 活跃STUB清单与代码中的STUB标记一致
- [ ] 已知问题列表是当前的（已解决的问题已移除）
