---
name: interface-change
description: 公共接口变更流程：影响评估、兼容性策略、调用方同步更新。修改公共接口、导出类型或共享函数签名时加载。
metadata:
  priority: L1
  category: workflow
  depends: layering, module-boundary
---

# 公共接口变更流程

## 规则

- **修改公共接口前必须评估影响范围** — 搜索所有调用方，确认影响面
- **接口变更必须同步更新所有调用方** — 不允许只改接口不改调用方，留下编译错误
- **优先向后兼容** — 新增参数使用可选参数或默认值，不破坏已有调用
- **兼容层只能临时存在** — 为迁移而保留的旧接口、旧格式适配、demo/微型实现必须设置移除条件；迁移完成后立即删除，禁止长期共存
- **临时兼容必须双标注** — 每个兼容层都必须明确写出 `COMPAT_REMOVE_BY` 与 `FULL_IMPL_TARGET`，缺一不可

## 什么是"公共接口"

- 从 Controller 导出的 REST API
- `common-feign` 中定义的 Feign 客户端接口
- `common-core` 中导出的工具类方法
- VO/DTO 中暴露给前端的数据结构

## 变更流程

```
Step 1: 评估影响
  → 全项目搜索当前接口的所有使用位置
  → 列出所有需要同步修改的文件

Step 2: 选择兼容性策略
  A) 向后兼容（推荐）: 新增可选参数/方法，旧接口继续可用
  B) 迁移（必要时）: 旧接口标记为@deprecated，提供迁移说明，设定移除日期
  C) 破坏性变更（尽量避免）: 一次性修改接口+所有调用方

Step 3: 执行变更
  → 修改接口定义
  → 同步修改所有调用方
  → 更新相关类型定义
  → 更新相关测试

Step 3.5: 清理兼容中间产物
  → 检查是否仍保留旧接口适配层、旧格式转换器、临时demo实现
  → 若迁移完成，立即删除这些中间产物，不得继续保留
  → 若未完成，必须明确剩余调用方和移除触发条件，并补齐双标注

Step 3.6: 为未完成迁移添加双标注
  → 在兼容实现附近标注 `COMPAT_REMOVE_BY: 日期/版本`
  → 在兼容实现附近标注 `FULL_IMPL_TARGET: 完整实现的验收目标`

Step 4: 记录
  → CHANGELOG中标注接口变更，列出受影响的模块
  → 如果是破坏性变更，在提交信息中标注 BREAKING CHANGE
```

## 本项目常见的接口变更场景

### Feign接口变更

```java
// ✅ 正确（向后兼容）
// 之前
Result<DeliveryStatsVO> getDeliveryStats(Long supplierId, String startDate, String endDate);

// 之后 — 新增可选参数，旧调用不受影响
Result<DeliveryStatsVO> getDeliveryStats(
    Long supplierId,
    String startDate,
    String endDate,
    @RequestParam(value = "includeHistory", defaultValue = "false") Boolean includeHistory
);
```

### VO字段变更

```java
// ✅ 正确（新字段标注为可选，不破坏前端现有解析）
@Data
public class SupplierVO {
    private Long supplierId;
    private String supplierName;
    // 新增字段，前端若无此字段会忽略，不影响现有功能
    // COMPAT_REMOVE_BY: v2.0 — 前端统一升级后移除此标记
    // FULL_IMPL_TARGET: 前端所有引用方已读取新字段
    @ApiModelProperty(value = "供应商评分", notes = "V2新增字段")
    private BigDecimal score;
}
```

## 提交前检查清单

- [ ] 已搜索并列出所有调用方
- [ ] 所有调用方已同步更新
- [ ] 项目可编译通过（无类型错误）
- [ ] 接口变更已记录在CHANGELOG中
- [ ] 如果是破坏性变更，提交信息包含 BREAKING CHANGE
- [ ] 迁移完成后已删除旧接口/旧格式兼容层/临时实现（若未删除，已写明剩余范围与移除条件）
- [ ] 未删除的临时兼容层已包含 `COMPAT_REMOVE_BY` + `FULL_IMPL_TARGET` 双标注
