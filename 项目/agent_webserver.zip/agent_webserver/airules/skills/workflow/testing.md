---
name: testing
description: 测试文件位置、命名、最小覆盖要求、临时调试测试的处理规范。写测试或改测试时加载。
metadata:
  priority: L2
  category: workflow
  depends: naming
---

# 测试规范

## 规则

- **测试文件与源文件同目录** — 便于发现和定位
- **测试文件命名**: `[源文件名]Test.java`（JUnit 5）
- **每个公共方法至少有一个正例和一个反例测试**
- **测试只测行为，不测实现细节** — 重构不应导致测试失败
- **单元测试由开发者各自负责**，测试桩文件需标注 STUB

## 测试文件位置

```
service-xxx/src/test/java/com/huayou/service/xxx/
├── SupplierServiceTest.java      # 对应 SupplierService
├── SupplierControllerTest.java   # 对应 SupplierController
└── EvaluationCalculatorTest.java # 对应 EvaluationCalculator
```

## 测试结构模板（JUnit 5）

```java
package com.huayou.service.supplier;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Nested;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("供应商评分计算测试")
class EvaluationCalculatorTest {

    @Nested
    @DisplayName("准时交付率计算")
    class OnTimeRateTests {

        @Test
        @DisplayName("全部准时交付时应返回100%")
        void shouldReturn100WhenAllOnTime() {
            EvaluationCalculator calculator = new EvaluationCalculator();
            BigDecimal rate = calculator.calculateOnTimeRate(10, 10);
            assertEquals(0, rate.compareTo(BigDecimal.valueOf(100)));
        }

        @Test
        @DisplayName("部分准时时应返回相应比例")
        void shouldReturnCorrectRateWhenPartial() {
            EvaluationCalculator calculator = new EvaluationCalculator();
            BigDecimal rate = calculator.calculateOnTimeRate(8, 10);
            assertEquals(0, rate.compareTo(BigDecimal.valueOf(80)));
        }

        @Test
        @DisplayName("无订单时应返回0而非异常")
        void shouldReturnZeroWhenNoOrders() {
            EvaluationCalculator calculator = new EvaluationCalculator();
            BigDecimal rate = calculator.calculateOnTimeRate(0, 0);
            assertEquals(0, rate.compareTo(BigDecimal.ZERO));
        }
    }
}
```

## 集成测试（Spring Boot Test）

```java
@AutoConfigureMockMvc
@SpringBootTest
@DisplayName("供应商管理接口测试")
class SupplierControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @DisplayName("创建供应商成功应返回201")
    void shouldReturn201WhenCreateSuccess() throws Exception {
        CreateSupplierDTO dto = new CreateSupplierDTO();
        dto.setSupplierCode("SUP001");
        dto.setSupplierName("测试供应商");

        mockMvc.perform(post("/suppliers")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dto)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.data.supplierId").exists());
    }

    @Test
    @DisplayName("供应商编码为空应返回400")
    void shouldReturn400WhenCodeEmpty() throws Exception {
        CreateSupplierDTO dto = new CreateSupplierDTO();
        dto.setSupplierName("测试供应商");

        mockMvc.perform(post("/suppliers")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dto)))
            .andExpect(status().isBadRequest());
    }
}
```

## 临时调试测试

开发过程中写的临时测试（用于调试、验证假设）：

- 用 `// DEBUG-TEST` 标记
- **不允许合并到主分支** — 提交前删除或转化为正式测试
- 转化：去掉 `DEBUG-TEST` 标记，补充断言，使其成为正式测试

```java
// DEBUG-TEST: 临时验证评分计算逻辑
@Test
void debugScoreCalculation() {
    // ...
}
```

## 本项目必须覆盖的测试场景

| 服务 | 必测场景 |
|------|---------|
| auth | 登录成功/失败、Token验证、权限校验 |
| supplier | CRUD完整流程、评分计算、联系人管理 |
| order | 订单状态流转、交货记录、金额计算 |
| data | 五维度评分聚合、仪表盘数据、溯源查询 |
| gateway | 路由转发、Token透传、限流熔断 |

## 提交前检查清单

- [ ] 测试文件命名和位置符合项目约定（`XxxTest.java`）
- [ ] 新增的公共方法有正例和反例测试
- [ ] 测试验证行为而非实现细节
- [ ] 没有残留的 `// DEBUG-TEST` 临时测试
- [ ] 集成测试有 `@SpringBootTest` + `@AutoConfigureMockMvc` 注解
