---
name: session-handoff
description: AI会话交接协议：新会话启动流程、会话结束必做项、任务交接模板。会话开始或结束时加载。
metadata:
  priority: L2
  category: workflow
  depends: status-management, stub-management, changelog
---

# 会话交接协议

## 问题背景

AI助手的上下文在每次对话结束时清空。如果不做好交接，下一次会话的AI（或同一个AI的新会话）将不知道项目当前状态，可能做出冲突的修改或重复工作。

## 新会话启动流程

```
1. 阅读 RULES.md（本规范主文件）
2. 阅读 rules/STATUS.md（项目当前状态）
3. 阅读 rules/CHANGELOG.md 最近3-5条记录（最近发生了什么）
4. 全局搜索 // STUB（当前有哪些假实现）
5. 了解当前任务需求后，从Skill索引匹配并加载相关skill
6. 开始工作
```

## 会话结束必做项

**在结束当前会话之前，必须完成以下步骤：**

```
□ 更新 rules/STATUS.md — 反映本次会话的工作成果
□ 更新 rules/CHANGELOG.md — 追加本次所有变更记录
□ 检查是否有新增STUB — 如有，已登记到STATUS.md
□ 确认代码可编译 — 不留下编译错误
□ 如果任务未完成 — 在STATUS.md的"进行中"标注当前进度和下一步
```

## 任务交接模板

当人类开发者要求"总结本次会话"或"准备交接"时，按以下格式输出：

```markdown
## 本次会话总结

**完成的工作**:
- [具体完成了什么]

**未完成的工作**:
- [哪些任务还在进行中，进度到哪里]

**引入的STUB**:
- [新增的STUB位置和原因]

**已知风险/注意事项**:
- [下一位开发者需要注意什么]

**建议的下一步**:
- [接下来应该做什么]
```

## 提交前检查清单

- [ ] rules/STATUS.md 已更新为最新状态
- [ ] rules/CHANGELOG.md 已追加本次变更
- [ ] 新增STUB已登记到 rules/STATUS.md
- [ ] 代码可编译通过，无遗留的编译错误
- [ ] 未完成任务在 rules/STATUS.md 中有明确的进度标注
