---
name: git-commit
description: Git提交信息格式、scope定义、提交频率和原子性要求。提交代码时加载。
metadata:
  priority: L2
  category: workflow
---

# Git提交规范

## 提交信息格式

```
<type>(<scope>): <简短描述>

[可选: 详细说明]

[可选: BREAKING CHANGE: 不兼容变更说明]
```

### type 类型

| type | 含义 | 示例 |
|------|------|------|
| `feat` | 新功能 | `feat(supplier): 添加供应商评分查询接口` |
| `fix` | bug修复 | `fix(order): 修复交货记录日期为空导致NPE` |
| `refactor` | 重构（不改变功能） | `refactor(data): 提取五维度计算为独立类` |
| `docs` | 文档 | `docs: 更新API文档` |
| `test` | 测试 | `test(supplier): 添加评分计算单元测试` |
| `chore` | 构建/工具/配置 | `chore: 升级Spring Boot到3.2.4` |
| `style` | 代码格式（不影响逻辑） | `style: 统一import排序` |
| `perf` | 性能优化 | `perf(order): 优化N+1查询为JOIN` |

### scope 范围

| scope | 含义 |
|-------|------|
| `common-core` | 公共模块 |
| `common-feign` | Feign客户端 |
| `gateway` | API网关 |
| `auth` | 认证服务 |
| `supplier` | 供应商服务 |
| `order` | 订单服务 |
| `data` | 数据分析服务 |
| `frontend` | 前端 |
| `db` | 数据库/迁移脚本 |
| `config` | 配置相关 |

## 规则

- **一个提交做一件事** — 原子性，回滚时不会牵连无关代码
- **提交信息用中文** — 描述简洁明了
- **不提交半成品** — 每个提交在 `git checkout` 后必须能编译通过
- **不提交生成文件和临时文件** — 确保 `.gitignore` 正确配置

## 示例

✅ 正确：

```
feat(supplier): 实现供应商基础信息CRUD

- 新增 SupplierBaseEntity 实体类
- 新增 SupplierMapper 和 SupplierMapper.xml
- 新增 SupplierService 和 SupplierServiceImpl
- 新增 SupplierController REST接口
```

❌ 错误：

```
update files               ← 没有type，没有scope，描述无意义
fix: 修了很多东西          ← 非原子提交
feat: WIP                  ← 半成品
```

## .gitignore 模板（Java Spring Boot项目）

```
# Maven
target/
*.jar
*.war
!.mvn/wrapper/maven-wrapper.jar

# IDE
.idea/
*.iml
.vscode/
.project
.classpath

# Logs
*.log
logs/

# OS
.DS_Store
Thumbs.db

# 敏感文件
.env
*.pem
```

## 提交前检查清单

- [ ] 提交信息符合 `<type>(<scope>): <描述>` 格式
- [ ] 本次提交只包含一个逻辑单元的变更
- [ ] 代码能编译通过，不是半成品
- [ ] CHANGELOG.md 已同步更新
- [ ] 没有提交临时文件、日志文件或生成文件
