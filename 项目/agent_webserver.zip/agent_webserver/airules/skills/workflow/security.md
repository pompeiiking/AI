---
name: security
description: 密钥管理、环境变量、敏感数据处理、依赖安全、输入验证。涉及认证、密钥、外部API或用户输入时加载。
metadata:
  priority: L1
  category: workflow
---

# 安全规范

## 铁律（已在全局铁律中，此处展开详述）

**密钥凭证不入代码库。** API Key、密码、token、证书等敏感信息只走环境变量。

## 规则

### 1. 密钥与凭证管理

- **所有密钥/token/密码通过环境变量注入**，不硬编码在源码中
- **提供 `.env.example` 文件**列出所有需要的环境变量（值留空或用占位符）
- **`.env` 文件必须在 `.gitignore` 中** — 绝不提交到版本控制
- **日志中不输出密钥** — 日志框架应自动脱敏或手动过滤

✅ 正确：

```java
// application.yml（不包含真实凭证）
spring:
  datasource:
    username: ${DB_USERNAME}
    password: ${DB_PASSWORD}
  redis:
    password: ${REDIS_PASSWORD}

// .env.example（提交到git）
DB_USERNAME=your_db_username
DB_PASSWORD=your_db_password
REDIS_PASSWORD=your_redis_password
NACOS_PASSWORD=your_nacos_password
JWT_SECRET=your_jwt_secret_min_32_chars
```

❌ 错误：

```java
// ❌ 硬编码密钥
private static final String JWT_SECRET = "my-super-secret-key-12345";

// ❌ 日志泄露密钥
log.info("JWT secret: {}", jwtSecret);
```

### 2. JWT凭证

```java
// ✅ 正确：从配置或环境变量读取
@Data
@Component
@ConfigurationProperties(prefix = "app.jwt")
public class JwtProperties {
    private String secret;
    private long expireSeconds;
}

// application.yml
app:
  jwt:
    secret: ${JWT_SECRET}
    expire-seconds: 7200
```

### 3. 数据库密码

```java
// ✅ 正确：使用环境变量
spring:
  datasource:
    url: jdbc:mysql://${DB_HOST}:${DB_PORT}/${DB_NAME}
    username: ${DB_USERNAME}
    password: ${DB_PASSWORD}
```

### 4. Nacos配置中心凭证

```yaml
# application.yml — Nacos认证
spring:
  cloud:
    nacos:
      username: ${NACOS_USERNAME:nacos}
      password: ${NACOS_PASSWORD}
      config:
        server-addr: ${NACOS_HOST}:8848
```

### 5. 用户输入验证

- **所有外部输入（用户输入、API参数、文件内容）在系统边界处验证**
- **验证逻辑与业务逻辑分离** — 用专门的验证层/中间件
- **验证失败返回明确错误信息**，不暴露系统内部细节

### 6. SQL注入防护

```java
// ✅ 正确：使用参数化查询（MyBatis-Plus默认支持）
LambdaQueryWrapper<Supplier> wrapper = new LambdaQueryWrapper<>();
wrapper.like(Supplier::getSupplierName, keyword);  // 参数化，安全

// ❌ 错误：字符串拼接SQL
@Select("SELECT * FROM supplier WHERE name LIKE '%${keyword}%'")
List<Supplier> searchByKeyword(@Param("keyword") String keyword);
```

### 7. 依赖安全

- **新增依赖前检查**：最近更新时间、下载量、已知漏洞
- **定期更新依赖** — 不使用已知有安全漏洞的版本
- **锁定依赖版本** — 使用 pom.xml 中的 `<version>` 锁定 + Maven Wrapper

## .gitignore 配置

```
# 敏感配置
.env
*.pem
*.key
credentials.json
secrets.yml

# 日志
*.log
logs/

# IDE
.idea/
*.iml
```

## 提交前检查清单

- [ ] 代码中没有硬编码的密钥、token、密码
- [ ] `.env` 文件在 `.gitignore` 中
- [ ] 新增的环境变量已在 `.env.example` 中列出
- [ ] 日志中没有输出敏感信息
- [ ] 外部输入在系统边界处有验证（@Valid 注解）
- [ ] 面向用户的错误信息不包含内部细节
- [ ] 没有字符串拼接SQL
