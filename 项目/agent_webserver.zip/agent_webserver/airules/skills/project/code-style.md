---
name: code-style
description: 项目代码风格：文件内部结构顺序、组件写法模板、样式方案、格式化配置。写代码时加载。
metadata:
  priority: L3
  category: project
  depends: naming, comments
---

# 代码风格

## 文件内部结构顺序

**每个Java源文件按以下顺序组织（不可打乱）：**

```
1. 包声明（package）

2. 导入语句（import，按分组排列）
   a. java.* / javax.* 标准库
   b. org.* 第三方库（Spring、MyBatis-Plus等）
   c. com.huayou.common.* 项目公共模块
   d. 同服务内部包（com.huayou.service.xxx.*）
   e. 静态导入（import static）

3. 类声明
   - @RestController / @Service / @Mapper 等注解
   - 类名 + implements/extends
   - Swagger注解（@Api / @ApiOperation）
   - 类级注释（Javadoc）

4. 成员变量
   - 常量（static final）
   - 配置值（@Value）
   - 依赖注入（@Autowired / @Resource / @RequiredArgsConstructor）
   - 普通成员变量

5. 构造方法

6. 公共方法（Controller层：处理方法在前，私有辅助方法在后）
   - 处理方法（带 @GetMapping / @PostMapping 等）
   - 私有辅助方法

7. 私有方法
```

## Java文件示例

✅ 正确：

```java
package com.huayou.service.supplier.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import com.huayou.common.core.result.Result;
import com.huayou.service.supplier.service.SupplierService;
import com.huayou.service.supplier.vo.SupplierVO;

/**
 * 供应商管理控制器
 * 职责：供应商档案的CRUD、评分查询
 */
@Api(tags = "供应商管理")
@Slf4j
@RestController
@RequestMapping("/suppliers")
@RequiredArgsConstructor
public class SupplierController {

    private final SupplierService supplierService;

    @ApiOperation("查询供应商列表")
    @GetMapping
    public Result<List<SupplierVO>> list(SupplierQuery query) {
        log.info("查询供应商列表，参数={}", query);
        return Result.success(supplierService.listByQuery(query));
    }

    @ApiOperation("查询供应商详情")
    @GetMapping("/{id}")
    public Result<SupplierVO> getById(@PathVariable Long id) {
        return Result.success(supplierService.getById(id));
    }

    private SupplierVO convertToVO(Supplier entity) {
        // ...
    }
}
```

❌ 错误：

```java
// 导入散乱，顺序混乱
import com.huayou.service.supplier.service.SupplierService;
import java.util.List;
import lombok.RequiredArgsConstructor;

// 无意义的类注释
// 这是控制器类
@RestController
public class SupplierController {  // 无Swagger注解
    @Autowired  // Field注入（不推荐）
    SupplierService service;  // 无private final
    @GetMapping("/suppliers")
    public List<SupplierVO> getAll() { // 返回Result不统一
        return service.list(); // 无日志
    }
    private void logSomething() {} // 处理方法后接私有方法
    @PostMapping
    public void create() {} // 方法间无空行
}
```

## Controller层规范

```java
// 统一返回 Result<T>
public Result<SupplierVO> getById(@PathVariable Long id) {
    SupplierVO vo = supplierService.getById(id);
    return Result.success(vo);
}

// 统一参数校验：@Valid + @RequestBody / @Validated + @RequestParam
@PostMapping
public Result<Void> create(@Valid @RequestBody CreateSupplierDTO dto) {
    supplierService.create(dto);
    return Result.success();
}
```

## Service层规范

```java
// 接口 + 实现分离
public interface SupplierService {
    SupplierVO getById(Long id);
}

@Slf4j
@Service
@RequiredArgsConstructor
public class SupplierServiceImpl implements SupplierService {

    private final SupplierMapper supplierMapper;
    private final SupplierScoreMapper scoreMapper;

    @Override
    public SupplierVO getById(Long id) {
        Supplier entity = supplierMapper.selectById(id);
        if (entity == null) {
            throw new SupplierNotFoundException(id);
        }
        return convertToVO(entity);
    }
}
```

## Mapper层规范

```java
@Mapper
public interface SupplierMapper extends BaseMapper<Supplier> {
    // 自定义查询方法在 XML 中实现
    List<Supplier> selectByCondition(@Param("status") Integer status);
}
```

## DTO/VO规范

```java
// DTO：请求参数，添加校验注解
@Data
public class CreateSupplierDTO {
    @NotBlank(message = "供应商名称不能为空")
    private String supplierName;

    @NotBlank(message = "供应商编码不能为空")
    @Size(max = 50)
    private String supplierCode;
}

// VO：响应结构，添加Swagger文档
@Data
public class SupplierVO {
    @ApiModelProperty("供应商ID")
    private Long supplierId;

    @ApiModelProperty("供应商名称")
    private String supplierName;
}
```

## 枚举写法

```java
@Getter
@AllArgsConstructor
public enum OrderStatus {
    PENDING("PENDING", "待确认"),
    CONFIRMED("CONFIRMED", "已确认"),
    SHIPPED("SHIPPED", "已发货"),
    COMPLETED("COMPLETED", "已完成");

    private final String code;
    private final String desc;

    public static OrderStatus fromCode(String code) {
        return Arrays.stream(values())
            .filter(s -> s.code.equals(code))
            .findFirst()
            .orElseThrow(() -> new IllegalArgumentException("未知状态码: " + code));
    }
}
```

## 常量写法

```java
// 模块常量类
public final class OrderConstant {
    private OrderConstant() {}

    public static final String ORDER_NO_PREFIX = "PO";
    public static final int MAX_ITEM_COUNT = 100;
}

// 状态码（统一在 ResultCode 枚举中定义）
public enum ResultCode {
    SUCCESS(200, "success"),
    BAD_REQUEST(400, "请求参数错误"),
    NOT_FOUND(404, "资源不存在"),
    UNAUTHORIZED(401, "未认证"),
    FORBIDDEN(403, "无权限"),
    INTERNAL_ERROR(500, "服务器内部错误");
}
```

## 前端文件结构顺序（Vue 3）

```
1. <script setup> — 脚本
   a. 导入（import）
   b. Props / Emits 定义
   c. 响应式状态（ref / reactive / computed）
   d. 生命周期钩子（onMounted 等）
   e. 方法
   f. 暴露（defineExpose）

2. <template> — 模板

3. <style scoped> — 样式（按需）
```

## 格式化配置

```
- 格式化工具: IDE默认（IntelliJ IDEA / VS Code格式化）
- 缩进: 4空格（Java）/ 2空格（前端）
- 分号: 有
- 大括号: K&R风格（Java）、1TBS（前端）
- 行尾: LF
- 最大行宽: 120字符（Java）/ 100字符（前端）
- 导包排序: 按IDE默认自动排序
```

## 提交前检查清单

- [ ] 文件内部结构按规定顺序排列（包→导入→类→成员→方法）
- [ ] 导入语句按分组排列，无冗余导入
- [ ] Controller返回统一使用 `Result<T>` 包装
- [ ] DTO有 `@Valid` 注解校验
- [ ] Service层有接口和实现分离
- [ ] VO/DTO有 `@Data` 注解（Lombok）
- [ ] 异常使用自定义异常类，不直接抛出 `RuntimeException`
- [ ] 处理方法有 `log.info` 入口日志
- [ ] Swagger注解完整（@Api / @ApiOperation）
- [ ] 代码已通过 IDE 格式化
