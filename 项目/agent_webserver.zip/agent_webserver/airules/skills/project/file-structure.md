---
name: file-structure
description: 项目目录结构、新增文件放置规则、禁止创建的文件、文档封闭清单。新建文件或不确定文件该放哪里时加载。
metadata:
  priority: L2
  category: project
  depends: layering, naming
---

# 项目目录结构

## 项目根目录

```
project-parent/                      # 后端Java父工程
├── pom.xml                          # Maven父POM（版本锁定、依赖管理）
├── project-common/                   # 公共模块（被所有服务依赖）
│   ├── common-core/                  # 核心工具类：Result封装、异常定义、常量
│   ├── common-feign/                 # Feign客户端：声明式HTTP调用代理
│   └── common-swagger/               # Swagger配置：API文档聚合
├── project-gateway/                  # API网关：路由、认证鉴权、限流熔断
└── project-service/                 # 业务服务模块
    ├── service-auth/                 # 认证服务（8081）：用户、角色、权限、JWT
    ├── service-supplier/             # 供应商服务（8082）：供应商档案、评分、响应记录
    ├── service-order/                 # 订单服务（8083）：采购订单、交货记录
    └── service-data/                 # 数据分析服务（8092）：供应评估、仪表盘、溯源聚合

project-frontend/                     # Vue前端工程（独立仓库或子目录）

rules/                               # AI开发规范（从 ai-rules-template 转化）
├── RULES.md                          # 主规范文件
├── STATUS.md                         # 项目状态快照
├── CHANGELOG.md                      # 变更日志
├── contracts/                        # 接口契约文档
│   ├── _index.md                     # 契约索引
│   ├── shared-types.contract.md      # 全局共享类型
│   └── [模块对].contract.md          # 模块间契约
└── skills/                           # 技能规则
    ├── principles/                   # 设计原则
    └── workflow/                     # 工作流程
```

## Java服务内部结构

```
service-xxx/src/main/
├── java/com/huayou/service/xxx/
│   ├── XxxApplication.java           # Spring Boot启动类
│   ├── config/                       # 配置类：Bean定义、参数校验组
│   ├── controller/                   # REST控制器：接收请求、参数校验、响应处理
│   │   └── XxxController.java
│   ├── service/                      # 业务逻辑层
│   │   ├── impl/
│   │   │   └── XxxServiceImpl.java
│   │   └── XxxService.java
│   ├── repository/                   # 数据访问层（MyBatis-Plus Mapper）
│   │   └── XxxMapper.java
│   ├── entity/                       # 数据库实体：DO对象
│   │   └── Xxx.java
│   ├── vo/                           # 视图对象：返回给前端的结构
│   │   ├── XxxVO.java
│   │   └── XxxDetailVO.java
│   ├── dto/                          # 数据传输对象：请求参数封装
│   │   ├── CreateXxxDTO.java
│   │   └── UpdateXxxDTO.java
│   ├── query/                        # 查询参数：分页、过滤条件
│   │   └── XxxQuery.java
│   ├── enums/                        # 枚举：状态、类型等
│   │   └── XxxStatus.java
│   ├── constant/                     # 模块常量
│   │   └── XxxConstant.java
│   └── exception/                    # 自定义异常
│       ├── XxxNotFoundException.java
│       └── XxxErrorCode.java
├── resources/
│   ├── application.yml               # 主配置
│   ├── application-dev.yml            # 开发环境
│   ├── application-prod.yml           # 生产环境
│   └── mapper/                       # MyBatis XML映射文件
│       └── XxxMapper.xml
└── test/java/                        # 单元测试

gateway/src/main/
├── java/com/huayou/gateway/
│   ├── GatewayApplication.java
│   ├── config/                        # 网关配置（路由、过滤器、全局CORS）
│   └── filter/                        # 网关过滤器（认证鉴权、日志追踪）
└── resources/
    └── application.yml               # 网关路由配置
```

## 前端目录结构（Vue 3）

```
project-frontend/src/
├── api/                              # API请求层（按服务拆分）
│   ├── auth.js                        # 认证相关接口
│   ├── supplier.js                    # 供应商接口
│   ├── order.js                      # 订单接口
│   └── data.js                       # 数据分析接口
├── components/                        # 公共组件
├── views/                            # 页面视图（按功能模块）
│   ├── dashboard/                     # 首页仪表盘
│   ├── supplier/                      # 供应商管理
│   ├── order/                        # 订单管理
│   └── trace/                        # 溯源查询
├── router/                           # 路由配置
├── store/                           # 状态管理
├── utils/                           # 工具函数
└── App.vue
```

## 新增文件放置规则

| 文件类型 | 放置位置 | 示例 |
|----------|---------|------|
| 服务启动类 | `service-xxx/src/main/java/.../XxxApplication.java` | `AuthApplication.java` |
| 控制器 | `service-xxx/controller/` | `SupplierController.java` |
| 业务接口 | `service-xxx/service/` | `OrderService.java` |
| 业务实现 | `service-xxx/service/impl/` | `OrderServiceImpl.java` |
| Mapper | `service-xxx/repository/` | `SupplierMapper.java` |
| MyBatis XML | `service-xxx/resources/mapper/` | `SupplierMapper.xml` |
| VO | `service-xxx/vo/` | `OrderVO.java` |
| DTO | `service-xxx/dto/` | `CreateOrderDTO.java` |
| 枚举 | `service-xxx/enums/` | `OrderStatus.java` |
| 公共组件 | `project-frontend/src/components/` | `DataCard.vue` |
| API请求 | `project-frontend/src/api/` | `supplier.js` |
| 页面视图 | `project-frontend/src/views/` | `SupplierList.vue` |

## 禁止创建的文件

- **源码目录下的数据文件**（JSON/YAML/CSV等，构建配置文件除外）
- **未在RULES.md文档体系中登记的文档文件**
- **临时文件/调试文件**（如 `temp.java`, `debug.js`）
- **重复的工具函数文件**（先搜索 common-core 是否已有类似功能）
- **跨服务直接依赖实现**（服务间通信必须通过 Feign 接口，禁止直接注入其他服务的 Mapper/Service）

## 新建文件决策流

```
Q1: "这个文件属于哪个服务/模块？"
  → 认证/用户/权限 → service-auth/
  → 供应商相关 → service-supplier/
  → 订单相关 → service-order/
  → 数据分析/聚合 → service-data/
  → 前端组件 → project-frontend/src/components/
  → 多个服务都用到 → project-common/

Q2: "这是哪一层？"
  → 接收HTTP请求 → controller/
  → 业务逻辑 → service/
  → 数据访问 → repository/ + mapper XML
  → 返回结构 → vo/
  → 请求参数 → dto/ 或 query/

Q3: "类似功能的文件是否已存在？"
  → 是 → 扩展已有文件而非新建
  → 否 → 创建新文件
```

## 提交前检查清单

- [ ] 新文件放在了正确的目录下（按上方放置规则）
- [ ] 同类文件已存在时，扩展而非新建
- [ ] 没有在源码目录下创建数据文件
- [ ] 没有创建未登记的文档文件
- [ ] 检查过 common-core 是否已有类似功能的工具类
- [ ] 跨服务调用使用 Feign 方式，而非直接依赖实现
