---
name: layering
description: 严格分层架构，只允许向下依赖，禁止跨层引用和同层具体实现互相依赖。新建文件或添加import时加载。
metadata:
  priority: L2
  category: principles
  depends: module-boundary
---

# 严格分层，禁止跨层依赖

## 本项目分层结构

```
客户端层 (前端 Vue)
  ↓ HTTP请求
网关层 (Spring Cloud Gateway)
  ↓ 路由转发
服务层 (各微服务)

  ├─ Controller层：接收HTTP请求，参数校验，调用Service
  ├─ Service层：业务逻辑处理，事务管理
  ├─ Repository层：数据访问，SQL执行
  └─ VO/DTO层：数据转换，对外暴露结构

公共模块 (project-common)
  ├─ common-core：工具类、Result封装、异常定义
  ├─ common-feign：Feign客户端接口定义
  └─ common-swagger：Swagger聚合配置
```

## 规则

- **依赖方向只允许向下** — 上层可以依赖下层，下层绝不能依赖上层
- **Controller禁止直接注入Mapper** — 必须通过Service层
- **Service禁止直接注入其他Service的Mapper** — 必须通过Feign接口
- **同层之间禁止通过具体实现互相依赖** — 应通过事件总线或依赖注入解耦
- **每个文件的 import 语句必须符合分层方向** — 违反即为架构破坏

## 正确的依赖方向

```java
// ✅ Controller → Service（向下）
@RestController
@RequiredArgsConstructor
public class SupplierController {
    private final SupplierService supplierService;  // ✅ 正确
}

// ✅ ServiceImpl → Mapper（向下）
@Service
@RequiredArgsConstructor
public class SupplierServiceImpl {
    private final SupplierMapper supplierMapper;  // ✅ 正确
}

// ✅ ServiceImpl → Feign接口（跨服务通信，不是上下层依赖）
@Service
@RequiredArgsConstructor
public class DataEvaluationServiceImpl {
    private final OrderFeignClient orderFeignClient;  // ✅ 正确
    private final SupplierFeignClient supplierFeignClient;  // ✅ 正确
}
```

## 禁止的依赖方向

❌ **Controller直接注入Mapper**（违反三层架构）：

```java
@RestController
@RequiredArgsConstructor
public class SupplierController {
    private final SupplierMapper supplierMapper;  // ❌ 错误：Controller不能直接访问Mapper
}
```

❌ **Service直接注入其他服务的Mapper**（跨服务耦合）：

```java
@Service
@RequiredArgsConstructor
public class DataEvaluationServiceImpl {
    // ❌ 错误：data-service不能直接依赖order-service的Mapper
    // ✅ 正确：应该通过 OrderFeignClient 调用
    private final OrderMapper orderMapper;
}
```

❌ **下层依赖上层**：

```java
// common-core 中的类不能依赖 service 层
package com.huayou.common.core;

public class SomeUtil {
    // ❌ 错误：common-core不能依赖service-supplier中的类
    private final SupplierService supplierService;
}
```

## Feign接口定义位置

Feign客户端定义在 `common-feign` 模块中，由调用方服务声明：

```java
// service-data 调用 order-service
// 定义在 common-feign 模块
@FeignClient(name = "order-service")
public interface OrderFeignClient {
    @GetMapping("/orders/delivery-stats")
    Result<DeliveryStatsVO> getDeliveryStats(
        @RequestParam("supplierId") Long supplierId,
        @RequestParam("startDate") String startDate,
        @RequestParam("endDate") String endDate
    );
}
```

## 添加import时的检查流程

添加 `import` 时问自己：
1. "被引用的文件在哪一层？我在哪一层？" → 必须是我引用下层
2. "被引用的模块属于哪个服务？" → 跨服务必须用 Feign，不能直接 import 其他服务的 Mapper/Entity
3. "如果被引用的模块被删除/重写，我需要改吗？" → 是 → 耦合过紧，应加接口层

## 提交前检查清单

- [ ] 所有新增的 `import` 语句都符合向下依赖方向
- [ ] Controller只注入Service，不注入Mapper/Entity
- [ ] 没有跨服务直接依赖Mapper/Service（必须用Feign）
- [ ] 同层模块之间没有直接import具体实现
- [ ] common-core 模块没有依赖任何 service 模块
