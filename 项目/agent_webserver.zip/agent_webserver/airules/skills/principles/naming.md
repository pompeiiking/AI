---
name: naming
description: 文件、变量、函数、类的命名一致性规范，禁止同义词混用和无意义缩写。新建任何标识符时加载。
metadata:
  priority: L2
  category: principles
---

# 命名一致性

## 规则

- **全项目同一种命名约定**，不混用多种风格
- **同一概念必须使用同一名称** — 不允许一处叫 `user` 另一处叫 `account`
- **禁止无意义缩写** — 用 `eventBus` 不用 `eb`，用 `configuration` 不用 `cfg`
- **禁止无意义命名** — `data`, `info`, `item`, `temp`, `result`, `obj` 不能独立作为变量名

## Java命名规则

| 类别 | 规则 | 示例 |
|------|------|------|
| 类/接口/枚举 | PascalCase | `SupplierService`, `OrderStatus`, `ResultCode` |
| 方法名 | lowerCamelCase | `getOrderById`, `listSuppliers` |
| 变量名 | lowerCamelCase | `supplierId`, `orderNo`, `isActive` |
| 常量 | UPPER_SNAKE_CASE | `ORDER_NO_PREFIX`, `MAX_RETRY_COUNT` |
| 包名 | 全小写 | `com.huayou.service.order` |
| 枚举值 | UPPER_SNAKE_CASE | `PENDING`, `CONFIRMED`, `SHIPPED` |

## 前端命名规则

| 类别 | 规则 | 示例 |
|------|------|------|
| 组件文件 | PascalCase | `SupplierList.vue`, `OrderCard.vue` |
| 工具函数/JS文件 | camelCase | `formatDate.js`, `httpRequest.js` |
| API文件 | camelCase | `supplier.js`, `order.js` |
| 变量/函数 | lowerCamelCase | `supplierList`, `getOrderById` |
| 常量 | UPPER_SNAKE_CASE | `API_BASE_URL`, `MAX_PAGE_SIZE` |
| CSS类名 | kebab-case | `supplier-card`, `order-header` |

## 数据库命名规则

| 类别 | 规则 | 示例 |
|------|------|------|
| 表名 | 小写下划线，单数名词 | `order_main`, `supplier_base` |
| 字段名 | 小写下划线 | `order_no`, `supplier_id`, `created_at` |
| 索引名 | `idx_` + 表名 + 字段 | `idx_order_no`, `idx_supplier_id` |

## 项目术语统一表

| 概念 | 统一名称 | 禁止使用 |
|------|---------|---------|
| 供应商 | Supplier | Provider, Vendor, Supply |
| 订单 | Order | PO, Purchase |
| 交货/发货 | Delivery | Ship, Dispatch |
| 评估/评分 | Evaluation/Score | Rate, Assess |
| 溯源 | Trace | Track, Origin |
| 仪表盘 | Dashboard | Home, Index |

## 示例

✅ 正确：

```java
// 变量名有意义
private final SupplierMapper supplierMapper;
private final OrderMapper orderMapper;
private boolean isLoading = false;
private Long supplierId;
private String orderNo;

// 方法名清晰
public List<SupplierVO> listByQuery(SupplierQuery query);
public SupplierEvaluationVO getEvaluationDetail(Long supplierId, String period);

// 类名职责明确
public class SupplierNotFoundException extends BusinessException {}
public class DeliveryStatsVO {}
```

❌ 错误：

```java
// 无意义缩写
private SupplierMapper sm;  // sm是什么？
private int cnt;  // count什么？
private String tp;  // type？temp？tip？

// 无意义命名
private Object data;  // 什么data？
private String info;  // 什么info？
private List<?> temp;  // 临时存放什么？
private Result result;  // 什么result？

// 混用同义词
// 一处用 supplier，另一处用 vendor
private SupplierService supplierService;
public VendorVO getVendorById(Long id);  // vendor ≠ supplier
```

## 布尔变量

```java
// 使用 is/has/can/should 前缀
private boolean isActive;
private boolean hasPermission;
private boolean canEdit;
private boolean shouldNotify;

// 方法返回布尔值
public boolean isSupplierActive(Long id);
public boolean hasUnpaidOrders(Long supplierId);
public boolean canApproveOrder(Long userId, Long orderId);
```

## 提交前检查清单

- [ ] 新变量/方法名能让不看上下文的人理解含义
- [ ] 没有使用 `data`, `info`, `temp`, `result` 等作为独立变量名
- [ ] 同一概念在所有文件中使用同一名称（查术语统一表）
- [ ] 文件命名遵循项目统一约定
- [ ] 布尔变量使用了 `is/has/can/should` 前缀
- [ ] 数据库表名使用单数名词 + 小写下划线
