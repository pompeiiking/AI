---
name: data-separation
description: 数据文件与代码文件严格分离，通过接口访问数据，数据格式变化不影响业务逻辑。涉及数据文件或配置时加载。
metadata:
  priority: L2
  category: principles
  depends: layering
---

# 数据与逻辑分离

## 规则

- **源码目录下不允许出现业务数据文件**（配置YAML/JSON如 application.yml 除外）
- **数据目录下不允许出现代码文件**
- **业务代码不直接读取数据文件路径**，必须通过 Repository/Mapper 访问
- **数据格式变化不应导致业务逻辑代码修改** — 格式转换在数据访问层处理

## 允许存放的文件

| 文件类型 | 位置 | 示例 |
|----------|------|------|
| Spring配置 | `resources/application*.yml` | `application.yml`, `application-dev.yml` |
| MyBatis XML映射 | `resources/mapper/` | `SupplierMapper.xml` |
| 数据库初始化脚本 | `resources/db/` | `schema.sql`, `data.sql` |
| 枚举值定义 | Java `enums/` 包 | `OrderStatus.java`（非数据文件） |

## 禁止存放的文件

❌ **禁止在源码目录存放业务数据**：

```
// ❌ 错误
service-data/src/main/resources/
├── supplier_evaluation.json     ← 禁止：业务数据文件
├── evaluation_rules.yaml        ← 禁止：业务规则数据
└── material_trace_data.csv     ← 禁止：溯源数据

// ✅ 正确：数据存MySQL，业务代码通过Mapper访问
service-data/src/main/resources/
├── application.yml
└── mapper/
    └── SupplierEvaluationMapper.xml
```

## 数据库初始化脚本管理

```bash
# 数据库脚本统一存放在 resources/db/ 目录
resources/db/
├── init/
│   ├── auth_db.sql          # 认证库初始化（用户、角色、权限表）
│   ├── supplier_db.sql      # 供应商库初始化
│   ├── order_db.sql        # 订单库初始化
│   └── data_db.sql         # 数据分析库初始化
└── migration/               # Flyway版本化迁移（如使用）
    ├── V1__init_schema.sql
    └── V2__add_indexes.sql
```

## 前端数据文件管理

```bash
# 前端静态数据文件（如国家列表、枚举值等）存放在 assets
project-frontend/src/assets/
├── data/
│   ├── order-status.json   # 订单状态枚举（静态配置）
│   └── eval-levels.json    # 评估等级定义
└── icons/                  # 图标资源
```

## 提交前检查清单

- [ ] 业务数据（用户数据、订单数据、评估结果）不存放在源码目录
- [ ] 源码目录下的 JSON/YAML/CSV 文件是配置文件（如 application.yml），不是业务数据
- [ ] 数据库脚本存放在 `resources/db/` 目录
- [ ] 业务代码通过 MyBatis-Plus Mapper 访问数据库，不直接读写文件
- [ ] 前端枚举类从后端API获取，不硬编码在前端
