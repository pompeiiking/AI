---
name: performance
description: 执行频率意识、高频路径禁忌、精确订阅、异步加载策略。涉及渲染循环或高频调用路径时加载。
metadata:
  priority: L3
  category: principles
---

# 性能意识

## 规则

- **新增代码时必须考虑其执行频率** — 启动初始化 vs 请求处理 vs 数据聚合，策略完全不同
- **禁止在循环中执行数据库查询或网络请求** — 必须批量处理
- **高频接口禁止 N+1 查询** — 使用 JOIN 或批量查询
- **异步加载非关键资源** — 不阻塞主流程和首屏渲染

## 数据库性能禁忌

❌ **N+1查询问题**：

```java
// ❌ 错误：N+1查询，orders有多少条就查多少次supplier表
List<OrderVO> orders = orderMapper.selectList(wrapper);
for (OrderVO order : orders) {
    Supplier s = supplierMapper.selectById(order.getSupplierId());
    order.setSupplierName(s.getSupplierName());
}
```

✅ **正确：JOIN查询**：

```java
// ✅ 正确：一次性JOIN查询
List<OrderVO> orders = orderMapper.selectOrderWithSupplier(wrapper);
```

❌ **循环内执行SQL**：

```java
// ❌ 错误：每条明细查一次物资表
for (OrderItemDTO item : items) {
    Material m = materialMapper.selectByCode(item.getMaterialCode());
    item.setMaterialName(m.getName());
}
```

✅ **正确：批量查询**：

```java
// ✅ 正确：一次查询所有物资
List<String> codes = items.stream().map(OrderItemDTO::getMaterialCode).toList();
Map<String, Material> materialMap = materialMapper.selectByCodes(codes).stream()
    .collect(Collectors.toMap(Material::getCode, m -> m));
```

## 缓存策略

```java
// 热点数据使用Redis缓存
@Service
@RequiredArgsConstructor
public class SupplierService {
    private final SupplierMapper supplierMapper;
    private final RedisTemplate<String, SupplierVO> redisTemplate;
    private static final String SUPPLIER_KEY_PREFIX = "supplier:";

    public SupplierVO getById(Long id) {
        String key = SUPPLIER_KEY_PREFIX + id;
        SupplierVO cached = redisTemplate.opsForValue().get(key);
        if (cached != null) {
            return cached;
        }
        SupplierVO vo = convertToVO(supplierMapper.selectById(id));
        redisTemplate.opsForValue().set(key, vo, Duration.ofHours(1));
        return vo;
    }
}
```

## 分页查询

```java
// ✅ 正确：强制分页，防止查询全表
@GetMapping
public Result<IPage<SupplierVO>> list(SupplierQuery query) {
    IPage<Supplier> page = new Page<>(query.getCurrent(), query.getSize());
    IPage<SupplierVO> result = supplierService.page(page, query);
    return Result.success(result);
}
```

## 项目性能指标

```
- 接口响应时间: P99 < 500ms（常规查询），P99 < 2s（聚合查询）
- 数据库单表查询: < 100ms（10万级数据，有索引）
- 前端首屏加载: < 3s（4G网络）
- Feign调用超时: 3s（可配置）
```

## 提交前检查清单

- [ ] 循环中没有执行SQL查询（改为批量查询或JOIN）
- [ ] 分页查询限制了最大页大小
- [ ] 热点数据使用了缓存
- [ ] 没有在循环中执行HTTP请求（Feign调用）
- [ ] 数据库查询有合理的索引覆盖
