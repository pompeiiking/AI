---
name: module-boundary
description: 模块入口出口规范，资源获取释放对称，统一index导出，外部不直接引用内部文件。新建模块时加载。
metadata:
  priority: L2
  category: principles
  depends: naming
---

# 单一入口，单一出口

## 规则

- **每个模块有一个清晰的入口**（Service接口）和**一个清晰的出口**（返回结果）
- **资源获取和释放必须对称** — 获取了就必须释放，在对称位置（init/destroy, open/close）
- **Feign客户端只定义在 common-feign**，调用方和提供方都依赖公共接口
- **每个服务只通过 Controller 暴露 API**，内部 Service 不相互暴露

## Feign接口规范

```java
// common-feign 模块：统一Feign接口定义
// 调用方和提供方都依赖 common-feign，解耦

@FeignClient(name = "order-service", path = "/orders")
public interface OrderFeignClient {
    @GetMapping("/delivery-stats")
    Result<DeliveryStatsVO> getDeliveryStats(
        @RequestParam("supplierId") Long supplierId,
        @RequestParam("startDate") String startDate,
        @RequestParam("endDate") String endDate
    );

    @GetMapping
    Result<List<OrderVO>> getOrders(@RequestParam Map<String, Object> params);
}
```

## DTO/VO统一包结构

```
service-xxx/
├── dto/            # 请求参数（创建/更新/导入）
│   ├── CreateXxxDTO.java
│   ├── UpdateXxxDTO.java
│   └── ImportXxxDTO.java
├── query/          # 查询条件
│   └── XxxQuery.java
├── vo/             # 响应结构（暴露给前端）
│   ├── XxxVO.java
│   ├── XxxDetailVO.java
│   └── XxxListVO.java
```

## 资源获取释放对称

```java
// ✅ 正确：资源获取释放对称
@Service
@RequiredArgsConstructor
public class CacheService {
    private final RedisTemplate<String, Object> redisTemplate;

    public void cacheEvaluation(Long supplierId, EvaluationVO vo) {
        String key = "eval:" + supplierId;
        redisTemplate.opsForValue().set(key, vo, Duration.ofHours(1));
        // Redis连接由Spring管理，自动释放
    }
}

// ✅ Feign客户端生命周期由Spring管理
@Service
@RequiredArgsConstructor
public class DataEvaluationServiceImpl {
    private final OrderFeignClient orderFeignClient;  // Spring管理连接生命周期
}
```

## 禁止的模式

❌ **直接引用其他服务的内部类**：

```java
// service-data 中不应出现
import com.huayou.service.order.entity.OrderMain;
import com.huayou.service.order.mapper.OrderMapper;

// ✅ 正确：通过Feign接口
import com.huayou.common.feign.OrderFeignClient;
```

❌ **多个Controller暴露同一实体的不同视图**（造成混乱）：

```java
// ❌ 错误：不应该在多个Controller中定义相同实体的不同返回结构
// supplier-service 的 Controller
public SupplierVO getSupplier(Long id);

// auth-service 的 Controller
public SupplierBasicVO getSupplierBasic(Long id);  // 同样的数据，不同的VO
```

## 提交前检查清单

- [ ] Feign接口定义在 common-feign 模块，不在服务内部
- [ ] 跨服务调用使用Feign接口，不直接import其他服务的类
- [ ] DTO/VO放在正确的子包中（dto/query/vo）
- [ ] 资源获取有对应的释放逻辑（由Spring管理的除外）
- [ ] 每个服务只通过Controller暴露API
