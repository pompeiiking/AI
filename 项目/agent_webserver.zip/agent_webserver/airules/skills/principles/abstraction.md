---
name: abstraction
description: 抽象层设计规范，每个抽象必须能一句话说清职责，禁止过度抽象。新建接口或基类时加载。
metadata:
  priority: L3
  category: principles
  depends: naming
---

# 一个抽象层，易懂的抽象层

## 规则

- **每个抽象层（接口、基类、泛型）必须能用一句话说清楚它的职责**，说不清楚就需要拆分或重构
- **不允许"为了抽象而抽象"** — 每个接口必须有至少两个可预见的实现
- **抽象层的命名必须直觉可懂**，不允许无意义缩写或过长的组合词
- **继承层级不超过3层** — 超过则改用组合（composition）

## 本项目常见的合理抽象

| 抽象 | 职责（一句话） | 可预见实现 |
|------|-------------|-----------|
| `OrderFeignClient` | 订单服务的HTTP接口定义 | order-service提供实现，前端网关路由 |
| `SupplierFeignClient` | 供应商服务的HTTP接口定义 | supplier-service提供实现 |
| `Result<T>` | 统一HTTP响应包装 | 所有Controller统一使用 |
| `BaseEntity` | 提供公共字段（id, createdAt, updatedAt） | 所有实体继承 |
| `EvaluationCalculator` | 五维度评分计算策略 | 本版本直接实现 |

## 本项目禁止的过度抽象

❌ **只有一个实现的接口**：

```java
// ❌ 错误：SupplierService只有SupplierServiceImpl一个实现，抽象无意义
public interface SupplierService {
    SupplierVO getById(Long id);
}

@Service
@RequiredArgsConstructor
public class SupplierServiceImpl implements SupplierService {}

// ✅ 正确：如果确定只有一个实现，可以不抽象接口
// 直接使用类
@Slf4j
@Service
public class SupplierService {
    // 直接实现
}
```

❌ **泛型滥用**：

```java
// ❌ 错误：说不清楚这是干什么的
public class GenericProcessorFactory<T, U, V, W> {}

// ✅ 正确：有具体职责
public class EvaluationCalculator { /* 计算五维度评分 */ }
```

## 判断标准

新建抽象时问自己：
1. "能用一句话说清这个抽象的职责吗？" → 不能 → 设计有问题
2. "能想到至少两个不同的实现吗？" → 不能 → 可能不需要抽象
3. "去掉这层抽象，调用方代码会变复杂吗？" → 不会 → 不需要抽象

## 提交前检查清单

- [ ] 新建的每个接口/基类都能用一句话描述职责
- [ ] 新建的每个接口都有至少两个可预见的实现场景
- [ ] 继承层级未超过3层
- [ ] 没有出现只有一个实现的接口（除非架构规划中明确预留扩展点）
- [ ] 抽象类名不包含无意义的泛型组合
