---
name: error-handling
description: 自定义错误类、错误信息规范、异步错误处理、故障隔离策略。写错误处理或catch块时加载。
metadata:
  priority: L1
  category: principles
---

# 错误处理一致性

## 规则

- **使用自定义错误类**，按模块或功能分类，不用裸 `RuntimeException`
- **错误信息必须包含上下文** — 哪个模块、什么操作、什么原因
- **异步操作必须有错误处理** — 每个 Feign 调用都要考虑失败路径
- **核心模块的错误不能导致整个应用崩溃** — 故障隔离，非核心功能失败不影响主流程
- **统一错误码** — 所有业务异常必须使用 `ResultCode` 枚举或自定义错误码

## 错误码体系

| 错误码范围 | 含义 | 示例 |
|-----------|------|------|
| 200 | 成功 | SUCCESS |
| 400 | 请求参数错误 | BAD_REQUEST, VALIDATION_ERROR |
| 401 | 未认证 | UNAUTHORIZED, TOKEN_INVALID |
| 403 | 无权限 | FORBIDDEN, ACCESS_DENIED |
| 404 | 资源不存在 | NOT_FOUND, ORDER_NOT_FOUND |
| 500 | 服务器内部错误 | INTERNAL_ERROR, DB_ERROR |

## 自定义异常写法

```java
// 基础业务异常（所有业务异常的父类）
@Getter
public class BusinessException extends RuntimeException {
    private final int code;
    private final String message;

    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }

    public BusinessException(ResultCode resultCode) {
        super(resultCode.getMessage());
        this.code = resultCode.getCode();
        this.message = resultCode.getMessage();
    }

    public BusinessException(ResultCode resultCode, String detail) {
        super(resultCode.getMessage() + "：" + detail);
        this.code = resultCode.getCode();
        this.message = resultCode.getMessage() + "：" + detail;
    }
}

// 资源不存在异常
@Getter
public class ResourceNotFoundException extends BusinessException {
    private final String resourceType;
    private final Object resourceId;

    public ResourceNotFoundException(String resourceType, Object resourceId) {
        super(ResultCode.NOT_FOUND, resourceType + "不存在，id=" + resourceId);
        this.resourceType = resourceType;
        this.resourceId = resourceId;
    }
}

// 使用示例
throw new ResourceNotFoundException("供应商", supplierId);
throw new BusinessException(ResultCode.BAD_REQUEST, "订单状态不允许此操作");
```

## 全局异常处理器

```java
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 业务异常
     */
    @ExceptionHandler(BusinessException.class)
    public Result<Void> handleBusinessException(BusinessException e) {
        log.warn("业务异常: code={}, message={}", e.getCode(), e.getMessage());
        return Result.fail(e.getCode(), e.getMessage());
    }

    /**
     * 参数校验异常
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<Void> handleValidationException(MethodArgumentNotValidException e) {
        String message = e.getBindingResult().getFieldErrors().stream()
            .map(FieldError::getDefaultMessage)
            .collect(Collectors.joining("; "));
        log.warn("参数校验失败: {}", message);
        return Result.fail(ResultCode.BAD_REQUEST.getCode(), message);
    }

    /**
     * Feign调用异常
     */
    @ExceptionHandler(FeignException.class)
    public Result<Void> handleFeignException(FeignException e) {
        log.error("Feign调用失败: method={}, url={}, message={}",
            e.method(), e.url(), e.getMessage(), e);
        return Result.fail(ResultCode.INTERNAL_ERROR.getCode(), "远程服务调用失败");
    }

    /**
     * 未知异常（不允许向上抛出RuntimeException）
     */
    @ExceptionHandler(Exception.class)
    public Result<Void> handleException(Exception e) {
        log.error("未知异常", e);
        return Result.fail(ResultCode.INTERNAL_ERROR);
    }
}
```

## Feign调用错误处理

```java
// ✅ 正确：显式处理Feign异常
@Slf4j
@Service
@RequiredArgsConstructor
public class DataEvaluationServiceImpl implements DataEvaluationService {

    private final OrderFeignClient orderFeignClient;

    @Override
    public DeliveryStatsVO getDeliveryStats(Long supplierId, String period) {
        try {
            return orderFeignClient.getDeliveryStats(supplierId, period, period);
        } catch (FeignException.NotFound e) {
            log.warn("订单服务未找到对应数据，supplierId={}", supplierId);
            return DeliveryStatsVO.empty();
        } catch (FeignException e) {
            log.error("调用订单服务失败", e);
            throw new BusinessException(ResultCode.INTERNAL_ERROR, "获取交货统计数据失败");
        }
    }
}
```

## 禁止的错误模式

❌ **空catch块**：
```java
try {
    sendNotification(id);
} catch (Exception e) {
    // 空catch — 错误被静默吞掉
}
```

✅ **正确做法**：
```java
try {
    sendNotification(id);
} catch (Exception e) {
    log.error("发送通知失败，orderId={}", id, e);
    // 决定：降级继续（不影响主流程）还是向上抛出
}
```

## 错误处理策略

| 错误类型 | 处理方式 |
|----------|---------|
| 参数校验失败 | 返回 Result.fail(400, message) |
| 资源不存在 | 抛出 ResourceNotFoundException → 全局处理返回 404 |
| 业务规则冲突 | 抛出 BusinessException(ResultCode.BAD_REQUEST) → 返回 400 |
| 无权限 | 抛出 BusinessException(ResultCode.FORBIDDEN) → 返回 403 |
| 服务间调用失败 | Feign降级 → 记录日志 → 返回降级数据或抛出业务异常 |
| 未知异常 | 记录完整堆栈 → 返回通用错误信息（不暴露内部细节） |

## 提交前检查清单

- [ ] 新抛出的异常使用了自定义异常类，不是裸 `RuntimeException`
- [ ] 错误信息包含模块名、操作名、原因
- [ ] 每个 Feign 调用都有错误处理（try-catch）
- [ ] 没有空的 catch 块
- [ ] 全局异常处理器已处理所有异常类型
- [ ] 面向用户的错误信息不包含内部细节（堆栈、SQL、文件路径）
