---
name: zero-hardcoding
description: 所有可变值必须来自配置或常量，禁止魔术数字和魔术字符串。写任何新代码时加载。
metadata:
  priority: L2
  category: principles
  depends: naming
---

# 零硬编码（Zero Hardcoding）

## 规则

- **所有可变值必须来自配置文件、环境变量或命名常量**，组件/函数内部不允许出现裸数字或裸字符串
- **如果一个值在两个以上地方出现，必须提取为常量或配置项**
- **所有配置通过统一的配置读取接口获取**，不直接硬编码路径
- **唯一例外**：构建工具的本地配置（如本地开发端口号）、测试中的断言值

## Java常量定义位置

| 常量类型 | 定义位置 | 示例 |
|----------|---------|------|
| 全局业务常量 | `common-core/constant/` | `OrderConstant`, `SupplierConstant` |
| HTTP状态码 | `common-core/enums/ResultCode` | `ResultCode.SUCCESS` |
| 枚举值 | `service-xxx/enums/` | `OrderStatus`, `SupplierStatus` |
| 服务端口 | `resources/application.yml` | `server.port: 8081` |
| Nacos配置 | Nacos配置中心 | `spring.cloud.nacos.config.*` |

## 示例

✅ 正确：

```java
// 常量定义在统一位置
public final class OrderConstant {
    private OrderConstant() {}

    public static final String ORDER_NO_PREFIX = "PO";
    public static final int MAX_ITEM_COUNT = 100;
    public static final BigDecimal MAX_ORDER_AMOUNT = new BigDecimal("999999999.99");
}

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderMapper orderMapper;

    @Override
    public void createOrder(CreateOrderDTO dto) {
        if (dto.getItems().size() > OrderConstant.MAX_ITEM_COUNT) {
            throw new OrderItemCountExceededException(OrderConstant.MAX_ITEM_COUNT);
        }
        // ...
    }
}
```

❌ 错误：

```java
// 魔术数字：3是什么？为什么是3？改的时候能找到所有3吗？
for (int i = 0; i < 3; i++) { /* retry */ }

// 魔术字符串
if ("PENDING".equals(order.getStatus())) {}

// 硬编码URL
private static final String NACOS_URL = "http://localhost:8848";

// 硬编码端口
private static final int PORT = 8083;
```

## Spring配置读取

```java
// 使用 @ConfigurationProperties 绑定配置类
@Data
@Component
@ConfigurationProperties(prefix = "app.order")
public class OrderProperties {
    private int maxItemCount = 100;
    private BigDecimal maxAmount = new BigDecimal("999999999.99");
}

// 使用 @Value 注入简单值
@Value("${app.order.order-no-prefix:PO}")
private String orderNoPrefix;
```

## 判断标准

遇到一个值时问自己：
1. "这个值将来可能变吗？" → 是 → 提取为配置
2. "这个值在别处也用了吗？" → 是 → 提取为常量
3. "看到这个值能立刻理解含义吗？" → 否 → 用命名常量替代

## 提交前检查清单

- [ ] 代码中没有裸数字（除 0、1、-1 用于索引/条件判断）
- [ ] 代码中没有裸字符串（除日志消息和错误消息）
- [ ] URL、端口号、金额限制、状态值等全部来自配置或常量
- [ ] 同一个值没有在多个文件中重复出现
- [ ] 新增的配置项已同步到 `application.yml` 和 Nacos 配置中心
