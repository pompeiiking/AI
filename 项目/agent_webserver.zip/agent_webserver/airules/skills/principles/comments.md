---
name: comments
description: 注释最小化原则，只注释"为什么"不注释"做什么"，禁止注释掉的代码。添加注释或文档时加载。
metadata:
  priority: L3
  category: principles
---

# 注释与文档最小化

## 规则

- **代码应该是自解释的** — 好的命名胜过注释
- 只在以下场景添加注释：
  1. **"为什么"而非"做什么"** — 解释设计决策，不解释代码逻辑
  2. **非直觉的性能优化** — 说明为什么选择了看起来不直觉的写法
  3. **公共API的参数和返回值说明** — Javadoc（Java）、JSDoc（前端）
  4. **TODO标记** — 格式：`// TODO(日期): 具体内容`
- **禁止注释掉的代码** — 直接删除，git有历史记录
- **禁止与代码不一致的注释** — 比不注释更糟糕

## 示例

✅ 正确：

```java
// 使用ThreadLocal而非参数传递，因为需要在深层调用中访问用户上下文
// 且每个线程独立，不需要考虑并发安全问题
private static final ThreadLocal<UserContext> USER_CONTEXT = new ThreadLocal<>();

/**
 * 计算供应商综合评分
 * @param supplierId 供应商ID
 * @param period 评估周期，格式：YYYY-MM
 * @return 五维度评分和综合评分
 */
EvaluationResultVO calculateScore(Long supplierId, String period);
```

❌ 错误：

```java
// 获取供应商列表（废话注释，代码本身已说明）
List<Supplier> list = supplierMapper.selectList(wrapper);

// i++（逐行注释，说明代码不够清晰）
i++;

// public void createOrder() {  ← 注释掉的代码，应直接删除
//     orderService.create(dto);
// }

private String name;  // 供应商名称（字段名已说明）
```

## 类/接口Javadoc规范

```java
/**
 * 供应商评估计算服务
 * 职责：聚合order-service和supplier-service数据，计算五维度评分
 *
 * <p>五维度权重：准时交付率25%、质量合格率30%、价格竞争力25%、
 *               服务响应10%、整改配合10%
 */
public interface EvaluationService {
    // 方法Javadoc
    /**
     * 计算指定供应商指定周期的综合评分
     * @param supplierId 供应商ID（非空）
     * @param period 评估周期，格式YYYY-MM或YYYY-Qn（非空）
     * @return 综合评分VO，包含五维度分项和总分
     * @throws ResourceNotFoundException 当供应商不存在时
     */
    EvaluationResultVO calculateScore(Long supplierId, String period);
}
```

## 提交前检查清单

- [ ] 新增注释解释的是"为什么"而非"做什么"
- [ ] 没有注释掉的代码残留
- [ ] 现有注释与修改后的代码仍然一致
- [ ] 公共API（Controller/Service接口）有Javadoc
- [ ] 复杂业务逻辑有"为什么"的解释（而非逐行说明）
