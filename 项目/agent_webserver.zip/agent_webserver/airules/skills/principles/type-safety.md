---
name: type-safety
description: 强类型严格模式的具体规则，禁用any和类型逃生舱，所有公共函数必须有返回类型。写类型声明或遇到类型问题时加载。
metadata:
  priority: L1
  category: principles
---

# 强类型严格模式

## Java规则

- **不用类型系统的"逃生舱"来绕过编译/检查**
- **所有公共方法必须有明确的参数类型和返回类型声明**
- **类型定义集中管理** — 不在多个文件中重复定义相同类型
- **禁止 `@SuppressWarnings("unchecked")`**（除非有充分理由并注释说明）
- **禁止直接返回实体对象给前端** — 必须通过 VO 转换

## VO/DTO强制转换规则

```java
// ❌ 错误：直接将Entity暴露给前端
@GetMapping("/{id}")
public Supplier getById(@PathVariable Long id) {
    return supplierMapper.selectById(id);
}

// ✅ 正确：通过VO转换，只暴露必要字段
@GetMapping("/{id}")
public Result<SupplierVO> getById(@PathVariable Long id) {
    SupplierVO vo = supplierService.getById(id);
    return Result.success(vo);
}
```

## DTO校验

```java
// 所有请求DTO必须添加校验注解
@Data
public class CreateOrderDTO {
    @NotNull(message = "供应商ID不能为空")
    private Long supplierId;

    @NotBlank(message = "订单编号不能为空")
    @Size(max = 50)
    private String orderNo;

    @NotEmpty(message = "订单明细不能为空")
    private List<OrderItemDTO> items;

    @Future(message = "需求日期必须是将来的时间")
    private LocalDate requiredDate;
}

// Controller方法参数必须加 @Valid
@PostMapping
public Result<Void> create(@Valid @RequestBody CreateOrderDTO dto) {
    // ...
}
```

## MyBatis-Plus QueryWrapper

```java
// ✅ 正确：显式指定字段类型
LambdaQueryWrapper<Supplier> wrapper = new LambdaQueryWrapper<>();
wrapper.eq(Supplier::getStatus, 1);
wrapper.like(Supplier::getSupplierName, keyword);
wrapper.orderByDesc(Supplier::getCreatedAt);

// ❌ 错误：字符串拼接SQL
wrapper.eq("status", 1);  // 没有类型安全
```

## 泛型使用

```java
// ✅ 正确：明确泛型参数
public Result<List<SupplierVO>> listSuppliers() {
    return Result.success(supplierService.list());
}

// ✅ 正确：通配符有上界
public void processList(List<? extends SupplierBase> suppliers) {}

// ❌ 错误：裸泛型
public List findAll() {}  // 应该返回具体类型
```

## 前端规则（TypeScript）

- `strict: true` 必须开启
- **禁止 `any`** — 用 `unknown` + 类型守卫，或定义具体类型
- **禁止 `@ts-ignore`**
- 优先使用 `interface` 定义对象形状，`type` 用于联合类型和工具类型
- 所有 props 必须定义类型
- API 响应必须定义接口

```typescript
// ✅ 正确
interface SupplierVO {
  supplierId: number;
  supplierName: string;
  status: 'active' | 'inactive';
}

interface ApiResponse<T> {
  code: number;
  message: string;
  data: T;
}

// ❌ 错误
const data: any = response.data;
const result = response as any;
```

## 提交前检查清单

- [ ] 所有公共方法都有参数类型和返回类型声明
- [ ] DTO类有完整的校验注解（@NotNull, @NotBlank, @Size等）
- [ ] Controller方法参数有 `@Valid` 注解
- [ ] Entity不直接返回前端，必须通过VO转换
- [ ] 没有使用 `@SuppressWarnings` 绕过类型检查
- [ ] 前端API响应定义了明确的TypeScript接口
- [ ] 没有 `any` / `@ts-ignore` / `as any` 类型逃逸
