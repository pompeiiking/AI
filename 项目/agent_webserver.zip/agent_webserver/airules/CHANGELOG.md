# 变更日志

> 本文件为纯时间线追加日志。每次变更后追加记录，不修改历史。
> 格式规范详见 `rules/skills/workflow/changelog.md`

---

### 2026-04-01 16:00 — AI:Cursor

**任务**: 初始化项目规范，从通用模板转化为华北油田物资管理系统专属规范；搭建Maven项目骨架

**变更文件**:

- `rules/RULES.md` — 模板→项目专属，更新TEMPLATE_STATUS为INITIALIZED，锁定技术栈（Spring Cloud 2023.x + Vue 3 + MySQL 8.0 + Redis 7.x），更新Skill索引、文档体系、AI接入协议
- `rules/skills/principles/zero-hardcoding.md` — 填充Java常量定义位置（common-core/constant/、application.yml、Nacos）
- `rules/skills/principles/naming.md` — 填充Java/前端/数据库命名规则，建立项目术语统一表（Supplier/Order/Delivery/Evaluation/Trace/Dashboard）
- `rules/skills/principles/type-safety.md` — 填充Java强类型规则（VO/DTO强制转换、校验注解、MyBatis-Plus LambdaQueryWrapper）
- `rules/skills/principles/error-handling.md` — 填充自定义异常体系（BusinessException、ResourceNotFoundException、全局异常处理器、Feign错误处理）
- `rules/skills/principles/stub-management.md` — 填充本项目常见STUB场景（前端模拟数据、第三方服务、Feign未就绪等）
- `rules/skills/principles/layering.md` — 填充本项目分层结构（Controller→Service→Repository→VO/DTO），禁止跨服务直接依赖Mapper
- `rules/skills/principles/module-boundary.md` — 填充Feign接口规范、DTO/VO包结构、禁止直接引用其他服务内部类
- `rules/skills/principles/comments.md` — 填充Java Javadoc规范、类注释示例
- `rules/skills/principles/abstraction.md` — 填充本项目合理抽象示例（FeignClient、Result、BaseEntity）
- `rules/skills/principles/data-separation.md` — 填充数据文件存放规则（禁止源码目录存放业务数据）
- `rules/skills/principles/performance.md` — 填充数据库性能禁忌（N+1查询、循环内SQL）、缓存策略、分页规范
- `rules/skills/workflow/anti-paranoid.md` — 填充本项目bug修复示例（五维度评分null兜底）
- `rules/skills/workflow/collaboration.md` — 填充技术栈清单（Spring Boot 3.2.x等）、Maven/npm依赖管理规则
- `rules/skills/workflow/changelog.md` — 填充本项目CHANGELOG示例
- `rules/skills/workflow/status-management.md` — 填充本项目STATUS.md模板和示例
- `rules/skills/workflow/git-commit.md` — 填充scope范围定义（common-core/auth/supplier/order/data/frontend/db/config）
- `rules/skills/workflow/interface-contract.md` — 填充本项目核心契约清单（data-order, data-supplier, gateway-auth）
- `rules/skills/workflow/session-handoff.md` — 更新文件路径为 rules/ 目录
- `rules/skills/workflow/interface-change.md` — 填充本项目接口变更场景（Feign接口向后兼容、VO字段变更）
- `rules/skills/workflow/security.md` — 填充JWT凭证、数据库密码、Nacos凭证、SQL注入防护规范
- `rules/skills/workflow/testing.md` — 填充测试文件位置（`src/test/java/`）、JUnit 5模板、必测场景清单
- `rules/skills/project/file-structure.md` — 填充Spring Boot项目目录结构（controller/service/repository/entity/vo/dto/query/enums/constant/exception）、前端Vue 3目录结构、禁止跨服务直接依赖
- `rules/skills/project/code-style.md` — 填充Java文件结构顺序（package→import→类声明→成员→方法）、Controller/Service/Mapper/DTO/VO/枚举/常量写法模板
- `rules/contracts/_index.md` — 创建契约索引，登记6个契约文件
- `rules/contracts/shared-types.contract.md` — 填充统一响应格式Result<T>、ResultCode枚举、共享业务枚举（OrderStatus/SupplierStatus/EvalLevel）、PageResult<T>、日期格式约定
- `rules/contracts/_template.contract.md` — 创建契约模板
- `rules/contracts/data-order.contract.md` — 填充data-service↔order-service契约：DeliveryStatsVO、OrderBaseVO、DeliveryVO，4个Feign接口定义
- `rules/contracts/data-supplier.contract.md` — 填充data-service↔supplier-service契约：SupplierBaseVO、SupplierScoreVO、ResponseLogVO，4个Feign接口定义
- `rules/contracts/gateway-auth.contract.md` — 填充gateway↔auth-service契约：LoginRequest/LoginResponse/UserInfoVO/TokenValidateResponse，4个接口定义及JWT规范
- `rules/STATUS.md` — 新建项目状态快照，记录已完成模块、进行中/待开始任务、架构备忘、下一步建议
- `project-parent/pom.xml` — 创建父POM，锁定Spring Cloud 2023.0.0/Spring Boot 3.2.4/MyBatis-Plus 3.5.6/Element Plus最新版本，定义5个子模块
- `project-parent/project-common/common-core/pom.xml` — common-core模块POM
- `project-parent/project-common/common-feign/pom.xml` — common-feign模块POM
- `project-parent/project-common/common-swagger/pom.xml` — common-swagger模块POM
- `project-parent/project-gateway/pom.xml` — gateway模块POM
- `project-parent/project-service/service-auth/pom.xml` — service-auth模块POM
- `project-parent/project-service/service-supplier/pom.xml` — service-supplier模块POM
- `project-parent/project-service/service-order/pom.xml` — service-order模块POM
- `project-parent/project-service/service-data/pom.xml` — service-data模块POM

**影响范围**: 全局，所有后续开发行为遵循本规范体系

**关联STUB**: 无
