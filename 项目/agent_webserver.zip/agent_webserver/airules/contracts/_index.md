# 接口契约索引

> **本目录由人类（架构师/技术负责人）维护，AI不得擅自新增或修改契约文件。**
> **适用方案：方案B（分布式，三人团队协作）**

## 团队分工对应

| 成员 | 负责模块 | 协作接口 |
|------|----------|----------|
| **成员A** | 前端 + 网关 | gateway → 各服务的 HTTP 接口 |
| **成员B** | 微服务组件 | service-auth/supplier/order/data + common-feign |
| **成员C** | 整体逻辑 + 数据库 | 契约主导、审核、规范维护 |

## 使用说明

1. 每对需要对接的模块创建一个 `[模块A]-[模块B].contract.md` 文件
2. 全局共享类型放在 `shared-types.contract.md`
3. 每次新增契约后，在下方索引表中登记
4. AI开发时根据索引找到相关契约并严格遵守
5. 契约状态为"草案"时，AI应提醒人类确认后再实现

## 契约索引

| 契约文件 | 模块 | 状态 | 负责人 | 最后更新 |
|----------|------|------|--------|---------|
| `shared-types.contract.md` | 全局共享类型 | 草案 | 成员C | 2026-04-01 |
| `gateway-auth.contract.md` | gateway ↔ auth-service | 草案 | 成员C | 2026-04-01 |
| `gateway-supplier.contract.md` | gateway ↔ supplier-service | 草案 | 成员C | 2026-04-01 |
| `gateway-order.contract.md` | gateway ↔ order-service | 草案 | 成员C | 2026-04-01 |
| `gateway-data.contract.md` | gateway ↔ data-service | 草案 | 成员C | 2026-04-01 |
| `data-order.contract.md` | data-service ↔ order-service | 草案 | 成员C | 2026-04-01 |
| `data-supplier.contract.md` | data-service ↔ supplier-service | 草案 | 成员C | 2026-04-01 |
<!-- 新增契约在此行上方添加 -->

## 接口汇总表

### Gateway → 后端服务（HTTP/REST）

| 前端接口 | 网关路由 | 后端服务 | 后端路径 | 说明 |
|----------|----------|----------|----------|------|
| `POST /api/auth/login` | `/api/auth/**` | auth-service | `/auth/login` | 用户登录 |
| `POST /auth/logout` | `/api/auth/**` | auth-service | `/auth/logout` | 用户登出 |
| `POST /api/auth/refresh` | `/api/auth/**` | auth-service | `/auth/refresh` | 刷新Token |
| `GET /api/auth/userinfo` | `/api/auth/**` | auth-service | `/auth/userinfo` | 获取用户信息 |
| `GET /api/suppliers` | `/api/suppliers/**` | supplier-service | `/suppliers` | 供应商列表 |
| `GET /api/suppliers/{id}` | `/api/suppliers/**` | supplier-service | `/suppliers/{id}` | 供应商详情 |
| `POST /api/suppliers` | `/api/suppliers/**` | supplier-service | `/suppliers` | 新增供应商 |
| `PUT /api/suppliers/{id}` | `/api/suppliers/**` | supplier-service | `/suppliers/{id}` | 更新供应商 |
| `DELETE /api/suppliers/{id}` | `/api/suppliers/**` | supplier-service | `/suppliers/{id}` | 删除供应商 |
| `GET /api/suppliers/{id}/score` | `/api/suppliers/**` | supplier-service | `/suppliers/{id}/score` | 供应商评分 |
| `GET /api/suppliers/ranking` | `/api/suppliers/**` | supplier-service | `/suppliers/ranking` | 供应商排名 |
| `GET /api/orders` | `/api/orders/**` | order-service | `/orders` | 订单列表 |
| `GET /api/orders/{id}` | `/api/orders/**` | order-service | `/orders/{id}` | 订单详情 |
| `POST /api/orders` | `/api/orders/**` | order-service | `/orders` | 创建订单 |
| `PUT /api/orders/{id}` | `/api/orders/**` | order-service | `/orders/{id}` | 更新订单 |
| `PUT /api/orders/{id}/status` | `/api/orders/**` | order-service | `/orders/{id}/status` | 更新订单状态 |
| `POST /api/orders/{id}/deliveries` | `/api/orders/**` | order-service | `/orders/{id}/deliveries` | 添加交货记录 |
| `GET /api/orders/{id}/deliveries` | `/api/orders/**` | order-service | `/orders/{id}/deliveries` | 交货记录列表 |
| `GET /api/orders/delivery-stats` | `/api/orders/**` | order-service | `/orders/delivery-stats` | 交货统计 |
| `GET /api/dashboard` | `/api/dashboard/**` | data-service | `/dashboard` | 仪表盘 |
| `GET /api/statistics/purchase` | `/api/data/**` | data-service | `/statistics/purchase` | 采购统计 |
| `GET /api/statistics/quality` | `/api/data/**` | data-service | `/statistics/quality` | 质量统计 |
| `GET /api/evaluate/supplier/{id}` | `/api/data/**` | data-service | `/evaluate/supplier/{id}` | 供应商评估 |
| `GET /api/evaluate/ranking` | `/api/data/**` | data-service | `/evaluate/ranking` | 供应商排名 |
| `GET /api/evaluate/trend` | `/api/data/**` | data-service | `/evaluate/trend` | 月度趋势 |
| `GET /api/trace/material` | `/api/data/**` | data-service | `/trace/material` | 单品溯源 |
| `GET /api/trace/batch/{batchNo}` | `/api/data/**` | data-service | `/trace/batch/{batchNo}` | 批次溯源 |

### 服务间调用（Feign）

| 调用方 | 提供方 | 接口路径 | 说明 |
|--------|--------|----------|------|
| data-service | order-service | `/orders` | 查询订单列表 |
| data-service | order-service | `/orders/{id}` | 订单详情 |
| data-service | order-service | `/orders/delivery-stats` | 交货统计 |
| data-service | order-service | `/orders/{id}/deliveries` | 交货记录 |
| data-service | supplier-service | `/suppliers/{id}` | 供应商详情 |
| data-service | supplier-service | `/suppliers/{id}/score` | 供应商评分 |
| data-service | supplier-service | `/suppliers/{id}/response-log` | 服务响应记录 |
| order-service | supplier-service | `/suppliers/{id}/response-log` | 记录服务响应 |

## 状态说明

| 状态 | 含义 |
|------|------|
| 草案 | 初步定义，尚未确认，AI遇到时应提醒人类确认 |
| 已确认 | 人类确认，可以按此实现 |
| 已实现 | 双方已按契约完成代码实现 |
| 已弃用 | 不再使用，保留做历史参考 |

## 契约开发检查清单

### 开发前
- [ ] 阅读与己方模块相关的所有契约文档
- [ ] 确认自己是接口的"调用方"还是"提供方"
- [ ] 如果契约状态是"草案" → 提醒人类确认后再实现

### 开发中
- [ ] 严格按契约定义的类型、参数、返回值实现
- [ ] 发现契约有问题时，标记 `CONTRACT-ISSUE` 并报告

### 开发后
- [ ] 实现完成后更新契约状态：`草案` → `已确认` → `已实现`
- [ ] 在 CHANGELOG 中标注实现的接口
