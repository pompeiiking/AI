# gateway ↔ supplier-service 接口契约

> **状态**: 草案
> **负责人**: 成员C
> **最后更新**: 2026-04-01
> **实现方**: gateway侧=成员A, supplier侧=成员B

## 共享类型

```java
// 供应商基础信息
@Data
public class SupplierBaseVO implements Serializable {
    private Long supplierId;
    private String supplierCode;      // 供应商编码
    private String supplierName;      // 供应商名称
    private String categoryName;      // 分类名称
    private String status;           // 状态：ACTIVE/INACTIVE/PENDING/BLACKLIST
    private String statusDesc;       // 状态描述
    private String legalPerson;      // 法定代表人
    private String creditCode;       // 统一社会信用代码
    private LocalDateTime createdAt;  // 创建时间
}

// 供应商详情
@Data
public class SupplierDetailVO implements Serializable {
    private Long supplierId;
    private String supplierCode;
    private String supplierName;
    private String categoryId;
    private String categoryName;
    private String legalPerson;
    private BigDecimal regCapital;   // 注册资本
    private String businessScope;    // 经营范围
    private String creditCode;
    private String status;
    private LocalDate registeredDate;
    private LocalDate contractStart;
    private LocalDate contractEnd;
    private List<SupplierContactVO> contacts;  // 联系人列表
}

// 供应商联系人
@Data
public class SupplierContactVO implements Serializable {
    private Long contactId;
    private String contactName;
    private String position;          // 职位
    private String phone;
    private String email;
    private Boolean isPrimary;        // 是否主要联系人
}

// 供应商列表查询参数
@Data
public class SupplierQueryDTO implements Serializable {
    private String keyword;          // 搜索关键词（名称/编码）
    private String categoryId;       // 分类ID
    private String status;           // 状态筛选
    private Integer pageNum = 1;     // 页码
    private Integer pageSize = 10;   // 每页条数
}

// 供应商列表响应
@Data
public class SupplierListVO implements Serializable {
    private List<SupplierBaseVO> records;
    private long total;
    private long current;
    private long size;
}

// 供应商评分信息
@Data
public class SupplierScoreVO implements Serializable {
    private Long supplierId;
    private String supplierName;
    private BigDecimal totalScore;       // 综合评分(0-100)
    private BigDecimal onTimeRate;       // 准时交付率
    private BigDecimal qualityScore;     // 质量合格率
    private BigDecimal priceScore;       // 价格竞争力
    private BigDecimal responseScore;    // 服务响应
    private BigDecimal reformScore;       // 整改配合
    private String evalLevel;            // EXCELLENT/GOOD/AVERAGE/POOR
    private String period;               // 评估周期 2026-03
    private LocalDateTime calcDate;
}

// 服务响应记录
@Data
public class ResponseLogVO implements Serializable {
    private Long logId;
    private Long supplierId;
    private Long orderId;
    private String responseType;         // QUOTE/ORDER_CONFIRM/SAMPLE/DELIVERY
    private int responseTimeHours;       // 响应时间(小时)
    private String cooperationLevel;     // GOOD/NORMAL/POOR
    private String remark;
    private LocalDateTime createdAt;
}

// 供应商排名
@Data
public class SupplierRankVO implements Serializable {
    private Long supplierId;
    private String supplierName;
    private int rankPosition;            // 排名
    private int totalSuppliers;          // 参评供应商总数
    private int rankChange;              // 排名变化（正数上升）
    private String evalLevel;            // 评级
    private BigDecimal totalScore;       // 综合评分
}
```

## 函数接口

### 查询供应商列表

- **调用方**: gateway（API网关透传）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @GetMapping("/suppliers")
  Result<SupplierListVO> listSuppliers(@RequestParam(required = false) String keyword,
                                       @RequestParam(required = false) String categoryId,
                                       @RequestParam(required = false) String status,
                                       @RequestParam(defaultValue = "1") Integer pageNum,
                                       @RequestParam(defaultValue = "10") Integer pageSize);
  ```
- **前端接口**: `GET /api/suppliers?keyword=xxx&status=ACTIVE&pageNum=1&pageSize=10`
- **前置条件**: pageNum >= 1, pageSize > 0
- **后置条件**: 返回符合条件的供应商分页列表
- **错误处理**: 参数校验失败返回400

### 获取供应商详情

- **调用方**: gateway（API网关透传）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @GetMapping("/suppliers/{id}")
  Result<SupplierDetailVO> getSupplierById(@PathVariable("id") Long id);
  ```
- **前端接口**: `GET /api/suppliers/{id}`
- **前置条件**: id非空且为有效供应商ID
- **后置条件**: 返回供应商完整信息（含联系人）
- **错误处理**: 供应商不存在返回404

### 新增供应商

- **调用方**: gateway（API网关透传）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @PostMapping("/suppliers")
  Result<Long> createSupplier(@RequestBody @Valid SupplierCreateDTO dto);
  ```
- **前端接口**: `POST /api/suppliers`
- **前置条件**: dto.supplierName非空，dto.supplierCode唯一
- **后置条件**: 返回新创建的供应商ID
- **错误处理**: 编码重复返回409，参数校验失败返回400

### 更新供应商

- **调用方**: gateway（API网关透传）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @PutMapping("/suppliers/{id}")
  Result<Void> updateSupplier(@PathVariable("id") Long id,
                               @RequestBody @Valid SupplierUpdateDTO dto);
  ```
- **前端接口**: `PUT /api/suppliers/{id}`
- **前置条件**: id非空，供应商存在
- **后置条件**: 更新供应商信息
- **错误处理**: 供应商不存在返回404

### 删除供应商

- **调用方**: gateway（API网关透传）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @DeleteMapping("/suppliers/{id}")
  Result<Void> deleteSupplier(@PathVariable("id") Long id);
  ```
- **前端接口**: `DELETE /api/suppliers/{id}`
- **前置条件**: id非空，供应商存在且无关联订单
- **后置条件**: 删除供应商（软删除）
- **错误处理**: 供应商不存在返回404，有关联订单返回409

### 获取供应商评分

- **调用方**: gateway（API网关透传）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @GetMapping("/suppliers/{id}/score")
  Result<SupplierScoreVO> getSupplierScore(@PathVariable("id") Long supplierId,
                                          @RequestParam(required = false) String period);
  ```
- **前端接口**: `GET /api/suppliers/{id}/score?period=2026-03`
- **前置条件**: supplierId非空
- **后置条件**: 返回供应商评分信息（不传period则返回最新）
- **错误处理**: 无评分记录返回totalScore=0的默认对象

### 获取供应商排名

- **调用方**: gateway（API网关透传）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @GetMapping("/suppliers/ranking")
  Result<List<SupplierRankVO>> getSupplierRanking(@RequestParam(required = false) String period);
  ```
- **前端接口**: `GET /api/suppliers/ranking?period=2026-Q1`
- **前置条件**: period可选
- **后置条件**: 返回供应商排名列表（按评分降序）
- **错误处理**: 无数据返回空列表

### 记录服务响应日志

- **调用方**: gateway（API网关透传）/ order-service
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @PostMapping("/suppliers/{id}/response-log")
  Result<Void> recordResponseLog(@PathVariable("id") Long supplierId,
                                  @RequestBody @Valid ResponseLogDTO dto);
  ```
- **前端接口**: `POST /api/suppliers/{id}/response-log`
- **前置条件**: supplierId非空，dto.responseType非空，dto.responseTimeHours > 0
- **后置条件**: 创建服务响应记录
- **错误处理**: 参数校验失败返回400，供应商不存在返回404

### 查询服务响应记录

- **调用方**: gateway（API网关透传）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @GetMapping("/suppliers/{id}/response-log")
  Result<List<ResponseLogVO>> getResponseLogs(@PathVariable("id") Long supplierId,
                                               @RequestParam String period);
  ```
- **前端接口**: `GET /api/suppliers/{id}/response-log?period=2026-03`
- **前置条件**: supplierId非空，period格式为yyyy-MM
- **后置条件**: 返回指定周期内的服务响应记录列表
- **错误处理**: 无记录返回空列表

## 约束与边界

- **性能约束**：列表查询响应时间 < 300ms（带分页）
- **分页约束**：单次查询最大返回100条记录
- **日期格式**：period参数统一使用 `yyyy-MM` 或 `yyyy-Qn` 格式
- **状态枚举**：ACTIVE/INACTIVE/PENDING/BLACKLIST
- **服务响应类型枚举**：QUOTE（报价）/ ORDER_CONFIRM（订单确认）/ SAMPLE（样品）/ DELIVERY（交货）
- **合作等级枚举**：GOOD/NORMAL/POOR
