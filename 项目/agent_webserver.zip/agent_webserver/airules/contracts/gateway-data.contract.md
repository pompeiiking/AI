# gateway ↔ data-service 接口契约

> **状态**: 草案
> **负责人**: 成员C
> **最后更新**: 2026-04-01
> **实现方**: gateway侧=成员A, data侧=成员B

## 共享类型

```java
// 仪表盘数据
@Data
public class DashboardVO implements Serializable {
    private PurchaseStatsVO purchase;     // 采购统计
    private QualityStatsVO quality;       // 质量统计
    private List<AlertVO> alerts;         // 风险预警
    private List<TraceRecordVO> recentTraces;  // 近期溯源记录
    private BigDecimal totalPurchaseAmount;     // 总采购金额
    private BigDecimal onTimeRate;              // 准时交付率
    private BigDecimal qualityRate;             // 质量合格率
}

// 采购统计
@Data
public class PurchaseStatsVO implements Serializable {
    private int totalOrders;             // 总订单数
    private BigDecimal totalAmount;      // 总金额
    private BigDecimal avgAmount;        // 平均订单金额
    private int activeSuppliers;        // 活跃供应商数
    private String period;               // 统计周期
}

// 质量统计
@Data
public class QualityStatsVO implements Serializable {
    private int totalInspects;          // 总检验次数
    private int qualifiedInspects;     // 合格次数
    private BigDecimal qualifyRate;      // 合格率
    private String period;
}

// 风险预警
@Data
public class AlertVO implements Serializable {
    private Long alertId;
    private String alertType;           // DELIVERY_DELAY/QUALITY_ISSUE/CONTRACT_EXPIRE
    private String alertLevel;          // HIGH/MEDIUM/LOW
    private String title;
    private String description;
    private Long relatedId;              // 关联ID（订单/供应商）
    private String relatedType;          // ORDER/SUPPLIER
    private LocalDateTime createdAt;
}

// 溯源记录
@Data
public class TraceRecordVO implements Serializable {
    private Long traceId;
    private String materialCode;
    private String materialName;
    private String spec;
    private String supplierName;
    private String orderNo;
    private String status;
    private LocalDateTime createdAt;
}

// 供应评估详情
@Data
public class SupplierEvaluationVO implements Serializable {
    private Long supplierId;
    private String supplierName;
    private String period;               // 评估周期

    // 五维度得分
    private BigDecimal onTimeRate;       // 准时交付率(%)
    private BigDecimal qualityScore;     // 质量合格率(%)
    private BigDecimal priceScore;       // 价格竞争力(%)
    private BigDecimal responseScore;    // 服务响应得分(%)
    private BigDecimal reformScore;      // 整改配合得分(%)

    // 综合得分
    private BigDecimal totalScore;       // 综合得分(0-100)
    private String evalLevel;           // EXCELLENT/GOOD/AVERAGE/POOR

    // 排名
    private Integer rankPosition;        // 排名
    private Integer totalSuppliers;     // 参评供应商总数
    private Integer rankChange;         // 排名变化

    // 明细数据
    private int totalOrders;
    private int onTimeOrders;
    private int totalInspects;
    private int qualifiedInspects;
    private BigDecimal avgPrice;
    private BigDecimal marketPrice;
    private int avgResponseTime;
    private int totalIssues;
    private int resolvedIssues;

    // AI分析
    private String aiSuggestion;         // AI改进建议

    // 环比变化
    private BigDecimal onTimeChange;
    private BigDecimal qualityChange;

    private LocalDateTime calculatedAt;
}

// 供应商排名
@Data
public class EvaluationRankingVO implements Serializable {
    private int rankPosition;
    private Long supplierId;
    private String supplierName;
    private BigDecimal totalScore;
    private String evalLevel;
    private Integer rankChange;
    private BigDecimal onTimeRate;
    private BigDecimal qualityScore;
    private BigDecimal priceScore;
}

// 月度趋势
@Data
public class MonthlyTrendVO implements Serializable {
    private String statMonth;           // 2026-03
    private int totalOrders;
    private BigDecimal totalAmount;
    private BigDecimal onTimeRate;
    private BigDecimal qualityScore;
    private BigDecimal priceScore;
    private BigDecimal responseScore;
    private BigDecimal reformScore;
    private BigDecimal totalScore;
    private String evalLevel;
    private Integer rankPosition;
}

// 单品溯源详情
@Data
public class MaterialTraceVO implements Serializable {
    private Long traceId;
    private String materialCode;
    private String materialName;
    private String spec;

    // 采购信息
    private Long orderId;
    private String orderNo;
    private Long supplierId;
    private String supplierName;
    private LocalDate orderDate;
    private LocalDate requiredDate;

    // 发货运输
    private String logisticsNo;
    private String logisticsCompany;
    private LocalDate actualDeliveryDate;

    // 入库信息（预留）
    private String warehouseName;
    private String batchNo;
    private LocalDate stockInDate;
    private BigDecimal stockQty;

    // 当前状态
    private String currentStatus;
    private List<TraceNodeVO> timeline;  // 溯源时间线
}

// 溯源节点
@Data
public class TraceNodeVO implements Serializable {
    private String nodeType;            // ORDER/PRODUCE/SHIP/DELIVER/STOCK/USE
    private String nodeName;
    private String description;
    private LocalDateTime occurredAt;
    private String status;
}

// 批次物资分布
@Data
public class BatchDistributionVO implements Serializable {
    private String batchNo;
    private String materialName;
    private String spec;
    private BigDecimal totalQuantity;
    private BigDecimal stockQuantity;
    private List<BatchLocationVO> locations;  // 批次物资分布位置
}

// 批次物资位置
@Data
public class BatchLocationVO implements Serializable {
    private String warehouseName;
    private String locationCode;
    private BigDecimal quantity;
}

// 采购统计响应
@Data
public class PurchaseSummaryVO implements Serializable {
    private String statType;            // MONTH/QUARTER/YEAR
    private String statPeriod;          // 2026-03/2026-Q1/2026
    private int totalOrders;
    private BigDecimal totalAmount;
    private BigDecimal avgAmount;
    private BigDecimal onTimeRate;
    private BigDecimal qualityRate;
    private int supplierCount;
}
```

## 函数接口

### 获取仪表盘数据

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/dashboard")
  Result<DashboardVO> getDashboard();
  ```
- **前端接口**: `GET /api/dashboard`
- **前置条件**: 用户已登录
- **后置条件**: 返回仪表盘聚合数据（采购统计、质量统计、预警、溯源记录）
- **错误处理**: 无数据返回空对象

### 获取采购统计

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/statistics/purchase")
  Result<PurchaseSummaryVO> getPurchaseStatistics(@RequestParam(required = false) String period);
  ```
- **前端接口**: `GET /api/statistics/purchase?period=2026-Q1`
- **前置条件**: period可选，不传则返回当月
- **后置条件**: 返回采购统计汇总数据
- **错误处理**: 无数据返回空对象

### 获取质量统计

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/statistics/quality")
  Result<QualityStatsVO> getQualityStatistics(@RequestParam(required = false) String period);
  ```
- **前端接口**: `GET /api/statistics/quality?period=2026-Q1`
- **前置条件**: period可选
- **后置条件**: 返回质量统计汇总数据
- **错误处理**: 无数据返回空对象

### 获取风险预警列表

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/alerts")
  Result<List<AlertVO>> getAlerts(@RequestParam(required = false) String alertType,
                                   @RequestParam(required = false) String alertLevel,
                                   @RequestParam(required = false) Integer limit);
  ```
- **前端接口**: `GET /api/alerts?alertType=DELIVERY_DELAY&alertLevel=HIGH&limit=10`
- **前置条件**: limit可选，默认10
- **后置条件**: 返回预警列表（按时间倒序）
- **错误处理**: 无数据返回空列表

### 获取供应评估详情

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/evaluate/supplier/{id}")
  Result<SupplierEvaluationVO> getSupplierEvaluation(@PathVariable("id") Long supplierId,
                                                      @RequestParam(required = false) String period);
  ```
- **前端接口**: `GET /api/evaluate/supplier/1?period=2026-Q1`
- **前置条件**: supplierId非空
- **后置条件**: 返回供应商五维度评估详情
- **错误处理**: 无评估记录返回默认对象

### 获取供应商排名

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/evaluate/ranking")
  Result<List<EvaluationRankingVO>> getSupplierRanking(@RequestParam(required = false) String period);
  ```
- **前端接口**: `GET /api/evaluate/ranking?period=2026-Q1`
- **前置条件**: period可选
- **后置条件**: 返回供应商排名列表（按评分降序）
- **错误处理**: 无数据返回空列表

### 获取月度趋势

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/evaluate/trend")
  Result<List<MonthlyTrendVO>> getMonthlyTrend(@RequestParam("supplierId") Long supplierId,
                                                @RequestParam(required = false) Integer months);
  ```
- **前端接口**: `GET /api/evaluate/trend?supplierId=1&months=6`
- **前置条件**: supplierId非空，months默认6
- **后置条件**: 返回供应商月度趋势数据（按月份升序）
- **错误处理**: 无数据返回空列表

### 单品溯源查询

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/trace/material")
  Result<MaterialTraceVO> traceMaterial(@RequestParam(required = false) String materialCode,
                                         @RequestParam(required = false) String materialName,
                                         @RequestParam(required = false) String orderNo);
  ```
- **前端接口**: `GET /api/trace/material?materialCode=M001&materialName=钢管`
- **前置条件**: 至少提供一个查询条件
- **后置条件**: 返回单品溯源详情（聚合订单、供应商、交货等信息）
- **错误处理**: 无匹配数据返回404

### 批次溯源查询

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/trace/batch/{batchNo}")
  Result<BatchDistributionVO> traceBatch(@PathVariable("batchNo") String batchNo);
  ```
- **前端接口**: `GET /api/trace/batch/BATCH-20260315-001`
- **前置条件**: batchNo非空
- **后置条件**: 返回批次物资分布详情
- **错误处理**: 批次不存在返回404

### 获取批次物资分布

- **调用方**: gateway（API网关透传）
- **提供方**: data-service（数据分析服务）
- **签名**:
  ```java
  @GetMapping("/batch/distribution")
  Result<List<BatchDistributionVO>> getBatchDistribution(@RequestParam(required = false) String materialCode);
  ```
- **前端接口**: `GET /api/batch/distribution?materialCode=M001`
- **前置条件**: materialCode可选
- **后置条件**: 返回批次物资分布列表
- **错误处理**: 无数据返回空列表

## 约束与边界

- **性能约束**：
  - 仪表盘查询响应时间 < 1s
  - 排名查询响应时间 < 500ms
  - 溯源查询响应时间 < 2s（可能涉及多表查询）
- **日期格式**：
  - 月份：yyyy-MM（2026-03）
  - 季度：yyyy-Qn（2026-Q1）
  - 日期：yyyy-MM-dd
- **评估周期枚举**：yyyy-MM 或 yyyy-Qn
- **预警类型枚举**：DELIVERY_DELAY（交货延迟）/ QUALITY_ISSUE（质量问题）/ CONTRACT_EXPIRE（合同到期）
- **预警级别枚举**：HIGH/MEDIUM/LOW
- **溯源节点类型**：ORDER/PRODUCE/SHIP/DELIVER/STOCK/USE
- **五维度权重**：
  - 准时交付率：25%
  - 质量合格率：30%
  - 价格竞争力：25%
  - 服务响应：10%
  - 整改配合：10%

## 聚合服务说明

```
┌─────────────────────────────────────────────────────────────────┐
│                   data-service 聚合逻辑说明                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   data-service 是本项目的聚合服务层，汇总其他服务数据：           │
│                                                                 │
│   1. 仪表盘 (/dashboard)                                        │
│      - 调用 order-service：获取订单统计                          │
│      - 调用 supplier-service：获取供应商统计                     │
│      - 聚合返回                                                  │
│                                                                 │
│   2. 供应评估 (/evaluate/...)                                   │
│      - 调用 order-service：获取准时交付数据                      │
│      - 调用 supplier-service：获取服务响应数据                    │
│      - 计算五维度得分                                            │
│      - 存储评估结果到 data_db                                    │
│                                                                 │
│   3. 单品溯源 (/trace/...)                                      │
│      - 调用 order-service：获取订单和交货信息                    │
│      - 调用 supplier-service：获取供应商信息                      │
│      - 聚合时间线展示                                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```
