# 全局共享类型契约

> 状态: 草案
> 负责人: [TODO:填充]
> 最后更新: [TODO:填充]

## 说明

本文件定义所有模块都必须使用的公共类型。任何模块在实现时，涉及这些类型的地方必须严格使用此处的定义，不得自行定义同名或类似类型。

## 统一响应格式

```java
// 统一HTTP响应包装（所有Controller必须使用）
@Data
public class Result<T> {
    private int code;       // 状态码，非HTTP状态码，是业务状态码
    private String message; // 消息
    private T data;         // 数据体
    private long timestamp; // 时间戳
    private String traceId; // 链路追踪ID

    public static <T> Result<T> success(T data) {
        Result<T> r = new Result<>();
        r.code = 200;
        r.message = "success";
        r.data = data;
        r.timestamp = System.currentTimeMillis();
        return r;
    }

    public static <T> Result<T> fail(int code, String message) {
        Result<T> r = new Result<>();
        r.code = code;
        r.message = message;
        r.timestamp = System.currentTimeMillis();
        return r;
    }
}
```

## 统一状态码

```java
// ResultCode 枚举（必须统一使用此枚举定义的状态码）
public enum ResultCode {
    SUCCESS(200, "success"),
    BAD_REQUEST(400, "请求参数错误"),
    UNAUTHORIZED(401, "未认证"),
    FORBIDDEN(403, "无权限"),
    NOT_FOUND(404, "资源不存在"),
    INTERNAL_ERROR(500, "服务器内部错误"),
    VALIDATION_ERROR(400, "数据校验失败"),
    TOKEN_INVALID(401, "Token无效或已过期"),
    ACCESS_DENIED(403, "无权限访问该资源");

    private final int code;
    private final String message;

    ResultCode(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
```

## 共享业务枚举

```java
// 订单状态枚举
public enum OrderStatus {
    PENDING("待确认"),
    CONFIRMED("已确认"),
    IN_PRODUCTION("生产中"),
    SHIPPED("已发货"),
    DELIVERED("已到货"),
    COMPLETED("已完成"),
    CANCELLED("已取消");

    private final String desc;
    OrderStatus(String desc) { this.desc = desc; }
}

// 供应商状态枚举
public enum SupplierStatus {
    ACTIVE("正常"),
    INACTIVE("禁用"),
    PENDING("待审核"),
    BLACKLIST("黑名单");

    private final String desc;
    SupplierStatus(String desc) { this.desc = desc; }
}

// 评估等级枚举
public enum EvalLevel {
    EXCELLENT("优秀", 95),  // >=95分
    GOOD("良好", 85),      // 85-94分
    AVERAGE("一般", 70),   // 70-84分
    POOR("较差", 0);       // <70分

    private final String desc;
    private final int threshold;
    EvalLevel(String desc, int threshold) { this.desc = desc; this.threshold = threshold; }
}
```

## 共享分页对象

```java
// 统一分页响应
public class PageResult<T> {
    private List<T> records;   // 数据列表
    private long total;        // 总记录数
    private long current;      // 当前页
    private long size;         // 每页大小

    public static <T> PageResult<T> of(IPage<T> page) {
        PageResult<T> r = new PageResult<>();
        r.records = page.getRecords();
        r.total = page.getTotal();
        r.current = page.getCurrent();
        r.size = page.getSize();
        return r;
    }
}
```

## 日期格式约定

| 场景 | 格式 | 示例 |
|------|------|------|
| 日期 | `yyyy-MM-dd` | `2026-04-01` |
| 时间 | `yyyy-MM-dd HH:mm:ss` | `2026-04-01 10:30:00` |
| 月份 | `yyyy-MM` | `2026-04` |
| 评估周期 | `yyyy-MM` 或 `yyyy-Qn` | `2026-04`, `2026-Q1` |
| 时间戳 | 毫秒级Unix时间戳 | `1743475200000` |
