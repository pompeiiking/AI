# data-service ↔ order-service 接口契约

> 状态: 草案
> 负责人: [TODO:填充]
> 最后更新: [TODO:填充]
> 实现方: data侧=[开发者/AI], order侧=[开发者/AI]

## 共享类型

```java
// 交货统计数据（data-service聚合计算依赖此数据）
@Data
public class DeliveryStatsVO implements Serializable {
    private Long supplierId;
    private String supplierName;
    private int totalOrders;           // 总订单数
    private int onTimeOrders;         // 准时订单数
    private BigDecimal onTimeRate;    // 准时交付率(%)
    private String period;            // 统计周期 2026-04
}

// 订单基础信息（溯源聚合使用）
@Data
public class OrderBaseVO implements Serializable {
    private Long orderId;
    private String orderNo;
    private Long supplierId;
    private String supplierName;
    private BigDecimal totalAmount;
    private LocalDate orderDate;
    private LocalDate requiredDate;    // 需求日期（五维度-准时交付关键）
    private String status;
    private String statusDesc;
}

// 交货记录（溯源使用）
@Data
public class DeliveryVO implements Serializable {
    private Long deliveryId;
    private String deliveryNo;
    private Long orderId;
    private String logisticsNo;
    private String logisticsCompany;
    private LocalDate shipDate;
    private LocalDate actualDate;      // 实际到货日期
    private String warehouse;
    private String status;
}
```

## 函数接口

### 获取交货统计数据

- **调用方**: data-service（数据分析服务）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @GetMapping("/orders/delivery-stats")
  Result<DeliveryStatsVO> getDeliveryStats(
      @RequestParam("supplierId") Long supplierId,
      @RequestParam("startDate") String startDate,
      @RequestParam("endDate") String endDate
  );
  ```
- **前置条件**: supplierId非空，日期格式为yyyy-MM-dd
- **后置条件**: 返回指定供应商指定周期的交货统计数据
- **错误处理**: 供应商无订单时返回totalOrders=0的默认统计对象

### 查询订单列表（Feign）

- **调用方**: data-service（数据分析服务）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @GetMapping("/orders")
  Result<List<OrderBaseVO>> getOrders(@RequestParam Map<String, Object> params);
  ```
- **前置条件**: params可包含supplierId, status, startDate, endDate等过滤条件
- **后置条件**: 返回符合条件的订单基础信息列表
- **错误处理**: 无匹配订单时返回空列表

### 获取订单详情

- **调用方**: data-service（数据分析服务）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @GetMapping("/orders/{id}")
  Result<OrderDetailVO> getOrderById(@PathVariable("id") Long id);
  ```
- **前置条件**: 订单ID非空
- **后置条件**: 返回订单完整信息（含明细）
- **错误处理**: 订单不存在时抛出 NOT_FOUND 异常

### 获取交货记录列表

- **调用方**: data-service（数据分析服务）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @GetMapping("/orders/{orderId}/deliveries")
  Result<List<DeliveryVO>> getDeliveries(@PathVariable("orderId") Long orderId);
  ```
- **前置条件**: 订单ID非空
- **后置条件**: 返回该订单的所有交货记录
- **错误处理**: 无交货记录时返回空列表

## 约束与边界

- 性能约束：单个供应商统计查询响应时间 < 500ms
- 数据约束：日期范围最大不超过12个月
- order-service必须保证actualDate字段的准确性（五维度准时交付率的计算核心）
