# gateway ↔ order-service 接口契约

> **状态**: 草案
> **负责人**: 成员C
> **最后更新**: 2026-04-01
> **实现方**: gateway侧=成员A, order侧=成员B

## 共享类型

```java
// 订单基础信息
@Data
public class OrderBaseVO implements Serializable {
    private Long orderId;
    private String orderNo;          // 订单编号 PO-YYYYMMDD-XXXX
    private Long supplierId;
    private String supplierName;      // 供应商名称（冗余）
    private String orderType;        // 订单类型：STANDARD/URGENT/FRAMEWORK
    private BigDecimal totalAmount;  // 订单总金额
    private String currency;         // 币种，默认CNY
    private LocalDate requiredDate;  // 需求日期
    private String deliveryAddress;  // 交货地址
    private String status;          // 状态
    private String statusDesc;      // 状态描述
    private LocalDateTime createdAt;
}

// 订单详情
@Data
public class OrderDetailVO implements Serializable {
    private Long orderId;
    private String orderNo;
    private Long supplierId;
    private String supplierName;
    private String orderType;
    private BigDecimal totalAmount;
    private String currency;
    private LocalDate requiredDate;
    private String deliveryAddress;
    private String status;
    private String statusDesc;
    private Long createdBy;
    private String createdByName;
    private Long confirmedBy;
    private String confirmedByName;
    private LocalDateTime confirmedAt;
    private LocalDateTime shippedAt;
    private LocalDateTime completedAt;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private List<OrderItemVO> items;  // 订单明细
}

// 订单明细
@Data
public class OrderItemVO implements Serializable {
    private Long itemId;
    private Long orderId;
    private Integer lineNo;           // 行号
    private String materialCode;     // 物料编码
    private String materialName;     // 物料名称
    private String spec;             // 规格型号
    private String unit;             // 单位
    private BigDecimal quantity;     // 数量
    private BigDecimal price;        // 单价
    private BigDecimal amount;       // 金额
    private BigDecimal budgetPrice;  // 预算单价（价格竞争力参考）
}

// 交货记录
@Data
public class DeliveryVO implements Serializable {
    private Long deliveryId;
    private String deliveryNo;
    private Long orderId;
    private String logisticsNo;      // 物流单号
    private String logisticsCompany; // 物流公司
    private LocalDate shipDate;      // 发货日期
    private LocalDate actualDate;    // 实际到货日期
    private String warehouse;       // 仓库
    private String status;           // SHIPPED/IN_TRANSIT/DELIVERED
    private LocalDateTime createdAt;
}

// 订单列表查询参数
@Data
public class OrderQueryDTO implements Serializable {
    private String keyword;          // 搜索关键词（订单号/供应商名）
    private Long supplierId;         // 供应商ID
    private String status;          // 状态筛选
    private LocalDate startDate;     // 开始日期
    private LocalDate endDate;       // 结束日期
    private Integer pageNum = 1;
    private Integer pageSize = 10;
}

// 订单列表响应
@Data
public class OrderListVO implements Serializable {
    private List<OrderBaseVO> records;
    private long total;
    private long current;
    private long size;
}

// 交货统计
@Data
public class DeliveryStatsVO implements Serializable {
    private Long supplierId;
    private String supplierName;
    private int totalOrders;        // 总订单数
    private int onTimeOrders;       // 准时订单数
    private BigDecimal onTimeRate;   // 准时交付率(%)
    private BigDecimal totalAmount;  // 总金额
    private String period;           // 统计周期 2026-03
}

// 订单创建DTO
@Data
public class OrderCreateDTO implements Serializable {
    private Long supplierId;
    private String orderType;       // STANDARD/URGENT/FRAMEWORK
    private LocalDate requiredDate;
    private String deliveryAddress;
    private List<OrderItemDTO> items;
}

// 订单项DTO
@Data
public class OrderItemDTO implements Serializable {
    private String materialCode;
    private String materialName;
    private String spec;
    private String unit;
    private BigDecimal quantity;
    private BigDecimal price;
    private BigDecimal budgetPrice;
}

// 交货记录创建DTO
@Data
public class DeliveryCreateDTO implements Serializable {
    private String logisticsNo;
    private String logisticsCompany;
    private LocalDate shipDate;
    private LocalDate actualDate;
    private String warehouse;
}
```

## 函数接口

### 查询订单列表

- **调用方**: gateway（API网关透传）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @GetMapping("/orders")
  Result<OrderListVO> listOrders(@RequestParam(required = false) String keyword,
                                  @RequestParam(required = false) Long supplierId,
                                  @RequestParam(required = false) String status,
                                  @RequestParam(required = false) String startDate,
                                  @RequestParam(required = false) String endDate,
                                  @RequestParam(defaultValue = "1") Integer pageNum,
                                  @RequestParam(defaultValue = "10") Integer pageSize);
  ```
- **前端接口**: `GET /api/orders?keyword=xxx&supplierId=1&status=PENDING&pageNum=1&pageSize=10`
- **前置条件**: pageNum >= 1, pageSize > 0
- **后置条件**: 返回符合条件的订单分页列表
- **错误处理**: 参数校验失败返回400

### 获取订单详情

- **调用方**: gateway（API网关透传）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @GetMapping("/orders/{id}")
  Result<OrderDetailVO> getOrderById(@PathVariable("id") Long id);
  ```
- **前端接口**: `GET /api/orders/{id}`
- **前置条件**: id非空且为有效订单ID
- **后置条件**: 返回订单完整信息（含明细）
- **错误处理**: 订单不存在返回404

### 创建订单

- **调用方**: gateway（API网关透传）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @PostMapping("/orders")
  Result<Long> createOrder(@RequestBody @Valid OrderCreateDTO dto);
  ```
- **前端接口**: `POST /api/orders`
- **前置条件**: dto.supplierId非空，dto.items至少有一条明细
- **后置条件**: 创建订单并返回订单ID，订单状态为PENDING
- **错误处理**: 供应商不存在返回404，参数校验失败返回400

### 更新订单

- **调用方**: gateway（API网关透传）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @PutMapping("/orders/{id}")
  Result<Void> updateOrder(@PathVariable("id") Long id,
                           @RequestBody @Valid OrderUpdateDTO dto);
  ```
- **前端接口**: `PUT /api/orders/{id}`
- **前置条件**: id非空，订单存在且状态为PENDING
- **后置条件**: 更新订单信息（仅草稿状态可编辑）
- **错误处理**: 订单不存在返回404，状态不允许编辑返回409

### 更新订单状态

- **调用方**: gateway（API网关透传）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @PutMapping("/orders/{id}/status")
  Result<Void> updateOrderStatus(@PathVariable("id") Long id,
                                 @RequestBody @Valid OrderStatusUpdateDTO dto);
  ```
- **前端接口**: `PUT /api/orders/{id}/status`
- **前置条件**: id非空，dto.status为有效状态值
- **后置条件**: 更新订单状态并记录状态变更日志
- **错误处理**: 状态流转不合法返回409，订单不存在返回404

**状态流转规则**:
```
PENDING → CONFIRMED → IN_PRODUCTION → SHIPPED → DELIVERED → COMPLETED
                ↓           ↓           ↓
            CANCELLED   CANCELLED   CANCELLED
```

### 添加交货记录

- **调用方**: gateway（API网关透传）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @PostMapping("/orders/{id}/deliveries")
  Result<Long> addDelivery(@PathVariable("id") Long orderId,
                            @RequestBody @Valid DeliveryCreateDTO dto);
  ```
- **前端接口**: `POST /api/orders/{id}/deliveries`
- **前置条件**: orderId非空，dto.actualDate非空（到货日期必填）
- **后置条件**: 创建交货记录并返回deliveryId
- **错误处理**: 订单不存在返回404，订单状态不允许添加交货返回409

### 获取订单交货记录列表

- **调用方**: gateway（API网关透传）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @GetMapping("/orders/{id}/deliveries")
  Result<List<DeliveryVO>> getDeliveries(@PathVariable("id") Long orderId);
  ```
- **前端接口**: `GET /api/orders/{id}/deliveries`
- **前置条件**: orderId非空
- **后置条件**: 返回该订单的所有交货记录列表
- **错误处理**: 无交货记录返回空列表

### 获取交货统计

- **调用方**: gateway（API网关透传）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @GetMapping("/orders/delivery-stats")
  Result<DeliveryStatsVO> getDeliveryStats(@RequestParam("supplierId") Long supplierId,
                                            @RequestParam("startDate") String startDate,
                                            @RequestParam("endDate") String endDate);
  ```
- **前端接口**: `GET /api/orders/delivery-stats?supplierId=1&startDate=2026-01-01&endDate=2026-03-31`
- **前置条件**: supplierId非空，日期格式为yyyy-MM-dd
- **后置条件**: 返回指定供应商指定周期的交货统计数据
- **错误处理**: 供应商无订单时返回totalOrders=0的默认统计对象

### 获取订单状态变更日志

- **调用方**: gateway（API网关透传）
- **提供方**: order-service（订单服务）
- **签名**:
  ```java
  @GetMapping("/orders/{id}/status-log")
  Result<List<OrderStatusLogVO>> getStatusLogs(@PathVariable("id") Long orderId);
  ```
- **前端接口**: `GET /api/orders/{id}/status-log`
- **前置条件**: orderId非空
- **后置条件**: 返回该订单的状态变更日志列表
- **错误处理**: 无日志返回空列表

## 约束与边界

- **性能约束**：列表查询响应时间 < 500ms
- **分页约束**：单次查询最大返回100条记录
- **日期格式**：startDate/endDate参数统一使用 `yyyy-MM-dd` 格式
- **金额精度**：金额字段使用BigDecimal，精度为DECIMAL(15,2)
- **状态枚举**：PENDING/CONFIRMED/IN_PRODUCTION/SHIPPED/DELIVERED/COMPLETED/CANCELLED
- **订单类型枚举**：STANDARD（标准）/ URGENT（紧急）/ FRAMEWORK（框架协议）
- **到货日期约束**：actualDate字段必须准确，这是五维度准时交付率计算的核心数据

## 事件接口

### 订单状态变更事件

- **发布方**: order-service
- **订阅方**: supplier-service（记录服务响应）、data-service（聚合计算）
- **事件名**: `order:status-changed`
- **载荷类型**:
  ```java
  @Data
  public class OrderStatusChangedEvent implements Serializable {
      private Long orderId;
      private String orderNo;
      private String fromStatus;
      private String toStatus;
      private Long supplierId;
      private LocalDateTime changedAt;
      private Long operatorId;
  }
  ```
- **触发时机**: 订单状态发生变更时
- **幂等性**: 是 — 订阅方需处理重复事件
