# data-service ↔ supplier-service 接口契约

> 状态: 草案
> 负责人: [TODO:填充]
> 最后更新: [TODO:填充]
> 实现方: data侧=[开发者/AI], supplier侧=[开发者/AI]

## 共享类型

```java
// 供应商基础信息（data-service溯源展示使用）
@Data
public class SupplierBaseVO implements Serializable {
    private Long supplierId;
    private String supplierCode;
    private String supplierName;
    private String categoryName;
    private String status;
    private String statusDesc;
}

// 供应商评分（data-service五维度存储使用）
@Data
public class SupplierScoreVO implements Serializable {
    private Long supplierId;
    private String supplierName;
    private BigDecimal totalScore;      // 综合评分(0-100)
    private BigDecimal onTimeRate;       // 准时交付率
    private BigDecimal qualityScore;     // 质量合格率
    private BigDecimal priceScore;       // 价格竞争力
    private BigDecimal responseScore;    // 服务响应
    private BigDecimal reformScore;      // 整改配合
    private String evalLevel;            // EXCELLENT/GOOD/AVERAGE/POOR
    private String period;               // 评估周期
    private LocalDateTime calcDate;
}

// 服务响应记录（data-service服务响应维度计算）
@Data
public class ResponseLogVO implements Serializable {
    private Long logId;
    private Long supplierId;
    private Long orderId;
    private String responseType;         // QUOTE/ORDER_CONFIRM/SAMPLE/DELIVERY
    private int responseTimeHours;       // 响应时间(小时)
    private String cooperationLevel;     // GOOD/NORMAL/POOR
    private LocalDateTime createdAt;
}
```

## 函数接口

### 获取供应商基础信息

- **调用方**: data-service（数据分析服务）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @GetMapping("/suppliers/{id}")
  Result<SupplierBaseVO> getSupplierById(@PathVariable("id") Long id);
  ```
- **前置条件**: 供应商ID非空
- **后置条件**: 返回供应商基础信息
- **错误处理**: 供应商不存在时抛出 NOT_FOUND 异常

### 查询供应商评分

- **调用方**: data-service（数据分析服务）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @GetMapping("/suppliers/{id}/score")
  Result<SupplierScoreVO> getSupplierScore(
      @PathVariable("id") Long supplierId,
      @RequestParam(value = "period", required = false) String period
  );
  ```
- **前置条件**: supplierId非空，period可选（不传则返回最新）
- **后置条件**: 返回供应商评分信息
- **错误处理**: 无评分记录时返回totalScore=0的默认对象

### 查询服务响应记录

- **调用方**: data-service（数据分析服务）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @GetMapping("/suppliers/{id}/response-log")
  Result<List<ResponseLogVO>> getResponseLogs(
      @PathVariable("id") Long supplierId,
      @RequestParam("period") String period
  );
  ```
- **前置条件**: supplierId非空，period格式为yyyy-MM
- **后置条件**: 返回指定周期内的服务响应记录列表
- **错误处理**: 无记录时返回空列表

### 记录服务响应（内部）

- **调用方**: order-service（订单服务）
- **提供方**: supplier-service（供应商服务）
- **签名**:
  ```java
  @PostMapping("/suppliers/{id}/response-log")
  Result<Void> recordResponseLog(
      @PathVariable("id") Long supplierId,
      @RequestBody ResponseLogDTO dto
  );
  ```
- **前置条件**: dto包含responseType和responseTimeHours
- **后置条件**: 创建响应记录
- **错误处理**: 参数校验失败返回400

## 约束与边界

- 性能约束：评分查询响应时间 < 300ms（带缓存）
- supplier-service负责维护supplier_score表的评分数据
- data-service负责维护data_db中的supplier_evaluation（五维度聚合结果）
- 两者的区别：supplier_score是原始评分，supplier_evaluation是聚合后的评估报告
