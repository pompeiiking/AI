# gateway ↔ auth-service 接口契约

> 状态: 草案
> 负责人: [TODO:填充]
> 最后更新: [TODO:填充]
> 实现方: gateway侧=[开发者/AI], auth侧=[开发者/AI]

## 共享类型

```java
// 登录请求
@Data
public class LoginRequest implements Serializable {
    private String username;
    private String password;
}

// 登录响应
@Data
public class LoginResponse implements Serializable {
    private String token;
    private String tokenType = "Bearer";
    private long expiresIn;              // 有效期(秒)
    private UserInfoVO userInfo;
}

// 用户信息
@Data
public class UserInfoVO implements Serializable {
    private Long userId;
    private String username;
    private String realName;
    private String email;
    private String phone;
    private List<String> roles;
    private List<String> permissions;
}

// Token验证响应
@Data
public class TokenValidateResponse implements Serializable {
    private boolean valid;
    private Long userId;
    private String username;
    private List<String> roles;
}
```

## 函数接口

### 登录

- **调用方**: gateway（API网关）或前端
- **提供方**: auth-service（认证服务）
- **签名**:
  ```java
  @PostMapping("/auth/login")
  Result<LoginResponse> login(@RequestBody @Valid LoginRequest request);
  ```
- **前置条件**: username和password非空
- **后置条件**: 返回JWT Token和用户信息
- **错误处理**: 用户名密码错误返回401

### 验证Token（网关内部调用）

- **调用方**: gateway（API网关）
- **提供方**: auth-service（认证服务）
- **签名**:
  ```java
  @GetMapping("/auth/validate")
  Result<TokenValidateResponse> validateToken(@RequestHeader("Authorization") String token);
  ```
- **前置条件**: 请求头包含Authorization
- **后置条件**: 返回Token验证结果（valid=true/false）
- **错误处理**: Token无效或过期返回valid=false

### 获取当前用户信息

- **调用方**: gateway透传或前端
- **提供方**: auth-service（认证服务）
- **签名**:
  ```java
  @GetMapping("/auth/userinfo")
  Result<UserInfoVO> getUserInfo(@RequestHeader("Authorization") String token);
  ```
- **前置条件**: 请求头包含有效Token
- **后置条件**: 返回当前登录用户信息
- **错误处理**: Token无效返回401

### 刷新Token

- **调用方**: 前端
- **提供方**: auth-service（认证服务）
- **签名**:
  ```java
  @PostMapping("/auth/refresh")
  Result<LoginResponse> refreshToken(@RequestHeader("Authorization") String token);
  ```
- **前置条件**: 请求头包含有效Token
- **后置条件**: 返回新的JWT Token
- **错误处理**: Token无效返回401

## 约束与边界

- JWT Token有效期：默认2小时（可配置）
- Refresh Token有效期：默认7天（可配置）
- gateway必须将Token透传给下游服务（通过请求头）
- gateway缓存Token验证结果（TTL=Token剩余有效期，最大1小时）
