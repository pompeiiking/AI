# agent_webserver 项目结构声明文档

## 一、项目概述

| 属性 | 内容 |
|------|------|
| 项目名称 | agent_webserver |
| 项目类型 | 企业级前后分离物资管理系统（Java微服务 + Vue3前端） |
| 业务定位 | 企业物资管理 + 供应商分析 |
| 核心目标 | 实现需求计划全链路跟踪 + 供应商最优解推荐 |
| 服务对象 | 采购组织 |

---

## 二、顶层目录结构

```
agent_webserver/                              # 项目根目录（完整开发工作区）
│
├── agent_webserver/                          # 项目源码（Java后端 + Vue前端）
│   │
│   ├── pom.xml                              # Maven 父工程 POM
│   ├── .gitignore
│   │
│   ├── project-common/                       # 公共模块（被所有服务依赖）
│   │   ├── pom.xml
│   │   ├── common-core/                     # 核心工具类：Result封装、异常定义、常量
│   │   ├── common-feign/                    # Feign 客户端：声明式 HTTP 调用代理
│   │   └── common-swagger/                  # Swagger 配置：API 文档聚合
│   │
│   ├── project-gateway/                      # API 网关（认证鉴权、路由、限流熔断）
│   │   └── pom.xml
│   │
│   └── project-service/                      # 业务服务模块
│       ├── pom.xml
│       ├── service-auth/                    # 认证服务（8081）：用户、角色、权限、JWT
│       ├── service-supplier/                 # 供应商服务（8082）：供应商档案、评分、响应记录
│       ├── service-order/                   # 订单服务（8083）：采购订单、交货记录
│       └── service-data/                     # 数据分析服务（8092）：供应评估、仪表盘、溯源聚合
│
├── airules/                                  # AI 开发规范规则（从 AI-context 提取）
│   │
│   ├── RULES.md                             # 主规范文件
│   ├── STATUS.md                            # 项目状态快照
│   ├── CHANGELOG.md                         # 变更日志
│   ├── TEAM.md                              # 团队开发边界
│   │
│   ├── contracts/                           # 接口契约文档
│   │   ├── _index.md                        # 契约索引
│   │   ├── shared-types.contract.md         # 全局共享类型
│   │   ├── gateway-auth.contract.md         # 网关-认证服务契约
│   │   ├── gateway-supplier.contract.md     # 网关-供应商服务契约
│   │   ├── gateway-order.contract.md        # 网关-订单服务契约
│   │   ├── gateway-data.contract.md         # 网关-数据服务契约
│   │   ├── data-supplier.contract.md        # 数据服务-供应商服务契约
│   │   ├── data-order.contract.md           # 数据服务-订单服务契约
│   │   └── _template.contract.md            # 契约模板
│   │
│   └── skills/                              # 技能规则
│       ├── principles/                       # 设计原则
│       │   ├── abstraction.md                # 抽象原则
│       │   ├── data-separation.md            # 数据分离原则
│       │   ├── module-boundary.md            # 模块边界
│       │   ├── layering.md                   # 分层原则
│       │   ├── naming.md                     # 命名规范
│       │   ├── comments.md                   # 注释规范
│       │   ├── error-handling.md             # 错误处理
│       │   ├── type-safety.md               # 类型安全
│       │   ├── zero-hardcoding.md           # 零硬编码
│       │   ├── performance.md               # 性能原则
│       │   └── stub-management.md           # Stub 管理
│       │
│       ├── project/                          # 项目规范
│       │   ├── file-structure.md            # 文件结构规范
│       │   └── code-style.md                # 代码风格规范
│       │
│       ├── workflow/                         # 工作流程
│       │   ├── git-commit.md                # Git 提交规范
│       │   ├── interface-contract.md         # 接口契约流程
│       │   ├── interface-change.md          # 接口变更流程
│       │   ├── changelog.md                  # 变更日志流程
│       │   ├── status-management.md         # 状态管理流程
│       │   ├── collaboration.md             # 协作流程
│       │   ├── anti-paranoid.md              # 反偏执流程
│       │   ├── session-handoff.md           # 会话交接流程
│       │   ├── testing.md                   # 测试流程
│       │   └── security.md                  # 安全规范
│       │
│       └── team/                             # 团队分工边界
│           ├── team-development-boundary.md  # 团队开发边界总览
│           ├── member-a-gateway-frontend.md   # 前端&网关开发规范
│           ├── member-b-microservices.md      # 微服务开发规范
│           └── member-c-architecture-dba.md  # 架构&DBA 开发规范
│
├── design/                                   # 设计文档
│   │
│   ├── 业务逻辑/
│   │   └── 文稿/
│   │       └── 业务逻辑分析.txt              # 业务逻辑分析文档
│   │
│   └── 文稿/
│       └── 架构设计书_华油物资管理.md         # 架构设计书
│
└── PROJECT_STRUCTURE.md                     # 本文档（项目结构层级声明）
```

---

## 三、业务服务详细结构

### 3.1 服务总览

| 服务 | 端口 | 主要职责 |
|------|------|----------|
| project-gateway | - | API 网关：路由、认证鉴权、限流熔断 |
| service-auth | 8081 | 认证服务：用户、角色、权限、JWT |
| service-supplier | 8082 | 供应商服务：供应商档案、评分、响应记录 |
| service-order | 8083 | 订单服务：采购订单、交货记录 |
| service-data | 8092 | 数据分析服务：供应评估、仪表盘、溯源聚合 |

### 3.2 通用服务内部结构（以 service-xxx 为例）

```
service-xxx/
├── pom.xml
└── src/main/
    ├── java/com/huayou/service/xxx/
    │   ├── XxxApplication.java               # Spring Boot 启动类
    │   ├── config/                           # 配置类
    │   ├── controller/                       # REST 控制器
    │   │   └── XxxController.java
    │   ├── service/                         # 业务逻辑层
    │   │   ├── impl/
    │   │   │   └── XxxServiceImpl.java
    │   │   └── XxxService.java
    │   ├── repository/                      # MyBatis-Plus Mapper
    │   │   └── XxxMapper.java
    │   ├── entity/                          # 数据库实体 DO
    │   │   └── Xxx.java
    │   ├── vo/                              # 视图对象（返回前端）
    │   │   ├── XxxVO.java
    │   │   └── XxxDetailVO.java
    │   ├── dto/                             # 数据传输对象（请求参数）
    │   │   ├── CreateXxxDTO.java
    │   │   └── UpdateXxxDTO.java
    │   ├── query/                           # 查询参数（分页/过滤）
    │   │   └── XxxQuery.java
    │   ├── enums/                           # 枚举类
    │   │   └── XxxStatus.java
    │   ├── constant/                        # 模块常量
    │   │   └── XxxConstant.java
    │   └── exception/                       # 自定义异常
    │       ├── XxxNotFoundException.java
    │       └── XxxErrorCode.java
    └── resources/
        ├── application.yml                  # 主配置
        ├── application-dev.yml               # 开发环境
        ├── application-prod.yml              # 生产环境
        └── mapper/                           # MyBatis XML 映射
            └── XxxMapper.xml
```

### 3.3 网关内部结构

```
project-gateway/
├── pom.xml
└── src/main/
    ├── java/com/huayou/gateway/
    │   ├── GatewayApplication.java
    │   ├── config/                           # 网关配置（路由、CORS）
    │   └── filter/                           # 网关过滤器（认证、日志追踪）
    └── resources/
        └── application.yml                   # 网关路由配置
```

---

## 四、业务功能模块

### 4.1 供应商分析模块（service-supplier）

| 功能 | 说明 |
|------|------|
| 供应商档案管理 | 根据编码、名称、采购员、资质等分类管理供应商 |
| 交货及时率评分 | 根据采购订单的交货日期和实际交货日期计算 |
| 价格竞争力评分 | 根据同类物料的供应商价格对比（含税率、运费） |
| 供货质量评分 | 合格率计算 |

### 4.2 需求计划全链路（service-order）

| 阶段 | 说明 |
|------|------|
| 需求计划生成 | 根据画像 + 供应商评分，推荐最优供应商 |
| 采购订单生成 | 根据需求计划生成采购订单 |
| 采购订单执行 | 执行采购订单 |
| 采购订单完成 | 完成采购订单 |

### 4.3 数据分析模块（service-data）

| 功能 | 说明 |
|------|------|
| 供应评估 | 综合分析供应商表现 |
| 仪表盘 | 数据可视化展示 |
| 溯源聚合 | 采购全流程追溯 |

### 4.4 认证模块（service-auth）

| 功能 | 说明 |
|------|------|
| 用户管理 | 用户 CRUD |
| 角色权限 | RBAC 权限控制 |
| JWT 认证 | 令牌签发与验证 |

---

## 五、技术栈

| 层级 | 技术 |
|------|------|
| 后端框架 | Spring Boot + Spring Cloud |
| 服务通信 | OpenFeign |
| 数据库访问 | MyBatis-Plus |
| API 文档 | Swagger |
| 前端框架 | Vue 3 |
| 构建工具 | Maven |

---

## 六、模块依赖关系

```
service-auth          → project-common
service-supplier     → project-common
service-order        → project-common
service-data         → project-common
project-gateway      → project-common
```
